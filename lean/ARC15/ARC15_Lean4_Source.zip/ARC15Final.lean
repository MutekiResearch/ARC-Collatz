import Mathlib
import ARC.ARC15Stage5K_PositiveRigidity

set_option autoImplicit false

universe u

namespace ARC

/-!
# ARC15Final

Final entry point for the ARC₁₅ formalization.

All technical lemmas and intermediate stages are imported transitively
through `ARC15Stage5K_PositiveRigidity`.

The theorem states:

If a sequence `a : ℕ → α`

1. is invariant under the shortcut Collatz map, and
2. has finite base-15 kernel,

then `a` is constant on all positive natural numbers.

No assertion is made about `a 0`.
-/

/-!
============================================================
1. Final ARC₁₅ theorem
============================================================
-/

/--
Final ARC₁₅ rigidity theorem.

A base-15 finite-kernel sequence invariant under the shortcut Collatz map
is constant on `ℕ_{>0}`.
-/
theorem arc15_final
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha15 :
      ARCAutomaticByKernel 15 a) :
    ∃ c : α,
      ∀ n : ℕ,
        0 < n →
        a n = c := by

  exact
    arc15_stage5K_positive_rigidity
      a
      hinv
      ha15

/-!
============================================================
2. Equivalent pairwise form
============================================================
-/

/--
Equivalent form of `arc15_final`:
all positive inputs receive the same value.
-/
theorem arc15_final_pairwise
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha15 :
      ARCAutomaticByKernel 15 a) :
    ∀ m n : ℕ,
      0 < m →
      0 < n →
      a m = a n := by

  exact
    arc15_positive_pairwise_equal
      a
      hinv
      ha15

/-!
============================================================
3. Axiom audit
============================================================
-/

#print axioms arc15_final
#print axioms arc15_final_pairwise

end ARC

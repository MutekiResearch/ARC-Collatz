import Mathlib
import ARC.ARC15Stage5G_TopologicalPumpingClosure

set_option autoImplicit false

universe u

namespace ARC

noncomputable def ARC15DisagreeIndicator
    {α : Type u}
    (v w : ℕ → α) :
    ℕ → Bool := by
  classical
  exact fun n => if v n = w n then false else true

theorem arc15_disagreeIndicator_true_iff
    {α : Type u}
    (v w : ℕ → α)
    (n : ℕ) :
    ARC15DisagreeIndicator v w n = true ↔ v n ≠ w n := by
  classical
  simp [ARC15DisagreeIndicator]

def ARC15ChangeSet
    {α : Type u}
    (a : ℕ → α) :
    Set ℕ :=
  {n | a n ≠ a (n + 1)}

noncomputable def ARC15ChangeIndicator
    {α : Type u}
    (a : ℕ → α) :
    ℕ → Bool :=
  ARC15DisagreeIndicator a (fun n => a (n + 1))

theorem arc15_changeIndicator_true_iff
    {α : Type u}
    (a : ℕ → α)
    (n : ℕ) :
    ARC15ChangeIndicator a n = true ↔ n ∈ ARC15ChangeSet a := by
  unfold ARC15ChangeIndicator ARC15ChangeSet
  exact arc15_disagreeIndicator_true_iff a (fun n => a (n + 1)) n

theorem arc15_boolSupport_changeIndicator
    {α : Type u}
    (a : ℕ → α) :
    ARC15BoolSupport (ARC15ChangeIndicator a) = ARC15ChangeSet a := by
  ext n
  change ARC15ChangeIndicator a n = true ↔ n ∈ ARC15ChangeSet a
  exact arc15_changeIndicator_true_iff a n

def ARC15SuccState
    {α : Type u}
    (v : ℕ → α) :
    ℕ → α :=
  fun n => v (n + 1)

def ARC15SuccKernelFamily
    {α : Type u}
    (a : ℕ → α) :
    Set (ℕ → α) :=
  ARC15SuccState '' (ARCKernel 15 a)

def ARC15KernelOrSuccFamily
    {α : Type u}
    (a : ℕ → α) :
    Set (ℕ → α) :=
  (ARCKernel 15 a) ∪ ARC15SuccKernelFamily a

theorem arc15_succKernelFamily_finite
    {α : Type u}
    (a : ℕ → α)
    (hfinite : (ARCKernel 15 a).Finite) :
    (ARC15SuccKernelFamily a).Finite := by
  unfold ARC15SuccKernelFamily
  exact hfinite.image ARC15SuccState

theorem arc15_kernelOrSuccFamily_finite
    {α : Type u}
    (a : ℕ → α)
    (hfinite : (ARCKernel 15 a).Finite) :
    (ARC15KernelOrSuccFamily a).Finite := by
  unfold ARC15KernelOrSuccFamily
  exact
    hfinite.union
      (arc15_succKernelFamily_finite a hfinite)

def ARC15ChangeComparisonFamily
    {α : Type u}
    (a : ℕ → α) :
    Set (ℕ → Bool) :=
  Set.image2
    (fun x y : ℕ → α => ARC15DisagreeIndicator x y)
    (ARCKernel 15 a)
    (ARC15KernelOrSuccFamily a)

theorem arc15_changeComparisonFamily_finite
    {α : Type u}
    (a : ℕ → α)
    (hfinite : (ARCKernel 15 a).Finite) :
    (ARC15ChangeComparisonFamily a).Finite := by
  unfold ARC15ChangeComparisonFamily
  exact
    Set.Finite.image2
      (fun x y : ℕ → α => ARC15DisagreeIndicator x y)
      hfinite
      (arc15_kernelOrSuccFamily_finite a hfinite)

theorem arc15_changeIndicator_kernel_subset_family
    {α : Type u}
    (a : ℕ → α) :
    ARCKernel 15 (ARC15ChangeIndicator a)
      ⊆
    ARC15ChangeComparisonFamily a := by

  intro u hu

  change
    ∃ e r : ℕ,
      r < 15 ^ e ∧
      ∀ n : ℕ,
        u n =
          ARC15ChangeIndicator a (15 ^ e * n + r)
    at hu

  rcases hu with ⟨e, r, hr, huEq⟩

  let x : ℕ → α :=
    fun n => a (15 ^ e * n + r)

  let y : ℕ → α :=
    fun n => a (15 ^ e * n + r + 1)

  have hx : x ∈ ARCKernel 15 a := by
    change
      ∃ E R : ℕ,
        R < 15 ^ E ∧
        ∀ n : ℕ,
          x n = a (15 ^ E * n + R)
    refine ⟨e, r, hr, ?_⟩
    intro n
    rfl

  have hy : y ∈ ARC15KernelOrSuccFamily a := by
    unfold ARC15KernelOrSuccFamily

    by_cases hnext : r + 1 < 15 ^ e
    · left
      change
        ∃ E R : ℕ,
          R < 15 ^ E ∧
          ∀ n : ℕ,
            y n = a (15 ^ E * n + R)
      refine ⟨e, r + 1, hnext, ?_⟩
      intro n
      dsimp [y]
      congr 1
    · right
      have hedge : r + 1 = 15 ^ e := by
        have hpowpos : 0 < 15 ^ e := by
          positivity
        omega

      let z : ℕ → α :=
        fun n => a (15 ^ e * n)

      have hz : z ∈ ARCKernel 15 a := by
        change
          ∃ E R : ℕ,
            R < 15 ^ E ∧
            ∀ n : ℕ,
              z n = a (15 ^ E * n + R)
        refine ⟨e, 0, ?_, ?_⟩
        · positivity
        · intro n
          simp [z]

      unfold ARC15SuccKernelFamily
      refine ⟨z, hz, ?_⟩

      funext n
      dsimp [ARC15SuccState, y, z]
      congr 1

      calc
        15 ^ e * (n + 1) = 15 ^ e * n + 15 ^ e := by ring
        _ = 15 ^ e * n + (r + 1) := by rw [hedge]
        _ = 15 ^ e * n + r + 1 := by omega

  unfold ARC15ChangeComparisonFamily

  refine ⟨x, hx, y, hy, ?_⟩

  funext n

  have h := huEq n

  simpa
    [ARC15ChangeIndicator,
     ARC15SuccState,
     x,
     y,
     ARC15DisagreeIndicator]
    using h.symm

theorem arc15_changeIndicator_kernel_finite
    {α : Type u}
    (a : ℕ → α)
    (hfinite : (ARCKernel 15 a).Finite) :
    (ARCKernel 15 (ARC15ChangeIndicator a)).Finite := by
  exact
    (arc15_changeComparisonFamily_finite a hfinite).subset
      (arc15_changeIndicator_kernel_subset_family a)

theorem arc15_changeIndicator_automatic
    {α : Type u}
    (a : ℕ → α)
    (ha15 : ARCAutomaticByKernel 15 a) :
    ARCAutomaticByKernel 15 (ARC15ChangeIndicator a) := by
  unfold ARCAutomaticByKernel at ha15 ⊢
  exact arc15_changeIndicator_kernel_finite a ha15

theorem arc15_changeSet_finite_of_nowhereThick
    {α : Type u}
    (a : ℕ → α)
    (ha15 : ARCAutomaticByKernel 15 a)
    (hthin :
      ARC15DyadicallyNowhereThick (ARC15ChangeSet a)) :
    (ARC15ChangeSet a).Finite := by

  have hAuto :
      ARCAutomaticByKernel 15 (ARC15ChangeIndicator a) :=
    arc15_changeIndicator_automatic a ha15

  have hSupportEq :
      ARC15BoolSupport (ARC15ChangeIndicator a)
        =
      ARC15ChangeSet a :=
    arc15_boolSupport_changeIndicator a

  have hThinSupport :
      ARC15DyadicallyNowhereThick
        (ARC15BoolSupport (ARC15ChangeIndicator a)) := by
    simpa [hSupportEq] using hthin

  have hFiniteSupport :
      (ARC15BoolSupport (ARC15ChangeIndicator a)).Finite :=
    arc15_stage5G_topological_pumping_principle
      (ARC15ChangeIndicator a)
      hAuto
      hThinSupport

  simpa [hSupportEq] using hFiniteSupport

theorem arc15_stage5H_change_automaticity
    {α : Type u}
    (a : ℕ → α)
    (ha15 : ARCAutomaticByKernel 15 a) :
    ARCAutomaticByKernel 15 (ARC15ChangeIndicator a)
      ∧
    ARC15BoolSupport (ARC15ChangeIndicator a)
      =
    ARC15ChangeSet a := by
  constructor
  · exact arc15_changeIndicator_automatic a ha15
  · exact arc15_boolSupport_changeIndicator a

#print axioms arc15_disagreeIndicator_true_iff
#print axioms arc15_changeIndicator_true_iff
#print axioms arc15_boolSupport_changeIndicator
#print axioms arc15_succKernelFamily_finite
#print axioms arc15_kernelOrSuccFamily_finite
#print axioms arc15_changeComparisonFamily_finite
#print axioms arc15_changeIndicator_kernel_subset_family
#print axioms arc15_changeIndicator_kernel_finite
#print axioms arc15_changeIndicator_automatic
#print axioms arc15_changeSet_finite_of_nowhereThick
#print axioms arc15_stage5H_change_automaticity

end ARC

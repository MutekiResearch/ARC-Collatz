import Mathlib
import Mathlib.Order.Interval.Finset.Basic
import ARC.ARC15Stage5E_ExactDyadicPumpHandoff

set_option autoImplicit false

namespace ARC

/-!
============================================================
ARC₁₅ Stage 5F
Infinite support produces a long canonical base-15 support word
============================================================

Stage 5E reduced the ARC₁₅ topological pumping argument to one
remaining bridge:

    infinite Boolean support
      ->
    sufficiently long positive canonical base-15 support word.

For positive `n`, we construct its canonical MSD base-15 word from
`Nat.digits 15 n`, reversed and coerced digitwise to `Fin 15`.

Combining the long-word construction with Stage 5E yields:

    finite-state base-15 MSD presentation
      +
    dyadically nowhere-thick support
      ->
    finite support.
-/

/-!
============================================================
1. Canonical base-15 word attached to a natural number
============================================================
-/

/--
Total coercion of a natural number to a base-15 digit.
-/
def ARC15FinDigit
    (d : ℕ) :
    Fin 15 :=
  ⟨
    d % 15,
    Nat.mod_lt d (by norm_num)
  ⟩

/--
Canonical MSD base-15 word of `n`.
-/
def ARC15CanonicalWordOfNat
    (n : ℕ) :
    List (Fin 15) :=
  (Nat.digits 15 n).reverse.map ARC15FinDigit

/-!
============================================================
2. The canonical word decodes to the original number
============================================================
-/

/--
On genuine base-15 digits, `ARC15FinDigit` preserves the digit value.
-/
theorem arc15_finDigit_val_of_lt
    {d : ℕ}
    (hd :
      d < 15) :
    (ARC15FinDigit d).val = d := by

  simp
    [ARC15FinDigit,
     Nat.mod_eq_of_lt hd]

/--
The digit-value list underlying the canonical word is exactly
`Nat.digits 15 n`.
-/
theorem arc15_canonicalWordOfNat_digit_values
    (n : ℕ) :
    (
      (ARC15CanonicalWordOfNat n).reverse.map
        (fun d : Fin 15 => d.val)
    )
      =
    Nat.digits 15 n := by

  unfold ARC15CanonicalWordOfNat

  simp only
    [List.map_reverse,
     List.reverse_reverse,
     List.map_map]

  calc
    List.map
        ((fun d : Fin 15 => d.val) ∘ ARC15FinDigit)
        (Nat.digits 15 n)
      =
    List.map
        (fun d : ℕ => d)
        (Nat.digits 15 n) := by

      apply
        List.map_congr_left

      intro d hd

      simpa only [Function.comp_apply] using
        arc15_finDigit_val_of_lt
          (
            Nat.digits_lt_base
              (by norm_num : 1 < (15 : ℕ))
              hd
          )

    _ =
    Nat.digits 15 n := by
      simp

/--
The canonical base-15 MSD word decodes exactly to `n`.
-/
theorem arc15_canonicalWordOfNat_value
    (n : ℕ) :
    ARC15MSDValue
        (ARC15CanonicalWordOfNat n)
      =
    n := by

  unfold ARC15MSDValue

  rw
    [arc15_canonicalWordOfNat_digit_values]

  exact
    Nat.ofDigits_digits
      15
      n

/-!
============================================================
3. Positivity / canonical leading digit
============================================================
-/

/--
For positive `n`, the canonical base-15 MSD word has a nonzero leading digit.
-/
theorem arc15_canonicalWordOfNat_positive
    {n : ℕ}
    (hn :
      0 < n) :
    ARC15CanonicalPositiveMSDWord
      (ARC15CanonicalWordOfNat n) := by

  have hn0 :
      n ≠ 0 := by
    omega

  have hdigitsNe :
      Nat.digits 15 n ≠ [] :=
    (
      Nat.digits_ne_nil_iff_ne_zero
    ).2
      hn0

  have hrevNe :
      (Nat.digits 15 n).reverse ≠ [] := by
    simpa using hdigitsNe

  cases hrev :
      (Nat.digits 15 n).reverse with

  | nil =>

      exact
        (hrevNe hrev).elim

  | cons d ds =>

      refine
        ⟨ARC15FinDigit d,
         ds.map ARC15FinDigit,
         ?_,
         ?_⟩

      · unfold ARC15CanonicalWordOfNat

        rw [hrev]

        rfl

      · have hdLast :
            d
              =
            (Nat.digits 15 n).getLast
              hdigitsNe := by

          have hhead :=
            List.head_reverse
              hrevNe

          simpa [hrev] using hhead

        have hlastNe :
            (Nat.digits 15 n).getLast
                hdigitsNe
              ≠
            0 :=
          Nat.getLast_digit_ne_zero
            15
            hn0

        have hdNe :
            d ≠ 0 := by

          intro hd0

          apply hlastNe

          rw [← hdLast, hd0]

        have hdMem :
            d
              ∈
            Nat.digits 15 n := by

          rw [hdLast]

          exact
            List.getLast_mem
              hdigitsNe

        have hdLt :
            d < 15 :=
          Nat.digits_lt_base
            (by norm_num : 1 < (15 : ℕ))
            hdMem

        change
          0 < d % 15

        rw
          [Nat.mod_eq_of_lt hdLt]

        omega

/-!
============================================================
4. Length control
============================================================
-/

/--
The canonical MSD word has exactly the ordinary base-15 digit length.
-/
theorem arc15_canonicalWordOfNat_length
    (n : ℕ) :
    (ARC15CanonicalWordOfNat n).length
      =
    (Nat.digits 15 n).length := by

  simp
    [ARC15CanonicalWordOfNat]

/--
If `15^Q ≤ n`, then the canonical base-15 word of `n`
has length at least `Q`.
-/
theorem arc15_canonicalWordOfNat_length_ge
    (Q n : ℕ)
    (hn :
      15 ^ Q ≤ n) :
    Q
      ≤
    (ARC15CanonicalWordOfNat n).length := by

  have hlen :
      Q
        <
      (Nat.digits 15 n).length :=

    (
      Nat.lt_digits_length_iff
        (b := 15)
        (k := Q)
        (by norm_num : 1 < (15 : ℕ))
        n
    ).2
      hn

  rw
    [arc15_canonicalWordOfNat_length]

  omega

/-!
============================================================
5. Infinite support gives an arbitrarily long canonical support word
============================================================
-/

/--
An infinite Boolean base-15 support contains a positive canonical
support word of arbitrarily prescribed minimum length.
-/
theorem arc15_infinite_support_has_long_canonical_word
    (sseq : ℕ → Bool)
    (Q : ℕ)
    (hinf :
      (ARC15BoolSupport sseq).Infinite) :
    ∃ x : List (Fin 15),
      ARC15CanonicalPositiveMSDWord x
        ∧
      ARC15MSDValue x
        ∈
      ARC15BoolSupport sseq
        ∧
      Q ≤ x.length := by

  rcases
    hinf.exists_gt
      (15 ^ Q) with
    ⟨n,
     hnSupport,
     hnLarge⟩

  have hnPowPos :
      0 < 15 ^ Q :=
    pow_pos
      (by norm_num : 0 < (15 : ℕ))
      Q

  have hnPos :
      0 < n := by
    omega

  have hnPow :
      15 ^ Q ≤ n := by
    omega

  refine
    ⟨ARC15CanonicalWordOfNat n,
     arc15_canonicalWordOfNat_positive hnPos,
     ?_,
     arc15_canonicalWordOfNat_length_ge
       Q
       n
       hnPow⟩

  simpa
    [arc15_canonicalWordOfNat_value]
    using hnSupport

/-!
============================================================
6. Infinite MSD-automatic support cannot be nowhere-thick
============================================================
-/

/--
If a finite base-15 MSD-DFAO presentation has infinite support,
then the support is not dyadically nowhere-thick.
-/
theorem arc15_infinite_msd_support_not_nowhereThick
    (M : ARCMSDDFAO 15 Bool)
    [Fintype M.State]
    (sseq : ℕ → Bool)
    (hM :
      ARCMSDDFAO.Generates M sseq)
    (hinf :
      (ARC15BoolSupport sseq).Infinite) :
    ¬
      ARC15DyadicallyNowhereThick
        (ARC15BoolSupport sseq) := by

  rcases
    arc15_infinite_support_has_long_canonical_word
      sseq
      (Fintype.card M.State)
      hinf with
    ⟨x,
     hxCanonical,
     hxSupport,
     hxLength⟩

  exact
    arc15_stage5E_long_word_collision
      M
      sseq
      hM
      x
      hxCanonical
      hxSupport
      hxLength

/-!
============================================================
7. MSD-DFAO topological pumping theorem
============================================================
-/

/--
A Boolean sequence generated by a finite base-15 MSD automaton whose
support is dyadically nowhere-thick has finite support.
-/
theorem arc15_msd_nowhereThick_support_finite
    (M : ARCMSDDFAO 15 Bool)
    [Fintype M.State]
    (sseq : ℕ → Bool)
    (hM :
      ARCMSDDFAO.Generates M sseq)
    (hthin :
      ARC15DyadicallyNowhereThick
        (ARC15BoolSupport sseq)) :
    (ARC15BoolSupport sseq).Finite := by

  by_contra hfinite

  have hinf :
      (ARC15BoolSupport sseq).Infinite :=
    (Set.not_finite).mp
      hfinite

  have hnotThin :
      ¬
      ARC15DyadicallyNowhereThick
        (ARC15BoolSupport sseq) :=

    arc15_infinite_msd_support_not_nowhereThick
      M
      sseq
      hM
      hinf

  exact
    hnotThin
      hthin

/-!
============================================================
8. Stage-5F handoff
============================================================
-/

/--
Stage-5F final handoff at the explicit MSD-DFAO level.
-/
theorem arc15_stage5F_msd_topological_pumping
    (M : ARCMSDDFAO 15 Bool)
    [Fintype M.State]
    (sseq : ℕ → Bool)
    (hM :
      ARCMSDDFAO.Generates M sseq)
    (hthin :
      ARC15DyadicallyNowhereThick
        (ARC15BoolSupport sseq)) :
    (ARC15BoolSupport sseq).Finite := by

  exact
    arc15_msd_nowhereThick_support_finite
      M
      sseq
      hM
      hthin

#print axioms arc15_finDigit_val_of_lt
#print axioms arc15_canonicalWordOfNat_digit_values
#print axioms arc15_canonicalWordOfNat_value
#print axioms arc15_canonicalWordOfNat_positive
#print axioms arc15_canonicalWordOfNat_length
#print axioms arc15_canonicalWordOfNat_length_ge
#print axioms arc15_infinite_support_has_long_canonical_word
#print axioms arc15_infinite_msd_support_not_nowhereThick
#print axioms arc15_msd_nowhereThick_support_finite
#print axioms arc15_stage5F_msd_topological_pumping

end ARC

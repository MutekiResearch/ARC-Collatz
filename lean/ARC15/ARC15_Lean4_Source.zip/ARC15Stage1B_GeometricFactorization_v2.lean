import ARC.ARC15Stage1A_TwoAdicSetup

open scoped BigOperators

namespace ARC

/--
The recursive ARC₁₅ pumping sum agrees with the ordinary
finite geometric sum.
-/
theorem arc15G_eq_geomSum (L d : ℕ) :
    arc15G L d =
      ∑ i ∈ Finset.range d, arc15Q L ^ i := by
  induction d with
  | zero =>
      simp
  | succ d ih =>
      rw [arc15G_succ, ih, Finset.sum_range_succ]

/--
For positive block length L, the pumping sum has the
usual closed form
    G_d = (Q^d - 1) / (Q - 1).
-/
theorem arc15G_eq_div
    (L d : ℕ) (hL : L ≠ 0) :
    arc15G L d =
      (arc15Q L ^ d - 1) / (arc15Q L - 1) := by
  rw [arc15G_eq_geomSum]
  have hQ : 2 ≤ arc15Q L := by
    have h := arc15Q_gt_one L hL
    omega
  simpa using (Nat.geomSum_eq hQ d)

/--
Q - 1 divides Q^d - 1.
-/
theorem arc15Q_sub_one_dvd_pow_sub_one
    (L d : ℕ) :
    arc15Q L - 1 ∣ arc15Q L ^ d - 1 := by
  exact Nat.sub_one_dvd_pow_sub_one (arc15Q L) d

/--
The key geometric identity used in the valuation step:
    (Q - 1) * G_d = Q^d - 1.
This version avoids division and works directly over ℕ.
-/
theorem arc15_geom_factorization
    (L d : ℕ) :
    (arc15Q L - 1) * arc15G L d
      = arc15Q L ^ d - 1 := by
  rw [arc15G_eq_geomSum]
  have hQ : 1 ≤ arc15Q L := by
    have h := arc15Q_pos L
    omega
  have h :=
    geom_sum_mul_of_one_le (x := arc15Q L) hQ d
  simpa [Nat.mul_comm] using h

/--
For positive L, Q - 1 is nonzero.
-/
theorem arc15Q_sub_one_ne_zero
    (L : ℕ) (hL : L ≠ 0) :
    arc15Q L - 1 ≠ 0 := by
  have hQ : 1 < arc15Q L := arc15Q_gt_one L hL
  omega

/--
For nonzero d, G_d is nonzero.
-/
theorem arc15G_ne_zero
    (L d : ℕ) (hd : d ≠ 0) :
    arc15G L d ≠ 0 := by
  have hdpos : 0 < d := Nat.pos_of_ne_zero hd
  exact Nat.ne_of_gt (arc15G_pos L d hdpos)

/--
For positive L and nonzero d, Q^d - 1 is nonzero.
-/
theorem arc15Q_pow_sub_one_ne_zero
    (L d : ℕ) (hL : L ≠ 0) (hd : d ≠ 0) :
    arc15Q L ^ d - 1 ≠ 0 := by
  have hQ : 1 < arc15Q L := arc15Q_gt_one L hL
  have hpow : 1 < arc15Q L ^ d := by
    exact Nat.one_lt_pow hd hQ
  omega

end ARC

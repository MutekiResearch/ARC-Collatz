import Mathlib
import Mathlib.Computability.DFA
import Mathlib.Data.Nat.Digits.Defs
import ARC.ARC15Stage5B_DoubleLoopPumping
import ARC.ARC5Stage5L_NumericWordPumping_v2

set_option autoImplicit false

namespace ARC

/-!
============================================================
ARC₁₅ Stage 5C
Base-15 MSD numerical pumping
============================================================
-/

def ARC15BoolSupport
    (s : ℕ → Bool) :
    Set ℕ :=
  {n | s n = true}

def ARC15MSDSupportDFA
    (M : ARCMSDDFAO 15 Bool) :
    DFA (Fin 15) M.State where
  step := M.step
  start := M.start
  accept := {q | M.output q = true}

theorem arc15_msdSupportDFA_evalFrom_eq
    (M : ARCMSDDFAO 15 Bool)
    (q : M.State)
    (L : List (Fin 15)) :
    (ARC15MSDSupportDFA M).evalFrom q L
      =
    ARCMSDDFAO.eval M q L := by
  induction L generalizing q with
  | nil =>
      rfl
  | cons d ds ih =>
      rw [DFA.evalFrom_cons]
      change
        (ARC15MSDSupportDFA M).evalFrom
            (M.step q d)
            ds
          =
        ARCMSDDFAO.eval
            M
            (M.step q d)
            ds
      exact ih (M.step q d)

theorem arc15_msdSupportDFA_eval_eq
    (M : ARCMSDDFAO 15 Bool)
    (L : List (Fin 15)) :
    (ARC15MSDSupportDFA M).eval L
      =
    ARCMSDDFAO.eval M M.start L := by
  unfold DFA.eval
  exact arc15_msdSupportDFA_evalFrom_eq M M.start L

theorem arc15_msdSupportDFA_accepts_iff_output_true
    (M : ARCMSDDFAO 15 Bool)
    (L : List (Fin 15)) :
    L ∈ (ARC15MSDSupportDFA M).accepts
      ↔
    M.output
        (ARCMSDDFAO.eval M M.start L)
      =
    true := by
  rw [DFA.mem_accepts]
  change
    (ARC15MSDSupportDFA M).eval L
        ∈
      {q : M.State | M.output q = true}
      ↔
    M.output
        (ARCMSDDFAO.eval M M.start L)
      =
    true
  rw [arc15_msdSupportDFA_eval_eq]
  rfl

def ARC15MSDValue
    (L : List (Fin 15)) :
    ℕ :=
  Nat.ofDigits
    15
    (
      L.reverse.map
        (fun d => d.val)
    )

theorem arc15_msdSupportDFA_accepts_iff_support
    (M : ARCMSDDFAO 15 Bool)
    (s : ℕ → Bool)
    (hM :
      ARCMSDDFAO.Generates M s)
    (L : List (Fin 15)) :
    L ∈ (ARC15MSDSupportDFA M).accepts
      ↔
    ARC15MSDValue L
      ∈
    ARC15BoolSupport s := by
  rw [arc15_msdSupportDFA_accepts_iff_output_true]
  have hgen := hM L
  unfold ARC15BoolSupport
  unfold ARC15MSDValue
  rw [hgen]
  rfl

theorem arc15_msd_support_word_double_pumping
    (M : ARCMSDDFAO 15 Bool)
    [Fintype M.State]
    (s : ℕ → Bool)
    (hM :
      ARCMSDDFAO.Generates M s)
    (x : List (Fin 15))
    (hx :
      ARC15MSDValue x
        ∈
      ARC15BoolSupport s)
    (hlen :
      Fintype.card M.State
        ≤
      x.length) :
    ∃ a b c : List (Fin 15),
      x = a ++ b ++ c
        ∧
      a.length + b.length
        ≤
      Fintype.card M.State
        ∧
      b ≠ []
        ∧
      ARC15DoubleBlock b ≠ []
        ∧
      (ARC15DoubleBlock b).length
        =
      2 * b.length
        ∧
      0 < (ARC15DoubleBlock b).length
        ∧
      (
        ∀ n : ℕ,
          ARC15MSDValue
              (a ++ ARC5ListRepeat (ARC15DoubleBlock b) n ++ c)
            ∈
          ARC15BoolSupport s
      ) := by
  have hxDFA :
      x ∈ (ARC15MSDSupportDFA M).accepts := by
    exact
      (arc15_msdSupportDFA_accepts_iff_support
        M
        s
        hM
        x).2
        hx
  rcases
    arc15_stage5B_double_loop_pumping_handoff
      (ARC15MSDSupportDFA M)
      hxDFA
      hlen with
    ⟨a,
     b,
     c,
     hsplit,
     hshort,
     hbne,
     hdoubleNe,
     hdoubleLen,
     hdoublePos,
     hpump⟩
  refine
    ⟨a,
     b,
     c,
     hsplit,
     hshort,
     hbne,
     hdoubleNe,
     hdoubleLen,
     hdoublePos,
     ?_⟩
  intro n
  exact
    (arc15_msdSupportDFA_accepts_iff_support
      M
      s
      hM
      (a ++ ARC5ListRepeat (ARC15DoubleBlock b) n ++ c)).1
      (hpump n)

theorem arc15_msdValue_append
    (u v : List (Fin 15)) :
    ARC15MSDValue (u ++ v)
      =
    ARC15MSDValue u * 15 ^ v.length
      +
    ARC15MSDValue v := by
  unfold ARC15MSDValue
  rw [List.reverse_append]
  rw [List.map_append]
  rw [Nat.ofDigits_append]
  simp [List.length_map]
  ring

theorem arc15_listRepeat_length
    (b : List (Fin 15))
    (n : ℕ) :
    (ARC5ListRepeat b n).length
      =
    b.length * n := by
  induction n with
  | zero =>
      simp [ARC5ListRepeat]
  | succ n ih =>
      rw [arc5_listRepeat_succ]
      simp [ih, Nat.mul_succ]

theorem arc15_msdValue_listRepeat
    (b : List (Fin 15))
    (n : ℕ) :
    ARC15MSDValue
        (ARC5ListRepeat b n)
      =
    ARC15MSDValue b
      *
    ARC5GeomSum
      (15 ^ b.length)
      n := by
  induction n with
  | zero =>
      simp [ARC5ListRepeat, ARC15MSDValue, ARC5GeomSum]
  | succ n ih =>
      rw [arc5_listRepeat_succ]
      rw [arc15_msdValue_append]
      rw [ih]
      change
        ARC15MSDValue b
              * ARC5GeomSum
                  (15 ^ b.length)
                  n
              * 15 ^ b.length
            +
          ARC15MSDValue b
          =
        ARC15MSDValue b
          *
        ARC5GeomSum
          (15 ^ b.length)
          (n + 1)
      calc
        ARC15MSDValue b
              * ARC5GeomSum
                  (15 ^ b.length)
                  n
              * 15 ^ b.length
            +
          ARC15MSDValue b
            =
        ARC15MSDValue b
          *
        (
          15 ^ b.length
            *
          ARC5GeomSum
            (15 ^ b.length)
            n
          + 1
        ) := by
          ring
        _ =
        ARC15MSDValue b
          *
        ARC5GeomSum
          (15 ^ b.length)
          (n + 1) := by
            rw [arc5_geomSum_mul_add_one]

theorem arc15G_eq_ARC5GeomSum
    (L n : ℕ) :
    arc15G L n
      =
    ARC5GeomSum
      (15 ^ (2 * L))
      n := by
  induction n with
  | zero =>
      simp [arc15G, ARC5GeomSum]
  | succ n ih =>
      rw [arc15G_succ]
      rw [arc5_geomSum_succ]
      rw [ih]
      rfl

theorem arc15_msdValue_doublePumpedWord_closed
    (a b c : List (Fin 15))
    (n : ℕ) :
    ARC15MSDValue
        (a ++ ARC5ListRepeat (ARC15DoubleBlock b) n ++ c)
      =
    ARC15MSDValue a
        * (15 ^ (ARC15DoubleBlock b).length) ^ n
        * 15 ^ c.length
      +
    ARC15MSDValue (ARC15DoubleBlock b)
        * ARC5GeomSum
            (15 ^ (ARC15DoubleBlock b).length)
            n
        * 15 ^ c.length
      +
    ARC15MSDValue c := by
  calc
    ARC15MSDValue
        (a ++ ARC5ListRepeat (ARC15DoubleBlock b) n ++ c)
        =
    ARC15MSDValue
        (a ++ ARC5ListRepeat (ARC15DoubleBlock b) n)
        * 15 ^ c.length
      +
    ARC15MSDValue c := by
      rw [arc15_msdValue_append]
    _ =
    (
      ARC15MSDValue a
        * 15 ^ (ARC5ListRepeat (ARC15DoubleBlock b) n).length
      +
      ARC15MSDValue
        (ARC5ListRepeat (ARC15DoubleBlock b) n)
    )
      * 15 ^ c.length
      +
    ARC15MSDValue c := by
      rw [arc15_msdValue_append]
    _ =
    (
      ARC15MSDValue a
        * 15 ^ ((ARC15DoubleBlock b).length * n)
      +
      ARC15MSDValue (ARC15DoubleBlock b)
        * ARC5GeomSum
            (15 ^ (ARC15DoubleBlock b).length)
            n
    )
      * 15 ^ c.length
      +
    ARC15MSDValue c := by
      rw [arc15_listRepeat_length]
      rw [arc15_msdValue_listRepeat]
    _ =
    ARC15MSDValue a
        * (15 ^ (ARC15DoubleBlock b).length) ^ n
        * 15 ^ c.length
      +
    ARC15MSDValue (ARC15DoubleBlock b)
        * ARC5GeomSum
            (15 ^ (ARC15DoubleBlock b).length)
            n
        * 15 ^ c.length
      +
    ARC15MSDValue c := by
      rw [pow_mul]
      ring

def ARC15DoubleWordPumpIncrement
    (a b c : List (Fin 15)) :
    ℕ :=
  15 ^ c.length
    *
  (
    ARC15MSDValue a
      * (15 ^ (2 * b.length) - 1)
      +
    ARC15MSDValue (ARC15DoubleBlock b)
  )

theorem arc15_msdValue_doublePumpedWord_eq_pumpedFamily
    (a b c : List (Fin 15))
    (n : ℕ) :
    ARC15MSDValue
        (a ++ ARC5ListRepeat (ARC15DoubleBlock b) n ++ c)
      =
    ARC15PumpedFamily
      (ARC15MSDValue (a ++ c))
      (ARC15DoubleWordPumpIncrement a b c)
      b.length
      n := by
  rw [arc15_msdValue_doublePumpedWord_closed]
  unfold ARC15PumpedFamily
  unfold ARC15DoubleWordPumpIncrement
  rw [arc15_msdValue_append]
  have hdoubleLen :
      (ARC15DoubleBlock b).length
        =
      2 * b.length :=
    arc15_doubleBlock_length b
  rw [hdoubleLen]
  have hbase :
      1 ≤ 15 ^ (2 * b.length) := by
    have hpos :
        0 < 15 ^ (2 * b.length) := by
      positivity
    omega
  have hpow :
      (15 ^ (2 * b.length)) ^ n
        =
      1
        +
      (15 ^ (2 * b.length) - 1)
        *
      ARC5GeomSum
        (15 ^ (2 * b.length))
        n := by
    exact
      arc5_pow_eq_one_add_pred_mul_geomSum
        (15 ^ (2 * b.length))
        n
        hbase
  rw [arc15G_eq_ARC5GeomSum]
  change
    ARC15MSDValue a
        * (15 ^ (2 * b.length)) ^ n
        * 15 ^ c.length
      +
    ARC15MSDValue (ARC15DoubleBlock b)
        * ARC5GeomSum
            (15 ^ (2 * b.length))
            n
        * 15 ^ c.length
      +
    ARC15MSDValue c
      =
    ARC15MSDValue a * 15 ^ c.length
      +
    ARC15MSDValue c
      +
    (
      15 ^ c.length
        *
      (
        ARC15MSDValue a
          * (15 ^ (2 * b.length) - 1)
          +
        ARC15MSDValue (ARC15DoubleBlock b)
      )
    )
      *
    ARC5GeomSum
      (15 ^ (2 * b.length))
      n
  rw [hpow]
  ring

theorem arc15_stage5C_base15_numeric_pumping_handoff
    (M : ARCMSDDFAO 15 Bool)
    [Fintype M.State]
    (s : ℕ → Bool)
    (hM :
      ARCMSDDFAO.Generates M s)
    (x : List (Fin 15))
    (hx :
      ARC15MSDValue x
        ∈
      ARC15BoolSupport s)
    (hlen :
      Fintype.card M.State
        ≤
      x.length) :
    ∃ a b c : List (Fin 15),
      x = a ++ b ++ c
        ∧
      a.length + b.length
        ≤
      Fintype.card M.State
        ∧
      b ≠ []
        ∧
      ARC15DoubleBlock b ≠ []
        ∧
      (ARC15DoubleBlock b).length
        =
      2 * b.length
        ∧
      0 < (ARC15DoubleBlock b).length
        ∧
      (
        ∀ n : ℕ,
          ARC15PumpedFamily
              (ARC15MSDValue (a ++ c))
              (ARC15DoubleWordPumpIncrement a b c)
              b.length
              n
            ∈
          ARC15BoolSupport s
      )
        ∧
      (
        ∀ n : ℕ,
          ARC15MSDValue
              (a ++ ARC5ListRepeat (ARC15DoubleBlock b) n ++ c)
            =
          ARC15PumpedFamily
              (ARC15MSDValue (a ++ c))
              (ARC15DoubleWordPumpIncrement a b c)
              b.length
              n
      ) := by
  rcases
    arc15_msd_support_word_double_pumping
      M
      s
      hM
      x
      hx
      hlen with
    ⟨a,
     b,
     c,
     hsplit,
     hshort,
     hbne,
     hdoubleNe,
     hdoubleLen,
     hdoublePos,
     hpump⟩
  refine
    ⟨a,
     b,
     c,
     hsplit,
     hshort,
     hbne,
     hdoubleNe,
     hdoubleLen,
     hdoublePos,
     ?_,
     ?_⟩
  · intro n
    have hsupport :
        ARC15MSDValue
            (a ++ ARC5ListRepeat (ARC15DoubleBlock b) n ++ c)
          ∈
        ARC15BoolSupport s :=
      hpump n
    rw [
      arc15_msdValue_doublePumpedWord_eq_pumpedFamily
        a
        b
        c
        n
    ] at hsupport
    exact hsupport
  · intro n
    exact
      arc15_msdValue_doublePumpedWord_eq_pumpedFamily
        a
        b
        c
        n

#print axioms arc15_msdSupportDFA_evalFrom_eq
#print axioms arc15_msdSupportDFA_accepts_iff_support
#print axioms arc15_msd_support_word_double_pumping
#print axioms arc15_msdValue_append
#print axioms arc15_listRepeat_length
#print axioms arc15_msdValue_listRepeat
#print axioms arc15G_eq_ARC5GeomSum
#print axioms arc15_msdValue_doublePumpedWord_closed
#print axioms arc15_msdValue_doublePumpedWord_eq_pumpedFamily
#print axioms arc15_stage5C_base15_numeric_pumping_handoff

end ARC

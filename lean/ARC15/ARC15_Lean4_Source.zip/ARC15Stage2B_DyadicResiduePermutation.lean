import ARC.ARC15Stage2A_DyadicCongruence

namespace ARC

/--
The ARC₁₅ dyadic residue map:
    k ↦ G_k mod 2^r
viewed as a self-map of Fin (2^r).
-/
def arc15ResidueMap (L r : ℕ) :
    Fin (2 ^ r) → Fin (2 ^ r) :=
  fun k =>
    ⟨arc15G L k.1 % (2 ^ r),
      Nat.mod_lt _ (pow_pos (by norm_num) r)⟩

/--
On a complete dyadic residue block, equal G-residues force
equal indices.
-/
theorem arc15G_residue_injective_on_block
    (L r k j : ℕ)
    (hL : L ≠ 0)
    (hk : k < 2 ^ r)
    (hj : j < 2 ^ r)
    (hres :
      arc15G L k % (2 ^ r)
        = arc15G L j % (2 ^ r)) :
    k = j := by
  by_cases hkj : k = j
  · exact hkj
  · by_cases hlt : k < j
    · have hG :
        Nat.ModEq (2 ^ r) (arc15G L k) (arc15G L j) := by
        simpa [Nat.ModEq] using hres
      have hind :
          Nat.ModEq (2 ^ r) k j :=
        (arc15G_modEq_iff_index_modEq_of_lt
          L k j r hL hlt).mp hG
      simpa [Nat.ModEq,
        Nat.mod_eq_of_lt hk,
        Nat.mod_eq_of_lt hj] using hind
    · have hjk : j < k := by
        omega
      have hG :
          Nat.ModEq (2 ^ r) (arc15G L j) (arc15G L k) := by
        simpa [Nat.ModEq] using hres.symm
      have hind :
          Nat.ModEq (2 ^ r) j k :=
        (arc15G_modEq_iff_index_modEq_of_lt
          L j k r hL hjk).mp hG
      have hEq : j = k := by
        simpa [Nat.ModEq,
          Nat.mod_eq_of_lt hj,
          Nat.mod_eq_of_lt hk] using hind
      exact hEq.symm

/--
The dyadic residue map is injective.
-/
theorem arc15ResidueMap_injective
    (L r : ℕ)
    (hL : L ≠ 0) :
    Function.Injective (arc15ResidueMap L r) := by
  intro a b hab
  apply Fin.ext
  have hres :
      arc15G L a.1 % (2 ^ r)
        = arc15G L b.1 % (2 ^ r) := by
    have hval := congrArg Fin.val hab
    simpa [arc15ResidueMap] using hval
  exact arc15G_residue_injective_on_block
    L r a.1 b.1 hL a.2 b.2 hres

/--
Because the source and target are the same finite type,
injectivity implies surjectivity.
-/
theorem arc15ResidueMap_surjective
    (L r : ℕ)
    (hL : L ≠ 0) :
    Function.Surjective (arc15ResidueMap L r) := by
  exact
    (arc15ResidueMap_injective L r hL).surjective_of_finite
      (Equiv.refl (Fin (2 ^ r)))

/--
The dyadic residue map is a bijection.
Thus the first 2^r pumping sums run through every residue
class modulo 2^r exactly once.
-/
theorem arc15ResidueMap_bijective
    (L r : ℕ)
    (hL : L ≠ 0) :
    Function.Bijective (arc15ResidueMap L r) := by
  exact ⟨arc15ResidueMap_injective L r hL,
    arc15ResidueMap_surjective L r hL⟩

/--
Explicit residue-filling form:
every y < 2^r occurs as G_k mod 2^r for some k < 2^r.
-/
theorem arc15G_hits_every_dyadic_residue
    (L r y : ℕ)
    (hL : L ≠ 0)
    (hy : y < 2 ^ r) :
    ∃ k : ℕ,
      k < 2 ^ r ∧
      arc15G L k % (2 ^ r) = y := by
  let yFin : Fin (2 ^ r) := ⟨y, hy⟩
  obtain ⟨k, hk⟩ :=
    arc15ResidueMap_surjective L r hL yFin
  refine ⟨k.1, k.2, ?_⟩
  have hval := congrArg Fin.val hk
  simpa [arc15ResidueMap, yFin] using hval

end ARC

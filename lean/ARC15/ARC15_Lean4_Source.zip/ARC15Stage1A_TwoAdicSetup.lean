import ARC.ARC15Stage0C_DifferenceParity_v2

namespace ARC

/--
If a natural number is congruent to 1 modulo 2,
then it is not divisible by 2.
-/
theorem arc15_not_two_dvd_of_mod2_eq_one {n : ℕ}
    (h : n % 2 = 1) :
    ¬ 2 ∣ n := by
  intro hdiv
  rcases hdiv with ⟨m, rfl⟩
  simp at h

/--
For a positive block length L, Q = 15^(2L) is strictly greater than 1.
-/
theorem arc15Q_gt_one (L : ℕ) (hL : L ≠ 0) :
    1 < arc15Q L := by
  unfold arc15Q
  apply Nat.one_lt_pow
  · exact mul_ne_zero (by norm_num) hL
  · norm_num

/--
Q is odd, hence 2 does not divide Q.
-/
theorem arc15Q_not_two_dvd (L : ℕ) :
    ¬ 2 ∣ arc15Q L := by
  exact arc15_not_two_dvd_of_mod2_eq_one (arc15Q_mod2_eq_one L)

/--
If d is odd, then the 2-adic valuation of d is zero.
-/
theorem arc15_padicValNat_two_eq_zero_of_odd
    (d : ℕ) (hd : d % 2 = 1) :
    padicValNat 2 d = 0 := by
  rw [padicValNat.eq_zero_iff]
  exact Or.inr <| Or.inr <|
    arc15_not_two_dvd_of_mod2_eq_one hd

/--
If d is odd, then G_d is odd and therefore its 2-adic valuation is zero.
-/
theorem arc15_padicValNat_G_eq_zero_of_odd
    (L d : ℕ) (hd : d % 2 = 1) :
    padicValNat 2 (arc15G L d) = 0 := by
  rw [padicValNat.eq_zero_iff]
  apply Or.inr
  apply Or.inr
  apply arc15_not_two_dvd_of_mod2_eq_one
  rw [arc15G_mod2_eq]
  exact hd

/--
Odd-index case of the desired valuation identity:
ν₂(G_d) = ν₂(d).
-/
theorem arc15_padicValNat_G_eq_of_odd
    (L d : ℕ) (hd : d % 2 = 1) :
    padicValNat 2 (arc15G L d) = padicValNat 2 d := by
  rw [arc15_padicValNat_G_eq_zero_of_odd L d hd,
      arc15_padicValNat_two_eq_zero_of_odd d hd]

/--
LTE input for the even-index case.

For positive L and nonzero even d:
ν₂(Q^d - 1) + 1
  = ν₂(Q + 1) + ν₂(Q - 1) + ν₂(d).
-/
theorem arc15_lte_even
    (L d : ℕ)
    (hL : L ≠ 0)
    (hd : d ≠ 0)
    (heven : Even d) :
    padicValNat 2 (arc15Q L ^ d - 1) + 1
      =
    padicValNat 2 (arc15Q L + 1)
      + padicValNat 2 (arc15Q L - 1)
      + padicValNat 2 d := by
  exact padicValNat.pow_two_sub_one
    (arc15Q_gt_one L hL)
    (arc15Q_not_two_dvd L)
    hd
    heven

end ARC

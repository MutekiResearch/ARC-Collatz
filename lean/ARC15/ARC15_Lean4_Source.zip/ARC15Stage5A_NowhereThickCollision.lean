import ARC.ARC15Stage4B_DyadicParentFilling
import ARC.ARC5Stage5G_DisagreementReduction_v2

namespace ARC

/-!
============================================================
ARC₁₅ Stage 5A
Collision of dyadic child filling with nowhere-thickness
============================================================
-/

/--
ARC₁₅ name for the base-independent dyadic nowhere-thickness
predicate already formalized in the ARC5 development.
-/
abbrev ARC15DyadicallyNowhereThick
    (S : Set ℕ) : Prop :=
  ARC5DyadicallyNowhereThick S

/--
Every point in the parent cylinder

    n ≡ N0 (mod 2^s)

belongs, at every relative depth R, to one canonical child

    N0 + 2^s * r,   r < 2^R,

modulo 2^(s+R).
-/
theorem arc15_parent_point_has_canonical_child
    (N0 s R n : ℕ)
    (hnParent :
      Nat.ModEq (2 ^ s) n N0) :
    ∃ r : Fin (2 ^ R),
      Nat.ModEq
        (2 ^ (s + R))
        n
        (ARC15DyadicChildRepresentative N0 s R r) := by

  let D : ℕ := 2 ^ (s + R)
  let A : ℕ := n + D * N0

  have hDpos : 0 < D := by
    simp [D]

  have hDone : 1 ≤ D := by
    omega

  have hN0mul : N0 ≤ D * N0 := by
    have h :=
      Nat.mul_le_mul_right
        N0
        hDone
    simpa using h

  have hN0A : N0 ≤ A := by
    dsimp [A]
    omega

  have hzero :
      Nat.ModEq
        (2 ^ s)
        (D * N0)
        0 := by
    have hz :
        Nat.ModEq
          (2 ^ s)
          ((2 ^ s) * ((2 ^ R) * N0) + 0)
          0 :=
      Nat.ModEq.modulus_mul_add
    simpa [D, pow_add, Nat.mul_assoc] using hz

  have hAParent :
      Nat.ModEq
        (2 ^ s)
        A
        N0 := by
    have hadd :=
      hnParent.add hzero
    simpa [A] using hadd

  have hN0Amod :
      Nat.ModEq
        (2 ^ s)
        N0
        A :=
    hAParent.symm

  rcases
    (Nat.modEq_iff_exists_eq_add hN0A).mp
      hN0Amod with
    ⟨q, hAq⟩

  let r : Fin (2 ^ R) :=
    ⟨q % (2 ^ R),
      Nat.mod_lt
        q
        (Nat.two_pow_pos R)⟩

  refine ⟨r, ?_⟩

  have hq :
      Nat.ModEq
        (2 ^ R)
        q
        (q % (2 ^ R)) :=
    (Nat.mod_modEq q (2 ^ R)).symm

  have hscaledRaw :
      Nat.ModEq
        ((2 ^ s) * (2 ^ R))
        ((2 ^ s) * q)
        ((2 ^ s) * (q % (2 ^ R))) :=
    Nat.ModEq.mul_left'
      (2 ^ s)
      hq

  have hscaled :
      Nat.ModEq
        D
        ((2 ^ s) * q)
        ((2 ^ s) * (q % (2 ^ R))) := by
    simpa [D, pow_add] using hscaledRaw

  have hchildRaw :
      Nat.ModEq
        D
        (N0 + (2 ^ s) * q)
        (N0 + (2 ^ s) * (q % (2 ^ R))) :=
    Nat.ModEq.add_left
      N0
      hscaled

  have hAchild :
      Nat.ModEq
        D
        A
        (ARC15DyadicChildRepresentative
          N0 s R r) := by
    rw [hAq]
    simpa
      [ARC15DyadicChildRepresentative, r]
      using hchildRaw

  have hAn :
      Nat.ModEq
        D
        A
        n := by
    have hbase :
        Nat.ModEq
          D
          (D * N0 + n)
          n :=
      Nat.ModEq.modulus_mul_add
    simpa [A, Nat.add_comm] using hbase

  have hnA :
      Nat.ModEq
        D
        n
        A :=
    hAn.symm

  exact hnA.trans hAchild

/--
If two numbers agree modulo 2^(s+M),
then they agree modulo 2^M.
-/
theorem arc15_deep_dyadic_congruence_descends
    (s M : ℕ)
    {a b : ℕ}
    (h :
      Nat.ModEq
        (2 ^ (s + M))
        a
        b) :
    Nat.ModEq
      (2 ^ M)
      a
      b := by

  have hdvd :
      2 ^ M ∣ 2 ^ (s + M) := by
    refine ⟨2 ^ s, ?_⟩
    rw [pow_add]
    ring

  exact
    Nat.ModEq.of_dvd
      hdvd
      h

/--
An ARC₁₅ pumped family contained in S and filling all children
of its parent cylinder is incompatible with dyadic nowhere-thickness.
-/
theorem arc15_child_filling_not_nowhereThick
    (S : Set ℕ)
    (N0 d L s v : ℕ)
    (hL : L ≠ 0)
    (hd :
      d = 2 ^ s * (2 * v + 1))
    (hpump :
      ∀ k : ℕ,
        ARC15PumpedFamily
            N0
            d
            L
            k
          ∈ S) :
    ¬ ARC15DyadicallyNowhereThick S := by

  intro hthin

  rcases
    hthin s N0 with
    ⟨M,
     t,
     hinside,
     hpositive,
     hempty⟩

  rcases
    hpositive with
    ⟨n,
     hnpos,
     hnt⟩

  have hnParent :
      Nat.ModEq
        (2 ^ s)
        n
        N0 :=
    hinside n hnt

  rcases
    arc15_parent_point_has_canonical_child
      N0 s M n hnParent with
    ⟨r, hnChild⟩

  rcases
    arc15_pumpedFamily_hits_every_child_of_exact_two_factor
      N0 d L s v M hL hd r with
    ⟨k, hkChild⟩

  have hPumpNDeep :
      Nat.ModEq
        (2 ^ (s + M))
        (ARC15PumpedFamily
          N0 d L k.val)
        n :=
    hkChild.trans hnChild.symm

  have hPumpN :
      Nat.ModEq
        (2 ^ M)
        (ARC15PumpedFamily
          N0 d L k.val)
        n :=
    arc15_deep_dyadic_congruence_descends
      s M hPumpNDeep

  have hPumpT :
      Nat.ModEq
        (2 ^ M)
        (ARC15PumpedFamily
          N0 d L k.val)
        t :=
    hPumpN.trans hnt

  have hnotmem :
      ARC15PumpedFamily
          N0 d L k.val
        ∉ S :=
    hempty
      (ARC15PumpedFamily
        N0 d L k.val)
      hPumpT

  exact
    hnotmem
      (hpump k.val)

/--
Stage-5A handoff:
exact dyadic pumping plus support containment destroys
dyadic nowhere-thickness.
-/
theorem arc15_stage5A_nowhereThick_collision
    (S : Set ℕ)
    (N0 d L s v : ℕ)
    (hL : L ≠ 0)
    (hd :
      d = 2 ^ s * (2 * v + 1))
    (hpump :
      ∀ k : ℕ,
        ARC15PumpedFamily
            N0
            d
            L
            k
          ∈ S) :
    ¬ ARC15DyadicallyNowhereThick S := by
  exact
    arc15_child_filling_not_nowhereThick
      S N0 d L s v hL hd hpump

#print axioms arc15_parent_point_has_canonical_child
#print axioms arc15_deep_dyadic_congruence_descends
#print axioms arc15_child_filling_not_nowhereThick
#print axioms arc15_stage5A_nowhereThick_collision

end ARC

import Mathlib

namespace ARC

/--
The even-block power used in the ARC₁₅ pumping construction.
-/
def arc15Q (L : ℕ) : ℕ :=
  15 ^ (2 * L)

/--
15² ≡ 1 (mod 32).
-/
theorem arc15_sq_mod32 :
    Nat.ModEq 32 (15 ^ 2) 1 := by
  norm_num [Nat.ModEq]

/--
For every L, 15^(2L) ≡ 1 (mod 32).
-/
theorem arc15Q_mod32 (L : ℕ) :
    Nat.ModEq 32 (arc15Q L) 1 := by
  have h : Nat.ModEq 32 (15 ^ 2) 1 := by
    norm_num [Nat.ModEq]
  simpa [arc15Q, pow_mul] using h.pow L

/--
Concrete remainder form of the previous result.
-/
theorem arc15Q_mod32_eq_one (L : ℕ) :
    arc15Q L % 32 = 1 := by
  have h := arc15Q_mod32 L
  simpa [Nat.ModEq] using h

/--
In particular, 15^(2L) ≡ 1 (mod 8).
-/
theorem arc15Q_mod8 (L : ℕ) :
    Nat.ModEq 8 (arc15Q L) 1 := by
  have h : Nat.ModEq 8 (15 ^ 2) 1 := by
    norm_num [Nat.ModEq]
  simpa [arc15Q, pow_mul] using h.pow L

theorem arc15Q_mod8_eq_one (L : ℕ) :
    arc15Q L % 8 = 1 := by
  have h := arc15Q_mod8 L
  simpa [Nat.ModEq] using h

/--
The block multiplier is always odd.
-/
theorem arc15Q_mod2_eq_one (L : ℕ) :
    arc15Q L % 2 = 1 := by
  unfold arc15Q
  have h : Nat.ModEq 2 15 1 := by
    norm_num [Nat.ModEq]
  have hp := h.pow (2 * L)
  simpa [Nat.ModEq] using hp

/--
The block multiplier is positive.
-/
theorem arc15Q_pos (L : ℕ) :
    0 < arc15Q L := by
  unfold arc15Q
  positivity

end ARC

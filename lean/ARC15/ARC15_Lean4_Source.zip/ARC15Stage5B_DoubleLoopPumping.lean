import Mathlib
import Mathlib.Computability.DFA
import ARC.ARC15Stage5A_NowhereThickCollision
import ARC.ARC5Stage5K_MSDWordPumping_v3

set_option autoImplicit false

namespace ARC

universe u v

/-!
============================================================
ARC₁₅ Stage 5B
Double-loop automatic pumping
============================================================
-/

def ARC15DoubleBlock
    {β : Type u}
    (b : List β) : List β :=
  b ++ b

@[simp]
theorem arc15_doubleBlock_length
    {β : Type u}
    (b : List β) :
    (ARC15DoubleBlock b).length = 2 * b.length := by
  simp [ARC15DoubleBlock, two_mul]

theorem arc15_doubleBlock_ne_nil
    {β : Type u}
    (b : List β)
    (hb : b ≠ []) :
    ARC15DoubleBlock b ≠ [] := by
  cases b with
  | nil =>
      exact (hb rfl).elim
  | cons x xs =>
      simp [ARC15DoubleBlock]

theorem arc15_doubleBlock_length_pos
    {β : Type u}
    (b : List β)
    (hb : b ≠ []) :
    0 < (ARC15DoubleBlock b).length := by
  cases b with
  | nil =>
      exact (hb rfl).elim
  | cons x xs =>
      simp [ARC15DoubleBlock]

theorem arc15_doubleBlock_pow15_eq_Q
    {β : Type u}
    (b : List β) :
    15 ^ (ARC15DoubleBlock b).length = arc15Q b.length := by
  simp [ARC15DoubleBlock, arc15Q, two_mul]

theorem arc15_dfa_doubleBlock_loop
    {β : Type u}
    {σ : Type v}
    (M : DFA β σ)
    (q : σ)
    (b : List β)
    (hloop : M.evalFrom q b = q) :
    M.evalFrom q (ARC15DoubleBlock b) = q := by
  unfold ARC15DoubleBlock
  rw [DFA.evalFrom_of_append]
  rw [hloop]
  exact hloop

theorem arc15_dfa_evalFrom_doubleBlock_repeat
    {β : Type u}
    {σ : Type v}
    (M : DFA β σ)
    (q : σ)
    (b : List β)
    (hloop : M.evalFrom q b = q) :
    ∀ n : ℕ,
      M.evalFrom q
          (ARC5ListRepeat (ARC15DoubleBlock b) n) = q := by
  intro n
  exact
    arc5_dfa_evalFrom_word_pow
      M
      q
      (ARC15DoubleBlock b)
      (arc15_dfa_doubleBlock_loop M q b hloop)
      n

theorem arc15_listRepeat_add
    {β : Type u}
    (b : List β)
    (m n : ℕ) :
    ARC5ListRepeat b (m + n)
      = ARC5ListRepeat b m ++ ARC5ListRepeat b n := by
  induction n with
  | zero =>
      simp
  | succ n ih =>
      rw [Nat.add_succ]
      rw [arc5_listRepeat_succ]
      rw [arc5_listRepeat_succ]
      rw [ih]
      simp [List.append_assoc]

theorem arc15_listRepeat_doubleBlock
    {β : Type u}
    (b : List β)
    (n : ℕ) :
    ARC5ListRepeat (ARC15DoubleBlock b) n
      = ARC5ListRepeat b (2 * n) := by
  induction n with
  | zero =>
      simp [ARC15DoubleBlock]
  | succ n ih =>
      rw [arc5_listRepeat_succ]
      rw [ih]
      have hcount : 2 * (n + 1) = 2 * n + 2 := by
        omega
      rw [hcount]
      rw [arc15_listRepeat_add]
      simp [ARC15DoubleBlock, ARC5ListRepeat]

theorem arc15_doubleBlock_preserves_pumped_acceptance
    {β : Type u}
    {σ : Type v}
    (M : DFA β σ)
    (a b c : List β)
    (hpump :
      ∀ n : ℕ,
        a ++ ARC5ListRepeat b n ++ c ∈ M.accepts) :
    ∀ n : ℕ,
      a ++ ARC5ListRepeat (ARC15DoubleBlock b) n ++ c
        ∈ M.accepts := by
  intro n
  rw [arc15_listRepeat_doubleBlock]
  exact hpump (2 * n)

theorem arc15_stage5B_double_loop_pumping_handoff
    {β : Type u}
    {σ : Type v}
    (M : DFA β σ)
    [Fintype σ]
    {x : List β}
    (hx : x ∈ M.accepts)
    (hlen : Fintype.card σ ≤ x.length) :
    ∃ a b c : List β,
      x = a ++ b ++ c
        ∧ a.length + b.length ≤ Fintype.card σ
        ∧ b ≠ []
        ∧ ARC15DoubleBlock b ≠ []
        ∧ (ARC15DoubleBlock b).length = 2 * b.length
        ∧ 0 < (ARC15DoubleBlock b).length
        ∧ (
          ∀ n : ℕ,
            a ++ ARC5ListRepeat (ARC15DoubleBlock b) n ++ c
              ∈ M.accepts
        ) := by
  rcases
    arc5_dfa_pumping_loop M hx hlen with
    ⟨a, b, c, hsplit, hshort, hbne, hpump⟩

  have hdoubleNe : ARC15DoubleBlock b ≠ [] :=
    arc15_doubleBlock_ne_nil b hbne

  have hdoubleLen :
      (ARC15DoubleBlock b).length = 2 * b.length :=
    arc15_doubleBlock_length b

  have hdoublePos :
      0 < (ARC15DoubleBlock b).length :=
    arc15_doubleBlock_length_pos b hbne

  have hdoublePump :
      ∀ n : ℕ,
        a ++ ARC5ListRepeat (ARC15DoubleBlock b) n ++ c
          ∈ M.accepts :=
    arc15_doubleBlock_preserves_pumped_acceptance
      M a b c hpump

  exact
    ⟨a, b, c,
     hsplit,
     hshort,
     hbne,
     hdoubleNe,
     hdoubleLen,
     hdoublePos,
     hdoublePump⟩

#print axioms arc15_doubleBlock_length
#print axioms arc15_doubleBlock_ne_nil
#print axioms arc15_doubleBlock_length_pos
#print axioms arc15_doubleBlock_pow15_eq_Q
#print axioms arc15_dfa_doubleBlock_loop
#print axioms arc15_dfa_evalFrom_doubleBlock_repeat
#print axioms arc15_listRepeat_add
#print axioms arc15_listRepeat_doubleBlock
#print axioms arc15_doubleBlock_preserves_pumped_acceptance
#print axioms arc15_stage5B_double_loop_pumping_handoff

end ARC

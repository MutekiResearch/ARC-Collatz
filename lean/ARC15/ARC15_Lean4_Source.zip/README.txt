ARC15 Lean 4 Source Release
===========================

This archive contains the active ARC15-specific Lean modules used in the
base-15 rigidity development.

Main endpoints:
  arc15_final
  arc15_main_zero_digit_standard_msd_form
  arc15_zero_value_is_genuinely_free

The ARC15 files import shared ARC infrastructure developed in earlier stages
(automaticity bridges and base-independent local-density machinery). Thus this
archive is the ARC15-specific source layer, not a standalone Mathlib project.

Verification status reported by the authoring project:
  - standalone checks passed stage by stage;
  - integrated full `lake build` passed with 8884 jobs after sharpness inclusion;
  - audited endpoints reported only propext, Classical.choice, Quot.sound;
  - no sorryAx appeared in the successful final build reports.

Date: 2026-09-22
Author: Muteki
Repository: https://github.com/MutekiResearch/ARC-Collatz

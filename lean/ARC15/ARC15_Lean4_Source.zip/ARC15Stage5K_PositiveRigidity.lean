import Mathlib
import ARC.ARC15Stage5J_EventualConstancy

set_option autoImplicit false

universe u

namespace ARC

/-!
============================================================
ARC₁₅ Stage 5K
From eventual constancy to constancy on all positive integers
============================================================

Stage 5J proved that an ARC₁₅ sequence is eventually constant.

Shortcut invariance gives

    arcShortcutNat (2*n) = n,

hence

    a (2*n) = a n.

Iterating,

    a (2^k * n) = a n.

For every positive `n`, choose `k = N`, where `N` is the threshold of the
eventually constant tail. Since `N ≤ 2^N ≤ 2^N * n`, the doubled point lies
inside the constant tail. Thus every positive input has the same value.

Input `0` is intentionally left free.
-/

/-!
============================================================
1. Shortcut invariance under doubling
============================================================
-/

theorem arc15_shortcut_double
    (n : ℕ) :
    arcShortcutNat (2 * n) = n := by

  simp [arcShortcutNat]

theorem arc15_double_invariance
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (n : ℕ) :
    a (2 * n) = a n := by

  have h :=
    hinv (2 * n)

  have h' :
      a n = a (2 * n) := by
    simpa [arc15_shortcut_double] using h

  exact h'.symm

/-!
============================================================
2. Iterated doubling
============================================================
-/

theorem arc15_pow_two_mul_invariance
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n) :
    ∀ k n : ℕ,
      a (2 ^ k * n) = a n := by

  intro k

  induction k with

  | zero =>
      intro n
      simp

  | succ k ih =>
      intro n

      calc
        a (2 ^ (k + 1) * n)
            =
        a (2 * (2 ^ k * n)) := by
          congr 1
          rw [pow_succ]
          ring

        _ =
        a (2 ^ k * n) :=
          arc15_double_invariance
            a
            hinv
            (2 ^ k * n)

        _ =
        a n :=
          ih n

/-!
============================================================
3. Elementary growth bound
============================================================
-/

theorem arc15_nat_le_two_pow
    (N : ℕ) :
    N ≤ 2 ^ N := by

  induction N with

  | zero =>
      simp

  | succ N ih =>

      have hpowpos :
          0 < 2 ^ N := by
        exact
          pow_pos
            (by norm_num : 0 < (2 : ℕ))
            N

      have hone :
          1 ≤ 2 ^ N := by
        omega

      calc
        N + 1
            ≤
        2 ^ N + 1 :=
          Nat.add_le_add_right
            ih
            1

        _ ≤
        2 ^ N + 2 ^ N :=
          Nat.add_le_add_left
            hone
            (2 ^ N)

        _ =
        2 ^ (N + 1) := by
          rw [pow_succ]
          ring

theorem arc15_threshold_reached_by_doubling
    (N n : ℕ)
    (hn :
      0 < n) :
    N ≤ 2 ^ N * n := by

  have hpow :
      N ≤ 2 ^ N :=
    arc15_nat_le_two_pow
      N

  have hn1 :
      1 ≤ n := by
    omega

  have hmul :
      2 ^ N
        ≤
      2 ^ N * n := by

    simpa using
      Nat.mul_le_mul_left
        (2 ^ N)
        hn1

  exact
    le_trans
      hpow
      hmul

/-!
============================================================
4. Eventual constancy propagates to all positive inputs
============================================================
-/

theorem arc15_positive_constant_of_eventual
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (N : ℕ)
    (c : α)
    (htail :
      ∀ n : ℕ,
        N ≤ n →
        a n = c) :
    ∀ n : ℕ,
      0 < n →
      a n = c := by

  intro n hn

  let x : ℕ :=
    2 ^ N * n

  have hxLarge :
      N ≤ x := by

    dsimp [x]

    exact
      arc15_threshold_reached_by_doubling
        N
        n
        hn

  have hxColor :
      a x = a n := by

    dsimp [x]

    exact
      arc15_pow_two_mul_invariance
        a
        hinv
        N
        n

  calc
    a n
        =
    a x :=
      hxColor.symm

    _ =
    c :=
      htail
        x
        hxLarge

/-!
============================================================
5. Final positive-domain ARC₁₅ rigidity theorem
============================================================
-/

theorem arc15_positive_constant
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha15 :
      ARCAutomaticByKernel 15 a) :
    ∃ c : α,
      ∀ n : ℕ,
        0 < n →
        a n = c := by

  rcases
    arc15_stage5J_eventual_constancy
      a
      hinv
      ha15 with
    ⟨N,
     c,
     htail⟩

  exact
    ⟨c,
     arc15_positive_constant_of_eventual
       a
       hinv
       N
       c
       htail⟩

theorem arc15_positive_pairwise_equal
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha15 :
      ARCAutomaticByKernel 15 a) :
    ∀ m n : ℕ,
      0 < m →
      0 < n →
      a m = a n := by

  rcases
    arc15_positive_constant
      a
      hinv
      ha15 with
    ⟨c, hc⟩

  intro m n hm hn

  calc
    a m
        =
    c :=
      hc m hm

    _ =
    a n :=
      (hc n hn).symm

/-!
============================================================
6. Stage-5K final handoff
============================================================
-/

theorem arc15_stage5K_positive_rigidity
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha15 :
      ARCAutomaticByKernel 15 a) :
    ∃ c : α,
      ∀ n : ℕ,
        0 < n →
        a n = c := by

  exact
    arc15_positive_constant
      a
      hinv
      ha15

#print axioms arc15_shortcut_double
#print axioms arc15_double_invariance
#print axioms arc15_pow_two_mul_invariance
#print axioms arc15_nat_le_two_pow
#print axioms arc15_threshold_reached_by_doubling
#print axioms arc15_positive_constant_of_eventual
#print axioms arc15_positive_constant
#print axioms arc15_positive_pairwise_equal
#print axioms arc15_stage5K_positive_rigidity

end ARC

import Mathlib
import ARC.ARCAutomaticBridge2
import ARC.ARC15Stage5F_InfiniteSupportLongWord

set_option autoImplicit false

namespace ARC

/-!
============================================================
ARC₁₅ Stage 5G
Kernel automaticity -> MSD-DFAO -> topological pumping closure
============================================================

Stage 5F established the ARC₁₅ topological pumping theorem at the
explicit finite MSD-DFAO level:

    finite base-15 MSD-DFAO presentation
      +
    dyadically nowhere-thick support
      ->
    finite support.

Stage 5G closes the representation gap:

    finite base-15 kernel
      ->
    base-15 MSD automatic
      ->
    finite MSD-DFAO presentation
      ->
    Stage 5F
      ->
    finite support.
-/

/-!
============================================================
1. Kernel automaticity -> finite support
============================================================
-/

/--
Kernel-level form of the ARC₁₅ topological pumping theorem.
-/
theorem arc15_kernelAutomatic_nowhereThick_support_finite
    (sseq : ℕ → Bool)
    (hAuto :
      ARCAutomaticByKernel 15 sseq)
    (hthin :
      ARC15DyadicallyNowhereThick
        (ARC15BoolSupport sseq)) :
    (ARC15BoolSupport sseq).Finite := by

  have hKernel :
      (ARCKernel 15 sseq).Finite := by
    simpa [ARCAutomaticByKernel] using hAuto

  have hMSD :
      ARCMSDAutomatic 15 sseq :=
    arc_finite_kernel_implies_msd_automatic
      15
      sseq
      hKernel

  rcases hMSD with
    ⟨M, hM⟩

  letI : Finite M.State :=
    M.stateFinite

  letI : Fintype M.State :=
    Fintype.ofFinite M.State

  exact
    arc15_stage5F_msd_topological_pumping
      M
      sseq
      hM
      hthin

/-!
============================================================
2. Standalone ARC₁₅ topological pumping principle
============================================================
-/

/--
Kernel-form ARC₁₅ topological pumping principle.
-/
def ARC15TopologicalPumpingPrinciple : Prop :=
  ∀ sseq : ℕ → Bool,
    ARCAutomaticByKernel 15 sseq
      →
    ARC15DyadicallyNowhereThick
      (ARC15BoolSupport sseq)
      →
    (ARC15BoolSupport sseq).Finite

/--
The standalone ARC₁₅ topological pumping principle.
-/
theorem arc15_stage5G_topological_pumping_principle :
    ARC15TopologicalPumpingPrinciple := by

  intro sseq hAuto hthin

  exact
    arc15_kernelAutomatic_nowhereThick_support_finite
      sseq
      hAuto
      hthin

/-!
============================================================
3. Direct kernel-level handoff
============================================================
-/

/--
Stage-5G handoff:
every Boolean base-15 automatic sequence in the finite-kernel sense
with dyadically nowhere-thick support has finite support.
-/
theorem arc15_stage5G_kernel_topological_pumping
    (sseq : ℕ → Bool)
    (hAuto :
      ARCAutomaticByKernel 15 sseq)
    (hthin :
      ARC15DyadicallyNowhereThick
        (ARC15BoolSupport sseq)) :
    (ARC15BoolSupport sseq).Finite := by

  exact
    arc15_stage5G_topological_pumping_principle
      sseq
      hAuto
      hthin

#print axioms arc15_kernelAutomatic_nowhereThick_support_finite
#print axioms arc15_stage5G_topological_pumping_principle
#print axioms arc15_stage5G_kernel_topological_pumping

end ARC

import Mathlib
import ARC.ARC15Stage5D_PositivePumpIncrement

set_option autoImplicit false

namespace ARC

/-!
============================================================
ARC₁₅ Stage 5E
Exact dyadic factorization and collision handoff
============================================================
-/

/--
Every positive natural number is a power of two times a positive odd number.
-/
theorem arc15_exists_twoPow_mul_odd
    (d : ℕ)
    (hd : 0 < d) :
    ∃ s v : ℕ,
      d = 2 ^ s * (2 * v + 1) := by

  revert hd
  induction d using Nat.strong_induction_on with
  | h d ih =>
      intro hd
      by_cases heven : d % 2 = 0
      · have htwo : 2 ∣ d :=
          Nat.dvd_of_mod_eq_zero heven
        rcases htwo with ⟨q, hq⟩
        have hqpos : 0 < q := by
          nlinarith
        have hqlt : q < d := by
          nlinarith
        rcases ih q hqlt hqpos with ⟨s, v, hsv⟩
        refine ⟨s + 1, v, ?_⟩
        rw [hq, hsv, pow_succ]
        ring
      · have hmodlt : d % 2 < 2 :=
          Nat.mod_lt d (by norm_num)
        have hmod : d % 2 = 1 := by
          omega
        have hdiv := Nat.mod_add_div d 2
        refine ⟨0, d / 2, ?_⟩
        simp
        omega

/--
The positive doubled-word pump increment has an exact dyadic factorization.
-/
theorem arc15_doubleWordPumpIncrement_exact_two_factor
    (a b c : List (Fin 15))
    (hinc : 0 < ARC15DoubleWordPumpIncrement a b c) :
    ∃ s v : ℕ,
      ARC15DoubleWordPumpIncrement a b c
        =
      2 ^ s * (2 * v + 1) := by
  exact
    arc15_exists_twoPow_mul_odd
      (ARC15DoubleWordPumpIncrement a b c)
      hinc

/--
Full exact-factorization handoff from one sufficiently long positive
canonical base-15 support word.
-/
theorem arc15_stage5E_exact_dyadic_pumping_handoff
    (M : ARCMSDDFAO 15 Bool)
    [Fintype M.State]
    (sseq : ℕ → Bool)
    (hM : ARCMSDDFAO.Generates M sseq)
    (x : List (Fin 15))
    (hxCanonical : ARC15CanonicalPositiveMSDWord x)
    (hx :
      ARC15MSDValue x ∈ ARC15BoolSupport sseq)
    (hlen :
      Fintype.card M.State ≤ x.length) :
    ∃ a b c : List (Fin 15),
    ∃ s v : ℕ,
      x = a ++ b ++ c
        ∧
      a.length + b.length ≤ Fintype.card M.State
        ∧
      b ≠ []
        ∧
      0 < b.length
        ∧
      ARC15DoubleBlock b ≠ []
        ∧
      (ARC15DoubleBlock b).length = 2 * b.length
        ∧
      0 < (ARC15DoubleBlock b).length
        ∧
      0 < ARC15DoubleWordPumpIncrement a b c
        ∧
      ARC15DoubleWordPumpIncrement a b c
        =
      2 ^ s * (2 * v + 1)
        ∧
      (
        ∀ n : ℕ,
          ARC15PumpedFamily
              (ARC15MSDValue (a ++ c))
              (ARC15DoubleWordPumpIncrement a b c)
              b.length
              n
            ∈ ARC15BoolSupport sseq
      )
        ∧
      (
        ∀ n : ℕ,
          ARC15MSDValue
              (a ++ ARC5ListRepeat (ARC15DoubleBlock b) n ++ c)
            =
          ARC15PumpedFamily
              (ARC15MSDValue (a ++ c))
              (ARC15DoubleWordPumpIncrement a b c)
              b.length
              n
      ) := by

  rcases
    arc15_stage5D_positive_numeric_pumping_handoff
      M sseq hM x hxCanonical hx hlen with
    ⟨a, b, c,
     hsplit, hshort, hbne, hdoubleNe,
     hdoubleLen, hdoublePos, hinc, hpump, hvalue⟩

  have hblen : 0 < b.length := by
    cases b with
    | nil =>
        exact (hbne rfl).elim
    | cons d ds =>
        simp

  rcases
    arc15_doubleWordPumpIncrement_exact_two_factor
      a b c hinc with
    ⟨s, v, hfactor⟩

  exact
    ⟨a, b, c, s, v,
     hsplit, hshort, hbne, hblen,
     hdoubleNe, hdoubleLen, hdoublePos,
     hinc, hfactor, hpump, hvalue⟩

/--
A single sufficiently long positive canonical base-15 support word
already contradicts dyadic nowhere-thickness.
-/
theorem arc15_long_canonical_support_word_not_nowhereThick
    (M : ARCMSDDFAO 15 Bool)
    [Fintype M.State]
    (sseq : ℕ → Bool)
    (hM : ARCMSDDFAO.Generates M sseq)
    (x : List (Fin 15))
    (hxCanonical : ARC15CanonicalPositiveMSDWord x)
    (hx :
      ARC15MSDValue x ∈ ARC15BoolSupport sseq)
    (hlen :
      Fintype.card M.State ≤ x.length) :
    ¬ ARC15DyadicallyNowhereThick
        (ARC15BoolSupport sseq) := by

  rcases
    arc15_stage5E_exact_dyadic_pumping_handoff
      M sseq hM x hxCanonical hx hlen with
    ⟨a, b, c, s, v,
     hsplit, hshort, hbne, hblen,
     hdoubleNe, hdoubleLen, hdoublePos,
     hinc, hfactor, hpump, hvalue⟩

  have hL : b.length ≠ 0 :=
    Nat.ne_of_gt hblen

  exact
    arc15_child_filling_not_nowhereThick
      (ARC15BoolSupport sseq)
      (ARC15MSDValue (a ++ c))
      (ARC15DoubleWordPumpIncrement a b c)
      b.length
      s
      v
      hL
      hfactor
      hpump

/--
Stage-5E final handoff.
-/
theorem arc15_stage5E_long_word_collision
    (M : ARCMSDDFAO 15 Bool)
    [Fintype M.State]
    (sseq : ℕ → Bool)
    (hM : ARCMSDDFAO.Generates M sseq)
    (x : List (Fin 15))
    (hxCanonical : ARC15CanonicalPositiveMSDWord x)
    (hx :
      ARC15MSDValue x ∈ ARC15BoolSupport sseq)
    (hlen :
      Fintype.card M.State ≤ x.length) :
    ¬ ARC15DyadicallyNowhereThick
        (ARC15BoolSupport sseq) := by
  exact
    arc15_long_canonical_support_word_not_nowhereThick
      M sseq hM x hxCanonical hx hlen

#print axioms arc15_exists_twoPow_mul_odd
#print axioms arc15_doubleWordPumpIncrement_exact_two_factor
#print axioms arc15_stage5E_exact_dyadic_pumping_handoff
#print axioms arc15_long_canonical_support_word_not_nowhereThick
#print axioms arc15_stage5E_long_word_collision

end ARC

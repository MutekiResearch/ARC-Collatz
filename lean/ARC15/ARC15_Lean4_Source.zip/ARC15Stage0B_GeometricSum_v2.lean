import ARC.ARC15Stage0Arithmetic

namespace ARC

/--
Geometric pumping sum for ARC₁₅:
G_k(Q) = 1 + Q + ... + Q^(k-1),
with Q = 15^(2L).
We define it recursively to keep the basic algebra transparent.
-/
def arc15G (L : ℕ) : ℕ → ℕ
  | 0 => 0
  | k + 1 => arc15G L k + arc15Q L ^ k

/--
G_0 = 0.
-/
@[simp]
theorem arc15G_zero (L : ℕ) :
    arc15G L 0 = 0 := by
  rfl

/--
G_(k+1) = G_k + Q^k.
-/
@[simp]
theorem arc15G_succ (L k : ℕ) :
    arc15G L (k + 1) = arc15G L k + arc15Q L ^ k := by
  rfl

/--
G_1 = 1.
-/
@[simp]
theorem arc15G_one (L : ℕ) :
    arc15G L 1 = 1 := by
  simp [arc15G]

/--
Splitting a geometric pumping block:
G_(k+d) = G_k + Q^k * G_d.
-/
theorem arc15G_add (L k d : ℕ) :
    arc15G L (k + d)
      = arc15G L k + arc15Q L ^ k * arc15G L d := by
  induction d with
  | zero =>
      simp
  | succ d ih =>
      rw [Nat.add_succ, arc15G_succ, ih, arc15G_succ, pow_add]
      ring

/--
A one-step shift form of the block-splitting identity.
-/
theorem arc15G_add_one (L k : ℕ) :
    arc15G L (k + 1)
      = arc15G L k + arc15Q L ^ k := by
  simp

/--
Every positive geometric pumping sum is positive.
-/
theorem arc15G_pos (L k : ℕ) (hk : 0 < k) :
    0 < arc15G L k := by
  cases k with
  | zero =>
      simp at hk
  | succ k =>
      rw [arc15G_succ]
      have hQ : 0 < arc15Q L := arc15Q_pos L
      have hpow : 0 < arc15Q L ^ k := pow_pos hQ k
      omega

/--
The geometric pumping sums are strictly increasing in the index.
-/
theorem arc15G_lt_succ (L k : ℕ) :
    arc15G L k < arc15G L (k + 1) := by
  rw [arc15G_succ]
  have hQ : 0 < arc15Q L := arc15Q_pos L
  have hpow : 0 < arc15Q L ^ k := pow_pos hQ k
  omega

end ARC

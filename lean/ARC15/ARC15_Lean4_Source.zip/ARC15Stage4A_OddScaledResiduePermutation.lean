import ARC.ARC15Stage3B_DyadicChildFilling

namespace ARC

/--
Every odd factor `2*v+1` is coprime to every power of two.
-/
theorem arc15_oddFactor_coprime_pow2
    (v r : ℕ) :
    (2 * v + 1).Coprime (2 ^ r) := by
  by_cases hr : r = 0
  · subst r
    simp
  · have hrpos : 0 < r := by
      omega
    apply
      (Nat.coprime_pow_right_iff
        hrpos
        (2 * v + 1)
        2).2
    have hodd : Odd (2 * v + 1) := by
      refine ⟨v, ?_⟩
      omega
    exact
      (Nat.coprime_two_right).2 hodd

/--
The odd-scaled ARC₁₅ residue map

    k ↦ (2*v+1) * G_k  mod 2^r.

Since the scaling factor is odd, it should preserve
the permutation structure already proved for `G_k`.
-/
def arc15OddScaledResidueMap
    (v L r : ℕ) :
    Fin (2 ^ r) → Fin (2 ^ r) :=
  fun k =>
    ⟨
      ((2 * v + 1) * arc15G L k.1) % (2 ^ r),
      Nat.mod_lt
        _
        (pow_pos (by norm_num) r)
    ⟩

/--
The odd-scaled residue map is injective.

If two scaled pumping sums agree modulo `2^r`,
the odd common factor may be cancelled because it is
coprime to `2^r`.  The already proved injectivity of
the unscaled `G_k` residue map then forces the indices
to be equal.
-/
theorem arc15OddScaledResidueMap_injective
    (v L r : ℕ)
    (hL : L ≠ 0) :
    Function.Injective
      (arc15OddScaledResidueMap v L r) := by
  intro a b hab

  apply Fin.ext

  have hscaledRes :
      ((2 * v + 1) * arc15G L a.1) % (2 ^ r)
        =
      ((2 * v + 1) * arc15G L b.1) % (2 ^ r) := by
    have hval := congrArg Fin.val hab
    simpa [arc15OddScaledResidueMap] using hval

  have hscaled :
      Nat.ModEq
        (2 ^ r)
        ((2 * v + 1) * arc15G L a.1)
        ((2 * v + 1) * arc15G L b.1) := by
    simpa [Nat.ModEq] using hscaledRes

  have hcop :
      (2 * v + 1).Coprime (2 ^ r) :=
    arc15_oddFactor_coprime_pow2 v r

  have hG :
      Nat.ModEq
        (2 ^ r)
        (arc15G L a.1)
        (arc15G L b.1) := by
    exact
      Nat.ModEq.cancel_left_of_coprime
        hcop.symm.gcd_eq_one
        hscaled

  have hres :
      arc15G L a.1 % (2 ^ r)
        =
      arc15G L b.1 % (2 ^ r) := by
    simpa [Nat.ModEq] using hG

  exact
    arc15G_residue_injective_on_block
      L
      r
      a.1
      b.1
      hL
      a.2
      b.2
      hres

/--
Because the domain and codomain are the same finite type,
injectivity implies surjectivity.
-/
theorem arc15OddScaledResidueMap_surjective
    (v L r : ℕ)
    (hL : L ≠ 0) :
    Function.Surjective
      (arc15OddScaledResidueMap v L r) := by
  exact
    (arc15OddScaledResidueMap_injective
      v L r hL).surjective_of_finite
        (Equiv.refl (Fin (2 ^ r)))

/--
The odd-scaled residue map is a permutation of all
residue classes modulo `2^r`.
-/
theorem arc15OddScaledResidueMap_bijective
    (v L r : ℕ)
    (hL : L ≠ 0) :
    Function.Bijective
      (arc15OddScaledResidueMap v L r) := by
  exact
    ⟨
      arc15OddScaledResidueMap_injective
        v L r hL,
      arc15OddScaledResidueMap_surjective
        v L r hL
    ⟩

/--
Explicit residue-filling form.

For every `y < 2^r`, some index `k < 2^r`
satisfies

    (2*v+1) * G_k ≡ y  (mod 2^r).

Thus multiplication by an arbitrary odd factor does not
destroy the complete dyadic residue filling of `G_k`.
-/
theorem arc15OddScaled_hits_every_dyadic_residue
    (v L r y : ℕ)
    (hL : L ≠ 0)
    (hy : y < 2 ^ r) :
    ∃ k : ℕ,
      k < 2 ^ r
        ∧
      ((2 * v + 1) * arc15G L k) % (2 ^ r)
        =
      y := by
  let yFin : Fin (2 ^ r) :=
    ⟨y, hy⟩

  obtain ⟨k, hk⟩ :=
    arc15OddScaledResidueMap_surjective
      v L r hL yFin

  refine
    ⟨k.1, k.2, ?_⟩

  have hval :=
    congrArg Fin.val hk

  simpa
    [arc15OddScaledResidueMap, yFin]
    using hval

/--
Stage 4A handoff.

Odd scaling preserves the full dyadic residue permutation
of the ARC₁₅ geometric pumping sums.
-/
theorem arc15_stage4A_odd_scaled_residue_permutation
    (v L r : ℕ)
    (hL : L ≠ 0) :
    Function.Bijective
      (arc15OddScaledResidueMap v L r) := by
  exact
    arc15OddScaledResidueMap_bijective
      v L r hL

end ARC

import Mathlib
import ARC.ARC15Audit

set_option autoImplicit false

universe u

namespace ARC

def arc15SharpSequence
    {α : Type u}
    (x y : α) :
    ℕ → α :=
  fun n => if n = 0 then x else y

theorem arc15_sharp_even
    {α : Type u}
    (x y : α) :
    ∀ n : ℕ,
      arc15SharpSequence x y (2 * n) =
        arc15SharpSequence x y n := by
  intro n
  by_cases hn : n = 0
  · subst n
    simp [arc15SharpSequence]
  · have h2n : 2 * n ≠ 0 := by
      omega
    simp [arc15SharpSequence, hn, h2n]

theorem arc15_sharp_odd
    {α : Type u}
    (x y : α) :
    ∀ n : ℕ,
      arc15SharpSequence x y (2 * n + 1) =
        arc15SharpSequence x y (3 * n + 2) := by
  intro n
  simp [arc15SharpSequence]

theorem arc15_sharp_base15_kernel_finite
    {α : Type u}
    (x y : α) :
    ARCAutomaticByKernel 15
      (arc15SharpSequence x y) := by
  unfold ARCAutomaticByKernel

  have hfinite :
      ({arc15SharpSequence x y, (fun _ : ℕ => y)} :
        Set (ℕ → α)).Finite := by
    exact
      (Set.finite_singleton
        (fun _ : ℕ => y)).insert
        (arc15SharpSequence x y)

  refine hfinite.subset ?_
  intro v hv

  have hv' :
      ∃ e r : ℕ,
        r < 15 ^ e ∧
        ∀ n : ℕ,
          v n =
            arc15SharpSequence x y
              (15 ^ e * n + r) := by
    simpa [ARCKernel] using hv

  rcases hv' with
    ⟨e, r, hr, hvEq⟩

  by_cases hr0 : r = 0

  · have hvSharp :
        v = arc15SharpSequence x y := by
      funext n
      rw [hvEq n]

      by_cases hn : n = 0

      · subst n
        simp [arc15SharpSequence, hr0]

      · have hnpos : 0 < n :=
          Nat.pos_of_ne_zero hn

        have hpowpos : 0 < 15 ^ e := by
          positivity

        have hidxpos :
            0 < 15 ^ e * n := by
          exact Nat.mul_pos hpowpos hnpos

        have hidx :
            15 ^ e * n ≠ 0 :=
          Nat.ne_of_gt hidxpos

        simp
          [arc15SharpSequence,
           hr0,
           hn,
           hidx]

    simp [hvSharp]

  · have hrpos : 0 < r :=
      Nat.pos_of_ne_zero hr0

    have hvConst :
        v = (fun _ : ℕ => y) := by
      funext n
      rw [hvEq n]

      have hidxpos :
          0 < 15 ^ e * n + r := by
        omega

      have hidx :
          15 ^ e * n + r ≠ 0 :=
        Nat.ne_of_gt hidxpos

      unfold arc15SharpSequence
      split
      · rename_i hzero
        exact (hidx hzero).elim
      · rfl

    simp [hvConst]

theorem arc15_sharp_zero_digit_standard_automatic
    {α : Type u}
    (x y : α) :
    ARCStandardMSDZeroDigitAutomatic
      15
      (arc15SharpSequence x y) := by

  have hKernel :
      (ARCKernel 15
        (arc15SharpSequence x y)).Finite :=
    arc15_sharp_base15_kernel_finite
      x
      y

  have hMSD :
      ARCMSDAutomatic 15
        (arc15SharpSequence x y) :=
    arc_finite_kernel_implies_msd_automatic
      15
      (arc15SharpSequence x y)
      hKernel

  exact
    arc_msd_automatic_implies_zero_digit_standard
      (arc15SharpSequence x y)
      hMSD

theorem arc15_sharp_at_zero
    {α : Type u}
    (x y : α) :
    arc15SharpSequence x y 0 = x
      ∧
    (∀ n : ℕ,
      1 ≤ n →
      arc15SharpSequence x y n = y) := by
  constructor
  · simp [arc15SharpSequence]
  · intro n hn
    have hn0 : n ≠ 0 := by
      omega
    simp [arc15SharpSequence, hn0]

theorem arc15_zero_value_is_genuinely_free
    {α : Type u}
    (x y : α) :
    ARCStandardMSDZeroDigitAutomatic
        15
        (arc15SharpSequence x y)
      ∧
    (∀ n : ℕ,
      arc15SharpSequence x y (2 * n) =
        arc15SharpSequence x y n)
      ∧
    (∀ n : ℕ,
      arc15SharpSequence x y (2 * n + 1) =
        arc15SharpSequence x y (3 * n + 2))
      ∧
    arc15SharpSequence x y 0 = x
      ∧
    (∀ n : ℕ,
      1 ≤ n →
      arc15SharpSequence x y n = y) := by

  refine
    ⟨arc15_sharp_zero_digit_standard_automatic x y, ?_⟩
  refine
    ⟨arc15_sharp_even x y, ?_⟩
  refine
    ⟨arc15_sharp_odd x y, ?_⟩
  exact
    arc15_sharp_at_zero x y

#print axioms arc15_sharp_even
#print axioms arc15_sharp_odd
#print axioms arc15_sharp_base15_kernel_finite
#print axioms arc15_sharp_zero_digit_standard_automatic
#print axioms arc15_sharp_at_zero
#print axioms arc15_zero_value_is_genuinely_free

end ARC

import ARC.ARC15Stage2B_DyadicResiduePermutation

namespace ARC

/--
The shift by 2^r is positive, so k < k + 2^r.
-/
theorem arc15_lt_add_two_pow (k r : ℕ) :
    k < k + 2 ^ r := by
  have hp : 0 < 2 ^ r := pow_pos (by norm_num) r
  omega

/--
Indices k and k + 2^r are congruent modulo 2^r.
-/
theorem arc15_index_same_parent
    (k r : ℕ) :
    Nat.ModEq (2 ^ r) k (k + 2 ^ r) := by
  simp [Nat.ModEq]

/--
Indices k and k + 2^r are NOT congruent modulo 2^(r+1).
Thus they lie in different dyadic children of the same parent class.
-/
theorem arc15_index_different_children
    (k r : ℕ) :
    ¬ Nat.ModEq (2 ^ (r + 1)) k (k + 2 ^ r) := by
  intro hmod
  have hle : k ≤ k + 2 ^ r := by
    exact Nat.le_add_right k (2 ^ r)
  have hdvd :
      2 ^ (r + 1) ∣ (k + 2 ^ r) - k :=
    (Nat.modEq_iff_dvd' hle).mp hmod
  have hdvd' :
      2 ^ (r + 1) ∣ 2 ^ r := by
    simpa using hdvd
  have hpos : 0 < 2 ^ r := pow_pos (by norm_num) r
  have hlepow :
      2 ^ (r + 1) ≤ 2 ^ r :=
    Nat.le_of_dvd hpos hdvd'
  have hltpow :
      2 ^ r < 2 ^ (r + 1) := by
    rw [pow_succ]
    omega
  omega

/--
The pumping sums G_k and G_(k+2^r) lie in the same
parent residue class modulo 2^r.
-/
theorem arc15G_same_parent
    (L k r : ℕ)
    (hL : L ≠ 0) :
    Nat.ModEq (2 ^ r)
      (arc15G L k)
      (arc15G L (k + 2 ^ r)) := by
  have hlt : k < k + 2 ^ r :=
    arc15_lt_add_two_pow k r
  apply
    (arc15G_modEq_iff_index_modEq_of_lt
      L k (k + 2 ^ r) r hL hlt).2
  exact arc15_index_same_parent k r

/--
But one level deeper, G_k and G_(k+2^r) are in distinct
children modulo 2^(r+1).
-/
theorem arc15G_different_children
    (L k r : ℕ)
    (hL : L ≠ 0) :
    ¬ Nat.ModEq (2 ^ (r + 1))
      (arc15G L k)
      (arc15G L (k + 2 ^ r)) := by
  intro hG
  have hlt : k < k + 2 ^ r :=
    arc15_lt_add_two_pow k r
  have hidx :
      Nat.ModEq (2 ^ (r + 1))
        k (k + 2 ^ r) :=
    (arc15G_modEq_iff_index_modEq_of_lt
      L k (k + 2 ^ r) (r + 1) hL hlt).1 hG
  exact arc15_index_different_children k r hidx

/--
Dyadic child-separation package:
the two pumping sums are equal modulo 2^r
but unequal modulo 2^(r+1).
-/
theorem arc15G_child_separation
    (L k r : ℕ)
    (hL : L ≠ 0) :
    Nat.ModEq (2 ^ r)
        (arc15G L k)
        (arc15G L (k + 2 ^ r))
    ∧
    ¬ Nat.ModEq (2 ^ (r + 1))
        (arc15G L k)
        (arc15G L (k + 2 ^ r)) := by
  exact ⟨arc15G_same_parent L k r hL,
    arc15G_different_children L k r hL⟩

end ARC

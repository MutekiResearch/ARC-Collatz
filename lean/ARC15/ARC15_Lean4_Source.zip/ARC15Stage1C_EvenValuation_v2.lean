import ARC.ARC15Stage1B_GeometricFactorization_v2

namespace ARC

/--
Q = 15^(2L) is congruent to 1 modulo 4.
-/
theorem arc15Q_mod4_eq_one (L : ℕ) :
    arc15Q L % 4 = 1 := by
  unfold arc15Q
  have h : Nat.ModEq 4 (15 ^ 2) 1 := by
    norm_num [Nat.ModEq]
  have hp := h.pow L
  simpa [pow_mul, Nat.ModEq] using hp

/--
Therefore Q + 1 is congruent to 2 modulo 4.
-/
theorem arc15Q_add_one_mod4_eq_two (L : ℕ) :
    (arc15Q L + 1) % 4 = 2 := by
  rw [Nat.add_mod, arc15Q_mod4_eq_one]

/--
Q + 1 is divisible by 2.
-/
theorem arc15_two_dvd_Q_add_one (L : ℕ) :
    2 ∣ arc15Q L + 1 := by
  apply Nat.dvd_iff_mod_eq_zero.mpr
  rw [Nat.add_mod, arc15Q_mod2_eq_one]

/--
Q + 1 is not divisible by 4.
-/
theorem arc15_not_four_dvd_Q_add_one (L : ℕ) :
    ¬ 4 ∣ arc15Q L + 1 := by
  intro h
  have hz : (arc15Q L + 1) % 4 = 0 :=
    Nat.dvd_iff_mod_eq_zero.mp h
  rw [arc15Q_add_one_mod4_eq_two] at hz
  norm_num at hz

/--
Hence the exact 2-adic valuation of Q + 1 is 1.
-/
theorem arc15_padicValNat_Q_add_one (L : ℕ) :
    padicValNat 2 (arc15Q L + 1) = 1 := by
  have hne : arc15Q L + 1 ≠ 0 := by
    omega

  have hge :
      1 ≤ padicValNat 2 (arc15Q L + 1) := by
    rw [← Nat.pow_dvd_iff_le_padicValNat (p := 2) (k := 1)
      (by norm_num) hne]
    simpa using arc15_two_dvd_Q_add_one L

  have hnotge :
      ¬ 2 ≤ padicValNat 2 (arc15Q L + 1) := by
    intro h
    have h4 :
        2 ^ 2 ∣ arc15Q L + 1 := by
      rw [Nat.pow_dvd_iff_le_padicValNat (p := 2) (k := 2)
        (by norm_num) hne]
      exact h
    have : 4 ∣ arc15Q L + 1 := by
      norm_num at h4 ⊢
      exact h4
    exact arc15_not_four_dvd_Q_add_one L this

  omega

/--
Taking 2-adic valuations in
    (Q - 1) * G_d = Q^d - 1
gives the corresponding additive identity.
-/
theorem arc15_padicValNat_geom_factorization
    (L d : ℕ) (hL : L ≠ 0) (hd : d ≠ 0) :
    padicValNat 2 (arc15Q L ^ d - 1)
      =
    padicValNat 2 (arc15Q L - 1)
      + padicValNat 2 (arc15G L d) := by
  rw [← arc15_geom_factorization L d]
  exact padicValNat.mul
    (arc15Q_sub_one_ne_zero L hL)
    (arc15G_ne_zero L d hd)

/--
Even-index case of the central valuation identity:
    ν₂(G_d) = ν₂(d).
-/
theorem arc15_padicValNat_G_eq_of_even
    (L d : ℕ)
    (hL : L ≠ 0)
    (hd : d ≠ 0)
    (heven : Even d) :
    padicValNat 2 (arc15G L d)
      = padicValNat 2 d := by
  have hLTE := arc15_lte_even L d hL hd heven
  have hfactor :=
    arc15_padicValNat_geom_factorization L d hL hd
  have hplus :=
    arc15_padicValNat_Q_add_one L
  rw [hfactor, hplus] at hLTE
  omega

end ARC

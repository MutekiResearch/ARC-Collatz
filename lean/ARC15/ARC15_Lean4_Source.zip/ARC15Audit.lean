import Mathlib
import ARC.ARC15Final
import ARC.ARCAutomaticBridge5

set_option autoImplicit false

universe u

namespace ARC

/-!
# ARC15Audit
## Standard automaticity interfaces for the final ARC₁₅ rigidity theorem

The mathematical core of ARC₁₅ is closed in `ARC15Final.lean` in
finite-kernel form:

    ARCAutomaticByKernel 15 a
      + shortcut-Collatz invariance
      -> constant on all positive natural numbers.

This audit file closes the interface between that theorem and the usual
automata-theoretic wording "a is 15-automatic".

The existing ARC automaticity bridges provide:

* finite base-15 kernel -> finite MSD-DFAO generation;
* finite MSD-DFAO generation -> finite base-15 kernel (since 1 < 15);
* the canonical MSD interface where zero is represented by [];
* the usual canonical MSD interface where zero is represented by [0].

Thus the final ARC₁₅ theorem can be stated in each standard automaticity
interface without changing its mathematical content.
-/

/-!
============================================================
1. Finite 15-kernel <-> MSD-DFAO automaticity
============================================================
-/

/--
For base 15, finite-kernel automaticity and the ARC finite MSD-DFAO notion
are equivalent.
-/
theorem arc15_kernel_iff_msd_automatic
    {α : Type u}
    (a : ℕ → α) :
    ARCAutomaticByKernel 15 a
      ↔
    ARCMSDAutomatic 15 a := by

  constructor

  · intro hKernelAuto

    have hKernel :
        (ARCKernel 15 a).Finite := by
      simpa [ARCAutomaticByKernel] using hKernelAuto

    exact
      arc_finite_kernel_implies_msd_automatic
        15
        a
        hKernel

  · intro hMSD

    exact
      arc_msd_automatic_implies_finite_kernel
        (k := 15)
        (by norm_num)
        a
        hMSD

/-!
============================================================
2. Final theorem with explicit finite MSD-DFAO automaticity
============================================================
-/

/--
ARC₁₅ in explicit MSD-DFAO form.
-/
theorem arc15_main_msd_form
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha15 :
      ARCMSDAutomatic 15 a) :
    ∃ c : α,
      ∀ n : ℕ,
        0 < n →
        a n = c := by

  have hKernel :
      ARCAutomaticByKernel 15 a := by
    exact
      arc_msd_automatic_implies_finite_kernel
        (k := 15)
        (by norm_num)
        a
        ha15

  exact
    arc15_final
      a
      hinv
      hKernel

/-!
============================================================
3. Canonical MSD convention: zero represented by []
============================================================
-/

/--
ARC₁₅ using canonical most-significant-digit base-15 representations,
with zero represented by the empty word.
-/
theorem arc15_main_standard_msd_form
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha15 :
      ARCStandardMSDAutomatic 15 a) :
    ∃ c : α,
      ∀ n : ℕ,
        0 < n →
        a n = c := by

  have hMSD :
      ARCMSDAutomatic 15 a :=
    arc_standard_msd_automatic_implies_msd_automatic
      a
      ha15

  exact
    arc15_main_msd_form
      a
      hinv
      hMSD

/-!
============================================================
4. Usual canonical MSD convention: zero represented by [0]
============================================================
-/

/--
ARC₁₅ using the usual canonical most-significant-digit base-15 convention,
where positive integers have no leading zero and zero is represented by [0].

This is the interface closest to the ordinary paper statement
"a is a 15-automatic sequence".
-/
theorem arc15_main_zero_digit_standard_msd_form
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha15 :
      ARCStandardMSDZeroDigitAutomatic 15 a) :
    ∃ c : α,
      ∀ n : ℕ,
        0 < n →
        a n = c := by

  have hMSD :
      ARCMSDAutomatic 15 a :=
    arc_zero_digit_standard_implies_msd_automatic
      a
      ha15

  exact
    arc15_main_msd_form
      a
      hinv
      hMSD

/-!
============================================================
5. Direct equivalence with the usual [0]-canonical interface
============================================================
-/

/--
For base 15, the finite-kernel notion used by the ARC₁₅ core is equivalent
to the usual canonical MSD-DFAO notion with zero represented by [0].
-/
theorem arc15_kernel_iff_zero_digit_standard_msd
    {α : Type u}
    (a : ℕ → α) :
    ARCAutomaticByKernel 15 a
      ↔
    ARCStandardMSDZeroDigitAutomatic 15 a := by

  constructor

  · intro hKernel

    have hMSD :
        ARCMSDAutomatic 15 a :=
      (arc15_kernel_iff_msd_automatic a).1
        hKernel

    exact
      arc_msd_automatic_implies_zero_digit_standard
        a
        hMSD

  · intro hStandard

    have hMSD :
        ARCMSDAutomatic 15 a :=
      arc_zero_digit_standard_implies_msd_automatic
        a
        hStandard

    exact
      (arc15_kernel_iff_msd_automatic a).2
        hMSD

/-!
============================================================
6. Axiom audit
============================================================
-/

#print axioms arc15_kernel_iff_msd_automatic
#print axioms arc15_main_msd_form
#print axioms arc15_main_standard_msd_form
#print axioms arc15_main_zero_digit_standard_msd_form
#print axioms arc15_kernel_iff_zero_digit_standard_msd

end ARC

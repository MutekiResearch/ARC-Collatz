import ARC.ARC15Stage4A_OddScaledResiduePermutation

namespace ARC

def ARC15PumpedFamily
    (N0 d L k : ℕ) : ℕ :=
  N0 + d * arc15G L k

def ARC15DyadicChildRepresentative
    (N0 s R : ℕ)
    (r : Fin (2 ^ R)) : ℕ :=
  N0 + 2 ^ s * r.val

theorem arc15_pumpedFamily_scaled_odd
    (N0 s v L k : ℕ) :
    ARC15PumpedFamily
        N0
        (2 ^ s * (2 * v + 1))
        L
        k
      =
    N0
      + 2 ^ s
        * ((2 * v + 1) * arc15G L k) := by
  unfold ARC15PumpedFamily
  ring

theorem arc15_dyadicChildRepresentative_in_parent
    (N0 s R : ℕ)
    (r : Fin (2 ^ R)) :
    Nat.ModEq
      (2 ^ s)
      (ARC15DyadicChildRepresentative N0 s R r)
      N0 := by
  unfold ARC15DyadicChildRepresentative
  have hbase :
      Nat.ModEq
        (2 ^ s)
        (2 ^ s * r.val + N0)
        N0 :=
    Nat.ModEq.modulus_mul_add
  simpa [Nat.add_comm] using hbase

theorem arc15_dyadicChild_congruence_implies_parent
    (N0 s R : ℕ)
    (r : Fin (2 ^ R))
    {n : ℕ}
    (hn :
      Nat.ModEq
        (2 ^ (s + R))
        n
        (ARC15DyadicChildRepresentative N0 s R r)) :
    Nat.ModEq
      (2 ^ s)
      n
      N0 := by
  have hdvd :
      2 ^ s ∣ 2 ^ (s + R) := by
    refine ⟨2 ^ R, ?_⟩
    rw [pow_add]

  have hnParent :
      Nat.ModEq
        (2 ^ s)
        n
        (ARC15DyadicChildRepresentative N0 s R r) :=
    Nat.ModEq.of_dvd hdvd hn

  exact
    hnParent.trans
      (arc15_dyadicChildRepresentative_in_parent
        N0 s R r)

theorem arc15_lift_oddScaled_residue_hit
    (N0 s v L R k : ℕ)
    (r : Fin (2 ^ R))
    (hres :
      ((2 * v + 1) * arc15G L k) % (2 ^ R)
        =
      r.val) :
    Nat.ModEq
      (2 ^ (s + R))
      (ARC15PumpedFamily
        N0
        (2 ^ s * (2 * v + 1))
        L
        k)
      (ARC15DyadicChildRepresentative
        N0 s R r) := by

  have hnorm :
      Nat.ModEq
        (2 ^ R)
        ((2 * v + 1) * arc15G L k)
        r.val := by
    change
      ((2 * v + 1) * arc15G L k) % (2 ^ R)
        =
      r.val % (2 ^ R)
    simpa [Nat.mod_eq_of_lt r.isLt] using hres

  have hscaledRaw :
      Nat.ModEq
        ((2 ^ s) * (2 ^ R))
        (2 ^ s * ((2 * v + 1) * arc15G L k))
        (2 ^ s * r.val) :=
    Nat.ModEq.mul_left'
      (2 ^ s)
      hnorm

  have hscaled :
      Nat.ModEq
        (2 ^ (s + R))
        (2 ^ s * ((2 * v + 1) * arc15G L k))
        (2 ^ s * r.val) := by
    simpa [pow_add] using hscaledRaw

  have hoffset :
      Nat.ModEq
        (2 ^ (s + R))
        (N0 + 2 ^ s * ((2 * v + 1) * arc15G L k))
        (N0 + 2 ^ s * r.val) :=
    Nat.ModEq.add_left
      N0
      hscaled

  rw [arc15_pumpedFamily_scaled_odd]
  unfold ARC15DyadicChildRepresentative
  exact hoffset

theorem arc15_scaledOddPump_hits_every_child
    (N0 s v L R : ℕ)
    (hL : L ≠ 0)
    (r : Fin (2 ^ R)) :
    ∃ k : Fin (2 ^ R),
      Nat.ModEq
        (2 ^ (s + R))
        (ARC15PumpedFamily
          N0
          (2 ^ s * (2 * v + 1))
          L
          k.val)
        (ARC15DyadicChildRepresentative
          N0 s R r) := by

  rcases
    arc15OddScaled_hits_every_dyadic_residue
      v L R r.val hL r.isLt with
    ⟨k, hk, hres⟩

  let kFin : Fin (2 ^ R) := ⟨k, hk⟩

  refine ⟨kFin, ?_⟩

  exact
    arc15_lift_oddScaled_residue_hit
      N0 s v L R k r hres

theorem arc15_scaledOddPump_fills_parent_children
    (N0 s v L R : ℕ)
    (hL : L ≠ 0)
    (r : Fin (2 ^ R)) :
    (
      ∀ n : ℕ,
        Nat.ModEq
          (2 ^ (s + R))
          n
          (ARC15DyadicChildRepresentative N0 s R r)
          →
        Nat.ModEq
          (2 ^ s)
          n
          N0
    )
      ∧
    (
      ∃ k : Fin (2 ^ R),
        Nat.ModEq
          (2 ^ (s + R))
          (ARC15PumpedFamily
            N0
            (2 ^ s * (2 * v + 1))
            L
            k.val)
          (ARC15DyadicChildRepresentative
            N0 s R r)
    ) := by

  constructor

  · intro n hn
    exact
      arc15_dyadicChild_congruence_implies_parent
        N0 s R r hn

  · exact
      arc15_scaledOddPump_hits_every_child
        N0 s v L R hL r

theorem arc15_pumpedFamily_hits_every_child_of_exact_two_factor
    (N0 d L s v R : ℕ)
    (hL : L ≠ 0)
    (hd :
      d = 2 ^ s * (2 * v + 1))
    (r : Fin (2 ^ R)) :
    ∃ k : Fin (2 ^ R),
      Nat.ModEq
        (2 ^ (s + R))
        (ARC15PumpedFamily
          N0
          d
          L
          k.val)
        (ARC15DyadicChildRepresentative
          N0 s R r) := by

  rw [hd]

  exact
    arc15_scaledOddPump_hits_every_child
      N0 s v L R hL r

theorem arc15_stage4B_dyadic_parent_filling
    (N0 d L s v : ℕ)
    (hL : L ≠ 0)
    (hd :
      d = 2 ^ s * (2 * v + 1)) :
    ∀ R : ℕ,
    ∀ r : Fin (2 ^ R),
      (
        ∀ n : ℕ,
          Nat.ModEq
            (2 ^ (s + R))
            n
            (ARC15DyadicChildRepresentative N0 s R r)
            →
          Nat.ModEq
            (2 ^ s)
            n
            N0
      )
        ∧
      (
        ∃ k : Fin (2 ^ R),
          Nat.ModEq
            (2 ^ (s + R))
            (ARC15PumpedFamily
              N0
              d
              L
              k.val)
            (ARC15DyadicChildRepresentative
              N0 s R r)
      ) := by

  intro R r

  constructor

  · intro n hn
    exact
      arc15_dyadicChild_congruence_implies_parent
        N0 s R r hn

  · exact
      arc15_pumpedFamily_hits_every_child_of_exact_two_factor
        N0 d L s v R hL hd r

#print axioms arc15_pumpedFamily_scaled_odd
#print axioms arc15_dyadicChildRepresentative_in_parent
#print axioms arc15_dyadicChild_congruence_implies_parent
#print axioms arc15_lift_oddScaled_residue_hit
#print axioms arc15_scaledOddPump_hits_every_child
#print axioms arc15_scaledOddPump_fills_parent_children
#print axioms arc15_pumpedFamily_hits_every_child_of_exact_two_factor
#print axioms arc15_stage4B_dyadic_parent_filling

end ARC

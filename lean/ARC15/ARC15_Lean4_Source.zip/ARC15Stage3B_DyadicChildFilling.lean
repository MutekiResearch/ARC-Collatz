import ARC.ARC15Stage3A_DyadicChildSeparation_v2

namespace ARC

/--
If a < 2^r, then a is also below the next dyadic level 2^(r+1).
-/
theorem arc15_child0_lt_next
    (a r : ℕ)
    (ha : a < 2 ^ r) :
    a < 2 ^ (r + 1) := by
  rw [pow_succ]
  have hp : 0 < 2 ^ r := pow_pos (by norm_num) r
  omega

/--
If a < 2^r, then the second child residue a + 2^r
lies below 2^(r+1).
-/
theorem arc15_child1_lt_next
    (a r : ℕ)
    (ha : a < 2 ^ r) :
    a + 2 ^ r < 2 ^ (r + 1) := by
  rw [pow_succ]
  omega

/--
The two dyadic children a and a + 2^r are distinct.
-/
theorem arc15_children_ne
    (a r : ℕ) :
    a ≠ a + 2 ^ r := by
  have hp : 0 < 2 ^ r := pow_pos (by norm_num) r
  omega

/--
The two child residues have the same parent modulo 2^r.
-/
theorem arc15_children_same_parent
    (a r : ℕ) :
    Nat.ModEq (2 ^ r) a (a + 2 ^ r) := by
  exact arc15_index_same_parent a r

/--
Dyadic child filling.

For every parent residue a < 2^r, both children
    a
and
    a + 2^r
modulo 2^(r+1) are hit by ARC₁₅ pumping sums G_k,
with indices k lying in the complete block [0, 2^(r+1)).
-/
theorem arc15G_fills_both_children
    (L r a : ℕ)
    (hL : L ≠ 0)
    (ha : a < 2 ^ r) :
    ∃ k0 k1 : ℕ,
      k0 < 2 ^ (r + 1) ∧
      k1 < 2 ^ (r + 1) ∧
      arc15G L k0 % (2 ^ (r + 1)) = a ∧
      arc15G L k1 % (2 ^ (r + 1)) = a + 2 ^ r ∧
      k0 ≠ k1 := by
  have ha0 : a < 2 ^ (r + 1) :=
    arc15_child0_lt_next a r ha
  have ha1 : a + 2 ^ r < 2 ^ (r + 1) :=
    arc15_child1_lt_next a r ha

  obtain ⟨k0, hk0, hres0⟩ :=
    arc15G_hits_every_dyadic_residue
      L (r + 1) a hL ha0

  obtain ⟨k1, hk1, hres1⟩ :=
    arc15G_hits_every_dyadic_residue
      L (r + 1) (a + 2 ^ r) hL ha1

  have hkne : k0 ≠ k1 := by
    intro hEq
    subst k1
    have hchildEq : a = a + 2 ^ r := by
      calc
        a = arc15G L k0 % (2 ^ (r + 1)) := hres0.symm
        _ = a + 2 ^ r := hres1
    exact arc15_children_ne a r hchildEq

  exact ⟨k0, k1, hk0, hk1, hres0, hres1, hkne⟩

end ARC

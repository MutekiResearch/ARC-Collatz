import Mathlib
import ARC.ARC15Stage5C_Base15NumericPumping

set_option autoImplicit false

namespace ARC

def ARC15CanonicalPositiveMSDWord
    (L : List (Fin 15)) : Prop :=
  ∃ d : Fin 15,
    ∃ ds : List (Fin 15),
      L = d :: ds ∧ 0 < d.val

lemma arc15_canonicalPositive_ne_nil
    {L : List (Fin 15)}
    (hL : ARC15CanonicalPositiveMSDWord L) :
    L ≠ [] := by
  rcases hL with ⟨d, ds, hL, hd⟩
  rw [hL]
  simp

theorem arc15_msdValue_cons_pos
    (d : Fin 15)
    (ds : List (Fin 15))
    (hd : 0 < d.val) :
    0 < ARC15MSDValue (d :: ds) := by
  have happ := arc15_msdValue_append [d] ds
  have hsingle : ARC15MSDValue [d] = d.val := by
    simp [ARC15MSDValue]
  have hform :
      ARC15MSDValue (d :: ds)
        = d.val * 15 ^ ds.length + ARC15MSDValue ds := by
    simpa [hsingle] using happ
  have hpow : 0 < 15 ^ ds.length := by
    positivity
  have hlead : 0 < d.val * 15 ^ ds.length :=
    Nat.mul_pos hd hpow
  rw [hform]
  omega

theorem arc15_msdValue_pos_of_canonicalPositive
    {L : List (Fin 15)}
    (hL : ARC15CanonicalPositiveMSDWord L) :
    0 < ARC15MSDValue L := by
  rcases hL with ⟨d, ds, rfl, hd⟩
  exact arc15_msdValue_cons_pos d ds hd

lemma arc15_pow15_double_succ_sub_one_pos
    (n : ℕ) :
    0 < 15 ^ (2 * (n + 1)) - 1 := by
  have hpowOne : 1 ≤ 15 ^ (2 * n) := by
    have hpos : 0 < 15 ^ (2 * n) := by
      positivity
    omega
  have hgt : 1 < 15 ^ (2 * (n + 1)) := by
    calc
      1 < 225 := by norm_num
      _ ≤ 225 * 15 ^ (2 * n) := by nlinarith
      _ = 15 ^ (2 * (n + 1)) := by
        have hexp : 2 * (n + 1) = 2 * n + 2 := by
          omega
        rw [hexp, pow_add]
        norm_num
        ring
  omega

theorem arc15_doubleWordPumpIncrement_pos
    (x a b c : List (Fin 15))
    (hxCanonical : ARC15CanonicalPositiveMSDWord x)
    (hsplit : x = a ++ b ++ c)
    (hbne : b ≠ []) :
    0 < ARC15DoubleWordPumpIncrement a b c := by

  rcases hxCanonical with ⟨d, ds, hxform, hdpos⟩

  cases b with
  | nil =>
      exact (hbne rfl).elim

  | cons e es =>
      have hbaseSub :
          0 < 15 ^ (2 * (e :: es).length) - 1 := by
        change 0 < 15 ^ (2 * (es.length + 1)) - 1
        exact arc15_pow15_double_succ_sub_one_pos es.length

      have hcpow : 0 < 15 ^ c.length := by
        positivity

      cases a with
      | nil =>
          have hcons :
              e :: (es ++ c) = d :: ds := by
            calc
              e :: (es ++ c) = x := by
                simpa using hsplit.symm
              _ = d :: ds := hxform

          have hed : e = d := by
            injection hcons

          have hepos : 0 < e.val := by
            simpa [hed] using hdpos

          have hdoubleForm :
              ARC15DoubleBlock (e :: es)
                = e :: (es ++ (e :: es)) := by
            simp [ARC15DoubleBlock]

          have hdoubleVal :
              0 < ARC15MSDValue (ARC15DoubleBlock (e :: es)) := by
            rw [hdoubleForm]
            exact
              arc15_msdValue_cons_pos
                e
                (es ++ (e :: es))
                hepos

          unfold ARC15DoubleWordPumpIncrement

          have hnil :
              ARC15MSDValue ([] : List (Fin 15)) = 0 := by
            simp [ARC15MSDValue]

          rw [hnil]
          simp only [zero_mul, zero_add]

          exact Nat.mul_pos hcpow hdoubleVal

      | cons f fs =>
          have hcons :
              f :: (fs ++ e :: es ++ c) = d :: ds := by
            calc
              f :: (fs ++ e :: es ++ c) = x := by
                simpa [List.append_assoc] using hsplit.symm
              _ = d :: ds := hxform

          have hfd : f = d := by
            injection hcons

          have hfpos : 0 < f.val := by
            simpa [hfd] using hdpos

          have haval : 0 < ARC15MSDValue (f :: fs) :=
            arc15_msdValue_cons_pos f fs hfpos

          have hprod :
              0 <
                ARC15MSDValue (f :: fs)
                  * (15 ^ (2 * (e :: es).length) - 1) :=
            Nat.mul_pos haval hbaseSub

          have hinterior :
              0 <
                ARC15MSDValue (f :: fs)
                    * (15 ^ (2 * (e :: es).length) - 1)
                  + ARC15MSDValue
                      (ARC15DoubleBlock (e :: es)) := by
            omega

          unfold ARC15DoubleWordPumpIncrement
          exact Nat.mul_pos hcpow hinterior

theorem arc15_stage5D_positive_numeric_pumping_handoff
    (M : ARCMSDDFAO 15 Bool)
    [Fintype M.State]
    (s : ℕ → Bool)
    (hM : ARCMSDDFAO.Generates M s)
    (x : List (Fin 15))
    (hxCanonical : ARC15CanonicalPositiveMSDWord x)
    (hx :
      ARC15MSDValue x ∈ ARC15BoolSupport s)
    (hlen :
      Fintype.card M.State ≤ x.length) :
    ∃ a b c : List (Fin 15),
      x = a ++ b ++ c ∧
      a.length + b.length ≤ Fintype.card M.State ∧
      b ≠ [] ∧
      ARC15DoubleBlock b ≠ [] ∧
      (ARC15DoubleBlock b).length = 2 * b.length ∧
      0 < (ARC15DoubleBlock b).length ∧
      0 < ARC15DoubleWordPumpIncrement a b c ∧
      (
        ∀ n : ℕ,
          ARC15PumpedFamily
              (ARC15MSDValue (a ++ c))
              (ARC15DoubleWordPumpIncrement a b c)
              b.length
              n
            ∈ ARC15BoolSupport s
      ) ∧
      (
        ∀ n : ℕ,
          ARC15MSDValue
              (a ++ ARC5ListRepeat (ARC15DoubleBlock b) n ++ c)
            =
          ARC15PumpedFamily
              (ARC15MSDValue (a ++ c))
              (ARC15DoubleWordPumpIncrement a b c)
              b.length
              n
      ) := by

  rcases
    arc15_stage5C_base15_numeric_pumping_handoff
      M s hM x hx hlen with
    ⟨a, b, c,
     hsplit, hshort, hbne, hdoubleNe,
     hdoubleLen, hdoublePos, hpump, hvalue⟩

  have hinc :
      0 < ARC15DoubleWordPumpIncrement a b c :=
    arc15_doubleWordPumpIncrement_pos
      x a b c hxCanonical hsplit hbne

  exact
    ⟨a, b, c,
     hsplit, hshort, hbne, hdoubleNe,
     hdoubleLen, hdoublePos, hinc, hpump, hvalue⟩

#print axioms arc15_canonicalPositive_ne_nil
#print axioms arc15_msdValue_cons_pos
#print axioms arc15_msdValue_pos_of_canonicalPositive
#print axioms arc15_pow15_double_succ_sub_one_pos
#print axioms arc15_doubleWordPumpIncrement_pos
#print axioms arc15_stage5D_positive_numeric_pumping_handoff

end ARC

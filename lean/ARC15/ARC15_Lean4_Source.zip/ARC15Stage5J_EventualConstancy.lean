import Mathlib
import ARC.ARC15Stage5I_ChangeSetFinite

set_option autoImplicit false

universe u

namespace ARC

/-!
============================================================
ARC₁₅ Stage 5J
Finite change set implies eventual constancy
============================================================

Stage 5I proved that under shortcut invariance and base-15 automaticity,

    ARC15ChangeSet a = { n | a n ≠ a (n+1) }

is finite.

Stage 5J converts this purely combinatorial fact into eventual constancy.
No new shortcut dynamics are used here beyond the Stage-5I input.
-/

/-!
============================================================
1. A finite natural set has a strict upper bound
============================================================
-/

theorem arc15_finite_nat_set_strictly_bounded
    (S : Set ℕ)
    (hS : S.Finite) :
    ∃ N : ℕ,
      ∀ n : ℕ,
        n ∈ S →
        n < N := by

  have hb :
      BddAbove S :=
    hS.bddAbove

  rcases hb with
    ⟨B, hB⟩

  refine
    ⟨B + 1, ?_⟩

  intro n hn

  have hle :
      n ≤ B :=
    hB hn

  omega

/-!
============================================================
2. No changes beyond a bound
============================================================
-/

theorem arc15_eventually_no_adjacent_changes
    {α : Type u}
    (a : ℕ → α)
    (hfinite :
      (ARC15ChangeSet a).Finite) :
    ∃ N : ℕ,
      ∀ n : ℕ,
        N ≤ n →
        a n = a (n + 1) := by

  rcases
    arc15_finite_nat_set_strictly_bounded
      (ARC15ChangeSet a)
      hfinite with
    ⟨N, hN⟩

  refine
    ⟨N, ?_⟩

  intro n hn

  by_contra hne

  have hnmem :
      n ∈ ARC15ChangeSet a := by
    exact hne

  have hnlt :
      n < N :=
    hN n hnmem

  omega

/-!
============================================================
3. Adjacent equality on a tail implies constancy on that tail
============================================================
-/

theorem arc15_tail_constant_of_adjacent
    {α : Type u}
    (a : ℕ → α)
    (N : ℕ)
    (hstep :
      ∀ n : ℕ,
        N ≤ n →
        a n = a (n + 1)) :
    ∀ n : ℕ,
      N ≤ n →
      a n = a N := by

  intro n hn

  induction n, hn using Nat.le_induction with

  | base =>
      rfl

  | succ n hnN ih =>

      calc
        a (n + 1)
            =
        a n :=
          (hstep n hnN).symm

        _ =
        a N :=
          ih

/-!
============================================================
4. Finite change set implies eventual constancy
============================================================
-/

theorem arc15_eventually_constant_of_changeSet_finite
    {α : Type u}
    (a : ℕ → α)
    (hfinite :
      (ARC15ChangeSet a).Finite) :
    ∃ N : ℕ,
      ∃ c : α,
        ∀ n : ℕ,
          N ≤ n →
          a n = c := by

  rcases
    arc15_eventually_no_adjacent_changes
      a
      hfinite with
    ⟨N, hstep⟩

  refine
    ⟨N,
     a N,
     ?_⟩

  exact
    arc15_tail_constant_of_adjacent
      a
      N
      hstep

/-!
============================================================
5. ARC₁₅ hypotheses imply eventual constancy
============================================================
-/

theorem arc15_eventually_constant
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha15 :
      ARCAutomaticByKernel 15 a) :
    ∃ N : ℕ,
      ∃ c : α,
        ∀ n : ℕ,
          N ≤ n →
          a n = c := by

  exact
    arc15_eventually_constant_of_changeSet_finite
      a
      (arc15_changeSet_finite
        a
        hinv
        ha15)

/-!
============================================================
6. Stage-5J handoff
============================================================
-/

theorem arc15_stage5J_eventual_constancy
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha15 :
      ARCAutomaticByKernel 15 a) :
    ∃ N : ℕ,
      ∃ c : α,
        ∀ n : ℕ,
          N ≤ n →
          a n = c := by

  exact
    arc15_eventually_constant
      a
      hinv
      ha15

#print axioms arc15_finite_nat_set_strictly_bounded
#print axioms arc15_eventually_no_adjacent_changes
#print axioms arc15_tail_constant_of_adjacent
#print axioms arc15_eventually_constant_of_changeSet_finite
#print axioms arc15_eventually_constant
#print axioms arc15_stage5J_eventual_constancy

end ARC

import Mathlib
import ARC.ARC15Stage5H_ChangeAutomaticity
import ARC.ARC5Stage5F_CrossBaseCollision_v2

set_option autoImplicit false

universe u

namespace ARC

theorem arc15_changeSet_nowhereThick
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n) :
    ARC15DyadicallyNowhereThick
      (ARC15ChangeSet a) := by

  intro m r

  rcases
    arc5_naturalInvariantBlock_in_dyadicCylinder
      a
      hinv
      1
      m
      (r : ℤ) with
    ⟨M,
     s,
     hParent,
     _hPositive,
     hBlock⟩

  rcases
    arc5_pow5_preimage_dyadicCylinder
      0
      M
      s with
    ⟨t,
     hPreimage⟩

  refine
    ⟨M,
     t,
     ?_,
     ?_,
     ?_⟩

  · intro n hn

    have hChild :
        arcDyadicCylinder
          M
          s
          (n : ℤ) := by
      have h := hPreimage n hn
      simpa using h

    have hParentCyl :
        arcDyadicCylinder
          m
          (r : ℤ)
          (n : ℤ) :=
      hParent
        (n : ℤ)
        hChild

    have hIntModeq :
        (n : ℤ)
          ≡
        (r : ℤ)
          [ZMOD ((2 : ℤ) ^ m)] :=
      (arc5_dyadicCylinder_iff_modEq
        m
        (r : ℤ)
        (n : ℤ)).1
        hParentCyl

    apply
      Nat.ModEq.of_natCast
        (M := ℤ)

    simpa
      [AddCommGroup.modEq_iff_intModEq,
       Nat.cast_pow]
      using hIntModeq

  · refine
      ⟨t + 2 ^ M,
       ?_,
       ?_⟩

    · positivity

    · exact
        Nat.add_modEq_right

  · intro n hn

    have hChild :
        arcDyadicCylinder
          M
          s
          (n : ℤ) := by
      have h := hPreimage n hn
      simpa using h

    have hEq :
        a n = a (n + 1) := by
      have h :=
        hBlock
          n
          hChild
          1
          (by norm_num)
      simpa using h

    change ¬ (a n ≠ a (n + 1))

    exact
      fun hne =>
        hne hEq

theorem arc15_changeSet_finite
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha15 :
      ARCAutomaticByKernel 15 a) :
    (ARC15ChangeSet a).Finite := by

  exact
    arc15_changeSet_finite_of_nowhereThick
      a
      ha15
      (arc15_changeSet_nowhereThick
        a
        hinv)

theorem arc15_stage5I_change_set_finite_handoff
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha15 :
      ARCAutomaticByKernel 15 a) :
    ARCAutomaticByKernel
        15
        (ARC15ChangeIndicator a)
      ∧
    ARC15DyadicallyNowhereThick
        (ARC15ChangeSet a)
      ∧
    (ARC15ChangeSet a).Finite := by

  constructor

  · exact
      arc15_changeIndicator_automatic
        a
        ha15

  constructor

  · exact
      arc15_changeSet_nowhereThick
        a
        hinv

  · exact
      arc15_changeSet_finite
        a
        hinv
        ha15

#print axioms arc15_changeSet_nowhereThick
#print axioms arc15_changeSet_finite
#print axioms arc15_stage5I_change_set_finite_handoff

end ARC

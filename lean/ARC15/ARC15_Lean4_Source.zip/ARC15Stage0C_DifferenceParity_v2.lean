import ARC.ARC15Stage0B_GeometricSum_v2

namespace ARC

/--
Difference form of the geometric block decomposition:
G_(k+d) - G_k = Q^k * G_d.
-/
theorem arc15G_sub_eq (L k d : ℕ) :
    arc15G L (k + d) - arc15G L k
      = arc15Q L ^ k * arc15G L d := by
  rw [arc15G_add]
  omega

/--
Q^k is always odd.
-/
theorem arc15Q_pow_mod2_eq_one (L k : ℕ) :
    (arc15Q L ^ k) % 2 = 1 := by
  have hQ : arc15Q L % 2 = 1 := arc15Q_mod2_eq_one L
  induction k with
  | zero =>
      norm_num
  | succ k ih =>
      rw [pow_succ, Nat.mul_mod, hQ, ih]

/--
The parity of G_k agrees with the parity of k.
Since Q ≡ 1 (mod 2), the geometric sum behaves mod 2
like a sum of k copies of 1.
-/
theorem arc15G_mod2_eq (L k : ℕ) :
    arc15G L k % 2 = k % 2 := by
  induction k with
  | zero =>
      simp
  | succ k ih =>
      rw [arc15G_succ, Nat.add_mod, ih, arc15Q_pow_mod2_eq_one]
      omega

/--
Hence G_k is odd exactly when k is odd.
-/
theorem arc15G_odd_iff (L k : ℕ) :
    arc15G L k % 2 = 1 ↔ k % 2 = 1 := by
  rw [arc15G_mod2_eq]

/--
Likewise, G_k is even exactly when k is even.
-/
theorem arc15G_even_iff (L k : ℕ) :
    arc15G L k % 2 = 0 ↔ k % 2 = 0 := by
  rw [arc15G_mod2_eq]

/--
The difference G_(k+d) - G_k has the same parity as G_d,
because Q^k is odd.
-/
theorem arc15G_sub_mod2_eq (L k d : ℕ) :
    (arc15G L (k + d) - arc15G L k) % 2
      = arc15G L d % 2 := by
  rw [arc15G_sub_eq, Nat.mul_mod, arc15Q_pow_mod2_eq_one]
  simp

/--
Combining the previous results, the parity of the difference
G_(k+d) - G_k agrees with the parity of d.
-/
theorem arc15G_sub_mod2_eq_d (L k d : ℕ) :
    (arc15G L (k + d) - arc15G L k) % 2
      = d % 2 := by
  rw [arc15G_sub_mod2_eq, arc15G_mod2_eq]

end ARC

import ARC.ARC15Stage1D_ValuationRigidity_v2

namespace ARC

/--
For k < j, the geometric-sum difference G_j - G_k is nonzero.
-/
theorem arc15G_sub_ne_zero_of_lt
    (L k j : ℕ)
    (hkj : k < j) :
    arc15G L j - arc15G L k ≠ 0 := by
  have hd : j - k ≠ 0 := by
    omega
  have hj : k + (j - k) = j := by
    omega
  rw [← hj, arc15G_sub_eq]
  apply mul_ne_zero
  · have hQ : arc15Q L ≠ 0 := Nat.ne_of_gt (arc15Q_pos L)
    exact pow_ne_zero k hQ
  · exact arc15G_ne_zero L (j - k) hd

/--
Exact dyadic divisibility transfer.

For every r and k < j,
    2^r ∣ (G_j - G_k)  ↔  2^r ∣ (j - k).

This is the divisibility form of
    ν₂(G_j - G_k) = ν₂(j - k).
-/
theorem arc15_dyadic_dvd_sub_iff
    (L k j r : ℕ)
    (hL : L ≠ 0)
    (hkj : k < j) :
    2 ^ r ∣ (arc15G L j - arc15G L k)
      ↔
    2 ^ r ∣ (j - k) := by
  have hdiff :
      arc15G L j - arc15G L k ≠ 0 :=
    arc15G_sub_ne_zero_of_lt L k j hkj
  have hd : j - k ≠ 0 := by
    omega
  rw [Nat.pow_dvd_iff_le_padicValNat
        (p := 2) (k := r) (by norm_num) hdiff,
      Nat.pow_dvd_iff_le_padicValNat
        (p := 2) (k := r) (by norm_num) hd,
      arc15_padicValNat_G_sub_eq_of_lt L k j hL hkj]

/--
Dyadic congruence is preserved and reflected by the pumping sums.

For k < j,
    G_k ≡ G_j (mod 2^r)
if and only if
    k ≡ j (mod 2^r).
-/
theorem arc15G_modEq_iff_index_modEq_of_lt
    (L k j r : ℕ)
    (hL : L ≠ 0)
    (hkj : k < j) :
    Nat.ModEq (2 ^ r) (arc15G L k) (arc15G L j)
      ↔
    Nat.ModEq (2 ^ r) k j := by
  have hkle : k ≤ j := Nat.le_of_lt hkj
  have hGle : arc15G L k ≤ arc15G L j := by
    have hj : k + (j - k) = j := by
      omega
    rw [← hj, arc15G_add]
    omega
  rw [Nat.modEq_iff_dvd' hGle,
      Nat.modEq_iff_dvd' hkle]
  exact arc15_dyadic_dvd_sub_iff L k j r hL hkj

end ARC

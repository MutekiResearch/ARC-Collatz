import ARC.ARC15Stage1C_EvenValuation_v2

namespace ARC

/--
The exact 2-adic valuation of every nonzero pumping sum is the
same as that of its index:
    ν₂(G_d) = ν₂(d).
-/
theorem arc15_padicValNat_G_eq
    (L d : ℕ)
    (hL : L ≠ 0)
    (hd : d ≠ 0) :
    padicValNat 2 (arc15G L d)
      = padicValNat 2 d := by
  by_cases hodd : d % 2 = 1
  · exact arc15_padicValNat_G_eq_of_odd L d hodd
  · have hlt : d % 2 < 2 := Nat.mod_lt d (by norm_num)
    have hzero : d % 2 = 0 := by
      omega
    have htwo : 2 ∣ d := Nat.dvd_of_mod_eq_zero hzero
    rcases htwo with ⟨t, ht⟩
    have heven : Even d := by
      refine ⟨t, ?_⟩
      omega
    exact arc15_padicValNat_G_eq_of_even L d hL hd heven

/--
Every power Q^k is odd, hence has 2-adic valuation zero.
-/
theorem arc15_padicValNat_Q_pow_eq_zero
    (L k : ℕ) :
    padicValNat 2 (arc15Q L ^ k) = 0 := by
  rw [padicValNat.eq_zero_iff]
  apply Or.inr
  apply Or.inr
  exact arc15_not_two_dvd_of_mod2_eq_one
    (arc15Q_pow_mod2_eq_one L k)

/--
The exact 2-adic valuation of a geometric-sum difference:
    ν₂(G_(k+d) - G_k) = ν₂(d)
for every nonzero d.
-/
theorem arc15_padicValNat_G_sub_eq
    (L k d : ℕ)
    (hL : L ≠ 0)
    (hd : d ≠ 0) :
    padicValNat 2 (arc15G L (k + d) - arc15G L k)
      = padicValNat 2 d := by
  rw [arc15G_sub_eq]
  have hQpow_ne :
      arc15Q L ^ k ≠ 0 := by
    have hQ : 0 < arc15Q L := arc15Q_pos L
    exact pow_ne_zero k (Nat.ne_of_gt hQ)
  have hG_ne :
      arc15G L d ≠ 0 :=
    arc15G_ne_zero L d hd
  rw [padicValNat.mul hQpow_ne hG_ne]
  rw [arc15_padicValNat_Q_pow_eq_zero,
      arc15_padicValNat_G_eq L d hL hd]
  simp

/--
Equivalent shifted-index form:
for j > k, the difference G_j - G_k has 2-adic valuation ν₂(j-k).
-/
theorem arc15_padicValNat_G_sub_eq_of_lt
    (L k j : ℕ)
    (hL : L ≠ 0)
    (hkj : k < j) :
    padicValNat 2 (arc15G L j - arc15G L k)
      = padicValNat 2 (j - k) := by
  have hd : j - k ≠ 0 := by
    omega
  have hj : k + (j - k) = j := by
    omega
  have hcore :=
    arc15_padicValNat_G_sub_eq L k (j - k) hL hd
  simpa [hj] using hcore

end ARC

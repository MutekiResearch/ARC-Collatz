import Mathlib
import ARC.ARCProp32
import ARC.ARC2CobhamRemovalStage1_Thinness_v3

set_option autoImplicit false

universe u

namespace ARC

/-!
# ARC2 Cobham Removal — Stage 2 (v2)
## Direct finite-kernel reconnection and Cobham-free ARC2

The first Stage-2 draft used the higher-level wrapper
`arc_proposition3_2_kernel_form`.  That wrapper carries a `[Finite α]`
typeclass assumption inherited from the original automatic-sequence interface.

For the new General-ARC route this assumption is unnecessary.  The lower
theorem `arc_three_kernel_odd_finite` already proves exactly what is needed:
finite base-2 kernel of `a` implies finite base-3 kernel of the odd-indexed
subsequence, under the shortcut branch identities.

This version therefore works directly at finite-kernel level and then folds
the result back into `ARCAutomaticByKernel`.
-/

/-!
============================================================
1. Direct old-ARC2 kernel transfer
============================================================
-/

/--
A base-2 automatic shortcut-invariant coloring has a base-3 automatic
odd-indexed subsequence.

No `[Finite α]` assumption is required here.
-/
theorem arc2OddSubseq_threeAutomatic_of_twoAutomatic
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha2 :
      ARCAutomaticByKernel 2 a) :
    ARCAutomaticByKernel
      3
      (ARC2OddSubseq a) := by

  have hEven :
      ∀ n : ℕ,
        a (2 * n) = a n :=
    arc_baseFactor_even_branch
      a
      hinv

  have hOdd :
      ∀ n : ℕ,
        a (2 * n + 1) =
        a (3 * n + 2) :=
    arc_baseFactor_odd_branch
      a
      hinv

  have hK2 :
      (ARCKernel 2 a).Finite := by
    simpa [ARCAutomaticByKernel] using ha2

  have hK3Odd :
      (ARCKernel
        3
        (fun n : ℕ => a (2 * n + 1))).Finite :=
    _root_.arc_three_kernel_odd_finite
      a
      hEven
      hOdd
      hK2

  change
    ARCAutomaticByKernel
      3
      (fun n : ℕ => a (2 * n + 1))

  simpa [ARCAutomaticByKernel] using hK3Odd


/-!
============================================================
2. Cobham-free ARC2 rigidity
============================================================
-/

/--
Cobham-free finite-kernel ARC2 theorem.

A base-2 automatic shortcut-Collatz-invariant coloring is constant on all
positive integers.
-/
theorem arc2_main_kernel_form_no_cobham
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha2 :
      ARCAutomaticByKernel 2 a) :
    ∃ c : α,
      ∀ n : ℕ,
        0 < n →
        a n = c := by

  have hAuto3 :
      ARCAutomaticByKernel
        3
        (ARC2OddSubseq a) :=
    arc2OddSubseq_threeAutomatic_of_twoAutomatic
      a
      hinv
      ha2

  have hThin :
      ARCGeneralDyadicallyNowhereThick
        (ARCGeneralChangeSet
          (ARC2OddSubseq a)) :=
    arc2CobhamRemoval_stage1_thinness
      a
      hinv

  have hStep :
      ∀ n : ℕ,
        ARC2OddSubseq a (4 * n + 2) =
        ARC2OddSubseq a n :=
    arc2OddSubseq_four_mul_add_two_eq
      a
      hinv

  rcases
    arc2OddSubseq_rigidity_of_threeAutomatic_and_thin
      (ARC2OddSubseq a)
      hAuto3
      hThin
      hStep with
    ⟨c, hbConst⟩

  refine
    ⟨c, ?_⟩

  exact
    arc2_positive_constant_of_oddSubseq_constant
      a
      hinv
      c
      hbConst


/-!
============================================================
3. Stage-2 handoff
============================================================
-/

/--
Stage-2 endpoint: ARC2 in finite-kernel form with no Cobham hypothesis and
no finite-alphabet typeclass assumption.
-/
theorem arc2CobhamRemoval_stage2_final
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha2 :
      ARCAutomaticByKernel 2 a) :
    ∃ c : α,
      ∀ n : ℕ,
        0 < n →
        a n = c := by

  exact
    arc2_main_kernel_form_no_cobham
      a
      hinv
      ha2


#print axioms arc2OddSubseq_threeAutomatic_of_twoAutomatic
#print axioms arc2_main_kernel_form_no_cobham
#print axioms arc2CobhamRemoval_stage2_final

end ARC

import Mathlib
import ARC.ARC2CobhamRemovalStage2_Final_v2
import ARC.ARCFullGeneralCobhamLocalization

set_option autoImplicit false

universe u

namespace ARC

/-!
# Full General ARC — Final Cobham-Free Audit

This file independently reconstructs the full all-base rigidity theorem from
lower-level components, without invoking the packaged Stage-3 theorem
`arc_full_general_no_cobham`.

Audit structure:

1. Pure powers of two:
   descend `2^(t+1)` automaticity to base 2 and use the new Cobham-free ARC2.

2. Mixed even bases:
   factor `B = 2^s * m` with odd `m > 1`, descend to the odd part, and use
   the already verified General Odd ARC route.

3. Odd bases:
   invoke the General Odd ARC positive-rigidity theorem directly.

The final theorem has neither an `ARCCobhamPrinciple` parameter nor a
`[Finite α]` assumption.
-/

/-!
============================================================
1. Pure powers of two: re-derived directly
============================================================
-/

theorem arcFinalAudit_powTwoSucc_no_cobham
    {α : Type u}
    (a : ℕ → α)
    (t : ℕ)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (hAuto :
      ARCAutomaticByKernel
        (2 ^ (t + 1))
        a) :
    ∃ c : α,
      ∀ n : ℕ,
        0 < n →
        a n = c := by

  have hAuto2 :
      ARCAutomaticByKernel 2 a :=
    arc_powTwoSucc_automatic_descent_to_two
      a
      t
      hinv
      hAuto

  exact
    arc2CobhamRemoval_stage2_final
      a
      hinv
      hAuto2


theorem arcFinalAudit_powTwoBase_no_cobham
    {α : Type u}
    (a : ℕ → α)
    (B s : ℕ)
    (hB :
      B = 2 ^ s)
    (hs :
      0 < s)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (hAutoB :
      ARCAutomaticByKernel B a) :
    ∃ c : α,
      ∀ n : ℕ,
        0 < n →
        a n = c := by

  cases s with
  | zero =>
      omega

  | succ t =>
      have hAutoPow :
          ARCAutomaticByKernel
            (2 ^ (t + 1))
            a := by
        rw [hB] at hAutoB
        simpa [Nat.succ_eq_add_one] using hAutoB

      exact
        arcFinalAudit_powTwoSucc_no_cobham
          a
          t
          hinv
          hAutoPow


/-!
============================================================
2. Arbitrary even bases: re-derived directly
============================================================
-/

theorem arcFinalAudit_all_even_no_cobham
    {α : Type u}
    (a : ℕ → α)
    (B : ℕ)
    (hBBase :
      2 ≤ B)
    (hBEven :
      Even B)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (hAutoB :
      ARCAutomaticByKernel B a) :
    ∃ c : α,
      ∀ n : ℕ,
        0 < n →
        a n = c := by

  have hBpos :
      0 < B := by
    omega

  rcases
    arc_evenBase_factorization_exists
      B
      hBpos
      hBEven with
    ⟨s, m, hs, hmOdd, hFactor⟩

  by_cases hm1 :
      m = 1

  · subst m

    have hPow :
        B = 2 ^ s := by
      simpa using hFactor

    exact
      arcFinalAudit_powTwoBase_no_cobham
        a
        B
        s
        hPow
        hs
        hinv
        hAutoB

  · exact
      arcCobhamLoc_mixed_even_factorized_rigidity
        a
        B
        s
        m
        hFactor
        hs
        hmOdd
        hm1
        hinv
        hAutoB


/-!
============================================================
3. Full all-base theorem: independent reconstruction
============================================================
-/

theorem arcFinalAudit_full_general_no_cobham
    {α : Type u}
    (base : ℕ)
    (hbase2 :
      2 ≤ base)
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (hAuto :
      ARCAutomaticByKernel base a) :
    ∃ c : α,
      ∀ n : ℕ,
        0 < n →
        a n = c := by

  by_cases hmod :
      base % 2 = 0

  · have hEven :
        Even base := by
      refine
        ⟨base / 2, ?_⟩
      have hdiv :=
        Nat.mod_add_div base 2
      omega

    exact
      arcFinalAudit_all_even_no_cobham
        a
        base
        hbase2
        hEven
        hinv
        hAuto

  · have hlt :
        base % 2 < 2 :=
      Nat.mod_lt
        base
        (by norm_num)

    have hOddMod :
        base % 2 = 1 := by
      omega

    have hbase3 :
        3 ≤ base := by
      omega

    exact
      arcGeneral_stage14_positive_rigidity
        base
        hbase3
        hOddMod
        a
        hinv
        hAuto


/-!
============================================================
4. Representative audit smoke tests
============================================================
-/

theorem arcFinalAudit_base2
    {α : Type u}
    (a : ℕ → α)
    (hinv : ∀ n, a (arcShortcutNat n) = a n)
    (hAuto : ARCAutomaticByKernel 2 a) :
    ∃ c : α, ∀ n, 0 < n → a n = c := by
  exact
    arcFinalAudit_full_general_no_cobham
      2
      (by norm_num)
      a
      hinv
      hAuto

theorem arcFinalAudit_base3
    {α : Type u}
    (a : ℕ → α)
    (hinv : ∀ n, a (arcShortcutNat n) = a n)
    (hAuto : ARCAutomaticByKernel 3 a) :
    ∃ c : α, ∀ n, 0 < n → a n = c := by
  exact
    arcFinalAudit_full_general_no_cobham
      3
      (by norm_num)
      a
      hinv
      hAuto

theorem arcFinalAudit_base4
    {α : Type u}
    (a : ℕ → α)
    (hinv : ∀ n, a (arcShortcutNat n) = a n)
    (hAuto : ARCAutomaticByKernel 4 a) :
    ∃ c : α, ∀ n, 0 < n → a n = c := by
  exact
    arcFinalAudit_full_general_no_cobham
      4
      (by norm_num)
      a
      hinv
      hAuto

theorem arcFinalAudit_base5
    {α : Type u}
    (a : ℕ → α)
    (hinv : ∀ n, a (arcShortcutNat n) = a n)
    (hAuto : ARCAutomaticByKernel 5 a) :
    ∃ c : α, ∀ n, 0 < n → a n = c := by
  exact
    arcFinalAudit_full_general_no_cobham
      5
      (by norm_num)
      a
      hinv
      hAuto

theorem arcFinalAudit_base6
    {α : Type u}
    (a : ℕ → α)
    (hinv : ∀ n, a (arcShortcutNat n) = a n)
    (hAuto : ARCAutomaticByKernel 6 a) :
    ∃ c : α, ∀ n, 0 < n → a n = c := by
  exact
    arcFinalAudit_full_general_no_cobham
      6
      (by norm_num)
      a
      hinv
      hAuto

theorem arcFinalAudit_base7
    {α : Type u}
    (a : ℕ → α)
    (hinv : ∀ n, a (arcShortcutNat n) = a n)
    (hAuto : ARCAutomaticByKernel 7 a) :
    ∃ c : α, ∀ n, 0 < n → a n = c := by
  exact
    arcFinalAudit_full_general_no_cobham
      7
      (by norm_num)
      a
      hinv
      hAuto

theorem arcFinalAudit_base10
    {α : Type u}
    (a : ℕ → α)
    (hinv : ∀ n, a (arcShortcutNat n) = a n)
    (hAuto : ARCAutomaticByKernel 10 a) :
    ∃ c : α, ∀ n, 0 < n → a n = c := by
  exact
    arcFinalAudit_full_general_no_cobham
      10
      (by norm_num)
      a
      hinv
      hAuto

theorem arcFinalAudit_base15
    {α : Type u}
    (a : ℕ → α)
    (hinv : ∀ n, a (arcShortcutNat n) = a n)
    (hAuto : ARCAutomaticByKernel 15 a) :
    ∃ c : α, ∀ n, 0 < n → a n = c := by
  exact
    arcFinalAudit_full_general_no_cobham
      15
      (by norm_num)
      a
      hinv
      hAuto

theorem arcFinalAudit_base64
    {α : Type u}
    (a : ℕ → α)
    (hinv : ∀ n, a (arcShortcutNat n) = a n)
    (hAuto : ARCAutomaticByKernel 64 a) :
    ∃ c : α, ∀ n, 0 < n → a n = c := by
  exact
    arcFinalAudit_full_general_no_cobham
      64
      (by norm_num)
      a
      hinv
      hAuto

theorem arcFinalAudit_base100
    {α : Type u}
    (a : ℕ → α)
    (hinv : ∀ n, a (arcShortcutNat n) = a n)
    (hAuto : ARCAutomaticByKernel 100 a) :
    ∃ c : α, ∀ n, 0 < n → a n = c := by
  exact
    arcFinalAudit_full_general_no_cobham
      100
      (by norm_num)
      a
      hinv
      hAuto


/-!
============================================================
5. Axiom audit
============================================================
-/

#print axioms arcFinalAudit_powTwoSucc_no_cobham
#print axioms arcFinalAudit_powTwoBase_no_cobham
#print axioms arcFinalAudit_all_even_no_cobham
#print axioms arcFinalAudit_full_general_no_cobham
#print axioms arcFinalAudit_base2
#print axioms arcFinalAudit_base3
#print axioms arcFinalAudit_base4
#print axioms arcFinalAudit_base5
#print axioms arcFinalAudit_base6
#print axioms arcFinalAudit_base7
#print axioms arcFinalAudit_base10
#print axioms arcFinalAudit_base15
#print axioms arcFinalAudit_base64
#print axioms arcFinalAudit_base100

end ARC

import Mathlib
import ARC.ARCFullGeneralCobhamLocalization
import ARC.ARC2CobhamRemovalStage2_Final_v2

set_option autoImplicit false

universe u

namespace ARC

/-!
# ARC2 Cobham Removal — Stage 3
## Full General ARC without Cobham

Stage 2 proved ARC2 in finite-kernel form without any Cobham hypothesis:

    base-2 automatic
      + shortcut-Collatz invariance
      -> positive-domain constancy.

The previous full-general audit had already localized all remaining Cobham use
to pure powers of two.  Mixed even bases were Cobham-free by descent to their
nontrivial odd part, and odd bases were covered by the General Odd ARC theorem.

This stage replaces the last pure-power branch by the new Cobham-free ARC2
endpoint.  Consequently every base `b >= 2` is covered without
`ARCCobhamPrinciple` and without `[Finite α]`.
-/

/-!
============================================================
1. Pure powers of two without Cobham
============================================================
-/

/--
Every base `2^(t+1)` automatic shortcut-invariant coloring descends to
base 2 and is therefore rigid by the new Cobham-free ARC2 theorem.
-/
theorem arc_powTwoSucc_final_no_cobham
    {α : Type u}
    (a : ℕ → α)
    (t : ℕ)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (hAuto :
      ARCAutomaticByKernel
        (2 ^ (t + 1))
        a) :
    ∃ c : α,
      ∀ n : ℕ,
        0 < n →
        a n = c := by

  have hAuto2 :
      ARCAutomaticByKernel 2 a :=
    arc_powTwoSucc_automatic_descent_to_two
      a
      t
      hinv
      hAuto

  exact
    arc2_main_kernel_form_no_cobham
      a
      hinv
      hAuto2


/--
Pure-power wrapper for a supplied identity `B = 2^s`, `s > 0`.
-/
theorem arc_powTwoBase_final_no_cobham
    {α : Type u}
    (a : ℕ → α)
    (B s : ℕ)
    (hB :
      B = 2 ^ s)
    (hs :
      0 < s)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (hAutoB :
      ARCAutomaticByKernel B a) :
    ∃ c : α,
      ∀ n : ℕ,
        0 < n →
        a n = c := by

  cases s with
  | zero =>
      omega

  | succ t =>
      have hAutoPow :
          ARCAutomaticByKernel
            (2 ^ (t + 1))
            a := by
        rw [hB] at hAutoB
        simpa [Nat.succ_eq_add_one] using hAutoB

      exact
        arc_powTwoSucc_final_no_cobham
          a
          t
          hinv
          hAutoPow


/-!
============================================================
2. Every even base without Cobham
============================================================
-/

/--
All-even ARC rigidity with no Cobham hypothesis.

Factor the even base as

    B = 2^s * m,

with `s > 0` and odd `m`.

* `m = 1`: pure power of two, handled by the new ARC2 route.
* `m != 1`: descend to the odd part and invoke General Odd ARC through the
  already verified mixed-even theorem.
-/
theorem arc_all_even_rigidity_no_cobham
    {α : Type u}
    (a : ℕ → α)
    (B : ℕ)
    (hBBase :
      2 ≤ B)
    (hBEven :
      Even B)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (hAutoB :
      ARCAutomaticByKernel B a) :
    ∃ c : α,
      ∀ n : ℕ,
        0 < n →
        a n = c := by

  have hBpos :
      0 < B := by
    omega

  rcases
    arc_evenBase_factorization_exists
      B
      hBpos
      hBEven with
    ⟨s, m, hs, hmOdd, hFactor⟩

  by_cases hm1 :
      m = 1

  · subst m

    have hPow :
        B = 2 ^ s := by
      simpa using hFactor

    exact
      arc_powTwoBase_final_no_cobham
        a
        B
        s
        hPow
        hs
        hinv
        hAutoB

  · exact
      arcCobhamLoc_mixed_even_factorized_rigidity
        a
        B
        s
        m
        hFactor
        hs
        hmOdd
        hm1
        hinv
        hAutoB


/-!
============================================================
3. Full General ARC without Cobham
============================================================
-/

/--
Full General ARC, Cobham-free.

For every base `base >= 2`, every finite-kernel base-`base` automatic coloring
that is invariant under the shortcut Collatz map is constant on all positive
integers.

No `ARCCobhamPrinciple` hypothesis and no `[Finite α]` instance occur.
-/
theorem arc_full_general_no_cobham
    {α : Type u}
    (base : ℕ)
    (hbase2 :
      2 ≤ base)
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (hAuto :
      ARCAutomaticByKernel base a) :
    ∃ c : α,
      ∀ n : ℕ,
        0 < n →
        a n = c := by

  by_cases hmod :
      base % 2 = 0

  · have hEven :
        Even base := by
      refine
        ⟨base / 2, ?_⟩
      have hdiv :=
        Nat.mod_add_div base 2
      omega

    exact
      arc_all_even_rigidity_no_cobham
        a
        base
        hbase2
        hEven
        hinv
        hAuto

  · have hlt :
        base % 2 < 2 :=
      Nat.mod_lt
        base
        (by norm_num)

    have hOddMod :
        base % 2 = 1 := by
      omega

    have hbase3 :
        3 ≤ base := by
      omega

    exact
      arcGeneral_stage14_positive_rigidity
        base
        hbase3
        hOddMod
        a
        hinv
        hAuto


/-!
============================================================
4. Representative smoke tests
============================================================
-/

theorem arc_base2_no_cobham
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n,
        a (arcShortcutNat n) = a n)
    (hAuto :
      ARCAutomaticByKernel 2 a) :
    ∃ c : α,
      ∀ n,
        0 < n →
        a n = c := by
  exact
    arc_full_general_no_cobham
      2
      (by norm_num)
      a
      hinv
      hAuto

theorem arc_base4_no_cobham
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n,
        a (arcShortcutNat n) = a n)
    (hAuto :
      ARCAutomaticByKernel 4 a) :
    ∃ c : α,
      ∀ n,
        0 < n →
        a n = c := by
  exact
    arc_full_general_no_cobham
      4
      (by norm_num)
      a
      hinv
      hAuto

theorem arc_base6_full_no_cobham
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n,
        a (arcShortcutNat n) = a n)
    (hAuto :
      ARCAutomaticByKernel 6 a) :
    ∃ c : α,
      ∀ n,
        0 < n →
        a n = c := by
  exact
    arc_full_general_no_cobham
      6
      (by norm_num)
      a
      hinv
      hAuto

theorem arc_base7_full_no_cobham
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n,
        a (arcShortcutNat n) = a n)
    (hAuto :
      ARCAutomaticByKernel 7 a) :
    ∃ c : α,
      ∀ n,
        0 < n →
        a n = c := by
  exact
    arc_full_general_no_cobham
      7
      (by norm_num)
      a
      hinv
      hAuto

theorem arc_base64_no_cobham
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n,
        a (arcShortcutNat n) = a n)
    (hAuto :
      ARCAutomaticByKernel 64 a) :
    ∃ c : α,
      ∀ n,
        0 < n →
        a n = c := by
  exact
    arc_full_general_no_cobham
      64
      (by norm_num)
      a
      hinv
      hAuto

theorem arc_base100_full_no_cobham
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n,
        a (arcShortcutNat n) = a n)
    (hAuto :
      ARCAutomaticByKernel 100 a) :
    ∃ c : α,
      ∀ n,
        0 < n →
        a n = c := by
  exact
    arc_full_general_no_cobham
      100
      (by norm_num)
      a
      hinv
      hAuto


/-!
============================================================
5. Axiom audit
============================================================
-/

#print axioms arc_powTwoSucc_final_no_cobham
#print axioms arc_powTwoBase_final_no_cobham
#print axioms arc_all_even_rigidity_no_cobham
#print axioms arc_full_general_no_cobham
#print axioms arc_base2_no_cobham
#print axioms arc_base4_no_cobham
#print axioms arc_base6_full_no_cobham
#print axioms arc_base7_full_no_cobham
#print axioms arc_base64_no_cobham
#print axioms arc_base100_full_no_cobham

end ARC

import Mathlib
import ARC.ARC2CobhamRemovalStage0

set_option autoImplicit false

universe u

namespace ARC

/-!
# ARC2 Cobham Removal — Stage 1
## Dyadic thinness of the odd-indexed subsequence

For `b(n)=a(2n+1)`, adjacent changes of `b` compare
`a(2n+1)` with `a(2n+3)`.  The base-independent local-density theorem for a
shortcut-invariant `a`, used with gap `H = 2`, therefore gives a child dyadic
cylinder on which the odd subsequence has no adjacent changes.

No automaticity and no Cobham principle are used in this stage.
-/

/--
Inside every dyadic parent class for the odd-indexed subsequence there is a
child integer cylinder on which `a(2n+1)=a(2n+3)` identically.
-/
theorem arc2OddSubseq_local_gap_two_child
    {α : Type u}
    (a : ℕ → α)
    (hinv : ∀ n : ℕ, a (arcShortcutNat n) = a n)
    (m r : ℕ) :
    ∃ K : ℕ,
      ∃ q : ℤ,
        (∀ x : ℤ,
          arcDyadicCylinder K q x →
          arcDyadicCylinder m (r : ℤ) x)
        ∧
        (∃ n0 : ℕ,
          0 < n0 ∧
          arcDyadicCylinder K q (n0 : ℤ))
        ∧
        (∀ n : ℕ,
          arcDyadicCylinder K q (n : ℤ) →
          a (2 * n + 1) = a (2 * n + 3)) := by

  rcases
    arc5_naturalInvariantBlock_in_dyadicCylinder
      a hinv 2 (m + 1) (2 * (r : ℤ) + 1) with
    ⟨M, s, hParent, hPositive, hBlock⟩

  rcases hPositive with
    ⟨y0, hy0pos, hy0Child⟩

  have hy0Parent :
      arcDyadicCylinder
        (m + 1)
        (2 * (r : ℤ) + 1)
        (y0 : ℤ) :=
    hParent (y0 : ℤ) hy0Child

  rcases hy0Parent with
    ⟨z, hy0eq⟩

  let q : ℤ :=
    (r : ℤ) + (2 : ℤ) ^ m * z

  have hy0form :
      (y0 : ℤ) = 2 * q + 1 := by
    dsimp [q]
    rw [hy0eq, pow_succ]
    ring

  have hqParent :
      arcDyadicCylinder m (r : ℤ) q := by
    refine ⟨z, ?_⟩
    dsimp [q]

  let K : ℕ := M + m + 1

  have hBParent :
      ∀ x : ℤ,
        arcDyadicCylinder K q x →
        arcDyadicCylinder m (r : ℤ) x := by
    intro x hx
    rcases hx with ⟨w, hxw⟩
    rcases hqParent with ⟨z0, hqeq⟩
    refine ⟨z0 + (2 : ℤ) ^ (M + 1) * w, ?_⟩
    rw [hxw, hqeq]
    dsimp [K]
    simp only [pow_add, pow_succ]
    ring

  have hAffineChild :
      ∀ x : ℤ,
        arcDyadicCylinder K q x →
        arcDyadicCylinder M s (2 * x + 1) := by
    intro x hx
    rcases hx with ⟨w, hxw⟩
    rcases hy0Child with ⟨v, hy0eqChild⟩

    have hBase :
        2 * q + 1 =
        s + (2 : ℤ) ^ M * v := by
      exact hy0form.symm.trans hy0eqChild

    refine ⟨v + (2 : ℤ) ^ (m + 2) * w, ?_⟩
    rw [hxw]

    have hExp :
        K + 1 = M + (m + 2) := by
      dsimp [K]
      omega

    calc
      2 * (q + (2 : ℤ) ^ K * w) + 1
          =
        (2 * q + 1) + (2 : ℤ) ^ (K + 1) * w := by
          rw [pow_succ]
          ring

      _ =
        (s + (2 : ℤ) ^ M * v) +
          (2 : ℤ) ^ (K + 1) * w := by
          rw [hBase]

      _ =
        s +
          (2 : ℤ) ^ M *
            (v + (2 : ℤ) ^ (m + 2) * w) := by
          rw [hExp, pow_add]
          ring

  refine ⟨K, q, hBParent, ?_, ?_⟩

  · rcases arcDyadicCylinder_has_positive_nat K q with
      ⟨n0, hn0pos, hn0cyl⟩
    exact ⟨n0, hn0pos, hn0cyl⟩

  · intro n hn

    have hOddChild :
        arcDyadicCylinder
          M
          s
          ((2 * n + 1 : ℕ) : ℤ) := by
      have h := hAffineChild (n : ℤ) hn
      norm_num at h ⊢
      simpa using h

    have hEq :
        a (2 * n + 1) =
        a ((2 * n + 1) + 2) :=
      hBlock
        (2 * n + 1)
        hOddChild
        2
        (by norm_num)

    simpa [Nat.add_assoc] using hEq

/--
The adjacent-change set of `b(n)=a(2n+1)` is dyadically nowhere thick under
shortcut invariance of `a`.
-/
theorem arc2OddSubseq_changeSet_nowhereThick
    {α : Type u}
    (a : ℕ → α)
    (hinv : ∀ n : ℕ, a (arcShortcutNat n) = a n) :
    ARCGeneralDyadicallyNowhereThick
      (ARCGeneralChangeSet (ARC2OddSubseq a)) := by

  intro m r

  rcases
    arc2OddSubseq_local_gap_two_child a hinv m r with
    ⟨K, q, hParent, _hPositive, hAdjacent⟩

  rcases
    arc5_pow5_preimage_dyadicCylinder 0 K q with
    ⟨t, hPreimage⟩

  refine ⟨K, t, ?_, ?_, ?_⟩

  · intro n hn

    have hChild :
        arcDyadicCylinder K q (n : ℤ) := by
      have h := hPreimage n hn
      simpa using h

    have hParentCyl :
        arcDyadicCylinder m (r : ℤ) (n : ℤ) :=
      hParent (n : ℤ) hChild

    have hIntModeq :
        (n : ℤ) ≡ (r : ℤ)
          [ZMOD ((2 : ℤ) ^ m)] :=
      (arc5_dyadicCylinder_iff_modEq
        m (r : ℤ) (n : ℤ)).1 hParentCyl

    apply Nat.ModEq.of_natCast (M := ℤ)

    simpa
      [AddCommGroup.modEq_iff_intModEq,
       Nat.cast_pow]
      using hIntModeq

  · refine ⟨t + 2 ^ K, ?_, ?_⟩
    · positivity
    · exact Nat.add_modEq_right

  · intro n hn

    have hChild :
        arcDyadicCylinder K q (n : ℤ) := by
      have h := hPreimage n hn
      simpa using h

    have hEq :
        a (2 * n + 1) = a (2 * n + 3) :=
      hAdjacent n hChild

    change
      ¬ (ARC2OddSubseq a n ≠ ARC2OddSubseq a (n + 1))

    intro hne
    apply hne

    unfold ARC2OddSubseq

    simpa [Nat.mul_add, Nat.add_assoc] using hEq

/-- Stage-1 public handoff. -/
theorem arc2CobhamRemoval_stage1_thinness
    {α : Type u}
    (a : ℕ → α)
    (hinv : ∀ n : ℕ, a (arcShortcutNat n) = a n) :
    ARCGeneralDyadicallyNowhereThick
      (ARCGeneralChangeSet (ARC2OddSubseq a)) := by
  exact arc2OddSubseq_changeSet_nowhereThick a hinv

#print axioms arc2OddSubseq_local_gap_two_child
#print axioms arc2OddSubseq_changeSet_nowhereThick
#print axioms arc2CobhamRemoval_stage1_thinness

end ARC

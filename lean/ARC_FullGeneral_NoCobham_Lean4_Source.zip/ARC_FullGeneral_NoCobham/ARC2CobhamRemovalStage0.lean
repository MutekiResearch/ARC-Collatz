import Mathlib
import ARC.ARCBaseFactorDescentStage2
import ARC.ARCGeneralStage13_EventualConstancy

set_option autoImplicit false

universe u

namespace ARC

def ARC2OddSubseq
    {α : Type u}
    (a : ℕ → α) :
    ℕ → α :=
  fun n => a (2 * n + 1)

theorem arc2OddSubseq_four_mul_eq_three_mul
    {α : Type u}
    (a : ℕ → α)
    (hinv : ∀ n : ℕ, a (arcShortcutNat n) = a n)
    (n : ℕ) :
    ARC2OddSubseq a (4 * n) = ARC2OddSubseq a (3 * n) := by
  have hEven : ∀ n : ℕ, a (2 * n) = a n :=
    arc_baseFactor_even_branch a hinv
  have hOdd : ∀ n : ℕ, a (2 * n + 1) = a (3 * n + 2) :=
    arc_baseFactor_odd_branch a hinv
  calc
    ARC2OddSubseq a (4 * n)
        = a (3 * (4 * n) + 2) := by
            simpa [ARC2OddSubseq] using hOdd (4 * n)
    _ = a (2 * (6 * n + 1)) := by
          congr 1
          ring
    _ = a (6 * n + 1) := hEven (6 * n + 1)
    _ = ARC2OddSubseq a (3 * n) := by
          unfold ARC2OddSubseq
          congr 1
          ring

theorem arc2OddSubseq_four_mul_add_two_eq
    {α : Type u}
    (a : ℕ → α)
    (hinv : ∀ n : ℕ, a (arcShortcutNat n) = a n)
    (n : ℕ) :
    ARC2OddSubseq a (4 * n + 2) = ARC2OddSubseq a n := by
  have hEven : ∀ n : ℕ, a (2 * n) = a n :=
    arc_baseFactor_even_branch a hinv
  have hOdd : ∀ n : ℕ, a (2 * n + 1) = a (3 * n + 2) :=
    arc_baseFactor_odd_branch a hinv
  calc
    ARC2OddSubseq a (4 * n + 2)
        = a (3 * (4 * n + 2) + 2) := by
            simpa [ARC2OddSubseq] using hOdd (4 * n + 2)
    _ = a (2 * (6 * n + 4)) := by
          congr 1
          ring
    _ = a (6 * n + 4) := hEven (6 * n + 4)
    _ = a (2 * (3 * n + 2)) := by
          congr 1
          ring
    _ = a (3 * n + 2) := hEven (3 * n + 2)
    _ = a (2 * n + 1) := (hOdd n).symm
    _ = ARC2OddSubseq a n := rfl

def ARC2OddLift : ℕ → ℕ → ℕ
  | 0, n => n
  | k + 1, n => 4 * ARC2OddLift k n + 2

theorem arc2OddLift_lower
    (k n : ℕ) :
    k ≤ ARC2OddLift k n := by
  induction k with
  | zero =>
      simp [ARC2OddLift]
  | succ k ih =>
      change k + 1 ≤ 4 * ARC2OddLift k n + 2
      omega

theorem arc2OddLift_color_invariant
    {α : Type u}
    (b : ℕ → α)
    (hstep : ∀ n : ℕ, b (4 * n + 2) = b n) :
    ∀ k n : ℕ, b (ARC2OddLift k n) = b n := by
  intro k
  induction k with
  | zero =>
      intro n
      rfl
  | succ k ih =>
      intro n
      change b (4 * ARC2OddLift k n + 2) = b n
      calc
        b (4 * ARC2OddLift k n + 2)
            = b (ARC2OddLift k n) := hstep (ARC2OddLift k n)
        _ = b n := ih n

theorem arc2OddSubseq_constant_of_eventual
    {α : Type u}
    (b : ℕ → α)
    (hstep : ∀ n : ℕ, b (4 * n + 2) = b n)
    (N : ℕ)
    (c : α)
    (htail : ∀ n : ℕ, N ≤ n → b n = c) :
    ∀ n : ℕ, b n = c := by
  intro n
  let x : ℕ := ARC2OddLift N n
  have hxLarge : N ≤ x := by
    dsimp [x]
    exact arc2OddLift_lower N n
  have hxColor : b x = b n := by
    dsimp [x]
    exact arc2OddLift_color_invariant b hstep N n
  calc
    b n = b x := hxColor.symm
    _ = c := htail x hxLarge

theorem arc2OddSubseq_rigidity_of_threeAutomatic_and_thin
    {α : Type u}
    (b : ℕ → α)
    (hAuto3 : ARCAutomaticByKernel 3 b)
    (hthin :
      ARCGeneralDyadicallyNowhereThick
        (ARCGeneralChangeSet b))
    (hstep : ∀ n : ℕ, b (4 * n + 2) = b n) :
    ∃ c : α, ∀ n : ℕ, b n = c := by
  have hfinite :
      (ARCGeneralChangeSet b).Finite :=
    arcGeneral_changeSet_finite_of_nowhereThick
      3
      (by norm_num)
      (by norm_num)
      b
      hAuto3
      hthin
  rcases
    arcGeneral_eventually_constant_of_changeSet_finite
      b
      hfinite with
    ⟨N, c, htail⟩
  exact
    ⟨c,
     arc2OddSubseq_constant_of_eventual
       b hstep N c htail⟩

theorem arc2_positive_constant_of_oddSubseq_constant
    {α : Type u}
    (a : ℕ → α)
    (hinv : ∀ n : ℕ, a (arcShortcutNat n) = a n)
    (c : α)
    (hb : ∀ n : ℕ, ARC2OddSubseq a n = c) :
    ∀ n : ℕ, 0 < n → a n = c := by
  have hEven : ∀ n : ℕ, a (2 * n) = a n :=
    arc_baseFactor_even_branch a hinv
  intro n
  induction n using Nat.strong_induction_on with
  | h n ih =>
      intro hn
      by_cases hmod : n % 2 = 0
      · have hmoddiv := Nat.mod_add_div n 2
        have hrepr : n = 2 * (n / 2) := by
          omega
        have hhalfpos : 0 < n / 2 := by
          omega
        have hhalflt : n / 2 < n := by
          omega
        calc
          a n = a (2 * (n / 2)) := by
            exact congrArg a hrepr
          _ = a (n / 2) := hEven (n / 2)
          _ = c := ih (n / 2) hhalflt hhalfpos
      · have hmodlt : n % 2 < 2 :=
          Nat.mod_lt n (by norm_num)
        have hmodone : n % 2 = 1 := by
          omega
        let m : ℕ := n / 2
        have hmoddiv := Nat.mod_add_div n 2
        have hrepr : n = 2 * m + 1 := by
          dsimp [m]
          omega
        calc
          a n = a (2 * m + 1) := by
            exact congrArg a hrepr
          _ = ARC2OddSubseq a m := rfl
          _ = c := hb m

def ARC2OddSubseqThinnessPrinciple : Prop :=
  ∀ {α : Type u},
    ∀ b : ℕ → α,
      (∀ n : ℕ, b (4 * n) = b (3 * n)) →
      (∀ n : ℕ, b (4 * n + 2) = b n) →
      ARCGeneralDyadicallyNowhereThick
        (ARCGeneralChangeSet b)

theorem arc2_positive_rigidity_of_oddSubseq_threeAutomatic_and_thinness
    {α : Type u}
    (hThin : ARC2OddSubseqThinnessPrinciple.{u})
    (a : ℕ → α)
    (hinv : ∀ n : ℕ, a (arcShortcutNat n) = a n)
    (hAuto3 :
      ARCAutomaticByKernel
        3
        (ARC2OddSubseq a)) :
    ∃ c : α, ∀ n : ℕ, 0 < n → a n = c := by
  have h43 :
      ∀ n : ℕ,
        ARC2OddSubseq a (4 * n) =
        ARC2OddSubseq a (3 * n) :=
    arc2OddSubseq_four_mul_eq_three_mul a hinv
  have h42 :
      ∀ n : ℕ,
        ARC2OddSubseq a (4 * n + 2) =
        ARC2OddSubseq a n :=
    arc2OddSubseq_four_mul_add_two_eq a hinv
  have hthin :
      ARCGeneralDyadicallyNowhereThick
        (ARCGeneralChangeSet
          (ARC2OddSubseq a)) :=
    hThin
      (α := α)
      (ARC2OddSubseq a)
      h43
      h42
  rcases
    arc2OddSubseq_rigidity_of_threeAutomatic_and_thin
      (ARC2OddSubseq a)
      hAuto3
      hthin
      h42 with
    ⟨c, hb⟩
  exact
    ⟨c,
     arc2_positive_constant_of_oddSubseq_constant
       a hinv c hb⟩

#print axioms arc2OddSubseq_four_mul_eq_three_mul
#print axioms arc2OddSubseq_four_mul_add_two_eq
#print axioms arc2OddLift_lower
#print axioms arc2OddLift_color_invariant
#print axioms arc2OddSubseq_constant_of_eventual
#print axioms arc2OddSubseq_rigidity_of_threeAutomatic_and_thin
#print axioms arc2_positive_constant_of_oddSubseq_constant
#print axioms arc2_positive_rigidity_of_oddSubseq_threeAutomatic_and_thinness

end ARC

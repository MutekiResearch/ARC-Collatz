import Mathlib
import ARC.ARCProp32

set_option autoImplicit false

universe u


/-!
# ARC automaticity bridge — Part 1

We formalize the first direction of the standard
finite-kernel characterization:

    finite k-kernel
      ⇒
    finite-state output machine.

The kernel transition is

    u(n) ↦ u(k n + d)

for a digit d < k.

States are the members of K_k(a).

Digits are read least-significant first.
This agrees naturally with Nat.ofDigits, whose digit list
is little-endian.
-/



/-!
============================================================
1. Residual sequence
============================================================
-/


def ARCResidual
    {α : Type u}
    (k d : ℕ)
    (u : ℕ → α) :

    ℕ → α :=

  fun n =>
    u (k * n + d)



/-!
============================================================
2. Closure of the k-kernel under digit transitions
============================================================
-/


theorem arc_kernel_residual_mem
    {α : Type u}

    (k : ℕ)
    (a u : ℕ → α)

    (hu :
      u ∈ ARCKernel k a)

    (d : ℕ)
    (hd :
      d < k) :

    ARCResidual
      k
      d
      u
      ∈
    ARCKernel
      k
      a := by


  have hu' :

      ∃ e r : ℕ,

        r < k ^ e
          ∧

        ∀ n : ℕ,

          u n
            =
          a (k ^ e * n + r) := by

    simpa [ARCKernel] using hu


  rcases hu' with
    ⟨e, r, hr, hu_eq⟩


  change
    ∃ E R : ℕ,

      R < k ^ E
        ∧

      ∀ n : ℕ,

        ARCResidual k d u n
          =
        a (k ^ E * n + R)


  refine
    ⟨e + 1, k ^ e * d + r, ?_, ?_⟩


  ·
    have hd_succ :
        d + 1 ≤ k := by

      omega


    have hfirst :
        k ^ e * d + r
          <
        k ^ e * d + k ^ e :=

      Nat.add_lt_add_left
        hr
        (k ^ e * d)


    have hrewrite :
        k ^ e * d + k ^ e
          =
        k ^ e * (d + 1) := by

      ring


    have hsecond :
        k ^ e * (d + 1)
          ≤
        k ^ e * k :=

      Nat.mul_le_mul_left
        (k ^ e)
        hd_succ


    calc

      k ^ e * d + r

          <
        k ^ e * d + k ^ e :=

        hfirst


      _ =
        k ^ e * (d + 1) :=

        hrewrite


      _ ≤
        k ^ e * k :=

        hsecond


      _ =
        k ^ (e + 1) := by

        rw [pow_succ]


  ·
    intro n


    calc

      ARCResidual k d u n

          =
        u (k * n + d) := by

        rfl


      _ =
        a (
          k ^ e * (k * n + d)
            +
          r
        ) :=

        hu_eq
          (k * n + d)


      _ =
        a (
          k ^ (e + 1) * n
            +
          (k ^ e * d + r)
        ) := by

        congr 1

        rw [pow_succ]

        ring



/-!
============================================================
3. Kernel state space
============================================================
-/


abbrev ARCKernelState
    {α : Type u}

    (k : ℕ)
    (a : ℕ → α) :

    Type u :=

  {
    u : ℕ → α //
      u ∈ ARCKernel k a
  }



/-!
============================================================
4. Initial state
============================================================
-/


def arcKernelStart
    {α : Type u}

    (k : ℕ)
    (a : ℕ → α) :

    ARCKernelState
      k
      a :=

  ⟨
    a,

    by

      change
        ∃ e r : ℕ,

          r < k ^ e
            ∧

          ∀ n : ℕ,

            a n
              =
            a (k ^ e * n + r)


      refine
        ⟨0, 0, ?_, ?_⟩


      ·
        simp


      ·
        intro n

        simp
  ⟩



/-!
============================================================
5. Kernel transition
============================================================
-/


def arcKernelStep
    {α : Type u}

    (k : ℕ)
    (a : ℕ → α)

    (q :
      ARCKernelState
        k
        a)

    (d :
      Fin k) :

    ARCKernelState
      k
      a :=

  ⟨
    ARCResidual
      k
      d.val
      q.val,

    arc_kernel_residual_mem
      k
      a
      q.val
      q.property
      d.val
      d.isLt
  ⟩



/-!
============================================================
6. State output
============================================================
-/


def arcKernelOutput
    {α : Type u}

    {k : ℕ}
    {a : ℕ → α}

    (q :
      ARCKernelState
        k
        a) :

    α :=

  q.val 0



/-!
============================================================
7. Finite-state output machine
============================================================
-/


structure ARCLSDDFAO
    (k : ℕ)
    (α : Type u) where

  State :
    Type u

  stateFinite :
    Finite State

  start :
    State

  step :
    State → Fin k → State

  output :
    State → α



namespace ARCLSDDFAO


/-!
============================================================
8. Evaluation of a digit list
============================================================
-/


def eval
    {k : ℕ}
    {α : Type u}

    (M :
      ARCLSDDFAO
        k
        α) :

    M.State
      →
    List (Fin k)
      →
    M.State

  | q, [] =>

      q


  | q, d :: ds =>

      eval
        M
        (M.step q d)
        ds



/-!
============================================================
9. Generation property
============================================================
-/


def Generates
    {k : ℕ}
    {α : Type u}

    (M :
      ARCLSDDFAO
        k
        α)

    (a :
      ℕ → α) :

    Prop :=

  ∀ L : List (Fin k),

    M.output
      (
        M.eval
          M.start
          L
      )

      =

    a (
      Nat.ofDigits
        k
        (
          L.map
            (fun d =>
              d.val)
        )
    )


end ARCLSDDFAO



/-!
============================================================
10. Construct the kernel machine
============================================================
-/


def arcKernelDFAO
    {α : Type u}

    (k : ℕ)
    (a : ℕ → α)

    (ha :
      (ARCKernel k a).Finite) :

    ARCLSDDFAO
      k
      α :=

  {
    State :=
      ARCKernelState
        k
        a

    stateFinite := by

      exact
        ha.to_subtype

    start :=
      arcKernelStart
        k
        a

    step :=
      arcKernelStep
        k
        a

    output :=
      arcKernelOutput
  }



/-!
============================================================
11. Semantic invariant of the kernel automaton

After reading a little-endian digit list L from state q,

the resulting state represents

    n ↦ q(k^|L| n + ofDigits(k,L)).
============================================================
-/


theorem arc_kernel_dfao_eval_value
    {α : Type u}

    (k : ℕ)
    (a : ℕ → α)

    (ha :
      (ARCKernel k a).Finite)

    (q :
      ARCKernelState
        k
        a)

    (L :
      List (Fin k))

    (n :
      ℕ) :

    (
      ARCLSDDFAO.eval
        (arcKernelDFAO
          k
          a
          ha)
        q
        L
    ).val n

      =

    q.val (
      k ^ L.length * n
        +
      Nat.ofDigits
        k
        (
          L.map
            (fun d =>
              d.val)
        )
    ) := by


  induction L generalizing q with


  | nil =>

      simp [
        ARCLSDDFAO.eval
      ]


  | cons d ds ih =>


      /-
      Instead of asking rw to unfold the recursive
      equation, we state explicitly what evaluation of
      a nonempty list means.

      This avoids the equation-theorem rewriting problem
      reported by Lean.
      -/

      change

        (
          ARCLSDDFAO.eval
            (arcKernelDFAO
              k
              a
              ha)
            (arcKernelStep
              k
              a
              q
              d)
            ds
        ).val n

          =

        q.val (
          k ^ (d :: ds).length * n
            +
          Nat.ofDigits
            k
            (
              (d :: ds).map
                (fun x =>
                  x.val)
            )
        )


      have hih :=

        ih
          (q :=
            arcKernelStep
              k
              a
              q
              d)


      rw [hih]


      change

        q.val (
          k
            *
          (
            k ^ ds.length * n
              +
            Nat.ofDigits
              k
              (
                ds.map
                  (fun x =>
                    x.val)
              )
          )
            +
          d.val
        )

          =

        q.val (
          k ^ (d :: ds).length * n
            +
          Nat.ofDigits
            k
            (
              (d :: ds).map
                (fun x =>
                  x.val)
            )
        )


      congr 1


      simp only [
        List.length_cons,
        List.map_cons,
        Nat.ofDigits_cons
      ]


      rw [pow_succ]


      ring



/-!
============================================================
12. Correctness from the initial state
============================================================
-/


theorem arc_kernel_dfao_generates
    {α : Type u}

    (k : ℕ)
    (a : ℕ → α)

    (ha :
      (ARCKernel k a).Finite) :

    ARCLSDDFAO.Generates
      (arcKernelDFAO
        k
        a
        ha)
      a := by


  intro L


  change

    (
      ARCLSDDFAO.eval
        (arcKernelDFAO
          k
          a
          ha)
        (arcKernelStart
          k
          a)
        L
    ).val 0

      =

    a (
      Nat.ofDigits
        k
        (
          L.map
            (fun d =>
              d.val)
        )
    )


  have h :=

    arc_kernel_dfao_eval_value
      k
      a
      ha
      (arcKernelStart
        k
        a)
      L
      0


  simpa [
    arcKernelStart
  ] using
    h



/-!
============================================================
13. LSD-first automaticity
============================================================
-/


def ARCLSDAutomatic
    {α : Type u}

    (k : ℕ)
    (a : ℕ → α) :

    Prop :=

  ∃ M :
      ARCLSDDFAO
        k
        α,

    M.Generates
      a



/-!
============================================================
14. Finite kernel ⇒ LSD-first finite-state generation
============================================================
-/


theorem arc_finite_kernel_implies_lsd_automatic
    {α : Type u}

    (k : ℕ)
    (a : ℕ → α)

    (ha :
      (ARCKernel k a).Finite) :

    ARCLSDAutomatic
      k
      a := by


  refine
    ⟨
      arcKernelDFAO
        k
        a
        ha,
      ?_
    ⟩


  exact
    arc_kernel_dfao_generates
      k
      a
      ha



/-!
============================================================
15. Axiom audit
============================================================
-/


#print axioms arc_kernel_residual_mem

#print axioms arc_kernel_dfao_eval_value

#print axioms arc_kernel_dfao_generates

#print axioms arc_finite_kernel_implies_lsd_automatic

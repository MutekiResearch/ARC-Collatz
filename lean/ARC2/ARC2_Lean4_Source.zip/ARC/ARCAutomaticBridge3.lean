import Mathlib
import ARC.ARCMainBridge

universe u


/-
  ============================================================
  ARC Automatic Bridge 3
  ============================================================

  Goal:

      MSD automatic
          ↓
      LSD automatic
          ↓
      finite k-kernel

  and finally

      MSD 2-automatic
          ↓
      kernel-form ARC main theorem
          ↓
      constancy on positive integers

  Cobham remains an explicit hypothesis.
-/


/-
  ============================================================
  1. Append law for MSD evaluation
  ============================================================
-/

theorem arc_msd_eval_append
    {k : ℕ}
    {α : Type u}
    (M : ARCMSDDFAO k α)
    (q : M.State)
    (L₁ L₂ : List (Fin k)) :
    ARCMSDDFAO.eval
        M
        q
        (L₁ ++ L₂)
      =
    ARCMSDDFAO.eval
        M
        (ARCMSDDFAO.eval M q L₁)
        L₂ := by

  induction L₁ generalizing q with

  | nil =>
      rfl

  | cons d ds ih =>

      simp only [
        List.cons_append,
        ARCMSDDFAO.eval
      ]

      exact
        ih
          (M.step q d)


/-
  ============================================================
  2. Reverse an MSD machine into an LSD machine
  ============================================================
-/

def arcReverseMSDDFAO
    {k : ℕ}
    {α : Type u}
    (M : ARCMSDDFAO k α) :
    ARCLSDDFAO k α := by

  letI :
      Finite M.State :=
    M.stateFinite

  exact
    {
      State :=
        M.State → M.State

      stateFinite := by
        infer_instance

      start :=
        fun q => q

      step :=
        fun F d q =>
          F (M.step q d)

      output :=
        fun F =>
          M.output (F M.start)
    }


/-
  ============================================================
  3. One-step rule for the reversed MSD machine
  ============================================================
-/

theorem arc_reverse_msd_machine_step
    {k : ℕ}
    {α : Type u}
    (M : ARCMSDDFAO k α)
    (F : M.State → M.State)
    (d : Fin k) :
    (arcReverseMSDDFAO M).step F d
      =
    fun q =>
      F (M.step q d) := by

  funext q

  simp [arcReverseMSDDFAO]


/-
  ============================================================
  4. Semantic invariant of the reversed MSD machine
  ============================================================
-/

theorem arc_reverse_msd_machine_eval
    {k : ℕ}
    {α : Type u}
    (M : ARCMSDDFAO k α)
    (F : M.State → M.State)
    (L : List (Fin k))
    (q : M.State) :
    (
      ARCLSDDFAO.eval
        (arcReverseMSDDFAO M)
        F
        L
    ) q
      =
    F (
      ARCMSDDFAO.eval
        M
        q
        L.reverse
    ) := by

  induction L generalizing F q with

  | nil =>

      rfl

  | cons d ds ih =>

      simp only [ARCLSDDFAO.eval]

      rw [
        arc_reverse_msd_machine_step
          M
          F
          d
      ]

      rw [ih]

      rw [List.reverse_cons]

      rw [
        arc_msd_eval_append
          M
          q
          ds.reverse
          [d]
      ]

      rfl


/-
  ============================================================
  5. The reversed MSD machine generates the same sequence
  ============================================================
-/

theorem arc_reverse_msd_machine_generates
    {k : ℕ}
    {α : Type u}
    (M : ARCMSDDFAO k α)
    (a : ℕ → α)
    (hM :
      ARCMSDDFAO.Generates
        M
        a) :
    ARCLSDDFAO.Generates
      (arcReverseMSDDFAO M)
      a := by

  intro L

  change
    M.output
      (
        (
          ARCLSDDFAO.eval
            (arcReverseMSDDFAO M)
            (fun q => q)
            L
        )
        M.start
      )
      =
    a (
      Nat.ofDigits
        k
        (
          L.map
            (fun d =>
              d.val)
        )
    )

  have hrev :=
    arc_reverse_msd_machine_eval
      M
      (fun q => q)
      L
      M.start

  rw [hrev]

  have hold :=
    hM
      L.reverse

  simpa using
    hold


/-
  ============================================================
  6. MSD automatic ⇒ LSD automatic
  ============================================================
-/

theorem arc_msd_automatic_implies_lsd_automatic
    {k : ℕ}
    {α : Type u}
    (a : ℕ → α)
    (ha :
      ARCMSDAutomatic
        k
        a) :
    ARCLSDAutomatic
      k
      a := by

  rcases ha with
    ⟨M, hM⟩

  refine
    ⟨
      arcReverseMSDDFAO M,
      ?_
    ⟩

  exact
    arc_reverse_msd_machine_generates
      M
      a
      hM


/-
  ============================================================
  7. Fixed-length finite digit lists
  ============================================================
-/

theorem arc_nat_lt_pow_succ
    {k : ℕ}
    (hk : 1 < k)
    (n : ℕ) :
    n < k ^ (n + 1) := by

  have h₁ :
      n < k ^ n :=
    Nat.lt_pow_self hk

  have h₂ :
      k ^ n < k ^ (n + 1) :=
    Nat.pow_lt_pow_succ hk

  exact
    lt_trans
      h₁
      h₂


def arcFinDigitsAppend
    {k : ℕ}
    (hk : 1 < k)
    (l n : ℕ)
    (hn : n < k ^ l) :
    List (Fin k) :=

  (k.digitsAppend l n).attach.map
    (
      fun x =>
        ⟨
          x.val,
          Nat.lt_of_mem_digitsAppend
            hk
            l
            x.val
            x.property
        ⟩
    )


theorem arc_fin_digits_append_vals
    {k : ℕ}
    (hk : 1 < k)
    (l n : ℕ)
    (hn : n < k ^ l) :
    (
      arcFinDigitsAppend
        hk
        l
        n
        hn
    ).map
      (fun d =>
        d.val)
      =
    k.digitsAppend l n := by

  simp [
    arcFinDigitsAppend,
    List.map_map
  ]


theorem arc_fin_digits_append_length
    {k : ℕ}
    (hk : 1 < k)
    (l n : ℕ)
    (hn : n < k ^ l) :
    (
      arcFinDigitsAppend
        hk
        l
        n
        hn
    ).length
      =
    l := by

  simp [
    arcFinDigitsAppend,
    Nat.length_digitsAppend
      hk
      l
      hn
  ]


theorem arc_fin_digits_append_ofDigits
    {k : ℕ}
    (hk : 1 < k)
    (l n : ℕ)
    (hn : n < k ^ l) :
    Nat.ofDigits
        k
        (
          (
            arcFinDigitsAppend
              hk
              l
              n
              hn
          ).map
            (fun d =>
              d.val)
        )
      =
    n := by

  rw [
    arc_fin_digits_append_vals
      hk
      l
      n
      hn
  ]

  unfold Nat.digitsAppend

  rw [
    Nat.ofDigits_append_replicate_zero
  ]

  exact
    Nat.ofDigits_digits
      k
      n


def arcNatFinDigits
    {k : ℕ}
    (hk : 1 < k)
    (n : ℕ) :
    List (Fin k) :=

  arcFinDigitsAppend
    hk
    (n + 1)
    n
    (
      arc_nat_lt_pow_succ
        hk
        n
    )


theorem arc_nat_fin_digits_ofDigits
    {k : ℕ}
    (hk : 1 < k)
    (n : ℕ) :
    Nat.ofDigits
        k
        (
          (
            arcNatFinDigits
              hk
              n
          ).map
            (fun d =>
              d.val)
        )
      =
    n := by

  simpa [
    arcNatFinDigits
  ] using
    arc_fin_digits_append_ofDigits
      hk
      (n + 1)
      n
      (
        arc_nat_lt_pow_succ
          hk
          n
      )


/-
  ============================================================
  8. A residual sequence determined by one LSD state
  ============================================================
-/

def arcLSDStateSequence
    {k : ℕ}
    {α : Type u}
    (M : ARCLSDDFAO k α)
    (hk : 1 < k)
    (q : M.State) :
    ℕ → α :=

  fun n =>
    M.output
      (
        M.eval
          q
          (
            arcNatFinDigits
              hk
              n
          )
      )


/-
  ============================================================
  9. Every k-kernel element comes from one machine state
  ============================================================
-/

theorem arc_kernel_member_eq_lsd_state_sequence
    {k : ℕ}
    {α : Type u}
    (hk : 1 < k)
    (M : ARCLSDDFAO k α)
    (a : ℕ → α)
    (hM :
      ARCLSDDFAO.Generates
        M
        a)
    (u : ℕ → α)
    (hu :
      u ∈ ARCKernel k a) :
    ∃ q : M.State,
      u =
        arcLSDStateSequence
          M
          hk
          q := by

  have hu' :
      ∃ e r : ℕ,
        r < k ^ e
          ∧
        ∀ n : ℕ,
          u n =
            a (
              k ^ e * n + r
            ) := by

    simpa [ARCKernel] using
      hu

  rcases hu' with
    ⟨e, r, hr, hu_eq⟩

  let Dr :
      List (Fin k) :=
    arcFinDigitsAppend
      hk
      e
      r
      hr

  let q :
      M.State :=
    M.eval
      M.start
      Dr

  refine
    ⟨q, ?_⟩

  funext n

  let Dn :
      List (Fin k) :=
    arcNatFinDigits
      hk
      n

  have hDrVal :
      Nat.ofDigits
          k
          (
            Dr.map
              (fun d =>
                d.val)
          )
        =
      r := by

    dsimp [Dr]

    exact
      arc_fin_digits_append_ofDigits
        hk
        e
        r
        hr

  have hDrLen :
      (
        Dr.map
          (fun d =>
            d.val)
      ).length
        =
      e := by

    have h0 :
        Dr.length = e := by

      dsimp [Dr]

      exact
        arc_fin_digits_append_length
          hk
          e
          r
          hr

    simpa using
      h0

  have hDnVal :
      Nat.ofDigits
          k
          (
            Dn.map
              (fun d =>
                d.val)
          )
        =
      n := by

    dsimp [Dn]

    exact
      arc_nat_fin_digits_ofDigits
        hk
        n

  have hNumber :
      Nat.ofDigits
          k
          (
            (
              Dr ++ Dn
            ).map
              (fun d =>
                d.val)
          )
        =
      r + k ^ e * n := by

    rw [
      List.map_append,
      Nat.ofDigits_append,
      hDrVal,
      hDnVal,
      hDrLen
    ]

  calc
    u n
        =
      a (
        k ^ e * n + r
      ) :=
        hu_eq n

    _ =
      a (
        r + k ^ e * n
      ) := by

        congr 1
        omega

    _ =
      M.output
        (
          M.eval
            M.start
            (Dr ++ Dn)
        ) := by

        rw [← hNumber]

        exact
          (
            hM
              (Dr ++ Dn)
          ).symm

    _ =
      M.output
        (
          M.eval
            q
            Dn
        ) := by

        rw [
          arc_lsd_eval_append
            M
            M.start
            Dr
            Dn
        ]

    _ =
      arcLSDStateSequence
        M
        hk
        q
        n := by

        rfl


/-
  ============================================================
  10. LSD automatic ⇒ finite k-kernel
  ============================================================
-/

theorem arc_lsd_automatic_implies_finite_kernel
    {k : ℕ}
    {α : Type u}
    (hk : 1 < k)
    (a : ℕ → α)
    (ha :
      ARCLSDAutomatic
        k
        a) :
    ARCAutomaticByKernel
      k
      a := by

  rcases ha with
    ⟨M, hM⟩

  letI :
      Finite M.State :=
    M.stateFinite

  unfold ARCAutomaticByKernel

  apply
    (
      Set.finite_range
        (
          arcLSDStateSequence
            M
            hk
        )
    ).subset

  intro u hu

  rcases
      arc_kernel_member_eq_lsd_state_sequence
        hk
        M
        a
        hM
        u
        hu
    with
    ⟨q, hq⟩

  exact
    ⟨
      q,
      hq.symm
    ⟩


/-
  ============================================================
  11. MSD automatic ⇒ finite k-kernel
  ============================================================
-/

theorem arc_msd_automatic_implies_finite_kernel
    {k : ℕ}
    {α : Type u}
    (hk : 1 < k)
    (a : ℕ → α)
    (ha :
      ARCMSDAutomatic
        k
        a) :
    ARCAutomaticByKernel
      k
      a := by

  have hLSD :
      ARCLSDAutomatic
        k
        a :=
    arc_msd_automatic_implies_lsd_automatic
      a
      ha

  exact
    arc_lsd_automatic_implies_finite_kernel
      hk
      a
      hLSD


/-
  ============================================================
  12. Main theorem with MSD automaticity at the entrance
  ============================================================
-/

theorem arc_main_msd_form_of_cobham
    {α : Type u}
    [Finite α]
    (hCobham :
      ARCCobhamPrinciple.{u})
    (a : ℕ → α)
    (hEven :
      ∀ n : ℕ,
        a (2 * n) = a n)
    (hOdd :
      ∀ n : ℕ,
        a (2 * n + 1) =
          a (3 * n + 2))
    (ha :
      ARCMSDAutomatic
        2
        a) :
    ∃ c : α,
      ∀ N : ℕ,
        1 ≤ N →
        a N = c := by

  have hKernel :
      ARCAutomaticByKernel
        2
        a :=
    arc_msd_automatic_implies_finite_kernel
      (k := 2)
      (by norm_num)
      a
      ha

  exact
    arc_main_kernel_form_of_cobham
      hCobham
      a
      hEven
      hOdd
      hKernel


/-
  ============================================================
  13. Axiom audit
  ============================================================
-/

#print axioms arc_msd_eval_append

#print axioms arc_reverse_msd_machine_step

#print axioms arc_reverse_msd_machine_eval

#print axioms arc_reverse_msd_machine_generates

#print axioms arc_msd_automatic_implies_lsd_automatic

#print axioms arc_fin_digits_append_ofDigits

#print axioms arc_kernel_member_eq_lsd_state_sequence

#print axioms arc_lsd_automatic_implies_finite_kernel

#print axioms arc_msd_automatic_implies_finite_kernel

#print axioms arc_main_msd_form_of_cobham

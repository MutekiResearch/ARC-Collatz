import Mathlib
import ARC.ARCAutomaticBridge1

set_option autoImplicit false

universe u


/-!
# ARC automaticity bridge — Part 2

Part 1 proved:

    finite k-kernel
      ⇒
    finite-state output machine reading digits LSD-first.

We now reverse the reading direction.

Suppose the original LSD machine has state set Q.

A new MSD-reading state will be a transformation

    F : Q → Q.

After reading an MSD-prefix P, F satisfies

    F(q) = oldMachine.eval q (reverse P).

When a new digit d is read on the right of P,

    reverse(P ++ [d])
      =
    d :: reverse(P).

Therefore the new transformation becomes

    q ↦ F(oldStep q d).

Since Q is finite, Q → Q is finite.

This constructs a genuine finite-state output machine
reading the most-significant digit first.
-/



/-!
============================================================
1. Append law for the LSD machine

Evaluation satisfies

    eval q (L₁ ++ L₂)
      =
    eval (eval q L₁) L₂.
============================================================
-/


theorem arc_lsd_eval_append
    {k : ℕ}
    {α : Type u}

    (M :
      ARCLSDDFAO k α)

    (q :
      M.State)

    (L₁ L₂ :
      List (Fin k)) :

    ARCLSDDFAO.eval
      M
      q
      (L₁ ++ L₂)

      =

    ARCLSDDFAO.eval
      M
      (
        ARCLSDDFAO.eval
          M
          q
          L₁
      )
      L₂ := by


  induction L₁ generalizing q with


  | nil =>

      rfl


  | cons d ds ih =>

      change

        ARCLSDDFAO.eval
          M
          (M.step q d)
          (ds ++ L₂)

          =

        ARCLSDDFAO.eval
          M
          (
            ARCLSDDFAO.eval
              M
              (M.step q d)
              ds
          )
          L₂


      exact
        ih
          (q :=
            M.step q d)



/-!
============================================================
2. MSD-first finite-state output machine
============================================================
-/


structure ARCMSDDFAO
    (k : ℕ)
    (α : Type u) where

  State :
    Type u

  stateFinite :
    Finite State

  start :
    State

  step :
    State → Fin k → State

  output :
    State → α



namespace ARCMSDDFAO


/-!
============================================================
3. Evaluation
============================================================
-/


def eval
    {k : ℕ}
    {α : Type u}

    (M :
      ARCMSDDFAO k α) :

    M.State
      →
    List (Fin k)
      →
    M.State

  | q, [] =>

      q


  | q, d :: ds =>

      eval
        M
        (M.step q d)
        ds



/-!
============================================================
4. MSD-generation property

The input list is written in the usual order

    most-significant digit → least-significant digit.

Nat.ofDigits expects little-endian order.

Therefore we reverse the input list before calling
Nat.ofDigits.
============================================================
-/


def Generates
    {k : ℕ}
    {α : Type u}

    (M :
      ARCMSDDFAO k α)

    (a :
      ℕ → α) :

    Prop :=

  ∀ L : List (Fin k),

    M.output
      (
        M.eval
          M.start
          L
      )

      =

    a (
      Nat.ofDigits
        k
        (
          L.reverse.map
            (fun d =>
              d.val)
        )
    )


end ARCMSDDFAO



/-!
============================================================
5. Reverse an LSD machine

Original state space:

    Q.

New state space:

    Q → Q.

Start transformation:

    id.

Reading digit d updates

    F

to

    q ↦ F(step(q,d)).

Output of transformation F:

    oldOutput(F(oldStart)).
============================================================
-/


def arcReverseLSDDFAO
    {k : ℕ}
    {α : Type u}

    (M :
      ARCLSDDFAO k α) :

    ARCMSDDFAO
      k
      α := by


  letI :
      Finite M.State :=

    M.stateFinite


  exact
    {
      State :=
        M.State → M.State

      stateFinite := by

        infer_instance

      start :=
        fun q =>
          q

      step :=
        fun F d q =>
          F (M.step q d)

      output :=
        fun F =>
          M.output
            (F M.start)
    }



/-!
============================================================
6. Semantic invariant of the reversed machine

After the new MSD-machine reads a list L,

the transformation it stores satisfies

    newEval(F,L)(q)
      =
    F(oldEval(q, reverse L)).
============================================================
-/


theorem arc_reverse_machine_eval
    {k : ℕ}
    {α : Type u}

    (M :
      ARCLSDDFAO k α)

    (F :
      M.State → M.State)

    (L :
      List (Fin k))

    (q :
      M.State) :

    (
      ARCMSDDFAO.eval
        (arcReverseLSDDFAO M)
        F
        L
    )
      q

      =

    F (
      ARCLSDDFAO.eval
        M
        q
        L.reverse
    ) := by


  induction L generalizing F q with


  | nil =>

      rfl


  | cons d ds ih =>


      /-
      Reading d first changes F into

          q ↦ F(step(q,d)).

      Then the induction hypothesis is applied to ds.
      -/

      change

        (
          ARCMSDDFAO.eval
            (arcReverseLSDDFAO M)
            (
              fun x =>
                F (M.step x d)
            )
            ds
        )
          q

          =

        F (
          ARCLSDDFAO.eval
            M
            q
            (d :: ds).reverse
        )


      calc

        (
          ARCMSDDFAO.eval
            (arcReverseLSDDFAO M)
            (
              fun x =>
                F (M.step x d)
            )
            ds
        )
          q

            =

          (
            fun x =>
              F (M.step x d)
          )
          (
            ARCLSDDFAO.eval
              M
              q
              ds.reverse
          ) := by

            exact
              ih
                (
                  F :=
                    fun x =>
                      F (M.step x d)
                )
                (q := q)


        _ =

          F (
            M.step
              (
                ARCLSDDFAO.eval
                  M
                  q
                  ds.reverse
              )
              d
          ) := by

            rfl


        /-
        Appending [d] to the OLD machine input
        means that d is processed after reverse(ds).
        -/

        _ =

          F (
            ARCLSDDFAO.eval
              M
              q
              (ds.reverse ++ [d])
          ) := by

            congr 1


            simpa [
              ARCLSDDFAO.eval
            ] using

              (
                arc_lsd_eval_append
                  M
                  q
                  ds.reverse
                  [d]
              ).symm


        /-
        reverse(d :: ds)
          =
        reverse(ds) ++ [d].
        -/

        _ =

          F (
            ARCLSDDFAO.eval
              M
              q
              (d :: ds).reverse
          ) := by

            rw [
              List.reverse_cons
            ]



/-!
============================================================
7. Reversal preserves sequence generation

Suppose the LSD machine M generates a.

Then the reversed finite-state machine generates
the same sequence while reading digits MSD-first.
============================================================
-/


theorem arc_reverse_machine_generates
    {k : ℕ}
    {α : Type u}

    (M :
      ARCLSDDFAO k α)

    (a :
      ℕ → α)

    (hM :
      ARCLSDDFAO.Generates
        M
        a) :

    ARCMSDDFAO.Generates
      (arcReverseLSDDFAO M)
      a := by


  intro L


  change

    M.output
      (
        (
          ARCMSDDFAO.eval
            (arcReverseLSDDFAO M)
            (fun q => q)
            L
        )
        M.start
      )

      =

    a (
      Nat.ofDigits
        k
        (
          L.reverse.map
            (fun d =>
              d.val)
        )
    )


  have hrev :=

    arc_reverse_machine_eval
      M
      (fun q => q)
      L
      M.start


  rw [hrev]


  have hold :=

    hM
      L.reverse


  simpa using
    hold



/-!
============================================================
8. MSD-first automaticity

This is now the ordinary direction of digit reading:

    most-significant → least-significant.

A sequence is MSD-automatic here when such a finite-state
output machine exists.
============================================================
-/


def ARCMSDAutomatic
    {α : Type u}

    (k : ℕ)
    (a : ℕ → α) :

    Prop :=

  ∃ M :
      ARCMSDDFAO
        k
        α,

    M.Generates
      a



/-!
============================================================
9. LSD-automatic ⇒ MSD-automatic
============================================================
-/


theorem arc_lsd_automatic_implies_msd_automatic
    {α : Type u}

    (k : ℕ)
    (a : ℕ → α)

    (ha :
      ARCLSDAutomatic
        k
        a) :

    ARCMSDAutomatic
      k
      a := by


  rcases ha with
    ⟨M, hM⟩


  refine
    ⟨
      arcReverseLSDDFAO M,
      ?_
    ⟩


  exact
    arc_reverse_machine_generates
      M
      a
      hM



/-!
============================================================
10. Finite kernel ⇒ MSD-first finite-state generation

Part 1 gave

    finite kernel
      ⇒
    LSD-automatic.

The reversal theorem now gives

    finite kernel
      ⇒
    MSD-automatic.
============================================================
-/


theorem arc_finite_kernel_implies_msd_automatic
    {α : Type u}

    (k : ℕ)
    (a : ℕ → α)

    (ha :
      (ARCKernel k a).Finite) :

    ARCMSDAutomatic
      k
      a := by


  have hLSD :

      ARCLSDAutomatic
        k
        a :=

    arc_finite_kernel_implies_lsd_automatic
      k
      a
      ha


  exact
    arc_lsd_automatic_implies_msd_automatic
      k
      a
      hLSD



/-!
============================================================
11. Proposition 3.2 in explicit MSD-DFAO form

Let

    b(n) = a(2n+1).

The already verified kernel form of Proposition 3.2 gives

    K₂(b) finite

and

    K₃(b) finite.

The automaticity bridge converts these into

    b is 2-automatic

and

    b is 3-automatic

in the explicit MSD-first finite-state-output-machine
sense defined above.
============================================================
-/


theorem arc_proposition3_2_msd_form
    {α : Type u}

    [Finite α]

    (a :
      ℕ → α)

    (hEven :
      ∀ n : ℕ,

        a (2 * n)
          =
        a n)

    (hOdd :
      ∀ n : ℕ,

        a (2 * n + 1)
          =
        a (3 * n + 2))

    (ha :
      ARCAutomaticByKernel
        2
        a) :

    ARCMSDAutomatic
      2
      (
        fun n =>
          a (2 * n + 1)
      )

      ∧

    ARCMSDAutomatic
      3
      (
        fun n =>
          a (2 * n + 1)
      ) := by


  have hk :=

    arc_proposition3_2_kernel_form
      a
      hEven
      hOdd
      ha


  have h2 :

      (
        ARCKernel
          2
          (
            fun n =>
              a (2 * n + 1)
          )
      ).Finite := by

    simpa [
      ARCAutomaticByKernel
    ] using
      hk.1


  have h3 :

      (
        ARCKernel
          3
          (
            fun n =>
              a (2 * n + 1)
          )
      ).Finite := by

    simpa [
      ARCAutomaticByKernel
    ] using
      hk.2


  constructor


  ·
    exact
      arc_finite_kernel_implies_msd_automatic
        2
        (
          fun n =>
            a (2 * n + 1)
        )
        h2


  ·
    exact
      arc_finite_kernel_implies_msd_automatic
        3
        (
          fun n =>
            a (2 * n + 1)
        )
        h3



/-!
============================================================
12. Axiom audit
============================================================
-/


#print axioms arc_lsd_eval_append

#print axioms arc_reverse_machine_eval

#print axioms arc_reverse_machine_generates

#print axioms arc_lsd_automatic_implies_msd_automatic

#print axioms arc_finite_kernel_implies_msd_automatic

#print axioms arc_proposition3_2_msd_form

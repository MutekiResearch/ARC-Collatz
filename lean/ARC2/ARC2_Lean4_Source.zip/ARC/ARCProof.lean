import Mathlib

universe u

variable {Δ : Type u}


/-!
============================================================
ARC theorem - Lean verification
============================================================

現在このファイルで検証するもの：

* Lemma 4.1
      b_{4n}   = b_{3n}
      b_{4n+2} = b_n

* Lemma 4.3
      eventually constant
      + b_{4n+2}=b_n
      → constant

* Proposition 4.2
      ultimately periodic
      + b_{4n}=b_{3n}
      + b_{4n+2}=b_n
      → eventually constant

その内部で：

      最小 eventual period P は奇数
      3 ∤ P
      gcd(P,6)=1
      SFS⁻¹F⁻¹ = translation by -1/2
      translation by 1
      residue coloring is constant

まで検証する。
-/


/-!
============================================================
1. Odd indexed subsequence
============================================================
-/


def b (a : ℕ → Δ) (n : ℕ) : Δ :=
  a (2 * n + 1)



/-!
============================================================
2. Lemma 4.1
============================================================
-/


theorem lemma4_1_first
    (a : ℕ → Δ)
    (h_even :
      ∀ n : ℕ,
        a (2 * n) = a n)
    (h_odd :
      ∀ n : ℕ,
        a (2 * n + 1) = a (3 * n + 2))
    (n : ℕ) :

    b a (4 * n) = b a (3 * n) := by

  unfold b

  calc
    a (2 * (4 * n) + 1)
        = a (3 * (4 * n) + 2) :=
          h_odd (4 * n)

    _ = a (2 * (6 * n + 1)) := by
          congr 1
          omega

    _ = a (6 * n + 1) :=
          h_even (6 * n + 1)

    _ = a (2 * (3 * n) + 1) := by
          congr 1
          omega



theorem lemma4_1_second
    (a : ℕ → Δ)
    (h_even :
      ∀ n : ℕ,
        a (2 * n) = a n)
    (h_odd :
      ∀ n : ℕ,
        a (2 * n + 1) = a (3 * n + 2))
    (n : ℕ) :

    b a (4 * n + 2) = b a n := by

  unfold b

  calc
    a (2 * (4 * n + 2) + 1)
        = a (3 * (4 * n + 2) + 2) :=
          h_odd (4 * n + 2)

    _ = a (2 * (6 * n + 4)) := by
          congr 1
          omega

    _ = a (6 * n + 4) :=
          h_even (6 * n + 4)

    _ = a (2 * (3 * n + 2)) := by
          congr 1
          omega

    _ = a (3 * n + 2) :=
          h_even (3 * n + 2)

    _ = a (2 * n + 1) :=
          (h_odd n).symm



/-!
============================================================
3. Lemma 4.3
============================================================
-/


def arcF (n : ℕ) : ℕ :=
  4 * n + 2


def arcFIter : ℕ → ℕ → ℕ
  | 0, n => n
  | Nat.succ k, n => arcF (arcFIter k n)



lemma arcFIter_invariant
    (seq : ℕ → Δ)
    (h :
      ∀ n : ℕ,
        seq (arcF n) = seq n) :

    ∀ k n : ℕ,
      seq (arcFIter k n) = seq n := by

  intro k

  induction k with

  | zero =>
      intro n
      rfl

  | succ k ih =>
      intro n

      calc
        seq (arcFIter (Nat.succ k) n)
            = seq (arcF (arcFIter k n)) := by
                rfl

        _ = seq (arcFIter k n) :=
              h (arcFIter k n)

        _ = seq n :=
              ih n



lemma arcF_ge_succ
    (n : ℕ) :

    n + 1 ≤ arcF n := by

  unfold arcF
  omega



lemma arcFIter_ge
    (k n : ℕ) :

    n + k ≤ arcFIter k n := by

  induction k with

  | zero =>
      simp [arcFIter]

  | succ k ih =>

      calc
        n + Nat.succ k
            = (n + k) + 1 := by
                omega

        _ ≤ arcFIter k n + 1 := by
              omega

        _ ≤ arcF (arcFIter k n) :=
              arcF_ge_succ (arcFIter k n)

        _ = arcFIter (Nat.succ k) n := by
              rfl



theorem lemma4_3
    (seq : ℕ → Δ)

    (h_tail :
      ∃ (N : ℕ) (c : Δ),
        ∀ n : ℕ,
          N ≤ n →
          seq n = c)

    (h_step :
      ∀ n : ℕ,
        seq (4 * n + 2) = seq n) :

    ∃ c : Δ,
      ∀ n : ℕ,
        seq n = c := by

  rcases h_tail with ⟨N, c, hconst⟩

  refine ⟨c, ?_⟩

  intro n

  have hF :
      ∀ m : ℕ,
        seq (arcF m) = seq m := by

    intro m
    simpa [arcF] using h_step m


  have hinvariant :
      seq (arcFIter N n) = seq n :=
    arcFIter_invariant seq hF N n


  have hlarge :
      N ≤ arcFIter N n := by

    have hgrowth :=
      arcFIter_ge N n

    omega


  have htailvalue :
      seq (arcFIter N n) = c :=
    hconst (arcFIter N n) hlarge


  exact
    hinvariant.symm.trans htailvalue



/-!
============================================================
4. Eventual period
============================================================
-/


def IsEventualPeriod
    (seq : ℕ → Δ)
    (P : ℕ) : Prop :=

  ∃ N : ℕ,
    ∀ n : ℕ,
      N ≤ n →
      seq (n + P) = seq n



/-!
============================================================
5. P is odd
============================================================
-/


lemma eventual_period_twice
    (seq : ℕ → Δ)
    {P : ℕ}

    (hP :
      IsEventualPeriod seq P) :

    IsEventualPeriod seq (2 * P) := by

  rcases hP with ⟨N, hN⟩

  refine ⟨N, ?_⟩

  intro n hn

  calc
    seq (n + 2 * P)
        = seq ((n + P) + P) := by
            congr 1
            omega

    _ = seq (n + P) :=
          hN (n + P) (by omega)

    _ = seq n :=
          hN n hn



lemma even_eventual_period_halves
    (seq : ℕ → Δ)
    {P : ℕ}

    (hP :
      IsEventualPeriod seq P)

    (hstep :
      ∀ n : ℕ,
        seq (4 * n + 2) = seq n)

    (hEven :
      Even P) :

    ∃ d : ℕ,
      P = 2 * d ∧
      IsEventualPeriod seq d := by

  rcases hEven with ⟨d, hd⟩

  have hPeq :
      P = 2 * d := by
    omega


  have h2P :
      IsEventualPeriod seq (2 * P) :=
    eventual_period_twice seq hP

  rcases h2P with ⟨N, hN⟩


  refine ⟨d, hPeq, ?_⟩
  refine ⟨N, ?_⟩

  intro n hn


  have hs1 :
      seq (4 * (n + d) + 2)
        =
      seq (n + d) :=
    hstep (n + d)


  have hs2 :
      seq (4 * n + 2)
        =
      seq n :=
    hstep n


  have hlarge :
      N ≤ 4 * n + 2 := by
    omega


  have hperiod :
      seq ((4 * n + 2) + 2 * P)
        =
      seq (4 * n + 2) :=
    hN (4 * n + 2) hlarge


  have harith :
      4 * (n + d) + 2
        =
      (4 * n + 2) + 2 * P := by
    omega


  calc
    seq (n + d)
        =
      seq (4 * (n + d) + 2) :=
        hs1.symm

    _ =
      seq ((4 * n + 2) + 2 * P) := by
        rw [harith]

    _ =
      seq (4 * n + 2) :=
        hperiod

    _ =
      seq n :=
        hs2



theorem minimal_eventual_period_is_odd
    (seq : ℕ → Δ)
    {P : ℕ}

    (hPpos :
      0 < P)

    (hP :
      IsEventualPeriod seq P)

    (hminimal :
      ∀ d : ℕ,
        0 < d →
        d < P →
        ¬ IsEventualPeriod seq d)

    (hstep :
      ∀ n : ℕ,
        seq (4 * n + 2) = seq n) :

    Odd P := by

  by_contra hnotodd


  have heven :
      Even P :=
    Nat.not_odd_iff_even.mp hnotodd


  rcases
      even_eventual_period_halves
        seq hP hstep heven
    with ⟨d, hPeq, hdperiod⟩


  have hdpos :
      0 < d := by
    omega


  have hdlt :
      d < P := by
    omega


  exact
    hminimal d
      hdpos
      hdlt
      hdperiod



/-!
============================================================
6. Abstract 3-torsion shift
============================================================
-/


lemma shift_invariant_of_three_torsion
    {R : Type*}
    [CommRing R]

    (f : R → Δ)

    (h43 :
      ∀ x : R,
        f (4 * x) = f (3 * x))

    (h4surj :
      Function.Surjective
        (fun x : R => 4 * x))

    (d : R)

    (h3d :
      3 * d = 0) :

    ∀ y : R,
      f (y + d) = f y := by

  intro y

  rcases h4surj y with ⟨x, hx⟩


  have h4d :
      4 * d = d := by

    calc
      4 * d
          = 3 * d + d := by
              ring

      _ = d := by
            rw [h3d, zero_add]


  have harg1 :
      y + d = 4 * (x + d) := by

    calc
      y + d
          = 4 * x + d := by
              rw [← hx]

      _ = 4 * x + 4 * d := by
            rw [h4d]

      _ = 4 * (x + d) := by
            ring


  have harg2 :
      3 * (x + d) = 3 * x := by

    rw [mul_add, h3d, add_zero]


  calc
    f (y + d)
        = f (4 * (x + d)) :=
          congrArg f harg1

    _ = f (3 * (x + d)) :=
          h43 (x + d)

    _ = f (3 * x) :=
          congrArg f harg2

    _ = f (4 * x) :=
          (h43 x).symm

    _ = f y :=
          congrArg f hx



/-!
============================================================
7. Repeating an eventual period
============================================================
-/


lemma eventual_period_mul_from_threshold
    (seq : ℕ → Δ)
    {N P : ℕ}

    (hN :
      ∀ n : ℕ,
        N ≤ n →
        seq (n + P) = seq n)

    (k n : ℕ)

    (hn :
      N ≤ n) :

    seq (n + k * P) = seq n := by

  induction k with

  | zero =>
      simp

  | succ k ih =>

      calc
        seq (n + Nat.succ k * P)
            =
        seq ((n + k * P) + P) := by
          congr 1
          simp [Nat.succ_mul, Nat.add_assoc]

        _ =
        seq (n + k * P) :=
          hN (n + k * P) (by omega)

        _ =
        seq n :=
          ih



lemma eventual_eq_of_modeq
    (seq : ℕ → Δ)
    {N P a c : ℕ}

    (hN :
      ∀ n : ℕ,
        N ≤ n →
        seq (n + P) = seq n)

    (ha :
      N ≤ a)

    (hc :
      N ≤ c)

    (hmod :
      a ≡ c [MOD P]) :

    seq a = seq c := by

  rcases le_total a c with hac | hca


  ·
    rcases
        (Nat.modEq_iff_exists_eq_add hac).1 hmod
      with ⟨t, ht⟩

    subst c

    have hmul :=
      eventual_period_mul_from_threshold
        seq hN t a ha

    have hmul' :
        seq (a + P * t) = seq a := by

      simpa [Nat.mul_comm] using hmul

    exact hmul'.symm


  ·
    have hmod' :
        c ≡ a [MOD P] :=
      hmod.symm

    rcases
        (Nat.modEq_iff_exists_eq_add hca).1 hmod'
      with ⟨t, ht⟩

    subst a

    have hmul :=
      eventual_period_mul_from_threshold
        seq hN t c hc

    simpa [Nat.mul_comm] using hmul



/-!
============================================================
8. Tail coloring on ZMod P
============================================================
-/


def tailColor
    (seq : ℕ → Δ)
    (N P : ℕ)
    (x : ZMod P) : Δ :=

  seq (x.val + N * P)



lemma tailColor_eq_seq_of_ge
    (seq : ℕ → Δ)
    {N P : ℕ}

    (hPpos :
      0 < P)

    (hN :
      ∀ n : ℕ,
        N ≤ n →
        seq (n + P) = seq n)

    (n : ℕ)

    (hn :
      N ≤ n) :

    tailColor seq N P (n : ZMod P) = seq n := by

  letI : NeZero P :=
    ⟨Nat.ne_of_gt hPpos⟩


  have hlarge :
      N ≤ (n : ZMod P).val + N * P := by

    have hNP :
        N ≤ N * P :=
      Nat.le_mul_of_pos_right N hPpos

    omega


  have hmod :
      (n : ZMod P).val + N * P
        ≡
      n [MOD P] := by

    apply
      (ZMod.natCast_eq_natCast_iff
        ((n : ZMod P).val + N * P)
        n
        P).mp

    simp [
      ZMod.natCast_zmod_val,
      ZMod.natCast_self
    ]


  unfold tailColor

  exact
    eventual_eq_of_modeq
      seq
      hN
      hlarge
      hn
      hmod



lemma tailColor_h43
    (seq : ℕ → Δ)
    {N P : ℕ}

    (hPpos :
      0 < P)

    (hN :
      ∀ n : ℕ,
        N ≤ n →
        seq (n + P) = seq n)

    (h43seq :
      ∀ n : ℕ,
        seq (4 * n) = seq (3 * n)) :

    ∀ x : ZMod P,
      tailColor seq N P (4 * x)
        =
      tailColor seq N P (3 * x) := by

  letI : NeZero P :=
    ⟨Nat.ne_of_gt hPpos⟩


  intro x


  let m : ℕ :=
    x.val + N * P


  have hm :
      N ≤ m := by

    dsimp [m]

    have hNP :
        N ≤ N * P :=
      Nat.le_mul_of_pos_right N hPpos

    omega


  have hleftLarge :
      N ≤ (4 * x).val + N * P := by

    have hNP :
        N ≤ N * P :=
      Nat.le_mul_of_pos_right N hPpos

    omega


  have hrightLarge :
      N ≤ (3 * x).val + N * P := by

    have hNP :
        N ≤ N * P :=
      Nat.le_mul_of_pos_right N hPpos

    omega


  have h4mLarge :
      N ≤ 4 * m := by
    omega


  have h3mLarge :
      N ≤ 3 * m := by
    omega


  have hleftMod :
      (4 * x).val + N * P
        ≡
      4 * m [MOD P] := by

    apply
      (ZMod.natCast_eq_natCast_iff
        ((4 * x).val + N * P)
        (4 * m)
        P).mp

    dsimp [m]

    simp [
      ZMod.natCast_zmod_val,
      ZMod.natCast_self
    ]


  have hrightMod :
      (3 * x).val + N * P
        ≡
      3 * m [MOD P] := by

    apply
      (ZMod.natCast_eq_natCast_iff
        ((3 * x).val + N * P)
        (3 * m)
        P).mp

    dsimp [m]

    simp [
      ZMod.natCast_zmod_val,
      ZMod.natCast_self
    ]


  have hleft :
      seq ((4 * x).val + N * P)
        =
      seq (4 * m) :=

    eventual_eq_of_modeq
      seq
      hN
      hleftLarge
      h4mLarge
      hleftMod


  have hright :
      seq ((3 * x).val + N * P)
        =
      seq (3 * m) :=

    eventual_eq_of_modeq
      seq
      hN
      hrightLarge
      h3mLarge
      hrightMod


  unfold tailColor

  calc
    seq ((4 * x).val + N * P)
        =
      seq (4 * m) :=
        hleft

    _ =
      seq (3 * m) :=
        h43seq m

    _ =
      seq ((3 * x).val + N * P) :=
        hright.symm



/-!
============================================================
9. The affine identity also descends to tailColor
============================================================
-/


lemma tailColor_hF
    (seq : ℕ → Δ)
    {N P : ℕ}

    (hPpos :
      0 < P)

    (hN :
      ∀ n : ℕ,
        N ≤ n →
        seq (n + P) = seq n)

    (hstep :
      ∀ n : ℕ,
        seq (4 * n + 2) = seq n) :

    ∀ x : ZMod P,
      tailColor seq N P (4 * x + 2)
        =
      tailColor seq N P x := by

  letI : NeZero P :=
    ⟨Nat.ne_of_gt hPpos⟩


  intro x


  let m : ℕ :=
    x.val + N * P


  have hm :
      N ≤ m := by

    dsimp [m]

    have hNP :
        N ≤ N * P :=
      Nat.le_mul_of_pos_right N hPpos

    omega


  have hFm :
      N ≤ 4 * m + 2 := by
    omega


  have hmCast :
      (m : ZMod P) = x := by

    dsimp [m]

    simp [
      ZMod.natCast_zmod_val,
      ZMod.natCast_self
    ]


  have hFmCast :
      ((4 * m + 2 : ℕ) : ZMod P)
        =
      4 * x + 2 := by

    calc
      ((4 * m + 2 : ℕ) : ZMod P)
          =
        4 * (m : ZMod P) + 2 := by
          norm_num

      _ =
        4 * x + 2 := by
          rw [hmCast]


  have hleft :
      tailColor seq N P
          ((4 * m + 2 : ℕ) : ZMod P)
        =
      seq (4 * m + 2) :=

    tailColor_eq_seq_of_ge
      seq
      hPpos
      hN
      (4 * m + 2)
      hFm


  have hright :
      tailColor seq N P
          (m : ZMod P)
        =
      seq m :=

    tailColor_eq_seq_of_ge
      seq
      hPpos
      hN
      m
      hm


  calc
    tailColor seq N P (4 * x + 2)
        =
      tailColor seq N P
        ((4 * m + 2 : ℕ) : ZMod P) := by
          rw [hFmCast]

    _ =
      seq (4 * m + 2) :=
        hleft

    _ =
      seq m :=
        hstep m

    _ =
      tailColor seq N P
        (m : ZMod P) :=
        hright.symm

    _ =
      tailColor seq N P x := by
        rw [hmCast]



/-!
============================================================
10. ZMod shift -> natural eventual period
============================================================
-/


lemma tailColor_shift_to_eventual_period
    (seq : ℕ → Δ)
    {N P : ℕ}

    (hPpos :
      0 < P)

    (hN :
      ∀ n : ℕ,
        N ≤ n →
        seq (n + P) = seq n)

    (d : ℕ)

    (hshift :
      ∀ x : ZMod P,
        tailColor seq N P
            (x + (d : ZMod P))
          =
        tailColor seq N P x) :

    IsEventualPeriod seq d := by

  letI : NeZero P :=
    ⟨Nat.ne_of_gt hPpos⟩


  refine ⟨N, ?_⟩

  intro n hn


  have hleft :
      tailColor seq N P
          ((n + d : ℕ) : ZMod P)
        =
      seq (n + d) :=

    tailColor_eq_seq_of_ge
      seq
      hPpos
      hN
      (n + d)
      (by omega)


  have hright :
      tailColor seq N P
          (n : ZMod P)
        =
      seq n :=

    tailColor_eq_seq_of_ge
      seq
      hPpos
      hN
      n
      hn


  have hs :=
    hshift (n : ZMod P)


  calc
    seq (n + d)
        =
      tailColor seq N P
        ((n + d : ℕ) : ZMod P) :=
        hleft.symm

    _ =
      tailColor seq N P
        ((n : ZMod P) + (d : ZMod P)) := by
          simp

    _ =
      tailColor seq N P
        (n : ZMod P) :=
        hs

    _ =
      seq n :=
        hright



/-!
============================================================
11. 3 does not divide the minimal period
============================================================
-/


theorem minimal_eventual_period_not_divisible_by_three
    (seq : ℕ → Δ)
    {P : ℕ}

    (hPpos :
      0 < P)

    (hP :
      IsEventualPeriod seq P)

    (hminimal :
      ∀ d : ℕ,
        0 < d →
        d < P →
        ¬ IsEventualPeriod seq d)

    (h43seq :
      ∀ n : ℕ,
        seq (4 * n) = seq (3 * n))

    (hstep :
      ∀ n : ℕ,
        seq (4 * n + 2) = seq n) :

    ¬ 3 ∣ P := by


  have hOdd :
      Odd P :=
    minimal_eventual_period_is_odd
      seq
      hPpos
      hP
      hminimal
      hstep


  intro h3dvd


  rcases h3dvd with ⟨d, hd⟩


  have hdpos :
      0 < d := by
    omega


  have hdlt :
      d < P := by
    omega


  rcases hP with ⟨N, hN⟩


  letI : NeZero P :=
    ⟨Nat.ne_of_gt hPpos⟩


  let f : ZMod P → Δ :=
    tailColor seq N P


  have h43f :
      ∀ x : ZMod P,
        f (4 * x) = f (3 * x) := by

    intro x

    dsimp [f]

    exact
      tailColor_h43
        seq
        hPpos
        hN
        h43seq
        x


  have h2cop :
      Nat.Coprime 2 P :=
    hOdd.coprime_two_left


  have h4cop :
      Nat.Coprime 4 P := by

    simpa using
      h2cop.mul_left h2cop


  have h4unit :
      IsUnit (4 : ZMod P) :=

    (ZMod.isUnit_iff_coprime 4 P).2 h4cop


  have h4surj :
      Function.Surjective
        (fun x : ZMod P => 4 * x) := by

    intro y

    refine
      ⟨(4 : ZMod P)⁻¹ * y, ?_⟩

    calc
      4 * ((4 : ZMod P)⁻¹ * y)
          =
        (4 * (4 : ZMod P)⁻¹) * y := by
          rw [← mul_assoc]

      _ =
        1 * y := by
          rw [
            ZMod.mul_inv_of_unit
              (4 : ZMod P)
              h4unit
          ]

      _ =
        y := by
          simp


  have h3dZ :
      (3 : ZMod P) * (d : ZMod P) = 0 := by

    have hz :
        ((3 * d : ℕ) : ZMod P) = 0 := by

      rw [← hd]

      exact
        ZMod.natCast_self P

    simpa using hz


  have hshift :
      ∀ y : ZMod P,
        f (y + (d : ZMod P)) = f y :=

    shift_invariant_of_three_torsion
      f
      h43f
      h4surj
      (d : ZMod P)
      h3dZ


  have hdperiod :
      IsEventualPeriod seq d := by

    apply
      tailColor_shift_to_eventual_period
        seq
        hPpos
        hN
        d

    intro x

    exact
      hshift x


  exact
    hminimal d
      hdpos
      hdlt
      hdperiod



/-!
============================================================
12. Commutator S F S⁻¹ F⁻¹

S(x)    = 3/4 x
Sinv(x) = 4/3 x

F(x)    = 4x+2
Finv(x) = (x-2)/4

The commutator is x - 1/2.
============================================================
-/


lemma zmod_commutator_gives_half_translation
    {P : ℕ}
    [NeZero P]

    (f : ZMod P → Δ)

    (h2unit :
      IsUnit (2 : ZMod P))

    (h3unit :
      IsUnit (3 : ZMod P))

    (h4unit :
      IsUnit (4 : ZMod P))

    (h43 :
      ∀ x : ZMod P,
        f (4 * x) = f (3 * x))

    (hF :
      ∀ x : ZMod P,
        f (4 * x + 2) = f x) :

    ∀ x : ZMod P,
      f (x - (2 : ZMod P)⁻¹) = f x := by


  let S : ZMod P → ZMod P :=
    fun x =>
      3 * (4 : ZMod P)⁻¹ * x


  let Sinv : ZMod P → ZMod P :=
    fun x =>
      4 * (3 : ZMod P)⁻¹ * x


  let F : ZMod P → ZMod P :=
    fun x =>
      4 * x + 2


  let Finv : ZMod P → ZMod P :=
    fun x =>
      (4 : ZMod P)⁻¹ * (x - 2)


  have h2mul :
      (2 : ZMod P)
          * (2 : ZMod P)⁻¹
        =
      1 :=

    ZMod.mul_inv_of_unit
      (2 : ZMod P)
      h2unit


  have h3mul :
      (3 : ZMod P)
          * (3 : ZMod P)⁻¹
        =
      1 :=

    ZMod.mul_inv_of_unit
      (3 : ZMod P)
      h3unit


  have h4mul :
      (4 : ZMod P)
          * (4 : ZMod P)⁻¹
        =
      1 :=

    ZMod.mul_inv_of_unit
      (4 : ZMod P)
      h4unit


  have hS_Sinv :
      ∀ x : ZMod P,
        S (Sinv x) = x := by

    intro x

    dsimp [S, Sinv]

    calc
      3 * (4 : ZMod P)⁻¹
          *
        (4 * (3 : ZMod P)⁻¹ * x)
          =
        (3 * (3 : ZMod P)⁻¹)
          *
        (4 * (4 : ZMod P)⁻¹)
          *
        x := by
          ring

      _ =
        x := by
          rw [h3mul, h4mul]
          ring


  have hSinv_S :
      ∀ x : ZMod P,
        Sinv (S x) = x := by

    intro x

    dsimp [S, Sinv]

    calc
      4 * (3 : ZMod P)⁻¹
          *
        (3 * (4 : ZMod P)⁻¹ * x)
          =
        (3 * (3 : ZMod P)⁻¹)
          *
        (4 * (4 : ZMod P)⁻¹)
          *
        x := by
          ring

      _ =
        x := by
          rw [h3mul, h4mul]
          ring


  have hF_Finv :
      ∀ x : ZMod P,
        F (Finv x) = x := by

    intro x

    dsimp [F, Finv]

    calc
      4 * ((4 : ZMod P)⁻¹ * (x - 2)) + 2
          =
        (4 * (4 : ZMod P)⁻¹) * (x - 2) + 2 := by
          ring

      _ =
        x := by
          rw [h4mul]
          ring


  have hFinv_F :
      ∀ x : ZMod P,
        Finv (F x) = x := by

    intro x

    dsimp [F, Finv]

    calc
      (4 : ZMod P)⁻¹
          *
        (4 * x + 2 - 2)
          =
        (4 * (4 : ZMod P)⁻¹) * x := by
          ring

      _ =
        x := by
          rw [h4mul]
          simp


  have hS :
      ∀ x : ZMod P,
        f (S x) = f x := by

    intro x


    have hleft :
        4 *
            ((4 : ZMod P)⁻¹ * x)
          =
        x := by

      calc
        4 * ((4 : ZMod P)⁻¹ * x)
            =
          (4 * (4 : ZMod P)⁻¹) * x := by
            ring

        _ =
          x := by
            rw [h4mul]
            simp


    have hright :
        3 *
            ((4 : ZMod P)⁻¹ * x)
          =
        S x := by

      dsimp [S]
      ring


    have hh :=
      h43 ((4 : ZMod P)⁻¹ * x)

    rw [hleft, hright] at hh

    exact hh.symm


  have hF0 :
      ∀ x : ZMod P,
        f (F x) = f x := by

    intro x

    simpa [F] using
      hF x


  have hSinv :
      ∀ x : ZMod P,
        f (Sinv x) = f x := by

    intro x

    have hh :=
      hS (Sinv x)

    rw [hS_Sinv x] at hh

    exact hh.symm


  have hFinv :
      ∀ x : ZMod P,
        f (Finv x) = f x := by

    intro x

    have hh :=
      hF0 (Finv x)

    rw [hF_Finv x] at hh

    exact hh.symm


  have hcomm_invariant :
      ∀ x : ZMod P,
        f (S (F (Sinv (Finv x))))
          =
        f x := by

    intro x

    calc
      f (S (F (Sinv (Finv x))))
          =
        f (F (Sinv (Finv x))) :=
          hS
            (F (Sinv (Finv x)))

      _ =
        f (Sinv (Finv x)) :=
          hF0
            (Sinv (Finv x))

      _ =
        f (Finv x) :=
          hSinv
            (Finv x)

      _ =
        f x :=
          hFinv x


  have hi2eq :
      (2 : ZMod P)⁻¹
        =
      2 * (4 : ZMod P)⁻¹ := by

    apply
      ZMod.inv_eq_of_mul_eq_one
        P
        (2 : ZMod P)
        (2 * (4 : ZMod P)⁻¹)

    calc
      (2 : ZMod P)
          *
        (2 * (4 : ZMod P)⁻¹)
          =
        4 * (4 : ZMod P)⁻¹ := by
          ring

      _ =
        1 :=
          h4mul


  have h8i4 :
      (8 : ZMod P)
          *
        (4 : ZMod P)⁻¹
        =
      2 := by

    calc
      (8 : ZMod P)
          *
        (4 : ZMod P)⁻¹
          =
        2 *
          (4 * (4 : ZMod P)⁻¹) := by
          ring

      _ =
        2 * 1 := by
          rw [h4mul]

      _ =
        2 := by
          ring


  have hSinvFinv :
      ∀ x : ZMod P,
        Sinv (Finv x)
          =
        (3 : ZMod P)⁻¹ * (x - 2) := by

    intro x

    dsimp [Sinv, Finv]

    calc
      4 * (3 : ZMod P)⁻¹
          *
        ((4 : ZMod P)⁻¹ * (x - 2))
          =
        (3 : ZMod P)⁻¹
          *
        (4 * (4 : ZMod P)⁻¹)
          *
        (x - 2) := by
          ring

      _ =
        (3 : ZMod P)⁻¹ * (x - 2) := by
          rw [h4mul]
          ring


  have hcomm_eq :
      ∀ x : ZMod P,
        S (F (Sinv (Finv x)))
          =
        x - (2 : ZMod P)⁻¹ := by

    intro x

    calc
      S (F (Sinv (Finv x)))
          =
        S
          (F
            ((3 : ZMod P)⁻¹
              * (x - 2))) := by
          rw [hSinvFinv x]

      _ =
        3 * (4 : ZMod P)⁻¹
          *
        (4 *
            ((3 : ZMod P)⁻¹
              * (x - 2))
          + 2) := by
          rfl

      _ =
        (x - 2)
          +
        6 * (4 : ZMod P)⁻¹ := by

          calc
            3 * (4 : ZMod P)⁻¹
                *
              (4 *
                  ((3 : ZMod P)⁻¹
                    * (x - 2))
                + 2)
                =
              (4 * (4 : ZMod P)⁻¹)
                *
              (3 * (3 : ZMod P)⁻¹)
                *
              (x - 2)
                +
              6 * (4 : ZMod P)⁻¹ := by
                ring

            _ =
              (x - 2)
                +
              6 * (4 : ZMod P)⁻¹ := by
                rw [h4mul, h3mul]
                ring

      _ =
        (x -
          8 * (4 : ZMod P)⁻¹)
          +
        6 * (4 : ZMod P)⁻¹ := by
          rw [h8i4]

      _ =
        x -
          2 * (4 : ZMod P)⁻¹ := by
          ring

      _ =
        x - (2 : ZMod P)⁻¹ := by
          rw [hi2eq]


  intro x

  have hh :=
    hcomm_invariant x

  rw [hcomm_eq x] at hh

  exact hh



/-!
============================================================
13. Half translation -> translation by 1
============================================================
-/


lemma zmod_translation_one_of_half_translation
    {P : ℕ}
    [NeZero P]

    (f : ZMod P → Δ)

    (h2unit :
      IsUnit (2 : ZMod P))

    (hhalf :
      ∀ x : ZMod P,
        f (x - (2 : ZMod P)⁻¹)
          =
        f x) :

    ∀ x : ZMod P,
      f (x + 1) = f x := by


  have h2mul :
      (2 : ZMod P)
          *
        (2 : ZMod P)⁻¹
        =
      1 :=

    ZMod.mul_inv_of_unit
      (2 : ZMod P)
      h2unit


  intro x


  have hA :=
    hhalf
      ((x + 1)
        - (2 : ZMod P)⁻¹)


  have hB :=
    hhalf (x + 1)


  have hAB :
      f
        (((x + 1)
            - (2 : ZMod P)⁻¹)
          - (2 : ZMod P)⁻¹)
        =
      f (x + 1) :=

    hA.trans hB


  have harg :
      ((x + 1)
          - (2 : ZMod P)⁻¹)
        - (2 : ZMod P)⁻¹
        =
      x := by

    calc
      ((x + 1)
          - (2 : ZMod P)⁻¹)
        - (2 : ZMod P)⁻¹
          =
        x + 1
          -
        2 * (2 : ZMod P)⁻¹ := by
          ring

      _ =
        x + 1 - 1 := by
          rw [h2mul]

      _ =
        x := by
          ring


  rw [harg] at hAB

  exact hAB.symm



/-!
============================================================
14. Translation by 1 forces f to be constant on ZMod P
============================================================
-/


lemma zmod_constant_of_translation_one
    {P : ℕ}
    [NeZero P]

    (f : ZMod P → Δ)

    (hone :
      ∀ x : ZMod P,
        f (x + 1) = f x) :

    ∀ x : ZMod P,
      f x = f 0 := by


  have hnat :
      ∀ n : ℕ,
        f (n : ZMod P) = f 0 := by

    intro n

    induction n with

    | zero =>
        simp

    | succ n ih =>

        simpa [Nat.cast_succ] using
          (hone (n : ZMod P)).trans ih


  intro x

  simpa [
    ZMod.natCast_zmod_val
  ] using
    hnat x.val



/-!
============================================================
15. Minimal-period version of Proposition 4.2
============================================================
-/


theorem minimal_eventual_period_eventually_constant
    (seq : ℕ → Δ)
    {P : ℕ}

    (hPpos :
      0 < P)

    (hP :
      IsEventualPeriod seq P)

    (hminimal :
      ∀ d : ℕ,
        0 < d →
        d < P →
        ¬ IsEventualPeriod seq d)

    (h43seq :
      ∀ n : ℕ,
        seq (4 * n) = seq (3 * n))

    (hstep :
      ∀ n : ℕ,
        seq (4 * n + 2) = seq n) :

    ∃ (N : ℕ) (c : Δ),
      ∀ n : ℕ,
        N ≤ n →
        seq n = c := by


  have hOdd :
      Odd P :=
    minimal_eventual_period_is_odd
      seq
      hPpos
      hP
      hminimal
      hstep


  have hNot3 :
      ¬ 3 ∣ P :=
    minimal_eventual_period_not_divisible_by_three
      seq
      hPpos
      hP
      hminimal
      h43seq
      hstep


  have h2cop :
      Nat.Coprime 2 P :=
    hOdd.coprime_two_left


  have h3cop :
      Nat.Coprime 3 P :=
    (Nat.prime_three.coprime_iff_not_dvd).2
      hNot3


  have h4cop :
      Nat.Coprime 4 P := by

    simpa using
      h2cop.mul_left h2cop


  rcases hP with ⟨N, hN⟩


  letI : NeZero P :=
    ⟨Nat.ne_of_gt hPpos⟩


  let f : ZMod P → Δ :=
    tailColor seq N P


  have h43f :
      ∀ x : ZMod P,
        f (4 * x) = f (3 * x) := by

    intro x

    dsimp [f]

    exact
      tailColor_h43
        seq
        hPpos
        hN
        h43seq
        x


  have hFf :
      ∀ x : ZMod P,
        f (4 * x + 2) = f x := by

    intro x

    dsimp [f]

    exact
      tailColor_hF
        seq
        hPpos
        hN
        hstep
        x


  have h2unit :
      IsUnit (2 : ZMod P) :=

    (ZMod.isUnit_iff_coprime 2 P).2
      h2cop


  have h3unit :
      IsUnit (3 : ZMod P) :=

    (ZMod.isUnit_iff_coprime 3 P).2
      h3cop


  have h4unit :
      IsUnit (4 : ZMod P) :=

    (ZMod.isUnit_iff_coprime 4 P).2
      h4cop


  have hhalf :
      ∀ x : ZMod P,
        f (x - (2 : ZMod P)⁻¹)
          =
        f x :=

    zmod_commutator_gives_half_translation
      f
      h2unit
      h3unit
      h4unit
      h43f
      hFf


  have hone :
      ∀ x : ZMod P,
        f (x + 1) = f x :=

    zmod_translation_one_of_half_translation
      f
      h2unit
      hhalf


  have hfconst :
      ∀ x : ZMod P,
        f x = f 0 :=

    zmod_constant_of_translation_one
      f
      hone


  refine
    ⟨N, f 0, ?_⟩


  intro n hn


  have htail :
      f (n : ZMod P) = seq n := by

    dsimp [f]

    exact
      tailColor_eq_seq_of_ge
        seq
        hPpos
        hN
        n
        hn


  have hc :
      f (n : ZMod P) = f 0 :=
    hfconst (n : ZMod P)


  exact
    htail.symm.trans hc



/-!
============================================================
16. Proposition 4.2 itself

Ultimately periodic means:

there exists some positive eventual period P.
============================================================
-/


theorem proposition4_2
    (seq : ℕ → Δ)

    (hperiodic :
      ∃ P : ℕ,
        0 < P ∧
        IsEventualPeriod seq P)

    (h43seq :
      ∀ n : ℕ,
        seq (4 * n) = seq (3 * n))

    (hstep :
      ∀ n : ℕ,
        seq (4 * n + 2) = seq n) :

    ∃ (N : ℕ) (c : Δ),
      ∀ n : ℕ,
        N ≤ n →
        seq n = c := by

  classical


  let P : ℕ :=
    Nat.find hperiodic


  have hspec :
      0 < P ∧
      IsEventualPeriod seq P := by

    dsimp [P]

    exact
      Nat.find_spec hperiodic


  have hPpos :
      0 < P :=
    hspec.1


  have hP :
      IsEventualPeriod seq P :=
    hspec.2


  have hminimal :
      ∀ d : ℕ,
        0 < d →
        d < P →
        ¬ IsEventualPeriod seq d := by

    intro d hd hdlt hdperiod


    have hlt :
        d < Nat.find hperiodic := by

      simpa [P] using hdlt


    have hnot :=
      Nat.find_min
        hperiodic
        hlt


    exact
      hnot
        ⟨hd, hdperiod⟩


  exact
    minimal_eventual_period_eventually_constant
      seq
      hPpos
      hP
      hminimal
      h43seq
      hstep



/-!
============================================================
17. Proposition 4.2 + Lemma 4.3

Ultimately periodic
+ the two Collatz identities
→ constant on all ℕ.
============================================================
-/


theorem section4_period_collapse
    (seq : ℕ → Δ)

    (hperiodic :
      ∃ P : ℕ,
        0 < P ∧
        IsEventualPeriod seq P)

    (h43seq :
      ∀ n : ℕ,
        seq (4 * n) = seq (3 * n))

    (hstep :
      ∀ n : ℕ,
        seq (4 * n + 2) = seq n) :

    ∃ c : Δ,
      ∀ n : ℕ,
        seq n = c := by


  have htail :
      ∃ (N : ℕ) (c : Δ),
        ∀ n : ℕ,
          N ≤ n →
          seq n = c :=

    proposition4_2
      seq
      hperiodic
      h43seq
      hstep


  exact
    lemma4_3
      seq
      htail
      hstep



/-!
============================================================
Optional axiom audit

必要なときだけ先頭の -- を外す。
============================================================
-/

-- #print axioms lemma4_1_first
-- #print axioms lemma4_1_second
-- #print axioms lemma4_3
-- #print axioms minimal_eventual_period_is_odd
-- #print axioms minimal_eventual_period_not_divisible_by_three
-- #print axioms proposition4_2
-- #print axioms section4_period_collapse

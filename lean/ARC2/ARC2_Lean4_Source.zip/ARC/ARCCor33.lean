import Mathlib
import ARC.ARCAutomaticBridge2

universe u


/-
  ============================================================
  ARC Corollary 3.3
  ============================================================

  Proposition 3.2 で得た

      b n = a (2*n + 1)

  が base 2 と base 3 の両方で automatic であることから、
  Cobham の定理を使って b が ultimately periodic であることを導く。

  ここでは Cobham の定理そのものを axiom として導入しない。

  代わりに、

      「Cobham の定理が成り立つ」

  という命題を明示的な仮定として theorem に渡す。

  したがって、このファイルで

      ・2 と 3 の multiplicative independence
      ・Proposition 3.2 から Cobham の適用条件への接続
      ・Corollary 3.3 の論理的導出

  は Lean が検証する。

  Cobham の定理そのものの Lean 形式化は別問題として明示的に残る。
-/


/--
A sequence is ultimately periodic if, after some index M,
it repeats with some positive period p.
-/
def ARCUltimatelyPeriodic
    {α : Type u}
    (b : ℕ → α) :
    Prop :=
  ∃ p M : ℕ,
    0 < p ∧
    ∀ m : ℕ,
      M ≤ m →
      b (m + p) = b m


/--
Two integer bases k and l are multiplicatively independent
if no positive powers of them are equal.
-/
def ARCMultiplicativelyIndependent
    (k l : ℕ) :
    Prop :=
  ∀ m n : ℕ,
    0 < m →
    0 < n →
    k ^ m ≠ l ^ n


/-
  ============================================================
  2 and 3 are multiplicatively independent
  ============================================================
-/

/--
2 and 3 are multiplicatively independent.

The proof uses the coprimality of powers of 2 and 3.
If 2^m = 3^n for positive m,n, that common number would be
coprime to itself, hence equal to 1, contradicting 1 < 3^n.
-/
theorem arc_two_three_multiplicatively_independent :
    ARCMultiplicativelyIndependent 2 3 := by

  intro m n hm hn hEq

  have hc :
      Nat.Coprime
        (2 ^ m)
        (3 ^ n) :=
    Nat.Coprime.pow
      m
      n
      (by
        norm_num :
        Nat.Coprime 2 3)

  rw [hEq] at hc

  have hone :
      3 ^ n = 1 :=
    (Nat.coprime_self (3 ^ n)).mp hc

  have hn_ne :
      n ≠ 0 :=
    Nat.ne_of_gt hn

  have hgt :
      1 < 3 ^ n :=
    Nat.one_lt_pow
      hn_ne
      (by norm_num)

  omega


/-
  ============================================================
  Cobham principle
  ============================================================

  This is NOT declared as an axiom.

  It is merely the exact mathematical statement that will be
  supplied as an explicit hypothesis when proving Corollary 3.3.

  This makes the boundary between

      Lean-proved ARC mathematics

  and

      externally cited Cobham theorem

  completely visible.
-/

/--
The form of Cobham's theorem needed by the ARC manuscript.

For finite-alphabet sequences:
if k,l ≥ 2 are multiplicatively independent and the sequence
is both k-automatic and l-automatic, then it is ultimately periodic.
-/
def ARCCobhamPrinciple :
    Prop :=
  ∀ {β : Type u}
    [Finite β]
    {k l : ℕ},
      2 ≤ k →
      2 ≤ l →
      ARCMultiplicativelyIndependent k l →
      ∀ b : ℕ → β,
        ARCMSDAutomatic k b →
        ARCMSDAutomatic l b →
        ARCUltimatelyPeriodic b


/-
  ============================================================
  Corollary 3.3
  ============================================================
-/

/--
Corollary 3.3, conditional only on the explicitly supplied
Cobham principle.

From Proposition 3.2:
    b(n) = a(2n+1)
is both 2-automatic and 3-automatic.

Since 2 and 3 are multiplicatively independent,
Cobham gives ultimate periodicity of b.
-/
theorem arc_corollary3_3_of_cobham
    {α : Type u}
    [Finite α]
    (hCobham : ARCCobhamPrinciple.{u})
    (a : ℕ → α)
    (hEven :
      ∀ n : ℕ,
        a (2 * n) = a n)
    (hOdd :
      ∀ n : ℕ,
        a (2 * n + 1) =
          a (3 * n + 2))
    (ha :
      ARCAutomaticByKernel 2 a) :
    ARCUltimatelyPeriodic
      (fun n =>
        a (2 * n + 1)) := by

  have hAuto :
      ARCMSDAutomatic
          2
          (fun n =>
            a (2 * n + 1))
        ∧
      ARCMSDAutomatic
          3
          (fun n =>
            a (2 * n + 1)) :=
    arc_proposition3_2_msd_form
      a
      hEven
      hOdd
      ha

  unfold ARCCobhamPrinciple at hCobham

  exact
    hCobham
      (β := α)
      (k := 2)
      (l := 3)
      (by norm_num)
      (by norm_num)
      arc_two_three_multiplicatively_independent
      (fun n =>
        a (2 * n + 1))
      hAuto.1
      hAuto.2


/-
  ============================================================
  Axiom audit
  ============================================================
-/

#print axioms arc_two_three_multiplicatively_independent
#print axioms arc_corollary3_3_of_cobham

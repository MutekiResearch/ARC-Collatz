import Mathlib
import ARC.ARCAutomaticBridge3

universe u


/-
  ============================================================
  ARC Automatic Bridge 4
  ============================================================

  Purpose:

  Our existing definition

      ARCMSDAutomatic k a

  requires the DFAO to produce the correct value for EVERY
  finite digit list.

  That is slightly stronger in presentation than the usual
  "canonical base-k representation" formulation, because
  arbitrary lists may contain leading zeros.

  In this file we introduce a canonical-MSD formulation and
  prove equivalence with ARCMSDAutomatic.

  Convention used here:

      0 is represented by the empty word [].

  Every nonempty canonical word must begin with a nonzero digit.

  Main bridge:

      ARCStandardMSDAutomatic k a
            ↔
      ARCMSDAutomatic k a

  The difficult direction removes leading zeros by modifying
  the finite automaton.
-/


/-
  ============================================================
  1. Numerical value of an MSD digit word
  ============================================================
-/

def arcMSDValue
    {k : ℕ}
    (L : List (Fin k)) :
    ℕ :=
  Nat.ofDigits
    k
    (
      L.reverse.map
        (fun d => d.val)
    )


/-
  ============================================================
  2. Canonical MSD words
  ============================================================
-/

def ARCIsCanonicalMSDWord
    {k : ℕ}
    (L : List (Fin k)) :
    Prop :=
  L = []
    ∨
  ∃ d : Fin k,
    ∃ ds : List (Fin k),
      L = d :: ds
        ∧
      d.val ≠ 0


/-
  ============================================================
  3. Canonical-word generation
  ============================================================
-/

def ARCMSDGeneratesCanonical
    {k : ℕ}
    {α : Type u}
    (M : ARCMSDDFAO k α)
    (a : ℕ → α) :
    Prop :=
  ∀ L : List (Fin k),
    ARCIsCanonicalMSDWord L →
    M.output
        (
          M.eval
            M.start
            L
        )
      =
    a (arcMSDValue L)


def ARCStandardMSDAutomatic
    (k : ℕ)
    (a : ℕ → α) :
    Prop :=
  ∃ M : ARCMSDDFAO k α,
    ARCMSDGeneratesCanonical M a


/-
  ============================================================
  4. Existing all-word generation immediately implies
     canonical generation
  ============================================================
-/

theorem arc_msd_generates_implies_canonical
    {k : ℕ}
    {α : Type u}
    (M : ARCMSDDFAO k α)
    (a : ℕ → α)
    (hM :
      ARCMSDDFAO.Generates
        M
        a) :
    ARCMSDGeneratesCanonical
      M
      a := by

  intro L hCanonical

  have h :=
    hM L

  simpa [arcMSDValue] using h


theorem arc_msd_automatic_implies_standard_msd_automatic
    {k : ℕ}
    {α : Type u}
    (a : ℕ → α)
    (ha :
      ARCMSDAutomatic
        k
        a) :
    ARCStandardMSDAutomatic
      k
      a := by

  rcases ha with
    ⟨M, hM⟩

  refine
    ⟨M, ?_⟩

  exact
    arc_msd_generates_implies_canonical
      M
      a
      hM


/-
  ============================================================
  5. Remove leading zeros
  ============================================================
-/

def arcDropLeadingZeros
    {k : ℕ} :
    List (Fin k) →
    List (Fin k)

  | [] =>
      []

  | d :: ds =>
      if d.val = 0 then
        arcDropLeadingZeros ds
      else
        d :: ds


/-
  ============================================================
  6. Dropping leading zeros produces a canonical word
  ============================================================
-/

theorem arc_drop_leading_zeros_canonical
    {k : ℕ}
    (L : List (Fin k)) :
    ARCIsCanonicalMSDWord
      (arcDropLeadingZeros L) := by

  induction L with

  | nil =>

      exact
        Or.inl rfl

  | cons d ds ih =>

      by_cases h :
          d.val = 0

      · rw [
          arcDropLeadingZeros,
          if_pos h
        ]

        exact ih

      · rw [
          arcDropLeadingZeros,
          if_neg h
        ]

        exact
          Or.inr
            ⟨
              d,
              ds,
              rfl,
              h
            ⟩


/-
  ============================================================
  7. Dropping leading zeros does not change the represented
     natural number
  ============================================================
-/

theorem arc_drop_leading_zeros_value
    {k : ℕ}
    (L : List (Fin k)) :
    arcMSDValue
        (arcDropLeadingZeros L)
      =
    arcMSDValue L := by

  induction L with

  | nil =>

      rfl

  | cons d ds ih =>

      by_cases h :
          d.val = 0

      · rw [
          arcDropLeadingZeros,
          if_pos h
        ]

        rw [ih]

        simp [
          arcMSDValue,
          List.reverse_cons,
          List.map_append,
          Nat.ofDigits_append,
          h
        ]

      · rw [
          arcDropLeadingZeros,
          if_neg h
        ]


/-
  ============================================================
  8. Normalize an MSD automaton so that leading zeros are
     ignored
  ============================================================
-/

def arcLeadingZeroNormalizedMSDDFAO
    {k : ℕ}
    {α : Type u}
    (M : ARCMSDDFAO k α) :
    ARCMSDDFAO k α := by

  letI :
      Finite M.State :=
    M.stateFinite

  exact
    {
      State :=
        Option M.State

      stateFinite := by
        infer_instance

      start :=
        none

      step :=
        fun s d =>
          match s with

          | none =>
              if d.val = 0 then
                none
              else
                some
                  (
                    M.step
                      M.start
                      d
                  )

          | some q =>
              some
                (
                  M.step
                    q
                    d
                )

      output :=
        fun s =>
          match s with

          | none =>
              M.output
                M.start

          | some q =>
              M.output q
    }


/-
  ============================================================
  9. Elementary facts about the normalized machine
  ============================================================
-/

theorem arc_lz_normalized_start
    {k : ℕ}
    {α : Type u}
    (M : ARCMSDDFAO k α) :
    (arcLeadingZeroNormalizedMSDDFAO M).start
      =
    none := by

  simp [
    arcLeadingZeroNormalizedMSDDFAO
  ]


theorem arc_lz_normalized_step_none_zero
    {k : ℕ}
    {α : Type u}
    (M : ARCMSDDFAO k α)
    (d : Fin k)
    (h :
      d.val = 0) :
    (arcLeadingZeroNormalizedMSDDFAO M).step
        none
        d
      =
    none := by

  simp [
    arcLeadingZeroNormalizedMSDDFAO,
    h
  ]


theorem arc_lz_normalized_step_none_nonzero
    {k : ℕ}
    {α : Type u}
    (M : ARCMSDDFAO k α)
    (d : Fin k)
    (h :
      d.val ≠ 0) :
    (arcLeadingZeroNormalizedMSDDFAO M).step
        none
        d
      =
    some
      (
        M.step
          M.start
          d
      ) := by

  simp [
    arcLeadingZeroNormalizedMSDDFAO,
    h
  ]


theorem arc_lz_normalized_step_some
    {k : ℕ}
    {α : Type u}
    (M : ARCMSDDFAO k α)
    (q : M.State)
    (d : Fin k) :
    (arcLeadingZeroNormalizedMSDDFAO M).step
        (some q)
        d
      =
    some
      (
        M.step
          q
          d
      ) := by

  simp [
    arcLeadingZeroNormalizedMSDDFAO
  ]


theorem arc_lz_normalized_output_none
    {k : ℕ}
    {α : Type u}
    (M : ARCMSDDFAO k α) :
    (arcLeadingZeroNormalizedMSDDFAO M).output
        none
      =
    M.output
      M.start := by

  simp [
    arcLeadingZeroNormalizedMSDDFAO
  ]


theorem arc_lz_normalized_output_some
    {k : ℕ}
    {α : Type u}
    (M : ARCMSDDFAO k α)
    (q : M.State) :
    (arcLeadingZeroNormalizedMSDDFAO M).output
        (some q)
      =
    M.output q := by

  simp [
    arcLeadingZeroNormalizedMSDDFAO
  ]


/-
  ============================================================
  10. Once normal execution starts, the normalized machine
      exactly simulates M
  ============================================================
-/

theorem arc_lz_normalized_eval_some
    {k : ℕ}
    {α : Type u}
    (M : ARCMSDDFAO k α)
    (q : M.State)
    (L : List (Fin k)) :
    (arcLeadingZeroNormalizedMSDDFAO M).eval
        (some q)
        L
      =
    some
      (
        M.eval
          q
          L
      ) := by

  induction L generalizing q with

  | nil =>

      rfl

  | cons d ds ih =>

      simp only [
        ARCMSDDFAO.eval
      ]

      rw [
        arc_lz_normalized_step_some
          M
          q
          d
      ]

      exact
        ih
          (M.step q d)


/-
  ============================================================
  11. Starting from "none" is equivalent to evaluating M on
      the word after all leading zeros have been deleted
  ============================================================
-/

theorem arc_lz_normalized_output_eval_none
    {k : ℕ}
    {α : Type u}
    (M : ARCMSDDFAO k α)
    (L : List (Fin k)) :
    (arcLeadingZeroNormalizedMSDDFAO M).output
      (
        (arcLeadingZeroNormalizedMSDDFAO M).eval
          none
          L
      )
      =
    M.output
      (
        M.eval
          M.start
          (arcDropLeadingZeros L)
      ) := by

  induction L with

  | nil =>

      change
        (arcLeadingZeroNormalizedMSDDFAO M).output
            none
          =
        M.output
          M.start

      exact
        arc_lz_normalized_output_none
          M

  | cons d ds ih =>

      by_cases h :
          d.val = 0

      · simp only [
          ARCMSDDFAO.eval
        ]

        rw [
          arc_lz_normalized_step_none_zero
            M
            d
            h
        ]

        simpa [
          arcDropLeadingZeros,
          h
        ] using ih

      · simp only [
          ARCMSDDFAO.eval
        ]

        rw [
          arc_lz_normalized_step_none_nonzero
            M
            d
            h
        ]

        rw [
          arc_lz_normalized_eval_some
            M
            (M.step M.start d)
            ds
        ]

        rw [
          arc_lz_normalized_output_some
            M
            (
              M.eval
                (M.step M.start d)
                ds
            )
        ]

        rw [
          arcDropLeadingZeros,
          if_neg h
        ]

        rfl


/-
  ============================================================
  12. Canonical generation ⇒ all-word generation
  ============================================================
-/

theorem arc_canonical_generates_implies_all_words
    {k : ℕ}
    {α : Type u}
    (M : ARCMSDDFAO k α)
    (a : ℕ → α)
    (hM :
      ARCMSDGeneratesCanonical
        M
        a) :
    ARCMSDDFAO.Generates
      (arcLeadingZeroNormalizedMSDDFAO M)
      a := by

  intro L

  have hCanonical :
      ARCIsCanonicalMSDWord
        (arcDropLeadingZeros L) :=
    arc_drop_leading_zeros_canonical
      L

  have hStandard :
      M.output
          (
            M.eval
              M.start
              (arcDropLeadingZeros L)
          )
        =
      a
        (
          arcMSDValue
            (arcDropLeadingZeros L)
        ) :=
    hM
      (arcDropLeadingZeros L)
      hCanonical

  have hValue :
      arcMSDValue
          (arcDropLeadingZeros L)
        =
      arcMSDValue L :=
    arc_drop_leading_zeros_value
      L

  calc
    (arcLeadingZeroNormalizedMSDDFAO M).output
        (
          (arcLeadingZeroNormalizedMSDDFAO M).eval
            (arcLeadingZeroNormalizedMSDDFAO M).start
            L
        )

        =
      (arcLeadingZeroNormalizedMSDDFAO M).output
        (
          (arcLeadingZeroNormalizedMSDDFAO M).eval
            none
            L
        ) := by

          rw [
            arc_lz_normalized_start
              M
          ]

    _ =
      M.output
        (
          M.eval
            M.start
            (arcDropLeadingZeros L)
        ) := by

          exact
            arc_lz_normalized_output_eval_none
              M
              L

    _ =
      a
        (
          arcMSDValue
            (arcDropLeadingZeros L)
        ) :=

          hStandard

    _ =
      a
        (
          arcMSDValue L
        ) := by

          rw [hValue]

    _ =
      a
        (
          Nat.ofDigits
            k
            (
              L.reverse.map
                (fun d => d.val)
            )
        ) := by

          rfl


/-
  ============================================================
  13. Standard MSD automatic ⇒ existing MSD automatic
  ============================================================
-/

theorem arc_standard_msd_automatic_implies_msd_automatic
    {k : ℕ}
    {α : Type u}
    (a : ℕ → α)
    (ha :
      ARCStandardMSDAutomatic
        k
        a) :
    ARCMSDAutomatic
      k
      a := by

  rcases ha with
    ⟨M, hM⟩

  refine
    ⟨
      arcLeadingZeroNormalizedMSDDFAO M,
      ?_
    ⟩

  exact
    arc_canonical_generates_implies_all_words
      M
      a
      hM


/-
  ============================================================
  14. Equivalence
  ============================================================
-/

theorem arc_standard_msd_automatic_iff_msd_automatic
    {k : ℕ}
    {α : Type u}
    (a : ℕ → α) :
    ARCStandardMSDAutomatic
        k
        a
      ↔
    ARCMSDAutomatic
        k
        a := by

  constructor

  · intro h

    exact
      arc_standard_msd_automatic_implies_msd_automatic
        a
        h

  · intro h

    exact
      arc_msd_automatic_implies_standard_msd_automatic
        a
        h


/-
  ============================================================
  15. Main ARC theorem with canonical-standard automaticity
      at the entrance
  ============================================================
-/

theorem arc_main_standard_msd_form_of_cobham
    {α : Type u}
    [Finite α]
    (hCobham :
      ARCCobhamPrinciple.{u})
    (a : ℕ → α)
    (hEven :
      ∀ n : ℕ,
        a (2 * n) =
          a n)
    (hOdd :
      ∀ n : ℕ,
        a (2 * n + 1) =
          a (3 * n + 2))
    (ha :
      ARCStandardMSDAutomatic
        2
        a) :
    ∃ c : α,
      ∀ N : ℕ,
        1 ≤ N →
        a N = c := by

  have ha' :
      ARCMSDAutomatic
        2
        a :=
    arc_standard_msd_automatic_implies_msd_automatic
      a
      ha

  exact
    arc_main_msd_form_of_cobham
      hCobham
      a
      hEven
      hOdd
      ha'


/-
  ============================================================
  16. Axiom audit
  ============================================================
-/

#print axioms arc_drop_leading_zeros_canonical

#print axioms arc_drop_leading_zeros_value

#print axioms arc_lz_normalized_step_none_zero

#print axioms arc_lz_normalized_step_none_nonzero

#print axioms arc_lz_normalized_step_some

#print axioms arc_lz_normalized_eval_some

#print axioms arc_lz_normalized_output_eval_none

#print axioms arc_msd_generates_implies_canonical

#print axioms arc_canonical_generates_implies_all_words

#print axioms arc_msd_automatic_implies_standard_msd_automatic

#print axioms arc_standard_msd_automatic_implies_msd_automatic

#print axioms arc_standard_msd_automatic_iff_msd_automatic

#print axioms arc_main_standard_msd_form_of_cobham

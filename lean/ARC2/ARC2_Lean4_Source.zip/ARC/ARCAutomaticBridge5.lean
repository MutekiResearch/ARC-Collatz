import Mathlib
import ARC.ARCAutomaticBridge4

universe u


/-
  ============================================================
  ARC Automatic Bridge 5
  ============================================================

  Purpose:

  Bridge 4 introduced canonical MSD automaticity using

      0 = []

  as the representation of zero.

  Another common convention uses

      0 = [0].

  Positive integers are represented in both conventions by
  nonempty words whose first digit is nonzero.

  This file proves that the two conventions define the same
  class of automatic sequences.

  Main result:

      ARCStandardMSDZeroDigitAutomatic k a
          ↔
      ARCStandardMSDAutomatic k a

  and therefore also

      ARCStandardMSDZeroDigitAutomatic k a
          ↔
      ARCMSDAutomatic k a.
-/


/-
  ============================================================
  1. Canonical MSD words with zero represented by [0]
  ============================================================
-/

/--
Canonical MSD representation using the convention

    0 = [0].

A word is canonical iff either

  * it consists of exactly one zero digit, or
  * it is nonempty and its first digit is nonzero.
-/
def ARCIsCanonicalMSDWordZeroDigit
    {k : ℕ}
    (L : List (Fin k)) :
    Prop :=
  (
    ∃ z : Fin k,
      z.val = 0
        ∧
      L = [z]
  )
    ∨
  (
    ∃ d : Fin k,
      ∃ ds : List (Fin k),
        L = d :: ds
          ∧
        d.val ≠ 0
  )


/-
  ============================================================
  2. Generation under the [0]-for-zero convention
  ============================================================
-/

def ARCMSDGeneratesCanonicalZeroDigit
    {k : ℕ}
    {α : Type u}
    (M : ARCMSDDFAO k α)
    (a : ℕ → α) :
    Prop :=
  ∀ L : List (Fin k),
    ARCIsCanonicalMSDWordZeroDigit L →
    M.output
        (
          M.eval
            M.start
            L
        )
      =
    a (arcMSDValue L)


def ARCStandardMSDZeroDigitAutomatic
    (k : ℕ)
    (a : ℕ → α) :
    Prop :=
  ∃ M : ARCMSDDFAO k α,
    ARCMSDGeneratesCanonicalZeroDigit M a


/-
  ============================================================
  3. A one-digit zero word really represents 0
  ============================================================
-/

theorem arc_single_zero_digit_value
    {k : ℕ}
    (z : Fin k)
    (hz :
      z.val = 0) :
    arcMSDValue [z] = 0 := by

  simp [
    arcMSDValue,
    hz
  ]


/-
  ============================================================
  4. All-word generation immediately implies the [0]
     canonical convention
  ============================================================
-/

theorem arc_msd_generates_implies_zero_digit_canonical
    {k : ℕ}
    {α : Type u}
    (M : ARCMSDDFAO k α)
    (a : ℕ → α)
    (hM :
      ARCMSDDFAO.Generates
        M
        a) :
    ARCMSDGeneratesCanonicalZeroDigit
      M
      a := by

  intro L hCanonical

  have h :=
    hM L

  simpa [arcMSDValue] using h


theorem arc_msd_automatic_implies_zero_digit_standard
    {k : ℕ}
    {α : Type u}
    (a : ℕ → α)
    (ha :
      ARCMSDAutomatic
        k
        a) :
    ARCStandardMSDZeroDigitAutomatic
      k
      a := by

  rcases ha with
    ⟨M, hM⟩

  refine
    ⟨M, ?_⟩

  exact
    arc_msd_generates_implies_zero_digit_canonical
      M
      a
      hM


/-
  ============================================================
  5. Add a fresh start state
  ============================================================

  To pass from the [0]-for-zero convention to the []-for-zero
  convention we introduce one new start state.

  State = Option M.State

      none   : fresh start state
      some q : ordinary state q of M

  On the first digit, the machine enters the corresponding
  state of M.

  The output of the fresh start state is chosen to be a(0).
  Therefore the empty word produces the correct value at zero.
-/


def arcFreshStartMSDDFAO
    {k : ℕ}
    {α : Type u}
    (M : ARCMSDDFAO k α)
    (zeroOutput : α) :
    ARCMSDDFAO k α := by

  letI :
      Finite M.State :=
    M.stateFinite

  exact
    {
      State :=
        Option M.State

      stateFinite := by
        infer_instance

      start :=
        none

      step :=
        fun s d =>
          match s with

          | none =>
              some
                (
                  M.step
                    M.start
                    d
                )

          | some q =>
              some
                (
                  M.step
                    q
                    d
                )

      output :=
        fun s =>
          match s with

          | none =>
              zeroOutput

          | some q =>
              M.output q
    }


/-
  ============================================================
  6. Elementary facts about the fresh-start machine
  ============================================================
-/

theorem arc_fresh_start_start
    {k : ℕ}
    {α : Type u}
    (M : ARCMSDDFAO k α)
    (zeroOutput : α) :
    (arcFreshStartMSDDFAO M zeroOutput).start
      =
    none := by

  simp [
    arcFreshStartMSDDFAO
  ]


theorem arc_fresh_start_step_none
    {k : ℕ}
    {α : Type u}
    (M : ARCMSDDFAO k α)
    (zeroOutput : α)
    (d : Fin k) :
    (arcFreshStartMSDDFAO M zeroOutput).step
        none
        d
      =
    some
      (
        M.step
          M.start
          d
      ) := by

  simp [
    arcFreshStartMSDDFAO
  ]


theorem arc_fresh_start_step_some
    {k : ℕ}
    {α : Type u}
    (M : ARCMSDDFAO k α)
    (zeroOutput : α)
    (q : M.State)
    (d : Fin k) :
    (arcFreshStartMSDDFAO M zeroOutput).step
        (some q)
        d
      =
    some
      (
        M.step
          q
          d
      ) := by

  simp [
    arcFreshStartMSDDFAO
  ]


theorem arc_fresh_start_output_start
    {k : ℕ}
    {α : Type u}
    (M : ARCMSDDFAO k α)
    (zeroOutput : α) :
    (arcFreshStartMSDDFAO M zeroOutput).output
        (arcFreshStartMSDDFAO M zeroOutput).start
      =
    zeroOutput := by

  simp [
    arcFreshStartMSDDFAO
  ]


theorem arc_fresh_start_output_some
    {k : ℕ}
    {α : Type u}
    (M : ARCMSDDFAO k α)
    (zeroOutput : α)
    (q : M.State) :
    (arcFreshStartMSDDFAO M zeroOutput).output
        (some q)
      =
    M.output q := by

  simp [
    arcFreshStartMSDDFAO
  ]


/-
  ============================================================
  7. Once M has been entered, evaluation agrees with M
  ============================================================
-/

theorem arc_fresh_start_eval_some
    {k : ℕ}
    {α : Type u}
    (M : ARCMSDDFAO k α)
    (zeroOutput : α)
    (q : M.State)
    (L : List (Fin k)) :
    (arcFreshStartMSDDFAO M zeroOutput).eval
        (some q)
        L
      =
    some
      (
        M.eval
          q
          L
      ) := by

  induction L generalizing q with

  | nil =>

      rfl

  | cons d ds ih =>

      simp only [
        ARCMSDDFAO.eval
      ]

      rw [
        arc_fresh_start_step_some
          M
          zeroOutput
          q
          d
      ]

      exact
        ih
          (M.step q d)


/-
  ============================================================
  8. Evaluation of every nonempty word agrees with M
  ============================================================
-/

theorem arc_fresh_start_eval_cons
    {k : ℕ}
    {α : Type u}
    (M : ARCMSDDFAO k α)
    (zeroOutput : α)
    (d : Fin k)
    (ds : List (Fin k)) :
    (arcFreshStartMSDDFAO M zeroOutput).eval
        (arcFreshStartMSDDFAO M zeroOutput).start
        (d :: ds)
      =
    some
      (
        M.eval
          M.start
          (d :: ds)
      ) := by

  rw [
    arc_fresh_start_start
      M
      zeroOutput
  ]

  simp only [
    ARCMSDDFAO.eval
  ]

  rw [
    arc_fresh_start_step_none
      M
      zeroOutput
      d
  ]

  rw [
    arc_fresh_start_eval_some
      M
      zeroOutput
      (M.step M.start d)
      ds
  ]


/-
  ============================================================
  9. Therefore outputs agree on every nonempty word
  ============================================================
-/

theorem arc_fresh_start_output_eval_cons
    {k : ℕ}
    {α : Type u}
    (M : ARCMSDDFAO k α)
    (zeroOutput : α)
    (d : Fin k)
    (ds : List (Fin k)) :
    (arcFreshStartMSDDFAO M zeroOutput).output
      (
        (arcFreshStartMSDDFAO M zeroOutput).eval
          (arcFreshStartMSDDFAO M zeroOutput).start
          (d :: ds)
      )
      =
    M.output
      (
        M.eval
          M.start
          (d :: ds)
      ) := by

  rw [
    arc_fresh_start_eval_cons
      M
      zeroOutput
      d
      ds
  ]

  rw [
    arc_fresh_start_output_some
      M
      zeroOutput
      (
        M.eval
          M.start
          (d :: ds)
      )
  ]


/-
  ============================================================
  10. [0]-canonical generation implies []-canonical generation
  ============================================================
-/

theorem arc_zero_digit_canonical_generates_implies_empty_canonical
    {k : ℕ}
    {α : Type u}
    (M : ARCMSDDFAO k α)
    (a : ℕ → α)
    (hM :
      ARCMSDGeneratesCanonicalZeroDigit
        M
        a) :
    ARCMSDGeneratesCanonical
      (arcFreshStartMSDDFAO M (a 0))
      a := by

  intro L hCanonical

  rcases hCanonical with
    hEmpty | hPositive

  · subst L

    have hOut :
        (arcFreshStartMSDDFAO M (a 0)).output
            (arcFreshStartMSDDFAO M (a 0)).start
          =
        a 0 :=
      arc_fresh_start_output_start
        M
        (a 0)

    simpa [
      ARCMSDDFAO.eval,
      arcMSDValue
    ] using hOut

  · rcases hPositive with
      ⟨d, ds, hL, hd⟩

    subst L

    have hZeroConvention :
        ARCIsCanonicalMSDWordZeroDigit
          (d :: ds) :=
      Or.inr
        ⟨
          d,
          ds,
          rfl,
          hd
        ⟩

    have hOld :
        M.output
            (
              M.eval
                M.start
                (d :: ds)
            )
          =
        a
          (
            arcMSDValue
              (d :: ds)
          ) :=
      hM
        (d :: ds)
        hZeroConvention

    calc
      (arcFreshStartMSDDFAO M (a 0)).output
          (
            (arcFreshStartMSDDFAO M (a 0)).eval
              (arcFreshStartMSDDFAO M (a 0)).start
              (d :: ds)
          )

          =
        M.output
          (
            M.eval
              M.start
              (d :: ds)
          ) := by

            exact
              arc_fresh_start_output_eval_cons
                M
                (a 0)
                d
                ds

      _ =
        a
          (
            arcMSDValue
              (d :: ds)
          ) :=
            hOld


/-
  ============================================================
  11. [0]-standard automatic ⇒ []-standard automatic
  ============================================================
-/

theorem arc_zero_digit_standard_implies_standard
    {k : ℕ}
    {α : Type u}
    (a : ℕ → α)
    (ha :
      ARCStandardMSDZeroDigitAutomatic
        k
        a) :
    ARCStandardMSDAutomatic
      k
      a := by

  rcases ha with
    ⟨M, hM⟩

  refine
    ⟨
      arcFreshStartMSDDFAO
        M
        (a 0),
      ?_
    ⟩

  exact
    arc_zero_digit_canonical_generates_implies_empty_canonical
      M
      a
      hM


/-
  ============================================================
  12. []-standard automatic ⇒ [0]-standard automatic
  ============================================================

  Bridge 4 already proved

      []-standard automatic
          ⇒
      all-word MSD automatic.

  All-word automaticity immediately implies correctness on
  the [0]-canonical words.
-/


theorem arc_standard_implies_zero_digit_standard
    {k : ℕ}
    {α : Type u}
    (a : ℕ → α)
    (ha :
      ARCStandardMSDAutomatic
        k
        a) :
    ARCStandardMSDZeroDigitAutomatic
      k
      a := by

  have hAll :
      ARCMSDAutomatic
        k
        a :=
    arc_standard_msd_automatic_implies_msd_automatic
      a
      ha

  exact
    arc_msd_automatic_implies_zero_digit_standard
      a
      hAll


/-
  ============================================================
  13. The two zero conventions are equivalent
  ============================================================
-/

theorem arc_zero_digit_standard_iff_standard
    {k : ℕ}
    {α : Type u}
    (a : ℕ → α) :
    ARCStandardMSDZeroDigitAutomatic
        k
        a
      ↔
    ARCStandardMSDAutomatic
        k
        a := by

  constructor

  · intro h

    exact
      arc_zero_digit_standard_implies_standard
        a
        h

  · intro h

    exact
      arc_standard_implies_zero_digit_standard
        a
        h


/-
  ============================================================
  14. [0]-standard automaticity is also equivalent to the
      existing all-word ARCMSDAutomatic definition
  ============================================================
-/

theorem arc_zero_digit_standard_implies_msd_automatic
    {k : ℕ}
    {α : Type u}
    (a : ℕ → α)
    (ha :
      ARCStandardMSDZeroDigitAutomatic
        k
        a) :
    ARCMSDAutomatic
      k
      a := by

  have hStandard :
      ARCStandardMSDAutomatic
        k
        a :=
    arc_zero_digit_standard_implies_standard
      a
      ha

  exact
    arc_standard_msd_automatic_implies_msd_automatic
      a
      hStandard


theorem arc_zero_digit_standard_iff_msd_automatic
    {k : ℕ}
    {α : Type u}
    (a : ℕ → α) :
    ARCStandardMSDZeroDigitAutomatic
        k
        a
      ↔
    ARCMSDAutomatic
        k
        a := by

  constructor

  · intro h

    exact
      arc_zero_digit_standard_implies_msd_automatic
        a
        h

  · intro h

    exact
      arc_msd_automatic_implies_zero_digit_standard
        a
        h


/-
  ============================================================
  15. Main ARC theorem using the [0]-for-zero convention
  ============================================================
-/

theorem arc_main_zero_digit_standard_msd_form_of_cobham
    {α : Type u}
    [Finite α]
    (hCobham :
      ARCCobhamPrinciple.{u})
    (a : ℕ → α)
    (hEven :
      ∀ n : ℕ,
        a (2 * n) =
          a n)
    (hOdd :
      ∀ n : ℕ,
        a (2 * n + 1) =
          a (3 * n + 2))
    (ha :
      ARCStandardMSDZeroDigitAutomatic
        2
        a) :
    ∃ c : α,
      ∀ N : ℕ,
        1 ≤ N →
        a N = c := by

  have hStandard :
      ARCStandardMSDAutomatic
        2
        a :=
    arc_zero_digit_standard_implies_standard
      a
      ha

  exact
    arc_main_standard_msd_form_of_cobham
      hCobham
      a
      hEven
      hOdd
      hStandard


/-
  ============================================================
  16. Axiom audit
  ============================================================
-/

#print axioms arc_single_zero_digit_value

#print axioms arc_msd_generates_implies_zero_digit_canonical

#print axioms arc_msd_automatic_implies_zero_digit_standard

#print axioms arc_fresh_start_start

#print axioms arc_fresh_start_step_none

#print axioms arc_fresh_start_step_some

#print axioms arc_fresh_start_eval_some

#print axioms arc_fresh_start_eval_cons

#print axioms arc_fresh_start_output_eval_cons

#print axioms arc_zero_digit_canonical_generates_implies_empty_canonical

#print axioms arc_zero_digit_standard_implies_standard

#print axioms arc_standard_implies_zero_digit_standard

#print axioms arc_zero_digit_standard_iff_standard

#print axioms arc_zero_digit_standard_implies_msd_automatic

#print axioms arc_zero_digit_standard_iff_msd_automatic

#print axioms arc_main_zero_digit_standard_msd_form_of_cobham

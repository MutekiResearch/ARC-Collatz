import Mathlib
import ARC.ARCLemma31Full

set_option autoImplicit false


/-!
# ARC Proposition 3.2 — kernel formalization

Let

  b(n) = a(2n+1).

We formalize the two kernel inclusions used in
Proposition 3.2:

  K₂(b) ⊆ K₂(a),

and

  K₃(b) ⊆ K₂(a).

Therefore, if K₂(a) is finite, then both K₂(b)
and K₃(b) are finite.

For finite-alphabet sequences, the standard
finite-kernel characterization identifies this
with 2-automaticity and 3-automaticity.
-/



/-!
============================================================
1. General k-kernel
============================================================
-/


def ARCKernel
    {α : Type*}
    (k : ℕ)
    (a : ℕ → α) :

    Set (ℕ → α) :=

  {
    u |
      ∃ e r : ℕ,

        r < k ^ e
          ∧

        ∀ n : ℕ,

          u n
            =
          a (k ^ e * n + r)
  }



/-!
============================================================
2. Automaticity represented by finite kernel

We deliberately call this AutomaticByKernel.

No DFA theorem is silently inserted here.

For finite alphabets, ordinary k-automaticity is
equivalent to finiteness of the k-kernel.
============================================================
-/


def ARCAutomaticByKernel
    {α : Type*}
    (k : ℕ)
    (a : ℕ → α) :

    Prop :=

  (ARCKernel k a).Finite



/-!
============================================================
3. The odd subsequence itself belongs to K₂(a)

b(n) = a(2n+1).

Take

  e = 1,
  r = 1.
============================================================
-/


lemma arc_odd_subsequence_mem_two_kernel
    {α : Type*}
    (a : ℕ → α) :

    (fun n =>
      a (2 * n + 1))
      ∈
    ARCKernel 2 a := by


  change
    ∃ e r : ℕ,

      r < 2 ^ e
        ∧

      ∀ n : ℕ,

        a (2 * n + 1)
          =
        a (2 ^ e * n + r)


  refine
    ⟨1, 1, ?_, ?_⟩


  · norm_num


  · intro n

    norm_num



/-!
============================================================
4. K₂(b) ⊆ K₂(a)

Let

  b(n) = a(2n+1).

A general member of K₂(b) has the form

  u(n) = b(2^e n+r).

Therefore

  u(n)
    =
  a(2(2^e n+r)+1)

    =
  a(2^(e+1)n + (2r+1)).

Since

  r < 2^e,

we have

  2r+1 < 2^(e+1).
============================================================
-/


theorem arc_two_kernel_odd_subset
    {α : Type*}
    (a : ℕ → α) :

    ARCKernel
      2
      (fun n =>
        a (2 * n + 1))

      ⊆

    ARCKernel
      2
      a := by


  intro u hu


  /-
  IMPORTANT:

  hu belongs to the 2-kernel of the ODD SUBSEQUENCE b,
  not directly to the 2-kernel of a.

  Hence the correct expansion is

    u(n)
      =
    a(2(2^e n+r)+1).
  -/

  have hu' :

      ∃ e r : ℕ,

        r < 2 ^ e
          ∧

        ∀ n : ℕ,

          u n
            =
          a (
            2 * (2 ^ e * n + r) + 1
          ) := by

    simpa [ARCKernel] using hu


  rcases hu' with
    ⟨e, r, hr, hu_eq⟩


  change
    ∃ E R : ℕ,

      R < 2 ^ E
        ∧

      ∀ n : ℕ,

        u n
          =
        a (2 ^ E * n + R)


  refine
    ⟨e + 1, 2 * r + 1, ?_, ?_⟩


  /-
  Remainder bound:

    r < 2^e

  implies

    2r+1 < 2^(e+1).
  -/

  ·
    rw [pow_succ]

    omega


  /-
  Pointwise sequence equality.
  -/

  ·
    intro n


    calc

      u n

          =
        a (
          2 * (2 ^ e * n + r) + 1
        ) :=

        hu_eq n


      _ =
        a (
          2 ^ (e + 1) * n
            +
          (2 * r + 1)
        ) := by

        congr 1

        rw [pow_succ]

        ring



/-!
============================================================
5. Arithmetic facts for the 3-kernel transfer

For

  c = 3r+2

and

  r < 3^e,

we require

  0 < c,

  c < 3^(e+1),

and

  3 ∤ c.

These are exactly the hypotheses needed for
the already verified Lemma 3.1.
============================================================
-/


lemma arc_three_r_plus_two_positive
    (r : ℕ) :

    0 < 3 * r + 2 := by

  omega



lemma arc_three_r_plus_two_lt
    (e r : ℕ)
    (hr :
      r < 3 ^ e) :

    3 * r + 2
      <
    3 ^ (e + 1) := by

  rw [pow_succ]

  omega



lemma arc_three_not_dvd_three_r_plus_two
    (r : ℕ) :

    ¬ 3 ∣ 3 * r + 2 := by

  intro h


  rcases h with
    ⟨d, hd⟩


  omega



/-!
============================================================
6. K₃(b) ⊆ K₂(a)

A member of K₃(b) has the form

  u(n) = b(3^e n+r).

Because

  b(m)=a(2m+1),

and

  a(2m+1)=a(3m+2),

we get

  u(n)
    =
  a(3^(e+1)n + (3r+2)).

Set

  c = 3r+2.

Then

  0 < c < 3^(e+1),

and

  3 ∤ c.

Lemma 3.1 therefore places this sequence
inside K₂(a).
============================================================
-/


theorem arc_three_kernel_odd_subset
    {α : Type*}
    (a : ℕ → α)

    (hEven :
      ∀ n : ℕ,

        a (2 * n)
          =
        a n)

    (hOdd :
      ∀ n : ℕ,

        a (2 * n + 1)
          =
        a (3 * n + 2)) :

    ARCKernel
      3
      (fun n =>
        a (2 * n + 1))

      ⊆

    ARCKernel
      2
      a := by


  intro u hu


  /-
  Expand membership in K₃(b), where

    b(m)=a(2m+1).
  -/

  have hu' :

      ∃ e r : ℕ,

        r < 3 ^ e
          ∧

        ∀ n : ℕ,

          u n
            =
          a (
            2 * (3 ^ e * n + r) + 1
          ) := by

    simpa [ARCKernel] using hu


  rcases hu' with
    ⟨e, r, hr, hu_eq⟩


  let c :
      ℕ :=
    3 * r + 2


  have hc_pos :
      0 < c := by

    dsimp [c]

    exact
      arc_three_r_plus_two_positive
        r


  have hc_lt :
      c < 3 ^ (e + 1) := by

    dsimp [c]

    exact
      arc_three_r_plus_two_lt
        e
        r
        hr


  have hc3 :
      ¬ 3 ∣ c := by

    dsimp [c]

    exact
      arc_three_not_dvd_three_r_plus_two
        r


  /-
  Invoke the already Lean-verified Lemma 3.1.
  -/

  have hlemma31 :

      ARCInTwoKernel
        a
        (fun n =>
          a (
            3 ^ (e + 1) * n
              +
            c
          )) := by


    exact
      arc_lemma3_1
        a
        hEven
        hOdd
        (e + 1)
        c
        (by omega)
        hc_pos
        hc_lt
        hc3


  unfold ARCInTwoKernel at hlemma31


  rcases hlemma31 with
    ⟨E, R, hR, hseq⟩


  change
    ∃ E R : ℕ,

      R < 2 ^ E
        ∧

      ∀ n : ℕ,

        u n
          =
        a (2 ^ E * n + R)


  refine
    ⟨E, R, hR, ?_⟩


  intro n


  calc

    u n

        =
      a (
        2 * (3 ^ e * n + r) + 1
      ) :=

      hu_eq n


    /-
    Here we use the actual Collatz odd identity:

      a(2m+1)=a(3m+2).
    -/

    _ =
      a (
        3 * (3 ^ e * n + r) + 2
      ) :=

      hOdd
        (3 ^ e * n + r)


    _ =
      a (
        3 ^ (e + 1) * n
          +
        c
      ) := by

      congr 1

      dsimp [c]

      rw [pow_succ]

      ring


    _ =
      a (
        2 ^ E * n
          +
        R
      ) :=

      hseq n



/-!
============================================================
7. Finiteness of K₂(b)

If

  K₂(a)

is finite and

  K₂(b) ⊆ K₂(a),

then K₂(b) is finite.
============================================================
-/


theorem arc_two_kernel_odd_finite
    {α : Type*}
    (a : ℕ → α)

    (ha :
      (ARCKernel 2 a).Finite) :

    (
      ARCKernel
        2
        (fun n =>
          a (2 * n + 1))
    ).Finite := by


  exact
    ha.subset
      (
        arc_two_kernel_odd_subset
          a
      )



/-!
============================================================
8. Finiteness of K₃(b)

Lemma 3.1 gives

  K₃(b) ⊆ K₂(a).

Therefore finite K₂(a) implies finite K₃(b).
============================================================
-/


theorem arc_three_kernel_odd_finite
    {α : Type*}
    (a : ℕ → α)

    (hEven :
      ∀ n : ℕ,

        a (2 * n)
          =
        a n)

    (hOdd :
      ∀ n : ℕ,

        a (2 * n + 1)
          =
        a (3 * n + 2))

    (ha :
      (ARCKernel 2 a).Finite) :

    (
      ARCKernel
        3
        (fun n =>
          a (2 * n + 1))
    ).Finite := by


  exact
    ha.subset
      (
        arc_three_kernel_odd_subset
          a
          hEven
          hOdd
      )



/-!
============================================================
9. Proposition 3.2 — finite-kernel form

Let

  b(n)=a(2n+1).

If a has finite 2-kernel and satisfies the two
Collatz-invariance identities, then b has

  finite 2-kernel,

and

  finite 3-kernel.

For finite-alphabet sequences, the standard
finite-kernel theorem converts these into
2-automaticity and 3-automaticity.
============================================================
-/


theorem arc_proposition3_2_kernel_form
    {α : Type*}
    [Finite α]

    (a : ℕ → α)

    (hEven :
      ∀ n : ℕ,

        a (2 * n)
          =
        a n)

    (hOdd :
      ∀ n : ℕ,

        a (2 * n + 1)
          =
        a (3 * n + 2))

    (ha :
      ARCAutomaticByKernel
        2
        a) :

    ARCAutomaticByKernel
      2
      (fun n =>
        a (2 * n + 1))

      ∧

    ARCAutomaticByKernel
      3
      (fun n =>
        a (2 * n + 1)) := by


  unfold ARCAutomaticByKernel at ha ⊢


  constructor


  ·
    exact
      arc_two_kernel_odd_finite
        a
        ha


  ·
    exact
      arc_three_kernel_odd_finite
        a
        hEven
        hOdd
        ha



/-!
============================================================
10. Direct inclusion form

This records explicitly the two inclusions used in
the manuscript proof:

  K₂(b) ⊆ K₂(a),

  K₃(b) ⊆ K₂(a).
============================================================
-/


theorem arc_proposition3_2_kernel_inclusions
    {α : Type*}

    (a : ℕ → α)

    (hEven :
      ∀ n : ℕ,

        a (2 * n)
          =
        a n)

    (hOdd :
      ∀ n : ℕ,

        a (2 * n + 1)
          =
        a (3 * n + 2)) :

    ARCKernel
      2
      (fun n =>
        a (2 * n + 1))

      ⊆

    ARCKernel 2 a

      ∧

    ARCKernel
      3
      (fun n =>
        a (2 * n + 1))

      ⊆

    ARCKernel 2 a := by


  constructor


  ·
    exact
      arc_two_kernel_odd_subset
        a


  ·
    exact
      arc_three_kernel_odd_subset
        a
        hEven
        hOdd



/-!
============================================================
11. Axiom audit
============================================================
-/


#print axioms arc_odd_subsequence_mem_two_kernel

#print axioms arc_two_kernel_odd_subset

#print axioms arc_three_kernel_odd_subset

#print axioms arc_two_kernel_odd_finite

#print axioms arc_three_kernel_odd_finite

#print axioms arc_proposition3_2_kernel_form

#print axioms arc_proposition3_2_kernel_inclusions

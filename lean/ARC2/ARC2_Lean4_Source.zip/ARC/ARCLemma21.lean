import Mathlib

set_option autoImplicit false


/-!
# ARC Lemma 2.1 — Lean verification

論文の Lemma 2.1：

For every j ≥ 1,
2 is a primitive root modulo 3^j.

ここでは primitive root modulo m を

  gcd(g,m)=1
  かつ
  ZMod m における g の乗法位数が φ(m)

として形式化する。

原稿の p-adic valuation による証明とは別に、
Mathlib の既存の位数定理を利用して
Lemma 2.1 の結論そのものを独立に形式検証する。
-/


/-!
============================================================
1. Primitive-root predicate
============================================================
-/


def ARCIsPrimitiveRootMod
    (g m : ℕ) : Prop :=

  Nat.Coprime g m
    ∧
  orderOf (g : ZMod m) = m.totient



/-!
============================================================
2. Order of 4 modulo 3^(n+1)

Mathlib:

  orderOf (1+p) mod p^(n+1) = p^n

for odd prime p.

For p=3,

  1+3 = 4

therefore

  ord_(3^(n+1))(4) = 3^n.
============================================================
-/


theorem arc_orderOf_four_mod_three_pow_succ
    (n : ℕ) :

    orderOf
      (4 : ZMod (3 ^ (n + 1)))
      =
    3 ^ n := by

  have h :=
    ZMod.orderOf_one_add_prime
      (p := 3)
      (by norm_num)
      (by norm_num)
      n

  norm_num at h ⊢

  exact h



/-!
============================================================
3. The order of 2 is even

Reduction

  ZMod(3^(n+1)) → ZMod 3

sends 2 to 2.

Modulo 3,

  2² = 1
  2 ≠ 1,

so orderOf(2 mod 3)=2.

Therefore

  2 ∣ orderOf(2 mod 3^(n+1)).
============================================================
-/


lemma arc_two_dvd_orderOf_two_mod_three_pow_succ
    (n : ℕ) :

    2 ∣
      orderOf
        (2 : ZMod (3 ^ (n + 1))) := by


  -- 3 divides 3^(n+1).
  have h3dvd :
      3 ∣ 3 ^ (n + 1) := by

    refine ⟨3 ^ n, ?_⟩

    rw [pow_succ]

    ring


  -- Canonical reduction map
  --
  -- ZMod(3^(n+1)) → ZMod 3
  let φ :
      ZMod (3 ^ (n + 1))
        →*
      ZMod 3 :=

    (ZMod.castHom
      h3dvd
      (ZMod 3)).toMonoidHom


  -- Reduction sends 2 to 2.
  have hmap2 :
      φ (2 : ZMod (3 ^ (n + 1)))
        =
      (2 : ZMod 3) := by

    change
      ZMod.cast
          (2 : ZMod (3 ^ (n + 1)))
        =
      (2 : ZMod 3)

    simpa using
      (ZMod.cast_natCast
        (n := 3 ^ (n + 1))
        (R := ZMod 3)
        h3dvd
        2)


  -- 2 has multiplicative order exactly 2 modulo 3.
  --
  -- Ordinary `decide` is used here rather than
  -- `native_decide`, so that no native-decide axioms
  -- are introduced into the final axiom audit.
  have horder3 :
      orderOf (2 : ZMod 3) = 2 := by

    letI :
        Fact (Nat.Prime 2) :=
      ⟨by norm_num⟩

    apply orderOf_eq_prime

    -- (2 mod 3)^2 = 1
    · decide

    -- 2 mod 3 ≠ 1
    · decide


  -- Order of the image divides the order of original.
  have hdiv :=
    orderOf_map_dvd
      φ
      (2 : ZMod (3 ^ (n + 1)))


  rw [hmap2, horder3] at hdiv

  exact hdiv



/-!
============================================================
4. 3^n divides the order of 2

Since

  4 = 2²,

the order of 4 divides the order of 2.

But

  ord(4)=3^n.

Therefore

  3^n ∣ ord(2).
============================================================
-/


lemma arc_three_pow_dvd_orderOf_two_mod_three_pow_succ
    (n : ℕ) :

    3 ^ n ∣
      orderOf
        (2 : ZMod (3 ^ (n + 1))) := by


  have h :=
    orderOf_pow_dvd
      (x :=
        (2 : ZMod (3 ^ (n + 1))))
      2


  have hsq :
      (2 : ZMod (3 ^ (n + 1))) ^ 2
        =
      4 := by

    norm_num


  rw [hsq] at h

  rw [
    arc_orderOf_four_mod_three_pow_succ n
  ] at h

  exact h



/-!
============================================================
5. ord(2) divides 2*3^n

Since

  ord(4)=3^n,

we have

  4^(3^n)=1.

But

  4^(3^n)=2^(2*3^n).

Therefore

  ord(2) ∣ 2*3^n.
============================================================
-/


lemma arc_orderOf_two_dvd_full_order
    (n : ℕ) :

    orderOf
      (2 : ZMod (3 ^ (n + 1)))
      ∣
    2 * 3 ^ n := by


  have h4 :
      (4 : ZMod (3 ^ (n + 1)))
        ^
      (3 ^ n)
        =
      1 := by

    have h :=
      pow_orderOf_eq_one
        (4 : ZMod (3 ^ (n + 1)))

    rw [
      arc_orderOf_four_mod_three_pow_succ n
    ] at h

    exact h


  have h2 :
      (2 : ZMod (3 ^ (n + 1)))
        ^
      (2 * 3 ^ n)
        =
      1 := by

    calc
      (2 : ZMod (3 ^ (n + 1)))
          ^
        (2 * 3 ^ n)

          =
        ((2 : ZMod (3 ^ (n + 1))) ^ 2)
          ^
        (3 ^ n) := by

            rw [pow_mul]


      _ =
        (4 : ZMod (3 ^ (n + 1)))
          ^
        (3 ^ n) := by

          norm_num


      _ =
        1 :=
          h4


  exact
    orderOf_dvd_of_pow_eq_one
      h2



/-!
============================================================
6. 2*3^n divides ord(2)

We already know

  2   ∣ ord(2)
  3^n ∣ ord(2).

Since

  gcd(2,3^n)=1,

their product divides ord(2).
============================================================
-/


lemma arc_full_order_dvd_orderOf_two
    (n : ℕ) :

    2 * 3 ^ n ∣
      orderOf
        (2 : ZMod (3 ^ (n + 1))) := by


  have h2 :
      2 ∣
        orderOf
          (2 : ZMod (3 ^ (n + 1))) :=

    arc_two_dvd_orderOf_two_mod_three_pow_succ
      n


  have h3 :
      3 ^ n ∣
        orderOf
          (2 : ZMod (3 ^ (n + 1))) :=

    arc_three_pow_dvd_orderOf_two_mod_three_pow_succ
      n


  have hcop :
      Nat.Coprime 2 (3 ^ n) := by

    have h23 :
        Nat.Coprime 2 3 := by

      norm_num

    exact
      h23.pow_right n


  exact
    hcop.mul_dvd_of_dvd_of_dvd
      h2
      h3



/-!
============================================================
7. Exact order of 2

Both divisibilities give

  ord_(3^(n+1))(2)
    =
  2*3^n.
============================================================
-/


theorem arc_orderOf_two_mod_three_pow_succ
    (n : ℕ) :

    orderOf
      (2 : ZMod (3 ^ (n + 1)))
      =
    2 * 3 ^ n := by


  apply Nat.dvd_antisymm


  · exact
      arc_orderOf_two_dvd_full_order
        n


  · exact
      arc_full_order_dvd_orderOf_two
        n



/-!
============================================================
8. Euler totient

φ(3^(n+1))
  =
3^n(3-1)
  =
2*3^n.
============================================================
-/


theorem arc_totient_three_pow_succ
    (n : ℕ) :

    (3 ^ (n + 1)).totient
      =
    2 * 3 ^ n := by


  have h :=
    Nat.totient_prime_pow_succ
      (p := 3)
      (by norm_num)
      n


  calc
    (3 ^ (n + 1)).totient
        =
      3 ^ n * (3 - 1) :=
        h

    _ =
      2 * 3 ^ n := by
        omega



/-!
============================================================
9. Lemma 2.1 — successor form

For all n ≥ 0,

  2 is a primitive root modulo 3^(n+1).
============================================================
-/


theorem arc_lemma2_1_succ
    (n : ℕ) :

    ARCIsPrimitiveRootMod
      2
      (3 ^ (n + 1)) := by


  constructor


  -- gcd(2,3^(n+1)) = 1
  ·
    have h23 :
        Nat.Coprime 2 3 := by

      norm_num

    exact
      h23.pow_right (n + 1)


  -- orderOf(2) = φ(3^(n+1))
  ·
    change
      orderOf
        (2 : ZMod (3 ^ (n + 1)))
        =
      (3 ^ (n + 1)).totient

    exact
      (arc_orderOf_two_mod_three_pow_succ n).trans
        (arc_totient_three_pow_succ n).symm



/-!
============================================================
10. Lemma 2.1 — paper indexing

For every j ≥ 1,

  2 is a primitive root modulo 3^j.
============================================================
-/


theorem arc_lemma2_1
    (j : ℕ)
    (hj :
      1 ≤ j) :

    ARCIsPrimitiveRootMod
      2
      (3 ^ j) := by


  cases j with

  | zero =>

      omega


  | succ n =>

      simpa [
        Nat.succ_eq_add_one
      ] using

        arc_lemma2_1_succ
          n



/-!
============================================================
11. Explicit order formula

For every j ≥ 1,

  ord_(3^j)(2)
    =
  2*3^(j-1).
============================================================
-/


theorem arc_lemma2_1_order_formula
    (j : ℕ)
    (hj :
      1 ≤ j) :

    orderOf
      (2 : ZMod (3 ^ j))
      =
    2 * 3 ^ (j - 1) := by


  cases j with

  | zero =>

      omega


  | succ n =>

      simpa [
        Nat.succ_eq_add_one
      ] using

        arc_orderOf_two_mod_three_pow_succ
          n



/-!
============================================================
12. Axiom audit
============================================================
-/


#print axioms arc_orderOf_four_mod_three_pow_succ
#print axioms arc_two_dvd_orderOf_two_mod_three_pow_succ
#print axioms arc_three_pow_dvd_orderOf_two_mod_three_pow_succ
#print axioms arc_orderOf_two_mod_three_pow_succ
#print axioms arc_lemma2_1_succ
#print axioms arc_lemma2_1
#print axioms arc_lemma2_1_order_formula

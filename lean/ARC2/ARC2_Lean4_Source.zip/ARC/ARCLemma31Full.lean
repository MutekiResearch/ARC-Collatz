import Mathlib
import ARC.ARCLemma31

set_option autoImplicit false


/-!
# ARC Lemma 3.1 — full formalization

This file completes the formal verification of Lemma 3.1.

Already verified in ARCLemma31:

  If j ≥ 1 and 3 ∤ c,
  then there exist s,q ∈ ℕ such that

      2^s c + 1 = q 3^j.

We now formalize the remaining steps from the paper.

The Collatz-invariance identities are

  a(2n)     = a(n)
  a(2n + 1) = a(3n + 2).

From the first identity we may multiply an index by 2^s
without changing the sequence value.

From the second identity we obtain the backward relation

  a(3m - 1) = a(2m - 1),

and iterate it j times.

Finally we prove that

  a(3^j n + c)
    =
  a(2^(s+j) n + r)

where

  r = 2^j q - 1

and

  r < 2^(s+j).

Thus the subsequence

  (a(3^j n + c))_n

belongs to the 2-kernel of a.
-/



/-!
============================================================
1. Iterating the even identity

If

    a(2n) = a(n),

then

    a(2^s n) = a(n)

for every s.
============================================================
-/


lemma arc_even_iter
    {α : Type*}
    (a : ℕ → α)
    (hEven :
      ∀ n : ℕ,
        a (2 * n) = a n)
    (s n : ℕ) :

    a (2 ^ s * n)
      =
    a n := by

  induction s with

  | zero =>

      simp


  | succ s ih =>

      calc

        a (2 ^ (s + 1) * n)

            =
          a (2 * (2 ^ s * n)) := by

            congr 1

            rw [pow_succ]

            ring


        _ =
          a (2 ^ s * n) :=

            hEven
              (2 ^ s * n)


        _ =
          a n :=

            ih



/-!
============================================================
2. One backward odd step

The odd identity is

    a(2n+1) = a(3n+2).

For m ≥ 1, put n = m-1.

Then

    3n+2 = 3m-1

and

    2n+1 = 2m-1.

Therefore

    a(3m-1) = a(2m-1).
============================================================
-/


lemma arc_backward_odd_once
    {α : Type*}
    (a : ℕ → α)
    (hOdd :
      ∀ n : ℕ,
        a (2 * n + 1)
          =
        a (3 * n + 2))
    (m : ℕ)
    (hm :
      1 ≤ m) :

    a (3 * m - 1)
      =
    a (2 * m - 1) := by


  have h :=
    (hOdd (m - 1)).symm


  calc

    a (3 * m - 1)

        =
      a (3 * (m - 1) + 2) := by

        congr 1

        omega


    _ =
      a (2 * (m - 1) + 1) :=

        h


    _ =
      a (2 * m - 1) := by

        congr 1

        omega



/-!
============================================================
3. Iterate the backward odd step

More generally,

    a(2^t 3^j M - 1)
      =
    a(2^(t+j) M - 1)

for M ≥ 1.

Each step replaces one factor 3 by one factor 2.
============================================================
-/


lemma arc_backward_odd_iter
    {α : Type*}
    (a : ℕ → α)
    (hOdd :
      ∀ n : ℕ,
        a (2 * n + 1)
          =
        a (3 * n + 2))
    (t j M : ℕ)
    (hM :
      1 ≤ M) :

    a (2 ^ t * 3 ^ j * M - 1)
      =
    a (2 ^ (t + j) * M - 1) := by


  induction j generalizing t with


  | zero =>

      simp


  | succ j ih =>


      have hMpos :
          0 < M := by

        omega


      have hm_pos :
          0 <
            2 ^ t
              *
            3 ^ j
              *
            M := by

        positivity


      have hm :
          1 ≤
            2 ^ t
              *
            3 ^ j
              *
            M := by

        omega


      calc

        a (
          2 ^ t
            *
          3 ^ (j + 1)
            *
          M
            -
          1
        )

            =
          a (
            3
              *
            (2 ^ t * 3 ^ j * M)
              -
            1
          ) := by

            congr 1

            rw [pow_succ]

            ring


        _ =
          a (
            2
              *
            (2 ^ t * 3 ^ j * M)
              -
            1
          ) :=

            arc_backward_odd_once
              a
              hOdd
              (2 ^ t * 3 ^ j * M)
              hm


        _ =
          a (
            2 ^ (t + 1)
              *
            3 ^ j
              *
            M
              -
            1
          ) := by

            congr 1

            rw [pow_succ]

            ring


        _ =
          a (
            2 ^ ((t + 1) + j)
              *
            M
              -
            1
          ) := by

            exact
              ih
                (t + 1)


        _ =
          a (
            2 ^ (t + (j + 1))
              *
            M
              -
            1
          ) := by

            have hexp :
                (t + 1) + j
                  =
                t + (j + 1) := by

              omega

            rw [hexp]



/-!
============================================================
4. Special case t = 0

This is the form used directly in Lemma 3.1:

    a(3^j M - 1)
      =
    a(2^j M - 1).
============================================================
-/


lemma arc_backward_odd_j
    {α : Type*}
    (a : ℕ → α)
    (hOdd :
      ∀ n : ℕ,
        a (2 * n + 1)
          =
        a (3 * n + 2))
    (j M : ℕ)
    (hM :
      1 ≤ M) :

    a (3 ^ j * M - 1)
      =
    a (2 ^ j * M - 1) := by


  simpa using

    arc_backward_odd_iter
      a
      hOdd
      0
      j
      M
      hM



/-!
============================================================
5. q is positive

From

    2^s c + 1 = q 3^j

the right side cannot vanish.

Hence q ≥ 1.
============================================================
-/


lemma arc_q_positive
    (s j c q : ℕ)
    (hsq :
      2 ^ s * c + 1
        =
      q * 3 ^ j) :

    1 ≤ q := by


  by_contra hq


  have hq0 :
      q = 0 := by

    omega


  subst q


  simp only [
    zero_mul
  ] at hsq


  have hpos :
      0 <
        2 ^ s * c + 1 := by

    positivity


  omega



/-!
============================================================
6. Upper bound on q

Assume

    c < 3^j

and

    2^s c + 1 = q 3^j.

Since

    2^s c + 1 ≤ 2^s 3^j,

we obtain

    q ≤ 2^s.
============================================================
-/


lemma arc_q_le_two_pow
    (s j c q : ℕ)
    (hc_lt :
      c < 3 ^ j)
    (hsq :
      2 ^ s * c + 1
        =
      q * 3 ^ j) :

    q ≤ 2 ^ s := by


  have h2pos :
      0 < 2 ^ s := by

    positivity


  have h3pos :
      0 < 3 ^ j := by

    positivity


  have hmul_lt :
      2 ^ s * c
        <
      2 ^ s * 3 ^ j :=

    Nat.mul_lt_mul_of_pos_left
      hc_lt
      h2pos


  have hleft_le :
      2 ^ s * c + 1
        ≤
      2 ^ s * 3 ^ j := by

    omega


  have hqmul_le :
      q * 3 ^ j
        ≤
      2 ^ s * 3 ^ j := by

    rw [← hsq]

    exact
      hleft_le


  have hqmul_le' :
      3 ^ j * q
        ≤
      3 ^ j * 2 ^ s := by

    simpa [
      Nat.mul_comm
    ] using
      hqmul_le


  exact
    Nat.le_of_mul_le_mul_left
      hqmul_le'
      h3pos



/-!
============================================================
7. First index identity

Using

    2^s c + 1 = q 3^j,

we obtain

    2^s (3^j n + c)
      =
    3^j (2^s n + q) - 1.
============================================================
-/


lemma arc_scaled_index_eq
    (s j c q n : ℕ)
    (hsq :
      2 ^ s * c + 1
        =
      q * 3 ^ j) :

    2 ^ s * (3 ^ j * n + c)
      =
    3 ^ j * (2 ^ s * n + q) - 1 := by


  have hplus :
      2 ^ s * (3 ^ j * n + c) + 1
        =
      3 ^ j * (2 ^ s * n + q) := by


    calc

      2 ^ s * (3 ^ j * n + c) + 1

          =
        3 ^ j * (2 ^ s * n)
          +
        (2 ^ s * c + 1) := by

          ring


      _ =
        3 ^ j * (2 ^ s * n)
          +
        q * 3 ^ j := by

          rw [hsq]


      _ =
        3 ^ j * (2 ^ s * n + q) := by

          ring


  have hright_pos :
      0 <
        3 ^ j * (2 ^ s * n + q) := by

    rw [← hplus]

    positivity


  omega



/-!
============================================================
8. Final index rearrangement

For q ≥ 1,

    2^j (2^s n + q) - 1

equals

    2^(s+j)n + (2^j q - 1).
============================================================
-/


lemma arc_final_index_eq
    (s j q n : ℕ)
    (hq :
      1 ≤ q) :

    2 ^ j * (2 ^ s * n + q) - 1
      =
    2 ^ (s + j) * n
      +
    (2 ^ j * q - 1) := by


  have hsum :
      2 ^ j * (2 ^ s * n + q)
        =
      2 ^ (s + j) * n
        +
      2 ^ j * q := by

    rw [pow_add]

    ring


  have hqpos :
      0 < q := by

    omega


  have hprodpos :
      0 < 2 ^ j * q :=

    Nat.mul_pos
      (by positivity)
      hqpos


  omega



/-!
============================================================
9. Bound for the 2-kernel remainder

We have

    q ≤ 2^s.

Therefore

    2^j q ≤ 2^j 2^s = 2^(s+j).

Since q ≥ 1,

    2^j q > 0,

so

    2^j q - 1 < 2^(s+j).
============================================================
-/


lemma arc_remainder_lt
    (s j q : ℕ)
    (hq_pos :
      1 ≤ q)
    (hq_le :
      q ≤ 2 ^ s) :

    2 ^ j * q - 1
      <
    2 ^ (s + j) := by


  have hmul_le :
      2 ^ j * q
        ≤
      2 ^ j * 2 ^ s :=

    Nat.mul_le_mul_left
      (2 ^ j)
      hq_le


  have hpow :
      2 ^ j * 2 ^ s
        =
      2 ^ (s + j) := by

    calc

      2 ^ j * 2 ^ s

          =
        2 ^ (j + s) := by

          rw [← pow_add]


      _ =
        2 ^ (s + j) := by

          rw [Nat.add_comm]


  have hq0 :
      0 < q := by

    omega


  have hprodpos :
      0 < 2 ^ j * q :=

    Nat.mul_pos
      (by positivity)
      hq0


  have hsub_lt :
      2 ^ j * q - 1
        <
      2 ^ j * q := by

    omega


  calc

    2 ^ j * q - 1

        <
      2 ^ j * q :=

        hsub_lt


    _ ≤
      2 ^ j * 2 ^ s :=

        hmul_le


    _ =
      2 ^ (s + j) :=

        hpow



/-!
============================================================
10. Explicit definition of membership in the 2-kernel

A sequence b belongs to the 2-kernel of a when there exist

    e ≥ 0
    0 ≤ r < 2^e

such that

    b(n) = a(2^e n + r)

for every n.

Because r is a natural number, 0 ≤ r is automatic.
============================================================
-/


def ARCInTwoKernel
    {α : Type*}
    (a b : ℕ → α) :

    Prop :=

  ∃ e r : ℕ,

    r < 2 ^ e
      ∧
    ∀ n : ℕ,

      b n
        =
      a (2 ^ e * n + r)



/-!
============================================================
11. Lemma 3.1 — full statement

Suppose a satisfies

    a(2n)     = a(n)
    a(2n + 1) = a(3n + 2).

Let

    j ≥ 1,
    0 < c < 3^j,
    3 ∤ c.

Then

    (a(3^j n + c))_n

belongs to the 2-kernel of a.

The witness is

    e = s+j

and

    r = 2^j q - 1,

where s,q satisfy

    2^s c + 1 = q 3^j.
============================================================
-/


theorem arc_lemma3_1
    {α : Type*}
    (a : ℕ → α)

    (hEven :
      ∀ n : ℕ,
        a (2 * n)
          =
        a n)

    (hOdd :
      ∀ n : ℕ,
        a (2 * n + 1)
          =
        a (3 * n + 2))

    (j c : ℕ)

    (hj :
      1 ≤ j)

    (_hc_pos :
      0 < c)

    (hc_lt :
      c < 3 ^ j)

    (hc3 :
      ¬ 3 ∣ c) :

    ARCInTwoKernel
      a
      (fun n =>
        a (3 ^ j * n + c)) := by


  obtain
    ⟨s, q, hsq⟩ :=

    arc_exists_s_q
      j
      c
      hj
      hc3


  have hq_pos :
      1 ≤ q :=

    arc_q_positive
      s
      j
      c
      q
      hsq


  have hq_le :
      q ≤ 2 ^ s :=

    arc_q_le_two_pow
      s
      j
      c
      q
      hc_lt
      hsq


  let r :
      ℕ :=
    2 ^ j * q - 1


  unfold ARCInTwoKernel


  refine
    ⟨s + j, r, ?_, ?_⟩


  ·
    dsimp [r]

    exact
      arc_remainder_lt
        s
        j
        q
        hq_pos
        hq_le


  ·
    intro n


    have hM :
        1 ≤
          2 ^ s * n + q := by

      omega


    have hindex1 :
        2 ^ s * (3 ^ j * n + c)
          =
        3 ^ j * (2 ^ s * n + q) - 1 :=

      arc_scaled_index_eq
        s
        j
        c
        q
        n
        hsq


    have hindex2 :
        2 ^ j * (2 ^ s * n + q) - 1
          =
        2 ^ (s + j) * n
          +
        (2 ^ j * q - 1) :=

      arc_final_index_eq
        s
        j
        q
        n
        hq_pos


    calc

      a (3 ^ j * n + c)

          =
        a (
          2 ^ s
            *
          (3 ^ j * n + c)
        ) := by

          symm

          exact
            arc_even_iter
              a
              hEven
              s
              (3 ^ j * n + c)


      _ =
        a (
          3 ^ j
            *
          (2 ^ s * n + q)
            -
          1
        ) := by

          rw [hindex1]


      _ =
        a (
          2 ^ j
            *
          (2 ^ s * n + q)
            -
          1
        ) :=

          arc_backward_odd_j
            a
            hOdd
            j
            (2 ^ s * n + q)
            hM


      _ =
        a (
          2 ^ (s + j) * n
            +
          (2 ^ j * q - 1)
        ) := by

          rw [hindex2]


      _ =
        a (
          2 ^ (s + j) * n
            +
          r
        ) := by

          simp [r]



/-!
============================================================
12. Axiom audit
============================================================
-/


#print axioms arc_even_iter

#print axioms arc_backward_odd_once

#print axioms arc_backward_odd_j

#print axioms arc_q_le_two_pow

#print axioms arc_remainder_lt

#print axioms arc_lemma3_1

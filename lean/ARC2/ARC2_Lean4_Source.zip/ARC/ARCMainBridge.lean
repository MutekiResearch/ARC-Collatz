import Mathlib
import ARC.ARCCor33
import ARC.ARCProof

universe u


/-
  ============================================================
  ARC Main Bridge
  ============================================================

  This file joins:

      Corollary 3.3
          ↓
      ultimate periodicity of b(n) = a(2n+1)
          ↓
      Section 4 period collapse
          ↓
      b is constant
          ↓
      the original sequence a is constant on positive integers.

  Cobham's theorem itself remains an explicit hypothesis
  through ARCCobhamPrinciple.

  IMPORTANT:
  The automaticity hypothesis here is still expressed in the
  finite-2-kernel form ARCAutomaticByKernel 2 a.

  Thus this file proves the kernel-form version of the main
  theorem, conditional on Cobham.

  The converse bridge

      MSD automatic  =>  finite k-kernel

  can be formalized separately if we want the Lean statement
  to begin literally from our explicit DFAO definition.
-/


/-
  ============================================================
  1. Translate our ultimate-periodicity definition
     into the Section 4 definition.
  ============================================================
-/

theorem arc_ultimate_periodic_to_section4
    {α : Type u}
    (seq : ℕ → α)
    (h :
      ARCUltimatelyPeriodic seq) :
    ∃ P : ℕ,
      0 < P ∧
      IsEventualPeriod seq P := by

  rcases h with
    ⟨P, N, hP, htail⟩

  refine
    ⟨P, hP, ?_⟩

  exact
    ⟨N, htail⟩


/-
  ============================================================
  2. The two Section 4 identities for the odd subsequence
  ============================================================
-/

/--
For seq(n) = a(2n+1),

    seq(4n) = seq(3n).
-/
theorem arc_odd_seq_first_identity
    {α : Type u}
    (a : ℕ → α)
    (hEven :
      ∀ n : ℕ,
        a (2 * n) = a n)
    (hOdd :
      ∀ n : ℕ,
        a (2 * n + 1) =
          a (3 * n + 2))
    (n : ℕ) :
    a (2 * (4 * n) + 1) =
      a (2 * (3 * n) + 1) := by

  calc
    a (2 * (4 * n) + 1)
        =
      a (3 * (4 * n) + 2) :=
        hOdd (4 * n)

    _ =
      a (2 * (6 * n + 1)) := by
        congr 1
        omega

    _ =
      a (6 * n + 1) :=
        hEven (6 * n + 1)

    _ =
      a (2 * (3 * n) + 1) := by
        congr 1
        omega


/--
For seq(n) = a(2n+1),

    seq(4n+2) = seq(n).
-/
theorem arc_odd_seq_second_identity
    {α : Type u}
    (a : ℕ → α)
    (hEven :
      ∀ n : ℕ,
        a (2 * n) = a n)
    (hOdd :
      ∀ n : ℕ,
        a (2 * n + 1) =
          a (3 * n + 2))
    (n : ℕ) :
    a (2 * (4 * n + 2) + 1) =
      a (2 * n + 1) := by

  calc
    a (2 * (4 * n + 2) + 1)
        =
      a (3 * (4 * n + 2) + 2) :=
        hOdd (4 * n + 2)

    _ =
      a (2 * (6 * n + 4)) := by
        congr 1
        omega

    _ =
      a (6 * n + 4) :=
        hEven (6 * n + 4)

    _ =
      a (2 * (3 * n + 2)) := by
        congr 1
        omega

    _ =
      a (3 * n + 2) :=
        hEven (3 * n + 2)

    _ =
      a (2 * n + 1) :=
        (hOdd n).symm


/-
  ============================================================
  3. Corollary 3.3 + Section 4
     => the odd subsequence is constant
  ============================================================
-/

theorem arc_odd_subsequence_constant_of_cobham
    {α : Type u}
    [Finite α]
    (hCobham :
      ARCCobhamPrinciple.{u})
    (a : ℕ → α)
    (hEven :
      ∀ n : ℕ,
        a (2 * n) = a n)
    (hOdd :
      ∀ n : ℕ,
        a (2 * n + 1) =
          a (3 * n + 2))
    (ha :
      ARCAutomaticByKernel 2 a) :
    ∃ c : α,
      ∀ n : ℕ,
        a (2 * n + 1) = c := by

  let seq : ℕ → α :=
    fun n =>
      a (2 * n + 1)

  have hPeriodic :
      ARCUltimatelyPeriodic seq := by

    simpa [seq] using
      arc_corollary3_3_of_cobham
        hCobham
        a
        hEven
        hOdd
        ha

  have hPeriodic4 :
      ∃ P : ℕ,
        0 < P ∧
        IsEventualPeriod seq P :=
    arc_ultimate_periodic_to_section4
      seq
      hPeriodic

  have h43 :
      ∀ n : ℕ,
        seq (4 * n) =
          seq (3 * n) := by

    intro n

    dsimp [seq]

    exact
      arc_odd_seq_first_identity
        a
        hEven
        hOdd
        n

  have hStep :
      ∀ n : ℕ,
        seq (4 * n + 2) =
          seq n := by

    intro n

    dsimp [seq]

    exact
      arc_odd_seq_second_identity
        a
        hEven
        hOdd
        n

  have hConst :
      ∃ c : α,
        ∀ n : ℕ,
          seq n = c :=
    section4_period_collapse
      seq
      hPeriodic4
      h43
      hStep

  rcases hConst with
    ⟨c, hc⟩

  refine
    ⟨c, ?_⟩

  intro n

  simpa [seq] using
    hc n


/-
  ============================================================
  4. Propagate odd-subsequence constancy
     to every positive integer
  ============================================================

  Instead of explicitly factoring

      N = 2^s (2m+1),

  we use strong induction.

  If N is odd, it is already in the odd subsequence.
  If N is even and positive, N = 2m with 0 < m < N,
  and the recurrence a(2m)=a(m) reduces the problem.
-/


theorem arc_main_kernel_form_of_cobham
    {α : Type u}
    [Finite α]
    (hCobham :
      ARCCobhamPrinciple.{u})
    (a : ℕ → α)
    (hEven :
      ∀ n : ℕ,
        a (2 * n) = a n)
    (hOdd :
      ∀ n : ℕ,
        a (2 * n + 1) =
          a (3 * n + 2))
    (ha :
      ARCAutomaticByKernel 2 a) :
    ∃ c : α,
      ∀ N : ℕ,
        1 ≤ N →
        a N = c := by

  rcases
      arc_odd_subsequence_constant_of_cobham
        hCobham
        a
        hEven
        hOdd
        ha
    with
    ⟨c, hOddConst⟩

  refine
    ⟨c, ?_⟩

  intro N

  induction N using Nat.strong_induction_on with
  | h N ih =>

      intro hN

      rcases
          Nat.mod_two_eq_zero_or_one N
        with
        hmod | hmod

      ·
        have hEq :
            N =
              2 * (N / 2) := by
          omega

        have hHalfPos :
            1 ≤ N / 2 := by
          omega

        have hHalfLt :
            N / 2 < N := by
          omega

        calc
          a N
              =
            a (2 * (N / 2)) := by
              exact congrArg a hEq

          _ =
            a (N / 2) :=
              hEven (N / 2)

          _ =
            c :=
              ih
                (N / 2)
                hHalfLt
                hHalfPos

      ·
        have hEq :
            N =
              2 * (N / 2) + 1 := by
          omega

        rw [hEq]

        exact
          hOddConst
            (N / 2)


/-
  ============================================================
  5. Axiom audit
  ============================================================
-/

#print axioms arc_ultimate_periodic_to_section4

#print axioms arc_odd_seq_first_identity

#print axioms arc_odd_seq_second_identity

#print axioms arc_odd_subsequence_constant_of_cobham

#print axioms arc_main_kernel_form_of_cobham

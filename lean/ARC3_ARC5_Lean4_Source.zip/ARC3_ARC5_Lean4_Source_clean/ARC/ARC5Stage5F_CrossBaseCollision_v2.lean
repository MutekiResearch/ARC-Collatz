import Mathlib
import ARC.ARC5Stage5E_StrongDyadicCPS

set_option autoImplicit false

universe u

/-!
# ARC5 — Stage 5F
## Cross-base collision: dyadic cylinders versus exact 5-kernel levels

Stage 5E recovered the full dyadic-cylinder strength of Local Density.

This file uses the coprimality

    gcd(5^q, 2^M) = 1

to pull a dyadic child cylinder through multiplication by `5^q`.

The result is a genuine cross-base statement:

For every exact 5-kernel level `q` and every prescribed dyadic parent
cylinder in the *kernel input variable*, there is a dyadic child cylinder
inside that parent on which every exact depth-q residual state agrees
pointwise with every other one.

This is substantially stronger than agreement at one point or on one finite
interval.
-/

/-!
============================================================
1. Dyadic cylinders as congruences
============================================================
-/

/--
The integer dyadic-cylinder predicate is exactly congruence modulo `2^M`.
-/
lemma arc5_dyadicCylinder_iff_modEq
    (M : ℕ)
    (r x : ℤ) :
    arcDyadicCylinder M r x
      ↔
    x ≡ r [ZMOD ((2 : ℤ) ^ M)] := by

  constructor

  · intro hx
    rcases hx with ⟨t, rfl⟩
    exact
      Int.modEq_add_fac_self

  · intro hmod
    have hsymm :
        r ≡ x [ZMOD ((2 : ℤ) ^ M)] :=
      hmod.symm

    rcases
      (Int.modEq_iff_add_fac).mp hsymm with
      ⟨t, ht⟩

    exact
      ⟨t, ht⟩


/-!
============================================================
2. Coprimality of the two bases
============================================================
-/

/--
Every power of 5 is coprime to every power of 2.
-/
lemma arc5_pow5_coprime_pow2
    (q M : ℕ) :
    (5 ^ q).Coprime (2 ^ M) := by

  exact
    Nat.coprime_pow_primes
      q
      M
      Nat.prime_five
      Nat.prime_two
      (by norm_num)


/-!
============================================================
3. Pull a dyadic cylinder back through multiplication by 5^q
============================================================
-/

/--
For every dyadic cylinder `C(s,M)`, multiplication by `5^q` has a full
dyadic residue-class preimage.

That is, there is a natural residue `t` modulo `2^M` such that every natural
`n ≡ t (mod 2^M)` satisfies

    5^q n ∈ C(s,M).
-/
lemma arc5_pow5_preimage_dyadicCylinder
    (q M : ℕ)
    (s : ℤ) :
    ∃ t : ℕ,
      ∀ n : ℕ,
        n ≡ t [MOD 2 ^ M]
          →
        arcDyadicCylinder
          M
          s
          ((5 ^ q * n : ℕ) : ℤ) := by

  have hcop :
      (5 ^ q).Coprime (2 ^ M) :=
    arc5_pow5_coprime_pow2
      q
      M

  rcases
    Int.mod_coprime hcop with
    ⟨y, hy⟩

  have hPpos :
      0 < (((2 ^ M : ℕ) : ℤ)) := by
    positivity

  rcases
    Int.existsUnique_equiv_nat
      (y * s)
      hPpos with
    ⟨t, _htlt, ht⟩

  refine
    ⟨t, ?_⟩

  intro n hn

  have hnInt :
      (n : ℤ)
        ≡
      (t : ℤ)
        [ZMOD (((2 ^ M : ℕ) : ℤ))] := by

    simpa only [AddCommGroup.modEq_iff_intModEq] using
      (AddCommGroup.ModEq.natCast
        (M := ℤ)
        hn)

  have hnys :
      (n : ℤ)
        ≡
      y * s
        [ZMOD (((2 ^ M : ℕ) : ℤ))] :=
    hnInt.trans ht

  have hmul :
      (((5 ^ q : ℕ) : ℤ) * (n : ℤ))
        ≡
      (((5 ^ q : ℕ) : ℤ) * (y * s))
        [ZMOD (((2 ^ M : ℕ) : ℤ))] :=
    hnys.mul_left
      (((5 ^ q : ℕ) : ℤ))

  have hyS :
      (((5 ^ q : ℕ) : ℤ) * (y * s))
        ≡
      s
        [ZMOD (((2 ^ M : ℕ) : ℤ))] := by

    have h :=
      hy.mul_right s

    simpa [mul_assoc] using h

  have hfinal :
      (((5 ^ q : ℕ) : ℤ) * (n : ℤ))
        ≡
      s
        [ZMOD (((2 ^ M : ℕ) : ℤ))] :=
    hmul.trans hyS

  apply
    (arc5_dyadicCylinder_iff_modEq
      M
      s
      (((5 ^ q * n : ℕ) : ℤ))).2

  simpa using hfinal


/-!
============================================================
4. The cross-base dense agreement property
============================================================
-/

/--
At every exact base-5 kernel depth `q`, the common-agreement set of all
depth-q residual states is dyadically dense in the following strong sense:

inside every prescribed natural dyadic parent class modulo `2^m`, there is
a child residue class modulo `2^M` such that

* the child lies inside the parent;
* the child contains a positive natural number;
* every exact depth-q residual state has the same value at every input in
  the child.
-/
def ARC5DyadicDenseLevelAgreement
    {α : Type u}
    (a : ℕ → α) : Prop :=
  ∀ q m r : ℕ,
    ∃ M t : ℕ,
      (
        ∀ n : ℕ,
          n ≡ t [MOD 2 ^ M]
            →
          n ≡ r [MOD 2 ^ m]
      )
      ∧
      (
        ∃ n : ℕ,
          0 < n
            ∧
          n ≡ t [MOD 2 ^ M]
      )
      ∧
      (
        ∀ n : ℕ,
          n ≡ t [MOD 2 ^ M]
            →
          ∀ v : ℕ → α,
            v ∈ ARC5LevelKernel q a
              →
            v n = a (5 ^ q * n)
      )


/--
Strong Dyadic CPS5 implies dyadically dense pointwise agreement of every
exact 5-kernel level.
-/
theorem arc5_dyadicDenseLevelAgreement_of_strongCPS
    {α : Type u}
    (a : ℕ → α)
    (hstrong :
      ARC5StrongDyadicCPS a) :
    ARC5DyadicDenseLevelAgreement a := by

  intro q m r

  let B : ℕ :=
    5 ^ q

  let Pm : ℕ :=
    2 ^ m

  rcases
    hstrong
      q
      m
      (((B * r : ℕ) : ℤ)) with
    ⟨M, s,
     hParent,
     _hPositiveOriginal,
     hBlock⟩

  rcases
    arc5_pow5_preimage_dyadicCylinder
      q
      M
      s with
    ⟨t, hPreimage⟩

  refine
    ⟨M,
     t,
     ?_,
     ?_,
     ?_⟩

  /- Child quotient cylinder lies inside the prescribed quotient parent. -/
  · intro n hn

    have hChildOriginal :
        arcDyadicCylinder
          M
          s
          (((B * n : ℕ) : ℤ)) := by

      simpa [B] using
        hPreimage
          n
          hn

    have hParentOriginal :
        arcDyadicCylinder
          m
          (((B * r : ℕ) : ℤ))
          (((B * n : ℕ) : ℤ)) :=
      hParent
        (((B * n : ℕ) : ℤ))
        hChildOriginal

    have hIntModeq :
        (((B * n : ℕ) : ℤ))
          ≡
        (((B * r : ℕ) : ℤ))
          [ZMOD ((2 : ℤ) ^ m)] :=
      (arc5_dyadicCylinder_iff_modEq
        m
        (((B * r : ℕ) : ℤ))
        (((B * n : ℕ) : ℤ))).1
        hParentOriginal

    have hNatModeq :
        B * n
          ≡
        B * r
          [MOD 2 ^ m] := by

      apply
        Nat.ModEq.of_natCast
          (M := ℤ)

      simpa [AddCommGroup.modEq_iff_intModEq, Nat.cast_pow] using
        hIntModeq

    have hcop :
        B.Coprime (2 ^ m) := by
      dsimp [B]
      exact
        arc5_pow5_coprime_pow2
          q
          m

    exact
      Nat.ModEq.cancel_left_of_coprime
        hcop.symm.gcd_eq_one
        hNatModeq

  /- Every natural dyadic residue class contains a positive natural. -/
  · let P : ℕ :=
      2 ^ M

    refine
      ⟨t + P,
       ?_,
       ?_⟩

    · dsimp [P]
      positivity

    · dsimp [P]
      exact
        Nat.add_modEq_right

  /- Every exact depth-q residual agrees with the zero-residue residual on
     every point of the quotient child cylinder. -/
  · intro n hn v hv

    have hChildOriginal :
        arcDyadicCylinder
          M
          s
          (((B * n : ℕ) : ℤ)) := by

      simpa [B] using
        hPreimage
          n
          hn

    change
      ∃ rr : ℕ,
        rr < 5 ^ q
          ∧
        ∀ z : ℕ,
          v z =
            a (5 ^ q * z + rr)
      at hv

    rcases hv with
      ⟨rr, hrr, hvEq⟩

    have hmono :
        a (B * n)
          =
        a (B * n + rr) := by

      have h :=
        hBlock
          (B * n)
          hChildOriginal
          rr
          hrr

      simpa [B] using h

    calc
      v n
          =
      a (5 ^ q * n + rr) :=
        hvEq n

      _ =
      a (B * n + rr) := by
        simp [B]

      _ =
      a (B * n) :=
        hmono.symm

      _ =
      a (5 ^ q * n) := by
        simp [B]


/--
Pairwise form of the same result: on the child dyadic cylinder, every two
exact depth-q kernel states are equal pointwise.
-/
theorem arc5_dyadicDenseLevelAgreement_pairwise
    {α : Type u}
    (a : ℕ → α)
    (hDense :
      ARC5DyadicDenseLevelAgreement a)
    (q m r : ℕ) :
    ∃ M t : ℕ,
      (
        ∀ n : ℕ,
          n ≡ t [MOD 2 ^ M]
            →
          n ≡ r [MOD 2 ^ m]
      )
      ∧
      (
        ∃ n : ℕ,
          0 < n
            ∧
          n ≡ t [MOD 2 ^ M]
      )
      ∧
      (
        ∀ n : ℕ,
          n ≡ t [MOD 2 ^ M]
            →
          ∀ v w : ℕ → α,
            v ∈ ARC5LevelKernel q a
              →
            w ∈ ARC5LevelKernel q a
              →
            v n = w n
      ) := by

  rcases
    hDense q m r with
    ⟨M, t,
     hSub,
     hPos,
     hCommon⟩

  refine
    ⟨M,
     t,
     hSub,
     hPos,
     ?_⟩

  intro n hn v w hv hw

  calc
    v n
        =
    a (5 ^ q * n) :=
      hCommon
        n
        hn
        v
        hv

    _ =
    w n :=
      (hCommon
        n
        hn
        w
        hw).symm


/-!
============================================================
5. ARC5 handoff
============================================================
-/

/--
Under the ARC5 hypotheses we now have both:

1. a finite full 5-kernel;
2. dyadically dense child cylinders of pointwise equality at every exact
   5-kernel level.

This is the Stage-5F cross-base collision interface.
-/
theorem arc5_stage5F_cross_base_collision
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha5 :
      ARCAutomaticByKernel 5 a) :
    (ARCKernel 5 a).Finite
      ∧
    ARC5DyadicDenseLevelAgreement a := by

  constructor

  · simpa [ARCAutomaticByKernel] using ha5

  · exact
      arc5_dyadicDenseLevelAgreement_of_strongCPS
        a
        (arc5_strongDyadicCPS_of_shortcut_invariant
          a
          hinv)


/-!
============================================================
6. Axiom audit
============================================================
-/

#print axioms arc5_dyadicCylinder_iff_modEq
#print axioms arc5_pow5_coprime_pow2
#print axioms arc5_pow5_preimage_dyadicCylinder
#print axioms arc5_dyadicDenseLevelAgreement_of_strongCPS
#print axioms arc5_dyadicDenseLevelAgreement_pairwise
#print axioms arc5_stage5F_cross_base_collision

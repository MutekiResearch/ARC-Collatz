import Mathlib
import Mathlib.Data.Nat.ModEq
import ARC.ARC5Stage5O_DyadicResiduePermutation_v2

set_option autoImplicit false

/-!
# ARC5 — Stage 5P
## Lifting the odd residue permutation to dyadic child cylinders

Stage 5O proved that an odd-increment pumped family

    Q(k) = ARC5PumpedFamily 0 (2*v+1) L k

permutes all residues modulo `2^R` on the first `2^R` pump indices.

Stage 5P restores the power-of-two factor and the offset:

    N(k) = ARC5PumpedFamily N0 (2^s * (2*v+1)) L k.

The natural children of the parent cylinder

    n ≡ N0 [MOD 2^s]

at relative depth `R` have representatives

    C_r = N0 + 2^s * r,     0 ≤ r < 2^R,

viewed modulo `2^(s+R)`.

We prove:

* every such child lies inside the parent cylinder;
* every such child is hit by the pumped family;
* the statement also works when the increment is supplied abstractly together
  with a factorization `d = 2^s * (2*v+1)`.

This is the arithmetic child-filling statement needed for the later
contradiction with `ARC5DyadicallyNowhereThick`.
-/

/-!
============================================================
1. Scaling identity for the pumped family
============================================================
-/

/--
Restoring an offset `N0` and a factor `2^s` simply scales the normalized
odd-increment family.
-/
theorem arc5_pumpedFamily_scaled_odd
    (N0 s v L k : ℕ) :
    ARC5PumpedFamily
        N0
        (2 ^ s * (2 * v + 1))
        L
        k
      =
    N0
      +
    2 ^ s
      *
    ARC5PumpedFamily
        0
        (2 * v + 1)
        L
        k := by

  unfold ARC5PumpedFamily

  ring


/-!
============================================================
2. Canonical representatives of dyadic child cylinders
============================================================
-/

/--
The child indexed by `r < 2^R` inside the parent residue `N0 mod 2^s`.
-/
def ARC5DyadicChildRepresentative
    (N0 s R : ℕ)
    (r : Fin (2 ^ R)) :
    ℕ :=
  N0 + 2 ^ s * r.val

/--
Every coded child representative belongs to the parent residue class.
-/
theorem arc5_dyadicChildRepresentative_in_parent
    (N0 s R : ℕ)
    (r : Fin (2 ^ R)) :
    ARC5DyadicChildRepresentative N0 s R r
      ≡
    N0
      [MOD 2 ^ s] := by

  unfold ARC5DyadicChildRepresentative

  have h :
      2 ^ s * r.val + N0
        ≡
      N0
        [MOD 2 ^ s] :=
    Nat.ModEq.modulus_mul_add

  simpa [Nat.add_comm] using h

/--
Congruence modulo the deeper child modulus implies congruence modulo the
parent modulus.
-/
theorem arc5_dyadicChild_congruence_implies_parent
    (N0 s R : ℕ)
    (r : Fin (2 ^ R))
    {n : ℕ}
    (hn :
      n
        ≡
      ARC5DyadicChildRepresentative N0 s R r
        [MOD 2 ^ (s + R)]) :
    n
      ≡
    N0
      [MOD 2 ^ s] := by

  have hdvd :
      2 ^ s ∣ 2 ^ (s + R) := by

    refine
      ⟨2 ^ R, ?_⟩

    rw [pow_add]

  have hnParent :
      n
        ≡
      ARC5DyadicChildRepresentative N0 s R r
        [MOD 2 ^ s] :=
    Nat.ModEq.of_dvd
      hdvd
      hn

  exact
    hnParent.trans
      (
        arc5_dyadicChildRepresentative_in_parent
          N0
          s
          R
          r
      )


/-!
============================================================
3. Lift one normalized residue hit through the factor 2^s
============================================================
-/

/--
If the normalized odd-increment family hits residue `r` modulo `2^R`, then
the scaled-offset family hits the corresponding child modulo `2^(s+R)`.
-/
theorem arc5_lift_oddPump_residue_hit
    (N0 s v L R k : ℕ)
    (r : Fin (2 ^ R))
    (hres :
      ARC5PumpedFamily
          0
          (2 * v + 1)
          L
          k
        %
      (2 ^ R)
        =
      r.val) :
    ARC5PumpedFamily
        N0
        (2 ^ s * (2 * v + 1))
        L
        k
      ≡
    ARC5DyadicChildRepresentative
        N0
        s
        R
        r
      [MOD 2 ^ (s + R)] := by

  have hnorm :
      ARC5PumpedFamily
          0
          (2 * v + 1)
          L
          k
        ≡
      r.val
        [MOD 2 ^ R] := by

    change
      ARC5PumpedFamily
          0
          (2 * v + 1)
          L
          k
        %
      (2 ^ R)
        =
      r.val % (2 ^ R)

    simpa [Nat.mod_eq_of_lt r.isLt] using hres

  have hscaledRaw :
      2 ^ s
          *
        ARC5PumpedFamily
          0
          (2 * v + 1)
          L
          k
        ≡
      2 ^ s * r.val
        [MOD (2 ^ s) * (2 ^ R)] :=

    Nat.ModEq.mul_left'
      (2 ^ s)
      hnorm

  have hscaled :
      2 ^ s
          *
        ARC5PumpedFamily
          0
          (2 * v + 1)
          L
          k
        ≡
      2 ^ s * r.val
        [MOD 2 ^ (s + R)] := by

    simpa [pow_add] using hscaledRaw

  have hoffset :
      N0
          +
        2 ^ s
          *
        ARC5PumpedFamily
          0
          (2 * v + 1)
          L
          k
        ≡
      N0 + 2 ^ s * r.val
        [MOD 2 ^ (s + R)] :=

    Nat.ModEq.add_left
      N0
      hscaled

  rw [arc5_pumpedFamily_scaled_odd]

  unfold ARC5DyadicChildRepresentative

  exact hoffset


/-!
============================================================
4. Every coded child is hit
============================================================
-/

/--
For each relative depth `R` and each child index `r < 2^R`, one of the first
`2^R` pump indices hits that child.
-/
theorem arc5_scaledOddPump_hits_every_child
    (N0 s v L R : ℕ)
    (r : Fin (2 ^ R)) :
    ∃ k : Fin (2 ^ R),
      ARC5PumpedFamily
          N0
          (2 ^ s * (2 * v + 1))
          L
          k.val
        ≡
      ARC5DyadicChildRepresentative
          N0
          s
          R
          r
        [MOD 2 ^ (s + R)] := by

  rcases
    arc5_oddPumpResidueMap_hits_every_residue
      v
      L
      R
      r with
    ⟨k, hk⟩

  refine
    ⟨k, ?_⟩

  exact
    arc5_lift_oddPump_residue_hit
      N0
      s
      v
      L
      R
      k.val
      r
      hk

/--
Every coded child is both inside the parent cylinder and hit by the pumped
family.
-/
theorem arc5_scaledOddPump_fills_parent_children
    (N0 s v L R : ℕ)
    (r : Fin (2 ^ R)) :
    (
      ∀ n : ℕ,
        n
          ≡
        ARC5DyadicChildRepresentative N0 s R r
          [MOD 2 ^ (s + R)]
          →
        n
          ≡
        N0
          [MOD 2 ^ s]
    )
      ∧
    (
      ∃ k : Fin (2 ^ R),
        ARC5PumpedFamily
            N0
            (2 ^ s * (2 * v + 1))
            L
            k.val
          ≡
        ARC5DyadicChildRepresentative
            N0
            s
            R
            r
          [MOD 2 ^ (s + R)]
    ) := by

  constructor

  · intro n hn

    exact
      arc5_dyadicChild_congruence_implies_parent
        N0
        s
        R
        r
        hn

  · exact
      arc5_scaledOddPump_hits_every_child
        N0
        s
        v
        L
        R
        r


/-!
============================================================
5. Abstract increment handoff
============================================================
-/

/--
Same child-filling theorem when the increment is given as an abstract `d`
with an exact factorization `d = 2^s * (2*v+1)`.
-/
theorem arc5_pumpedFamily_hits_every_child_of_exact_two_factor
    (N0 d L s v R : ℕ)
    (hd :
      d = 2 ^ s * (2 * v + 1))
    (r : Fin (2 ^ R)) :
    ∃ k : Fin (2 ^ R),
      ARC5PumpedFamily
          N0
          d
          L
          k.val
        ≡
      ARC5DyadicChildRepresentative
          N0
          s
          R
          r
        [MOD 2 ^ (s + R)] := by

  rw [hd]

  exact
    arc5_scaledOddPump_hits_every_child
      N0
      s
      v
      L
      R
      r


/-!
============================================================
6. Stage-5P handoff
============================================================
-/

/--
Stage-5P child-filling handoff.

An exact two-factorized Stage-5J pumped family hits every explicitly coded
deeper dyadic child of its parent cylinder.
-/
theorem arc5_stage5P_dyadic_child_filling
    (N0 d L s v : ℕ)
    (hd :
      d = 2 ^ s * (2 * v + 1)) :
    ∀ R : ℕ,
    ∀ r : Fin (2 ^ R),
      (
        ∀ n : ℕ,
          n
            ≡
          ARC5DyadicChildRepresentative N0 s R r
            [MOD 2 ^ (s + R)]
            →
          n
            ≡
          N0
            [MOD 2 ^ s]
      )
        ∧
      (
        ∃ k : Fin (2 ^ R),
          ARC5PumpedFamily
              N0
              d
              L
              k.val
            ≡
          ARC5DyadicChildRepresentative
              N0
              s
              R
              r
            [MOD 2 ^ (s + R)]
      ) := by

  intro R r

  constructor

  · intro n hn

    exact
      arc5_dyadicChild_congruence_implies_parent
        N0
        s
        R
        r
        hn

  · exact
      arc5_pumpedFamily_hits_every_child_of_exact_two_factor
        N0
        d
        L
        s
        v
        R
        hd
        r


/-!
============================================================
7. Axiom audit
============================================================
-/

#print axioms arc5_pumpedFamily_scaled_odd
#print axioms arc5_dyadicChildRepresentative_in_parent
#print axioms arc5_dyadicChild_congruence_implies_parent
#print axioms arc5_lift_oddPump_residue_hit
#print axioms arc5_scaledOddPump_hits_every_child
#print axioms arc5_scaledOddPump_fills_parent_children
#print axioms arc5_pumpedFamily_hits_every_child_of_exact_two_factor
#print axioms arc5_stage5P_dyadic_child_filling

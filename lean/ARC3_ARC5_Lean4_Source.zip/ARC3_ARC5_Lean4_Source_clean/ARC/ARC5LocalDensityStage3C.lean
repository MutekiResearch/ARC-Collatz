import Mathlib
import ARC.ARC5LocalDensityStage3B

set_option autoImplicit false

/-!
# ARC5 / Local-Density audit — Stage 3C

Stage 3B proved that the Stage-2 dyadic congruence condition really realizes
the prescribed parity word.

This file proves the "cylinder" part: once one integer `r` realizes the
word-congruence, every integer in the same residue class modulo
`2^(word length)` realizes it as well.

It then combines:
  * Stage 2A affine coalescence,
  * Stage 2C congruence translation,
  * Stage 3B genuine word realization,

to show that every point in one dyadic cylinder coalesces synchronously with
its translate by `N`, conditional only on the existence of one seed residue
for the first word.

The remaining Stage 3D obligation is pure existence:
prove that every parity word has at least one seed residue modulo
`2^(word length)`.
-/

/--
Concrete dyadic cylinder relation:
`x` lies in the residue class of `r` modulo `2^L`.
-/
def arcDyadicCylinder
    (L : ℕ)
    (r x : ℤ) : Prop :=
  ∃ t : ℤ,
    x = r + ((2 : ℤ) ^ L) * t

/--
The word numerator changes by a multiple of `2^L` when the start point is
changed by a multiple of `2^L`.
-/
lemma arcWordNumerator_periodic
    (w : List Bool)
    (r x : ℤ)
    (hx : arcDyadicCylinder w.length r x) :
    ∃ q : ℤ,
      arcWordNumerator w x
        =
      arcWordNumerator w r
        + ((2 : ℤ) ^ w.length) * q := by

  rcases hx with ⟨t, ht⟩

  refine
    ⟨((3 : ℤ) ^ arcOnes w) * t, ?_⟩

  unfold arcWordNumerator
  rw [ht]
  ring

/--
A word-congruence is constant on its whole dyadic cylinder.
-/
theorem arcWordCongruence_on_cylinder
    (w : List Bool)
    (r x : ℤ)
    (hr : arcWordCongruence w r)
    (hx : arcDyadicCylinder w.length r x) :
    arcWordCongruence w x := by

  have hrDvd :
      ((2 : ℤ) ^ w.length)
        ∣
      arcWordNumerator w r :=
    (arcWordCongruence_iff_dvd w r).mp hr

  rcases hrDvd with ⟨s, hs⟩

  rcases arcWordNumerator_periodic w r x hx with
    ⟨q, hq⟩

  apply (arcWordCongruence_iff_dvd w x).mpr

  refine ⟨s + q, ?_⟩

  rw [hq, hs]
  ring

/--
Conditional universal dyadic-cylinder coalescence.

For every positive gap `N`, there are equal-length words `u,v` with equal
odd-step count such that, for any seed `r` satisfying the congruence for `u`,
every integer in the complete dyadic cylinder of `r`:
  * genuinely follows `u`,
  * its translate by `N` genuinely follows `v`,
  * and the two endpoints are equal.
-/
theorem arcUniversalCylinderCoalescence_of_seed
    (N : ℕ)
    (hN : 0 < N) :
    ∃ u v : List Bool,
      u.length = v.length ∧
      arcOnes u = arcOnes v ∧
      ∀ r : ℤ,
        arcWordCongruence u r →
        ∀ x : ℤ,
          arcDyadicCylinder u.length r x →
          ∃ yu yv : ℤ,
            arcFollowsTo u x yu ∧
            arcFollowsTo v (x + (N : ℤ)) yv ∧
            yu = yv := by

  rcases arcUniversalAffineCoalescence N hN with
    ⟨u, v, hlen, hones, hcoal⟩

  have hgap :
      arcIntercept u - arcIntercept v
        =
      (3 : ℤ) ^ arcOnes u * (N : ℤ) :=
    arcIntercept_gap_of_affine_coalescence
      hlen
      hones
      hcoal

  refine ⟨u, v, hlen, hones, ?_⟩

  intro r hr x hx

  have huCong :
      arcWordCongruence u x :=
    arcWordCongruence_on_cylinder
      u
      r
      x
      hr
      hx

  have hvCong :
      arcWordCongruence v (x + (N : ℤ)) :=
    (arcWordCongruence_translation
      hlen
      hones
      hgap
      x).mp huCong

  rcases arcWordCongruence_realizes u x huCong with
    ⟨yu, hu⟩

  rcases arcWordCongruence_realizes
      v
      (x + (N : ℤ))
      hvCong with
    ⟨yv, hv⟩

  have hEq : yu = yv :=
    arcRealizedCoalescence_of_affine
      hcoal
      hu
      hv

  exact ⟨yu, yv, hu, hv, hEq⟩

#print axioms arcWordCongruence_on_cylinder
#print axioms arcUniversalCylinderCoalescence_of_seed

import Mathlib
import Mathlib.Data.Nat.Digits.Defs
import ARC.ARC5Stage5K_MSDWordPumping_v3

set_option autoImplicit false

/-!
# ARC5 — Stage 5L
## Numerical value of a pumped MSD word

Stage 5K produced a pumpable support-word family

    a ++ repeat(b,n) ++ c

with `b ≠ []`.

Stage 5J studied the arithmetic family

    ARC5PumpedFamily N0 d L n
      = N0 + d * ARC5GeomSum (5^L) n.

Stage 5L proves that these are exactly the same numerical families.

The key base-5 MSD concatenation rule is

    value(u ++ v) = value(u) * 5^(length v) + value(v).

From this we obtain

    value(repeat(b,n))
      = value(b) * ARC5GeomSum (5^(length b)) n,

and finally

    value(a ++ repeat(b,n) ++ c)
      =
    ARC5PumpedFamily
      (value(a ++ c))
      (5^(length c) *
        (value(a) * (5^(length b)-1) + value(b)))
      (length b)
      n.

No positivity assumption on the increment is used here.
That issue is intentionally left to the next stage, where canonical
base-5 representations will rule out the degenerate zero-increment case.
-/

/-!
============================================================
1. MSD concatenation
============================================================
-/

/--
Base-5 MSD concatenation formula.
-/
theorem arc5_msdValue_append
    (u v : List (Fin 5)) :
    ARC5MSDValue (u ++ v)
      =
    ARC5MSDValue u * 5 ^ v.length
      +
    ARC5MSDValue v := by

  unfold ARC5MSDValue

  rw [List.reverse_append]
  rw [List.map_append]
  rw [Nat.ofDigits_append]

  simp [List.length_map]

  ring


/-!
============================================================
2. Length of an explicitly repeated word
============================================================
-/

/--
The explicit repetition from Stage 5K has the expected length.
-/
theorem arc5_listRepeat_length
    (b : List (Fin 5))
    (n : ℕ) :
    (ARC5ListRepeat b n).length
      =
    b.length * n := by

  induction n with

  | zero =>
      simp [ARC5ListRepeat]

  | succ n ih =>
      rw [arc5_listRepeat_succ]
      simp [ih, Nat.mul_succ]


/-!
============================================================
3. A geometric-sum companion identity
============================================================
-/

/--
The Stage-5J geometric sum also satisfies

    c * S_n + 1 = S_(n+1).
-/
theorem arc5_geomSum_mul_add_one
    (c n : ℕ) :
    c * ARC5GeomSum c n + 1
      =
    ARC5GeomSum c (n + 1) := by

  induction n with

  | zero =>
      simp [ARC5GeomSum]

  | succ n ih =>
      rw [arc5_geomSum_succ]
      rw [arc5_geomSum_succ]
      rw [pow_succ]

      calc
        c * (ARC5GeomSum c n + c ^ n) + 1
            =
        (c * ARC5GeomSum c n + 1)
          + c ^ n * c := by
            ring
        _ =
        ARC5GeomSum c (n + 1)
          + c ^ n * c := by
            rw [ih]


/-!
============================================================
4. Numerical value of a repeated block
============================================================
-/

/--
Repeating one MSD block `b` exactly `n` times produces the expected
geometric sum in base `5^(length b)`.
-/
theorem arc5_msdValue_listRepeat
    (b : List (Fin 5))
    (n : ℕ) :
    ARC5MSDValue
        (ARC5ListRepeat b n)
      =
    ARC5MSDValue b
      *
    ARC5GeomSum
      (5 ^ b.length)
      n := by

  induction n with

  | zero =>
      simp [ARC5ListRepeat, ARC5MSDValue, ARC5GeomSum]

  | succ n ih =>
      rw [arc5_listRepeat_succ]
      rw [arc5_msdValue_append]
      rw [ih]

      calc
        ARC5MSDValue b
              * ARC5GeomSum
                  (5 ^ b.length)
                  n
              * 5 ^ b.length
            +
          ARC5MSDValue b
            =
        ARC5MSDValue b
          *
        (
          5 ^ b.length
            *
          ARC5GeomSum
            (5 ^ b.length)
            n
          + 1
        ) := by
          ring

        _ =
        ARC5MSDValue b
          *
        ARC5GeomSum
          (5 ^ b.length)
          (n + 1) := by
            rw [arc5_geomSum_mul_add_one]


/-!
============================================================
5. Power / geometric-sum identity with predecessor
============================================================
-/

/--
Subtraction-free companion identity:

    (d+1)^n = 1 + d * (1 + (d+1) + ... + (d+1)^(n-1)).
-/
theorem arc5_pow_succBase_eq_one_add_mul_geomSum
    (d n : ℕ) :
    (d + 1) ^ n
      =
    1 + d * ARC5GeomSum (d + 1) n := by

  induction n with

  | zero =>
      simp [ARC5GeomSum]

  | succ n ih =>
      rw [pow_succ]
      rw [arc5_geomSum_succ]
      rw [ih]
      ring

/--
For `1 ≤ c`,

    c^n = 1 + (c-1) * (1 + c + ... + c^(n-1)).

This is derived from the subtraction-free identity above, so truncated
natural-number subtraction never enters a `ring` goal.
-/
theorem arc5_pow_eq_one_add_pred_mul_geomSum
    (c n : ℕ)
    (hc :
      1 ≤ c) :
    c ^ n
      =
    1
      +
    (c - 1) * ARC5GeomSum c n := by

  have hcSplit :
      c - 1 + 1 = c :=
    Nat.sub_add_cancel hc

  have h :=
    arc5_pow_succBase_eq_one_add_mul_geomSum
      (c - 1)
      n

  simpa [hcSplit] using h


/-!
============================================================
6. Closed numerical form of a pumped word
============================================================
-/

/--
A direct closed form before re-packaging as `ARC5PumpedFamily`.
-/
theorem arc5_msdValue_pumpedWord_closed
    (a b c : List (Fin 5))
    (n : ℕ) :
    ARC5MSDValue
        (a ++ ARC5ListRepeat b n ++ c)
      =
    ARC5MSDValue a
        * (5 ^ b.length) ^ n
        * 5 ^ c.length
      +
    ARC5MSDValue b
        * ARC5GeomSum
            (5 ^ b.length)
            n
        * 5 ^ c.length
      +
    ARC5MSDValue c := by

  calc
    ARC5MSDValue
        (a ++ ARC5ListRepeat b n ++ c)
        =
    ARC5MSDValue
        (a ++ ARC5ListRepeat b n)
        * 5 ^ c.length
      +
    ARC5MSDValue c := by
      rw [arc5_msdValue_append]

    _ =
    (
      ARC5MSDValue a
        * 5 ^ (ARC5ListRepeat b n).length
      +
      ARC5MSDValue
        (ARC5ListRepeat b n)
    )
      * 5 ^ c.length
      +
    ARC5MSDValue c := by
      rw [arc5_msdValue_append]

    _ =
    (
      ARC5MSDValue a
        * 5 ^ (b.length * n)
      +
      ARC5MSDValue b
        * ARC5GeomSum
            (5 ^ b.length)
            n
    )
      * 5 ^ c.length
      +
    ARC5MSDValue c := by
      rw [arc5_listRepeat_length]
      rw [arc5_msdValue_listRepeat]

    _ =
    ARC5MSDValue a
        * (5 ^ b.length) ^ n
        * 5 ^ c.length
      +
    ARC5MSDValue b
        * ARC5GeomSum
            (5 ^ b.length)
            n
        * 5 ^ c.length
      +
    ARC5MSDValue c := by
      rw [pow_mul]
      ring


/-!
============================================================
7. Pump increment attached to a word decomposition
============================================================
-/

/--
The first numerical increment generated by pumping block `b` between
prefix `a` and suffix `c`.
-/
def ARC5WordPumpIncrement
    (a b c : List (Fin 5)) :
    ℕ :=
  5 ^ c.length
    *
  (
    ARC5MSDValue a
      * (5 ^ b.length - 1)
      +
    ARC5MSDValue b
  )


/-!
============================================================
8. Exact identification with Stage-5J ARC5PumpedFamily
============================================================
-/

/--
The numerical value of the pumped word is exactly the Stage-5J pumped
arithmetic family.
-/
theorem arc5_msdValue_pumpedWord_eq_pumpedFamily
    (a b c : List (Fin 5))
    (n : ℕ) :
    ARC5MSDValue
        (a ++ ARC5ListRepeat b n ++ c)
      =
    ARC5PumpedFamily
      (ARC5MSDValue (a ++ c))
      (ARC5WordPumpIncrement a b c)
      b.length
      n := by

  rw [arc5_msdValue_pumpedWord_closed]

  unfold ARC5PumpedFamily
  unfold ARC5WordPumpIncrement

  rw [arc5_msdValue_append]

  have hbase :
      1 ≤ 5 ^ b.length := by
    have hpos :
        0 < 5 ^ b.length := by
      positivity
    omega

  have hpow :
      (5 ^ b.length) ^ n
        =
      1
        +
      (5 ^ b.length - 1)
        *
      ARC5GeomSum
        (5 ^ b.length)
        n := by

    exact
      arc5_pow_eq_one_add_pred_mul_geomSum
        (5 ^ b.length)
        n
        hbase

  rw [hpow]

  ring


/-!
============================================================
9. Stage-5L support pumping handoff
============================================================
-/

/--
Word-level pumping from Stage 5K, now equipped with its exact natural-number
`ARC5PumpedFamily` formula.
-/
theorem arc5_stage5L_numeric_pumping_handoff
    (M : ARCMSDDFAO 5 Bool)
    [Fintype M.State]
    (s : ℕ → Bool)
    (hM :
      ARCMSDDFAO.Generates M s)
    (x : List (Fin 5))
    (hx :
      ARC5MSDValue x
        ∈
      ARC5BoolSupport s)
    (hlen :
      Fintype.card M.State
        ≤
      x.length) :
    ∃ a b c : List (Fin 5),
      x = a ++ b ++ c
        ∧
      a.length + b.length
        ≤
      Fintype.card M.State
        ∧
      b ≠ []
        ∧
      (
        ∀ n : ℕ,
          ARC5PumpedFamily
              (ARC5MSDValue (a ++ c))
              (ARC5WordPumpIncrement a b c)
              b.length
              n
            ∈
          ARC5BoolSupport s
      )
        ∧
      (
        ∀ n : ℕ,
          ARC5MSDValue
              (a ++ ARC5ListRepeat b n ++ c)
            =
          ARC5PumpedFamily
              (ARC5MSDValue (a ++ c))
              (ARC5WordPumpIncrement a b c)
              b.length
              n
      ) := by

  rcases
    arc5_msd_support_word_pumping
      M
      s
      hM
      x
      hx
      hlen with
    ⟨a,
     b,
     c,
     hsplit,
     hshort,
     hbne,
     hpump⟩

  refine
    ⟨a,
     b,
     c,
     hsplit,
     hshort,
     hbne,
     ?_,
     ?_⟩

  · intro n

    have hsupport :
        ARC5MSDValue
            (a ++ ARC5ListRepeat b n ++ c)
          ∈
        ARC5BoolSupport s :=
      hpump n

    rw [
      arc5_msdValue_pumpedWord_eq_pumpedFamily
        a
        b
        c
        n
    ] at hsupport

    exact hsupport

  · intro n

    exact
      arc5_msdValue_pumpedWord_eq_pumpedFamily
        a
        b
        c
        n


/-!
============================================================
10. Axiom audit
============================================================
-/

#print axioms arc5_msdValue_append
#print axioms arc5_listRepeat_length
#print axioms arc5_geomSum_mul_add_one
#print axioms arc5_msdValue_listRepeat
#print axioms arc5_pow_succBase_eq_one_add_mul_geomSum
#print axioms arc5_pow_eq_one_add_pred_mul_geomSum
#print axioms arc5_msdValue_pumpedWord_closed
#print axioms arc5_msdValue_pumpedWord_eq_pumpedFamily
#print axioms arc5_stage5L_numeric_pumping_handoff

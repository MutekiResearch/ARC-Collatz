import Mathlib
import ARC.ARC5Stage5U_ChangeSetFinite

set_option autoImplicit false

universe u

/-!
# ARC5 — Stage 5V
## Finite change set implies eventual constancy

Stage 5U proved that under the original ARC5 hypotheses the adjacent-change
set

    D_a = { n | a n ≠ a (n+1) }

is finite.

Stage 5V converts this purely combinatorial fact into eventual constancy.

The proof has two steps:

1. a finite subset of `ℕ` is bounded above;
2. beyond that bound there are no adjacent changes, so repeated adjacent
   equality makes the sequence constant on the whole tail.

No shortcut dynamics are used in this stage beyond the Stage-5U input.
-/

/-!
============================================================
1. A finite natural set has a strict upper bound
============================================================
-/

/--
Every finite subset of `ℕ` has a strict upper bound.
-/
theorem arc5_finite_nat_set_strictly_bounded
    (S : Set ℕ)
    (hS : S.Finite) :
    ∃ N : ℕ,
      ∀ n : ℕ,
        n ∈ S →
        n < N := by

  have hb :
      BddAbove S :=
    hS.bddAbove

  rcases hb with
    ⟨B, hB⟩

  refine
    ⟨B + 1, ?_⟩

  intro n hn

  have hle :
      n ≤ B :=
    hB hn

  omega


/-!
============================================================
2. No changes beyond a bound
============================================================
-/

/--
If the change set is finite, then there is a threshold beyond which every
adjacent pair agrees.
-/
theorem arc5_eventually_no_adjacent_changes
    {α : Type u}
    (a : ℕ → α)
    (hfinite :
      (ARC5ChangeSet a).Finite) :
    ∃ N : ℕ,
      ∀ n : ℕ,
        N ≤ n →
        a n = a (n + 1) := by

  rcases
    arc5_finite_nat_set_strictly_bounded
      (ARC5ChangeSet a)
      hfinite with
    ⟨N, hN⟩

  refine
    ⟨N, ?_⟩

  intro n hn

  by_contra hne

  have hnmem :
      n ∈ ARC5ChangeSet a := by
    exact hne

  have hnlt :
      n < N :=
    hN n hnmem

  omega


/-!
============================================================
3. Adjacent equality on a tail implies constancy on that tail
============================================================
-/

/--
If every adjacent pair agrees from `N` onward, then the whole tail is
constant with value `a N`.
-/
theorem arc5_tail_constant_of_adjacent
    {α : Type u}
    (a : ℕ → α)
    (N : ℕ)
    (hstep :
      ∀ n : ℕ,
        N ≤ n →
        a n = a (n + 1)) :
    ∀ n : ℕ,
      N ≤ n →
      a n = a N := by

  intro n hn

  induction n, hn using Nat.le_induction with

  | base =>
      rfl

  | succ n hnN ih =>

      calc
        a (n + 1)
            =
        a n :=
          (hstep n hnN).symm

        _ =
        a N :=
          ih


/-!
============================================================
4. Finite change set implies eventual constancy
============================================================
-/

/--
A sequence with finite adjacent-change set is eventually constant.
-/
theorem arc5_eventually_constant_of_changeSet_finite
    {α : Type u}
    (a : ℕ → α)
    (hfinite :
      (ARC5ChangeSet a).Finite) :
    ∃ N : ℕ,
      ∃ c : α,
        ∀ n : ℕ,
          N ≤ n →
          a n = c := by

  rcases
    arc5_eventually_no_adjacent_changes
      a
      hfinite with
    ⟨N, hstep⟩

  refine
    ⟨N,
     a N,
     ?_⟩

  exact
    arc5_tail_constant_of_adjacent
      a
      N
      hstep


/-!
============================================================
5. ARC5 hypotheses imply eventual constancy
============================================================
-/

/--
Under the original ARC5 hypotheses, `a` is eventually constant.
-/
theorem arc5_eventually_constant
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha5 :
      ARCAutomaticByKernel 5 a) :
    ∃ N : ℕ,
      ∃ c : α,
        ∀ n : ℕ,
          N ≤ n →
          a n = c := by

  exact
    arc5_eventually_constant_of_changeSet_finite
      a
      (arc5_changeSet_finite
        a
        hinv
        ha5)


/-!
============================================================
6. Stage-5V handoff
============================================================
-/

/--
Stage-5V handoff: the original ARC5 assumptions already force eventual
constancy.
-/
theorem arc5_stage5V_eventual_constancy
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha5 :
      ARCAutomaticByKernel 5 a) :
    ∃ N : ℕ,
      ∃ c : α,
        ∀ n : ℕ,
          N ≤ n →
          a n = c := by

  exact
    arc5_eventually_constant
      a
      hinv
      ha5


/-!
============================================================
7. Axiom audit
============================================================
-/

#print axioms arc5_finite_nat_set_strictly_bounded
#print axioms arc5_eventually_no_adjacent_changes
#print axioms arc5_tail_constant_of_adjacent
#print axioms arc5_eventually_constant_of_changeSet_finite
#print axioms arc5_eventually_constant
#print axioms arc5_stage5V_eventual_constancy

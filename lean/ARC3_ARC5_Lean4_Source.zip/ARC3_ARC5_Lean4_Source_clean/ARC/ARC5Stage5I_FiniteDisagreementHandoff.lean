import Mathlib
import ARC.ARC5Stage5H_DisagreementAutomatic

set_option autoImplicit false

universe u

/-!
# ARC5 — Stage 5I
## Finite-disagreement handoff

Stage 5H showed that if two exact depth-q residual states remain distinct,
then their disagreement set is simultaneously

* nonempty,
* dyadically nowhere thick, and
* 5-automatic (via its Boolean characteristic sequence).

A complete state-collapse theorem is too strong: the value at `0` is allowed
to be exceptional in ARC, and a finite disagreement such as `{0}` is therefore
a genuine boundary phenomenon that must not be ruled out.

The correct next target is the following odd-base topological pumping
principle:

    5-automatic + dyadically nowhere thick  ==>  finite support.

This file isolates that principle explicitly and proves the full ARC5
consequence from it:

    every two exact same-level residual states differ only on a finite set.

The topological pumping principle itself is the new mathematical obligation
for the next stage; it is kept as an explicit hypothesis here, not hidden as
an axiom.
-/

/-!
============================================================
1. Boolean support
============================================================
-/

/--
Support of a Boolean sequence.
-/
def ARC5BoolSupport
    (s : ℕ → Bool) :
    Set ℕ :=
  {n | s n = true}

/--
The Boolean support of the disagreement indicator is exactly the
disagreement set.
-/
theorem arc5_boolSupport_disagreeIndicator
    {α : Type u}
    (v w : ℕ → α) :
    ARC5BoolSupport
        (ARC5DisagreeIndicator v w)
      =
    ARC5Disagree v w := by

  ext n

  change
    ARC5DisagreeIndicator v w n = true
      ↔
    n ∈ ARC5Disagree v w

  exact
    arc5_disagreeIndicator_true_iff
      v
      w
      n


/-!
============================================================
2. Odd-base topological pumping principle
============================================================
-/

/--
The exact missing topological statement.

For Boolean 5-automatic sequences, a support that is dyadically nowhere
thick must be finite.

Mathematical motivation:
an infinite regular base-5 language admits a pumping loop.  Pumping a
nonempty block produces an infinite numerical subfamily of the form

    C + A * (5^L)^k.

Because `5^L` is an odd 2-adic unit, the even powers of this multiplier
generate a 2-adically open congruence pattern.  Thus an infinite 5-automatic
support should have nonempty 2-adic interior in its closure, contradicting
`ARC5DyadicallyNowhereThick`.

Stage 5I does NOT assume this silently: it is an explicit proposition to be
proved in the next substage.
-/
def ARC5OddBaseTopologicalPumpingPrinciple : Prop :=
  ∀ s : ℕ → Bool,
    ARCAutomaticByKernel 5 s
      →
    ARC5DyadicallyNowhereThick
      (ARC5BoolSupport s)
      →
    (ARC5BoolSupport s).Finite


/-!
============================================================
3. Thin automatic disagreement => finite disagreement
============================================================
-/

/--
Assuming the odd-base topological pumping principle, any disagreement set
between two exact same-level residual states is finite.
-/
theorem arc5_level_disagreement_finite
    {α : Type u}
    (hPump :
      ARC5OddBaseTopologicalPumpingPrinciple)
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha5 :
      ARCAutomaticByKernel 5 a)
    (q : ℕ)
    {v w : ℕ → α}
    (hv :
      v ∈ ARC5LevelKernel q a)
    (hw :
      w ∈ ARC5LevelKernel q a) :
    (ARC5Disagree v w).Finite := by

  have hAuto :
      ARCAutomaticByKernel
        5
        (ARC5DisagreeIndicator v w) :=
    arc5_disagreeIndicator_automatic
      a
      ha5
      q
      hv
      hw

  have hThin :
      ARC5DyadicallyNowhereThick
        (ARC5Disagree v w) :=
    arc5_stage5G_all_level_disagreements_nowhereThick
      a
      hinv
      ha5
      q
      v
      w
      hv
      hw

  have hSupportEq :
      ARC5BoolSupport
          (ARC5DisagreeIndicator v w)
        =
      ARC5Disagree v w :=
    arc5_boolSupport_disagreeIndicator
      v
      w

  have hThinSupport :
      ARC5DyadicallyNowhereThick
        (ARC5BoolSupport
          (ARC5DisagreeIndicator v w)) := by

    simpa [hSupportEq] using hThin

  have hFiniteSupport :
      (ARC5BoolSupport
        (ARC5DisagreeIndicator v w)).Finite :=
    hPump
      (ARC5DisagreeIndicator v w)
      hAuto
      hThinSupport

  simpa [hSupportEq] using hFiniteSupport


/--
Uniform same-level form: under the pumping principle, every exact level has
only finite pairwise disagreement.
-/
theorem arc5_stage5I_all_level_disagreements_finite
    {α : Type u}
    (hPump :
      ARC5OddBaseTopologicalPumpingPrinciple)
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha5 :
      ARCAutomaticByKernel 5 a) :
    ∀ q : ℕ,
      ∀ v w : ℕ → α,
        v ∈ ARC5LevelKernel q a
          →
        w ∈ ARC5LevelKernel q a
          →
        (ARC5Disagree v w).Finite := by

  intro q v w hv hw

  exact
    arc5_level_disagreement_finite
      hPump
      a
      hinv
      ha5
      q
      hv
      hw


/-!
============================================================
4. Correct obstruction after Stage 5I
============================================================
-/

/--
With the pumping principle, the surviving obstruction is no longer an
arbitrary thin automatic set.  Distinct same-level states may differ only on
a nonempty finite set.

This is intentionally weaker than full equality, because finite boundary
effects (especially at input `0`) are compatible with the ARC target.
-/
theorem arc5_stage5I_exact_finite_obstruction
    {α : Type u}
    (hPump :
      ARC5OddBaseTopologicalPumpingPrinciple)
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha5 :
      ARCAutomaticByKernel 5 a)
    (q : ℕ)
    {v w : ℕ → α}
    (hv :
      v ∈ ARC5LevelKernel q a)
    (hw :
      w ∈ ARC5LevelKernel q a) :
    v = w
      ∨
    (
      (ARC5Disagree v w).Nonempty
        ∧
      (ARC5Disagree v w).Finite
    ) := by

  by_cases hvw :
      v = w

  · exact
      Or.inl hvw

  · right

    constructor

    · exact
        arc5_disagree_nonempty_of_ne
          hvw

    · exact
        arc5_level_disagreement_finite
          hPump
          a
          hinv
          ha5
          q
          hv
          hw


/-!
============================================================
5. Stage-5I bridge package
============================================================
-/

/--
Stage-5I handoff.

Assuming the standalone odd-base topological pumping principle, the finite
5-kernel / Collatz hypotheses imply finite pairwise disagreement on every
exact base-5 level.
-/
theorem arc5_stage5I_finite_disagreement_handoff
    {α : Type u}
    (hPump :
      ARC5OddBaseTopologicalPumpingPrinciple)
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha5 :
      ARCAutomaticByKernel 5 a) :
    (ARCKernel 5 a).Finite
      ∧
    (
      ∀ q : ℕ,
        ∀ v w : ℕ → α,
          v ∈ ARC5LevelKernel q a
            →
          w ∈ ARC5LevelKernel q a
            →
          (ARC5Disagree v w).Finite
    ) := by

  constructor

  · simpa [ARCAutomaticByKernel] using ha5

  · exact
      arc5_stage5I_all_level_disagreements_finite
        hPump
        a
        hinv
        ha5


/-!
============================================================
6. Axiom audit
============================================================
-/

#print axioms arc5_boolSupport_disagreeIndicator
#print axioms arc5_level_disagreement_finite
#print axioms arc5_stage5I_all_level_disagreements_finite
#print axioms arc5_stage5I_exact_finite_obstruction
#print axioms arc5_stage5I_finite_disagreement_handoff

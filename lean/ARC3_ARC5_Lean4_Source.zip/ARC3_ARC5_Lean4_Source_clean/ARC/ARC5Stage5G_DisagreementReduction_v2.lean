import Mathlib
import ARC.ARC5Stage5F_CrossBaseCollision_v2

set_option autoImplicit false

universe u

/-!
# ARC5 — Stage 5G
## Disagreement-set reduction

Stage 5F proved that at every exact base-5 kernel level, all residual states
agree pointwise on a dyadic child cylinder inside every prescribed dyadic
parent cylinder.

Stage 5G isolates the exact obstruction that could still prevent state
collapse.

For two residual states `v,w`, define their disagreement set

    D(v,w) = { n : v(n) ≠ w(n) }.

If `v` and `w` are distinct, this set is nonempty.  Stage 5F forces it to be
"dyadically nowhere thick": every dyadic parent cylinder contains a nonempty
positive dyadic child cylinder disjoint from the disagreement set.

Thus any surviving distinct pair must differ only on a very thin set from
the 2-adic point of view.

This file deliberately stops at that exact reduction.  A later stage must use
the base-5 automatic structure of the disagreement set to rule out the
remaining sparse alternative.
-/

/-!
============================================================
1. Disagreement set
============================================================
-/

/--
The set of inputs on which two sequence states disagree.
-/
def ARC5Disagree
    {α : Type u}
    (v w : ℕ → α) :
    Set ℕ :=
  {n | v n ≠ w n}

/--
If two functions are distinct, their disagreement set is nonempty.
-/
theorem arc5_disagree_nonempty_of_ne
    {α : Type u}
    {v w : ℕ → α}
    (hvw : v ≠ w) :
    (ARC5Disagree v w).Nonempty := by

  classical

  by_contra hEmpty

  apply hvw

  funext n

  by_contra hne

  apply hEmpty

  exact
    ⟨n,
     hne⟩

/--
If the disagreement set is empty, the two states are equal as functions.
-/
theorem arc5_eq_of_disagree_not_nonempty
    {α : Type u}
    {v w : ℕ → α}
    (hEmpty :
      ¬ (ARC5Disagree v w).Nonempty) :
    v = w := by

  classical

  funext n

  by_contra hne

  apply hEmpty

  exact
    ⟨n,
     hne⟩


/-!
============================================================
2. Dyadically nowhere-thick subsets of ℕ
============================================================
-/

/--
A set `S ⊆ ℕ` is dyadically nowhere thick if every prescribed dyadic parent
class contains a nonempty positive dyadic child class completely disjoint
from `S`.

This is a purely arithmetic version of the "empty interior in every local
2-adic neighborhood" phenomenon needed in the ARC5 bridge audit.
-/
def ARC5DyadicallyNowhereThick
    (S : Set ℕ) : Prop :=
  ∀ m r : ℕ,
    ∃ M t : ℕ,
      (
        ∀ n : ℕ,
          n ≡ t [MOD 2 ^ M]
            →
          n ≡ r [MOD 2 ^ m]
      )
      ∧
      (
        ∃ n : ℕ,
          0 < n
            ∧
          n ≡ t [MOD 2 ^ M]
      )
      ∧
      (
        ∀ n : ℕ,
          n ≡ t [MOD 2 ^ M]
            →
          n ∉ S
      )


/-!
============================================================
3. Stage-5F forces every level-pair disagreement set to be thin
============================================================
-/

/--
Dyadically dense pairwise agreement is exactly the statement that every
same-level disagreement set is dyadically nowhere thick.
-/
theorem arc5_level_disagreement_nowhereThick
    {α : Type u}
    (a : ℕ → α)
    (hDense :
      ARC5DyadicDenseLevelAgreement a)
    (q : ℕ)
    {v w : ℕ → α}
    (hv :
      v ∈ ARC5LevelKernel q a)
    (hw :
      w ∈ ARC5LevelKernel q a) :
    ARC5DyadicallyNowhereThick
      (ARC5Disagree v w) := by

  intro m r

  rcases
    arc5_dyadicDenseLevelAgreement_pairwise
      a
      hDense
      q
      m
      r with
    ⟨M, t,
     hSub,
     hPos,
     hAgree⟩

  refine
    ⟨M,
     t,
     hSub,
     hPos,
     ?_⟩

  intro n hn

  change ¬ (v n ≠ w n)

  intro hne

  exact
    hne
      (hAgree
        n
        hn
        v
        w
        hv
        hw)


/--
Under the ARC5 hypotheses, every pair of exact depth-q states has a
dyadically nowhere-thick disagreement set.
-/
theorem arc5_stage5G_all_level_disagreements_nowhereThick
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha5 :
      ARCAutomaticByKernel 5 a) :
    ∀ q : ℕ,
      ∀ v w : ℕ → α,
        v ∈ ARC5LevelKernel q a
          →
        w ∈ ARC5LevelKernel q a
          →
        ARC5DyadicallyNowhereThick
          (ARC5Disagree v w) := by

  have hF :=
    arc5_stage5F_cross_base_collision
      a
      hinv
      ha5

  rcases hF with
    ⟨_hfinite,
     hDense⟩

  intro q v w hv hw

  exact
    arc5_level_disagreement_nowhereThick
      a
      hDense
      q
      hv
      hw


/-!
============================================================
4. Exact obstruction theorem
============================================================
-/

/--
Exact Stage-5G obstruction.

For any two exact depth-q kernel states, either

* they are equal as functions, or
* their disagreement set is simultaneously
    - nonempty, and
    - dyadically nowhere thick.

Hence the only remaining obstruction to full state collapse is a nonempty
2-adically thin disagreement set.
-/
theorem arc5_stage5G_exact_obstruction
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha5 :
      ARCAutomaticByKernel 5 a)
    (q : ℕ)
    {v w : ℕ → α}
    (hv :
      v ∈ ARC5LevelKernel q a)
    (hw :
      w ∈ ARC5LevelKernel q a) :
    v = w
      ∨
    (
      (ARC5Disagree v w).Nonempty
        ∧
      ARC5DyadicallyNowhereThick
        (ARC5Disagree v w)
    ) := by

  by_cases hvw :
      v = w

  · exact
      Or.inl hvw

  · right

    constructor

    · exact
        arc5_disagree_nonempty_of_ne
          hvw

    · exact
        arc5_stage5G_all_level_disagreements_nowhereThick
          a
          hinv
          ha5
          q
          v
          w
          hv
          hw


/-!
============================================================
5. Collapse criterion for the next stage
============================================================
-/

/--
Abstract collapse criterion.

If one can prove that no nonempty disagreement set arising from two exact
depth-q states can be dyadically nowhere thick, then all exact depth-q states
collapse to one function.

This theorem isolates the precise missing statement for the next stage.
-/
theorem arc5_levelKernel_collapses_of_no_thin_disagreement
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha5 :
      ARCAutomaticByKernel 5 a)
    (q : ℕ)
    (hNoThin :
      ∀ v w : ℕ → α,
        v ∈ ARC5LevelKernel q a
          →
        w ∈ ARC5LevelKernel q a
          →
        (ARC5Disagree v w).Nonempty
          →
        ¬ ARC5DyadicallyNowhereThick
            (ARC5Disagree v w)) :
    ∀ v w : ℕ → α,
      v ∈ ARC5LevelKernel q a
        →
      w ∈ ARC5LevelKernel q a
        →
      v = w := by

  intro v w hv hw

  rcases
    arc5_stage5G_exact_obstruction
      a
      hinv
      ha5
      q
      hv
      hw with
    hvw | hthin

  · exact hvw

  · rcases hthin with
      ⟨hNonempty,
       hNowhere⟩

    exact
      False.elim
        ((hNoThin
          v
          w
          hv
          hw
          hNonempty)
          hNowhere)


/-!
============================================================
6. Axiom audit
============================================================
-/

#print axioms arc5_disagree_nonempty_of_ne
#print axioms arc5_eq_of_disagree_not_nonempty
#print axioms arc5_level_disagreement_nowhereThick
#print axioms arc5_stage5G_all_level_disagreements_nowhereThick
#print axioms arc5_stage5G_exact_obstruction
#print axioms arc5_levelKernel_collapses_of_no_thin_disagreement

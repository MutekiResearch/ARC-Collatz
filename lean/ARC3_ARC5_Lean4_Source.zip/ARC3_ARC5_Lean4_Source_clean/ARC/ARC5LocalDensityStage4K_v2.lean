import Mathlib
import ARC.ARC5LocalDensityStage4J

set_option autoImplicit false

/-!
# ARC5 / Local-Density audit — Stage 4K

Stage 4J proved parameter-level termination: every `(a,b,B)` reaches a state
with equal exponents.  Before lifting an entire `arcParamReach` path, this
file aligns each abstract parameter constructor with the corresponding
genuine word/cylinder steering theorem from Stage 4F.

The small but important issue is that `arcParamReach` stores only the exact
offset equations.  The Stage-4F steering theorems ask for parity hypotheses.
Here we recover those parity facts from the equations and then prove
"exact-target" wrappers: the offset produced by the genuine steering move is
the very same offset named by the abstract reachability constructor.
-/

/-- An equation `B = 2*C` immediately makes `B` even. -/
lemma arcEven_of_eq_two_mul
    {B C : ℤ}
    (h : B = 2 * C) :
    Even B := by
  refine ⟨C, ?_⟩
  rw [h]
  ring

/--
The 01 offset equation forces the old offset `B` to be odd.
-/
lemma arcOdd_of_offset01_eq
    {a : ℕ}
    {B C : ℤ}
    (h :
      2 * C
        =
      3 * B + (3 : ℤ) ^ a) :
    Odd B := by

  apply (Int.not_even_iff_odd).mp

  intro hEven

  rcases hEven with ⟨q, hq⟩
  rcases arcThreePow_odd a with ⟨p, hp⟩

  rw [hq, hp] at h

  omega

/--
The 10 offset equation also forces the old offset `B` to be odd.
-/
lemma arcOdd_of_offset10_eq
    {b : ℕ}
    {B C : ℤ}
    (h :
      2 * C
        =
      3 * B - (3 : ℤ) ^ b) :
    Odd B := by

  apply (Int.not_even_iff_odd).mp

  intro hEven

  rcases hEven with ⟨q, hq⟩
  rcases arcThreePow_odd b with ⟨p, hp⟩

  rw [hq, hp] at h

  omega

/--
Exact 00 realization.

If the abstract reachability step names `C` by `B = 2*C`, the genuine
cylinder steering step can be chosen with exactly that same `C`.
-/
theorem arcSteer00_exact
    {a b : ℕ}
    {u v : List Bool}
    {r N y y' B C : ℤ}
    (hlen : u.length = v.length)
    (ha : arcOnes u = a)
    (hb : arcOnes v = b)
    (hu : arcFollowsTo u r y)
    (hv : arcFollowsTo v (r + N) y')
    (hrel :
      arcScaledRelation a b B y y')
    (hBC : B = 2 * C) :
    ∃ s z z' : ℤ,
      arcDyadicCylinder u.length r s
      ∧
      (u ++ [false]).length = (v ++ [false]).length
      ∧
      arcFollowsTo (u ++ [false]) s z
      ∧
      arcFollowsTo (v ++ [false]) (s + N) z'
      ∧
      arcScaledRelation a b C z z' := by

  have hEven : Even B :=
    arcEven_of_eq_two_mul hBC

  have hrelWords :
      arcScaledRelation
        (arcOnes u)
        (arcOnes v)
        B
        y
        y' := by
    simpa [ha, hb] using hrel

  rcases
    arcSteer00_of_evenOffset
      hlen
      hu
      hv
      hrelWords
      hEven with
    ⟨s, z, z', D,
     hs, hlen', huz, hvz, hBD, hrelD⟩

  have hDC : D = C := by
    linarith

  subst D

  refine
    ⟨s, z, z',
     hs,
     hlen',
     huz,
     hvz,
     ?_⟩

  simpa
    [arcOnes_append_false, ha, hb]
    using hrelD

/--
Exact 01 realization.

The abstract equation itself proves that `B` is odd, and uniqueness of the
halved integer equation identifies the concrete Stage-4F output with `C`.
-/
theorem arcSteer01_exact
    {a b : ℕ}
    {u v : List Bool}
    {r N y y' B C : ℤ}
    (hlen : u.length = v.length)
    (ha : arcOnes u = a)
    (hb : arcOnes v = b)
    (hu : arcFollowsTo u r y)
    (hv : arcFollowsTo v (r + N) y')
    (hrel :
      arcScaledRelation a b B y y')
    (hC :
      2 * C
        =
      3 * B + (3 : ℤ) ^ a) :
    ∃ s z z' : ℤ,
      arcDyadicCylinder u.length r s
      ∧
      (u ++ [false]).length = (v ++ [true]).length
      ∧
      arcFollowsTo (u ++ [false]) s z
      ∧
      arcFollowsTo (v ++ [true]) (s + N) z'
      ∧
      arcScaledRelation a (b + 1) C z z' := by

  have hOdd : Odd B :=
    arcOdd_of_offset01_eq hC

  have hrelWords :
      arcScaledRelation
        (arcOnes u)
        (arcOnes v)
        B
        y
        y' := by
    simpa [ha, hb] using hrel

  rcases
    arcSteer01_of_oddOffset
      hlen
      hu
      hv
      hrelWords
      hOdd with
    ⟨s, z, z', D,
     hs, hlen', huz, hvz, hD, hrelD⟩

  have hDC : D = C := by
    rw [ha] at hD
    linarith

  subst D

  refine
    ⟨s, z, z',
     hs,
     hlen',
     huz,
     hvz,
     ?_⟩

  simpa
    [arcOnes_append_false,
     arcOnes_append_true,
     ha, hb]
    using hrelD

/--
Exact 10 realization.
-/
theorem arcSteer10_exact
    {a b : ℕ}
    {u v : List Bool}
    {r N y y' B C : ℤ}
    (hlen : u.length = v.length)
    (ha : arcOnes u = a)
    (hb : arcOnes v = b)
    (hu : arcFollowsTo u r y)
    (hv : arcFollowsTo v (r + N) y')
    (hrel :
      arcScaledRelation a b B y y')
    (hC :
      2 * C
        =
      3 * B - (3 : ℤ) ^ b) :
    ∃ s z z' : ℤ,
      arcDyadicCylinder u.length r s
      ∧
      (u ++ [true]).length = (v ++ [false]).length
      ∧
      arcFollowsTo (u ++ [true]) s z
      ∧
      arcFollowsTo (v ++ [false]) (s + N) z'
      ∧
      arcScaledRelation (a + 1) b C z z' := by

  have hOdd : Odd B :=
    arcOdd_of_offset10_eq hC

  have hrelWords :
      arcScaledRelation
        (arcOnes u)
        (arcOnes v)
        B
        y
        y' := by
    simpa [ha, hb] using hrel

  rcases
    arcSteer10_of_oddOffset
      hlen
      hu
      hv
      hrelWords
      hOdd with
    ⟨s, z, z', D,
     hs, hlen', huz, hvz, hD, hrelD⟩

  have hDC : D = C := by
    rw [hb] at hD
    linarith

  subst D

  refine
    ⟨s, z, z',
     hs,
     hlen',
     huz,
     hvz,
     ?_⟩

  simpa
    [arcOnes_append_false,
     arcOnes_append_true,
     ha, hb]
    using hrelD

/--
Exact 11 zero-offset realization.

Both odd-step counts rise by one.  The concrete Stage-4F kick and the
abstract `arcParamReach.step11zero` constructor satisfy the same equation,
so their offsets are equal.
-/
theorem arcSteer11_exact
    {a b : ℕ}
    {u v : List Bool}
    {r N y y' C : ℤ}
    (hlen : u.length = v.length)
    (ha : arcOnes u = a)
    (hb : arcOnes v = b)
    (hu : arcFollowsTo u r y)
    (hv : arcFollowsTo v (r + N) y')
    (hrel :
      arcScaledRelation a b 0 y y')
    (hC :
      2 * C
        =
      (3 : ℤ) ^ (a + 1)
        - (3 : ℤ) ^ (b + 1)) :
    ∃ s z z' : ℤ,
      arcDyadicCylinder u.length r s
      ∧
      (u ++ [true]).length = (v ++ [true]).length
      ∧
      arcFollowsTo (u ++ [true]) s z
      ∧
      arcFollowsTo (v ++ [true]) (s + N) z'
      ∧
      arcScaledRelation (a + 1) (b + 1) C z z' := by

  have hrelWords :
      arcScaledRelation
        (arcOnes u)
        (arcOnes v)
        0
        y
        y' := by
    simpa [ha, hb] using hrel

  rcases
    arcSteer11_of_zeroOffset
      hlen
      hu
      hv
      hrelWords with
    ⟨s, z, z', D,
     hs, hlen', huz, hvz, hD, hrelD⟩

  have hDC : D = C := by
    rw [arcOnes_append_true,
        arcOnes_append_true,
        ha, hb] at hD
    linarith

  subst D

  refine
    ⟨s, z, z',
     hs,
     hlen',
     huz,
     hvz,
     ?_⟩

  simpa
    [arcOnes_append_true, ha, hb]
    using hrelD

#print axioms arcOdd_of_offset01_eq
#print axioms arcOdd_of_offset10_eq
#print axioms arcSteer00_exact
#print axioms arcSteer01_exact
#print axioms arcSteer10_exact
#print axioms arcSteer11_exact

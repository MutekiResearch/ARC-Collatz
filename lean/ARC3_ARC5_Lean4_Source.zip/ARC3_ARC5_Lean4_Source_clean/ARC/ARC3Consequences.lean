import Mathlib
import ARC.ARC3Audit

set_option autoImplicit false

universe u

/-!
# ARC₃ — sharpness and set/basin consequences

This file formalizes three items that strengthen the ARC₃ manuscript:

1. Sharpness at zero: for arbitrary values `x` and `y`, the sequence

       a(0) = x,   a(n) = y  for n >= 1

   is 3-automatic and satisfies the two shortcut-Collatz invariance identities.
   Thus the theorem cannot constrain `a 0`.

2. Every 3-automatic shortcut-Collatz-invariant set is trivial on the
   positive integers.

3. For the basin of 1 of any map satisfying the shortcut-Collatz branch
   equations, the Collatz statement is equivalent to 3-automaticity of the
   basin characteristic sequence, conditional on the same explicit Cobham
   principle as the main theorem.
-/


/-!
============================================================
1. Sharpness of the free value at zero
============================================================
-/

def arc3SharpSequence
    {α : Type u}
    (x y : α) :
    ℕ → α :=
  fun n => if n = 0 then x else y


theorem arc3_sharp_even
    {α : Type u}
    (x y : α) :
    ∀ n : ℕ,
      arc3SharpSequence x y (2 * n) =
        arc3SharpSequence x y n := by
  intro n
  by_cases hn : n = 0
  · subst n
    simp [arc3SharpSequence]
  · have h2n : 2 * n ≠ 0 := by
      omega
    simp [arc3SharpSequence, hn, h2n]


theorem arc3_sharp_odd
    {α : Type u}
    (x y : α) :
    ∀ n : ℕ,
      arc3SharpSequence x y (2 * n + 1) =
        arc3SharpSequence x y (3 * n + 2) := by
  intro n
  have hleft : 2 * n + 1 ≠ 0 := by
    omega
  have hright : 3 * n + 2 ≠ 0 := by
    omega
  simp [arc3SharpSequence, hleft, hright]


theorem arc3_sharp_three_kernel_finite
    {α : Type u}
    (x y : α) :
    ARCAutomaticByKernel 3 (arc3SharpSequence x y) := by
  unfold ARCAutomaticByKernel

  have hfinite :
      ({arc3SharpSequence x y, (fun _ : ℕ => y)} : Set (ℕ → α)).Finite := by
    exact
      (Set.finite_singleton (fun _ : ℕ => y)).insert
        (arc3SharpSequence x y)

  refine hfinite.subset ?_
  intro v hv

  have hv' :
      ∃ e r : ℕ,
        r < 3 ^ e ∧
        ∀ n : ℕ,
          v n = arc3SharpSequence x y (3 ^ e * n + r) := by
    simpa [ARCKernel] using hv

  rcases hv' with ⟨e, r, hr, hvEq⟩

  by_cases hr0 : r = 0
  · have hvSharp : v = arc3SharpSequence x y := by
      funext n
      rw [hvEq n]
      by_cases hn : n = 0
      · subst n
        simp [arc3SharpSequence, hr0]
      · have hnpos : 0 < n := Nat.pos_of_ne_zero hn
        have hpowpos : 0 < 3 ^ e := by
          positivity
        have hidxpos : 0 < 3 ^ e * n := by
          exact Nat.mul_pos hpowpos hnpos
        have hidx : 3 ^ e * n ≠ 0 := Nat.ne_of_gt hidxpos
        simp [arc3SharpSequence, hr0, hn, hidx]

    simp [hvSharp]

  · have hrpos : 0 < r := Nat.pos_of_ne_zero hr0
    have hvConst : v = (fun _ : ℕ => y) := by
      funext n
      rw [hvEq n]
      have hidxpos : 0 < 3 ^ e * n + r := by
        omega
      have hidx : 3 ^ e * n + r ≠ 0 := Nat.ne_of_gt hidxpos
      unfold arc3SharpSequence
      rw [if_neg hidx]

    simp [hvConst]


theorem arc3_sharp_zero_digit_standard_automatic
    {α : Type u}
    (x y : α) :
    ARCStandardMSDZeroDigitAutomatic
      3
      (arc3SharpSequence x y) := by
  have hKernel :
      (ARCKernel 3 (arc3SharpSequence x y)).Finite :=
    arc3_sharp_three_kernel_finite x y

  have hMSD :
      ARCMSDAutomatic 3 (arc3SharpSequence x y) :=
    arc_finite_kernel_implies_msd_automatic
      3
      (arc3SharpSequence x y)
      hKernel

  exact
    arc_msd_automatic_implies_zero_digit_standard
      (arc3SharpSequence x y)
      hMSD


theorem arc3_sharp_at_zero
    {α : Type u}
    (x y : α) :
    arc3SharpSequence x y 0 = x ∧
    (∀ n : ℕ, 1 ≤ n → arc3SharpSequence x y n = y) := by
  constructor
  · simp [arc3SharpSequence]
  · intro n hn
    have hn0 : n ≠ 0 := by
      omega
    simp [arc3SharpSequence, hn0]

/--
A compact sharpness package: the value at zero may be chosen independently
of the common value on all positive integers, while preserving both
3-automaticity and shortcut-Collatz invariance.
-/
theorem arc3_zero_value_is_genuinely_free
    {α : Type u}
    (x y : α) :
    ARCStandardMSDZeroDigitAutomatic 3 (arc3SharpSequence x y) ∧
    (∀ n : ℕ,
      arc3SharpSequence x y (2 * n) = arc3SharpSequence x y n) ∧
    (∀ n : ℕ,
      arc3SharpSequence x y (2 * n + 1) =
        arc3SharpSequence x y (3 * n + 2)) ∧
    arc3SharpSequence x y 0 = x ∧
    (∀ n : ℕ, 1 ≤ n → arc3SharpSequence x y n = y) := by
  refine ⟨arc3_sharp_zero_digit_standard_automatic x y, ?_⟩
  refine ⟨arc3_sharp_even x y, ?_⟩
  refine ⟨arc3_sharp_odd x y, ?_⟩
  exact arc3_sharp_at_zero x y


/-!
============================================================
2. 3-automatic invariant sets
============================================================
-/

/--
A set is called 3-automatic here when it has a Boolean characteristic
sequence that is automatic in the canonical MSD convention with zero
represented by `[0]`.
-/
def ARC3AutomaticSet
    (A : Set ℕ) :
    Prop :=
  ∃ χ : ℕ → Bool,
    ARCStandardMSDZeroDigitAutomatic 3 χ ∧
    ∀ n : ℕ,
      (χ n = true ↔ n ∈ A)

/--
Shortcut-Collatz invariance written directly in the two branch identities.
This is exactly the set-theoretic form needed by ARC₃.
-/
def ARC3CollatzInvariantSet
    (A : Set ℕ) :
    Prop :=
  (∀ n : ℕ,
    (2 * n ∈ A ↔ n ∈ A)) ∧
  (∀ n : ℕ,
    (2 * n + 1 ∈ A ↔ 3 * n + 2 ∈ A))


lemma arc3_bool_eq_of_true_iff
    (p q : Bool)
    (h : (p = true ↔ q = true)) :
    p = q := by
  cases p <;> cases q <;> simp at h ⊢


/--
A 3-automatic shortcut-Collatz-invariant set is either empty on the
positive integers or contains every positive integer.
-/
theorem arc3_invariant_automatic_set_trivial
    (hCobham : ARCCobhamPrinciple.{0})
    (A : Set ℕ)
    (hAuto : ARC3AutomaticSet A)
    (hInv : ARC3CollatzInvariantSet A) :
    (∀ n : ℕ, 1 ≤ n → n ∉ A) ∨
    (∀ n : ℕ, 1 ≤ n → n ∈ A) := by

  rcases hAuto with ⟨χ, hχAuto, hχ⟩
  rcases hInv with ⟨hSetEven, hSetOdd⟩

  have hEven :
      ∀ n : ℕ,
        χ (2 * n) = χ n := by
    intro n
    apply arc3_bool_eq_of_true_iff
    calc
      χ (2 * n) = true ↔ 2 * n ∈ A := hχ (2 * n)
      _ ↔ n ∈ A := hSetEven n
      _ ↔ χ n = true := (hχ n).symm

  have hOdd :
      ∀ n : ℕ,
        χ (2 * n + 1) = χ (3 * n + 2) := by
    intro n
    apply arc3_bool_eq_of_true_iff
    calc
      χ (2 * n + 1) = true ↔ 2 * n + 1 ∈ A := hχ (2 * n + 1)
      _ ↔ 3 * n + 2 ∈ A := hSetOdd n
      _ ↔ χ (3 * n + 2) = true := (hχ (3 * n + 2)).symm

  rcases
      arc3_main_zero_digit_standard_msd_form_of_cobham
        hCobham
        χ
        hEven
        hOdd
        hχAuto
    with ⟨c, hc⟩

  cases c with
  | false =>
      left
      intro n hn hmem
      have ht : χ n = true := (hχ n).2 hmem
      have hf : χ n = false := hc n hn
      rw [hf] at ht
      simp at ht

  | true =>
      right
      intro n hn
      exact (hχ n).1 (hc n hn)


/-!
============================================================
3. The basin of 1 and the ARC₃ Collatz criterion
============================================================
-/

/--
We characterize the shortcut Collatz map by its two branch equations,
without introducing any division convention into the formalization.
-/
def ARC3IsShortcutCollatzMap
    (T : ℕ → ℕ) :
    Prop :=
  (∀ n : ℕ, T (2 * n) = n) ∧
  (∀ n : ℕ, T (2 * n + 1) = 3 * n + 2)


def ARC3Iterate
    (T : ℕ → ℕ) :
    ℕ → ℕ → ℕ
  | 0, n => n
  | k + 1, n => ARC3Iterate T k (T n)


def ARC3BasinOne
    (T : ℕ → ℕ) :
    Set ℕ :=
  {n | ∃ k : ℕ, ARC3Iterate T k n = 1}


theorem arc3_basin_one_mem
    (T : ℕ → ℕ) :
    1 ∈ ARC3BasinOne T := by
  exact ⟨0, rfl⟩


theorem arc3_basin_T_invariant
    (T : ℕ → ℕ)
    (hT : ARC3IsShortcutCollatzMap T) :
    ∀ n : ℕ,
      (n ∈ ARC3BasinOne T ↔ T n ∈ ARC3BasinOne T) := by
  intro n
  constructor

  · rintro ⟨k, hk⟩
    cases k with
    | zero =>
        have hn : n = 1 := by
          simpa [ARC3Iterate] using hk
        subst n

        have hT1 : T 1 = 2 := by
          simpa using hT.2 0
        have hT2 : T 2 = 1 := by
          simpa using hT.1 1

        refine ⟨1, ?_⟩
        simp [ARC3Iterate, hT1, hT2]

    | succ k =>
        refine ⟨k, ?_⟩
        simpa [ARC3Iterate] using hk

  · rintro ⟨k, hk⟩
    refine ⟨k + 1, ?_⟩
    simpa [ARC3Iterate] using hk


theorem arc3_basin_collatz_invariant_set
    (T : ℕ → ℕ)
    (hT : ARC3IsShortcutCollatzMap T) :
    ARC3CollatzInvariantSet (ARC3BasinOne T) := by

  have hInv := arc3_basin_T_invariant T hT

  constructor
  · intro n
    have h := hInv (2 * n)
    simpa [hT.1 n] using h

  · intro n
    have h := hInv (2 * n + 1)
    simpa [hT.2 n] using h


theorem arc3_iterate_zero
    (T : ℕ → ℕ)
    (hT0 : T 0 = 0) :
    ∀ k : ℕ,
      ARC3Iterate T k 0 = 0 := by
  intro k
  induction k with
  | zero =>
      rfl
  | succ k ih =>
      simpa [ARC3Iterate, hT0] using ih


theorem arc3_basin_zero_not_mem
    (T : ℕ → ℕ)
    (hT : ARC3IsShortcutCollatzMap T) :
    0 ∉ ARC3BasinOne T := by
  intro hzero
  rcases hzero with ⟨k, hk⟩

  have hT0 : T 0 = 0 := by
    simpa using hT.1 0

  have hz : ARC3Iterate T k 0 = 0 :=
    arc3_iterate_zero T hT0 k

  omega

/--
If the basin of 1 is 3-automatic, ARC₃ forces every positive integer into
that basin. This is the nontrivial direction of the automaticity criterion.
-/
theorem arc3_basin_automatic_implies_collatz
    (hCobham : ARCCobhamPrinciple.{0})
    (T : ℕ → ℕ)
    (hT : ARC3IsShortcutCollatzMap T)
    (hAuto : ARC3AutomaticSet (ARC3BasinOne T)) :
    ∀ n : ℕ,
      1 ≤ n →
      n ∈ ARC3BasinOne T := by

  have hTrivial :=
    arc3_invariant_automatic_set_trivial
      hCobham
      (ARC3BasinOne T)
      hAuto
      (arc3_basin_collatz_invariant_set T hT)

  rcases hTrivial with hEmpty | hAll

  · have hNotOne : 1 ∉ ARC3BasinOne T :=
      hEmpty 1 (by omega)
    exact False.elim (hNotOne (arc3_basin_one_mem T))

  · exact hAll

/--
If every positive integer reaches 1, then the basin is simply the positive
integers; its characteristic sequence is the sharp two-valued sequence
`false` at zero and `true` elsewhere, hence is 3-automatic.
-/
theorem arc3_collatz_implies_basin_automatic
    (T : ℕ → ℕ)
    (hT : ARC3IsShortcutCollatzMap T)
    (hCollatz :
      ∀ n : ℕ,
        1 ≤ n →
        n ∈ ARC3BasinOne T) :
    ARC3AutomaticSet (ARC3BasinOne T) := by

  refine
    ⟨arc3SharpSequence false true,
      arc3_sharp_zero_digit_standard_automatic false true,
      ?_⟩

  intro n
  by_cases hn : n = 0

  · subst n
    have hz : 0 ∉ ARC3BasinOne T :=
      arc3_basin_zero_not_mem T hT
    simp [arc3SharpSequence, hz]

  · have hnpos : 1 ≤ n := by
      omega
    have hb : n ∈ ARC3BasinOne T :=
      hCollatz n hnpos
    simp [arc3SharpSequence, hn, hb]

/--
ARC₃ automaticity criterion for the shortcut Collatz conjecture:
all positive integers reach 1 iff the basin of 1 is 3-automatic.
The reverse implication is conditional only on the explicit Cobham principle.
-/
theorem arc3_collatz_iff_basin_three_automatic
    (hCobham : ARCCobhamPrinciple.{0})
    (T : ℕ → ℕ)
    (hT : ARC3IsShortcutCollatzMap T) :
    (∀ n : ℕ,
      1 ≤ n →
      n ∈ ARC3BasinOne T)
      ↔
    ARC3AutomaticSet (ARC3BasinOne T) := by
  constructor
  · intro hCollatz
    exact
      arc3_collatz_implies_basin_automatic
        T hT hCollatz
  · intro hAuto
    exact
      arc3_basin_automatic_implies_collatz
        hCobham T hT hAuto


/-!
============================================================
4. Axiom audit
============================================================
-/

#print axioms arc3_zero_value_is_genuinely_free
#print axioms arc3_invariant_automatic_set_trivial
#print axioms arc3_basin_T_invariant
#print axioms arc3_basin_collatz_invariant_set
#print axioms arc3_basin_automatic_implies_collatz
#print axioms arc3_collatz_implies_basin_automatic
#print axioms arc3_collatz_iff_basin_three_automatic

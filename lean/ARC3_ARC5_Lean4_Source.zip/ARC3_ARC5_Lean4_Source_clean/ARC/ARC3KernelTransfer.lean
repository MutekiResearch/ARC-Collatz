import Mathlib
import ARC.ARCAutomaticBridge2

set_option autoImplicit false

universe u

/-!
# ARC₃ — kernel transfer

This file formalizes the new ingredient in the base-3 ARC argument.

Assume

    a(2n)   = a(n),
    a(2n+1) = a(3n+2).

The goal is to prove that the 3-kernel of `a` is closed under
binary decimation.  Consequently every member of the 2-kernel
already belongs to the 3-kernel:

    K₂(a) ⊆ K₃(a).

Thus finite K₃(a) implies finite K₂(a).

Unlike the base-2 ARC proof, no primitive-root lemma is needed here.
-/


/-!
============================================================
1. The 3-kernel is closed under n ↦ 2n
============================================================
-/

/--
If `u` belongs to the 3-kernel of `a`, then its even decimation
`n ↦ u(2n)` also belongs to the 3-kernel.
-/
theorem arc3_three_kernel_closed_even
    {α : Type u}
    (a : ℕ → α)
    (hEven :
      ∀ n : ℕ,
        a (2 * n) = a n)
    (hOdd :
      ∀ n : ℕ,
        a (2 * n + 1) = a (3 * n + 2))
    {u : ℕ → α}
    (hu :
      u ∈ ARCKernel 3 a) :
    (fun n => u (2 * n)) ∈ ARCKernel 3 a := by

  have hu' :
      ∃ j r : ℕ,
        r < 3 ^ j ∧
        ∀ n : ℕ,
          u n = a (3 ^ j * n + r) := by
    simpa [ARCKernel] using hu

  rcases hu' with
    ⟨j, r, hr, huEq⟩

  change
    ∃ E R : ℕ,
      R < 3 ^ E ∧
      ∀ n : ℕ,
        u (2 * n) = a (3 ^ E * n + R)

  rcases Nat.mod_two_eq_zero_or_one r with
    hmod | hmod

  · /- r is even. -/
    have hrEq :
        r = 2 * (r / 2) := by
      omega

    refine
      ⟨j, r / 2, ?_, ?_⟩

    · exact
        lt_of_le_of_lt
          (Nat.div_le_self r 2)
          hr

    · intro n

      calc
        u (2 * n)
            =
          a (3 ^ j * (2 * n) + r) :=
            huEq (2 * n)

        _ =
          a (2 * (3 ^ j * n + r / 2)) := by
            congr 1
            calc
              3 ^ j * (2 * n) + r
                  = 2 * (3 ^ j * n) + r := by
                      ring
              _ = 2 * (3 ^ j * n) + 2 * (r / 2) := by
                      omega
              _ = 2 * (3 ^ j * n + r / 2) := by
                      ring

        _ =
          a (3 ^ j * n + r / 2) :=
            hEven (3 ^ j * n + r / 2)

  · /- r is odd. -/
    have hrEq :
        r = 2 * (r / 2) + 1 := by
      omega

    have hhalf :
        r / 2 < 3 ^ j :=
      lt_of_le_of_lt
        (Nat.div_le_self r 2)
        hr

    refine
      ⟨j + 1, 3 * (r / 2) + 2, ?_, ?_⟩

    · rw [pow_succ]
      omega

    · intro n

      calc
        u (2 * n)
            =
          a (3 ^ j * (2 * n) + r) :=
            huEq (2 * n)

        _ =
          a (2 * (3 ^ j * n + r / 2) + 1) := by
            congr 1
            calc
              3 ^ j * (2 * n) + r
                  = 2 * (3 ^ j * n) + r := by
                      ring
              _ = 2 * (3 ^ j * n) + (2 * (r / 2) + 1) := by
                      omega
              _ = 2 * (3 ^ j * n + r / 2) + 1 := by
                      ring

        _ =
          a (3 * (3 ^ j * n + r / 2) + 2) :=
            hOdd (3 ^ j * n + r / 2)

        _ =
          a (3 ^ (j + 1) * n + (3 * (r / 2) + 2)) := by
            congr 1
            rw [pow_succ]
            ring


/-!
============================================================
2. The 3-kernel is closed under n ↦ 2n+1
============================================================
-/

/--
If `u` belongs to the 3-kernel of `a`, then its odd decimation
`n ↦ u(2n+1)` also belongs to the 3-kernel.
-/
theorem arc3_three_kernel_closed_odd
    {α : Type u}
    (a : ℕ → α)
    (hEven :
      ∀ n : ℕ,
        a (2 * n) = a n)
    (hOdd :
      ∀ n : ℕ,
        a (2 * n + 1) = a (3 * n + 2))
    {u : ℕ → α}
    (hu :
      u ∈ ARCKernel 3 a) :
    (fun n => u (2 * n + 1)) ∈ ARCKernel 3 a := by

  have hu' :
      ∃ j r : ℕ,
        r < 3 ^ j ∧
        ∀ n : ℕ,
          u n = a (3 ^ j * n + r) := by
    simpa [ARCKernel] using hu

  rcases hu' with
    ⟨j, r, hr, huEq⟩

  change
    ∃ E R : ℕ,
      R < 3 ^ E ∧
      ∀ n : ℕ,
        u (2 * n + 1) = a (3 ^ E * n + R)

  let d : ℕ :=
    3 ^ j + r

  have hd :
      d < 2 * (3 ^ j) := by
    dsimp [d]
    omega

  rcases Nat.mod_two_eq_zero_or_one d with
    hmod | hmod

  · /- d is even. -/
    have hdEq :
        d = 2 * (d / 2) := by
      omega

    have hrem :
        d / 2 < 3 ^ j := by
      omega

    refine
      ⟨j, d / 2, hrem, ?_⟩

    intro n

    calc
      u (2 * n + 1)
          =
        a (3 ^ j * (2 * n + 1) + r) :=
          huEq (2 * n + 1)

      _ =
        a (2 * (3 ^ j * n + d / 2)) := by
          congr 1
          calc
            3 ^ j * (2 * n + 1) + r
                =
              2 * (3 ^ j * n) + d := by
                dsimp [d]
                ring

            _ =
              2 * (3 ^ j * n) + 2 * (d / 2) := by
                omega

            _ =
              2 * (3 ^ j * n + d / 2) := by
                ring

      _ =
        a (3 ^ j * n + d / 2) :=
          hEven (3 ^ j * n + d / 2)

  · /- d is odd. -/
    have hdEq :
        d = 2 * (d / 2) + 1 := by
      omega

    have hhalf :
        d / 2 < 3 ^ j := by
      omega

    refine
      ⟨j + 1, 3 * (d / 2) + 2, ?_, ?_⟩

    · rw [pow_succ]
      omega

    · intro n

      calc
        u (2 * n + 1)
            =
          a (3 ^ j * (2 * n + 1) + r) :=
            huEq (2 * n + 1)

        _ =
          a (2 * (3 ^ j * n + d / 2) + 1) := by
            congr 1
            calc
              3 ^ j * (2 * n + 1) + r
                  =
                2 * (3 ^ j * n) + d := by
                  dsimp [d]
                  ring

              _ =
                2 * (3 ^ j * n) + (2 * (d / 2) + 1) := by
                  omega

              _ =
                2 * (3 ^ j * n + d / 2) + 1 := by
                  ring

        _ =
          a (3 * (3 ^ j * n + d / 2) + 2) :=
            hOdd (3 ^ j * n + d / 2)

        _ =
          a (3 ^ (j + 1) * n + (3 * (d / 2) + 2)) := by
            congr 1
            rw [pow_succ]
            ring


/-!
============================================================
3. Every canonical 2-kernel subsequence lies in K₃(a)
============================================================
-/

/--
For every binary-kernel index pair `(e,r)`, the canonical sequence

    n ↦ a(2^e n + r)

belongs to the 3-kernel.

The induction peels off the most significant binary remainder bit:

* if `r < 2^e`, use even decimation;
* otherwise write `r = 2^e + s` and use odd decimation.
-/
theorem arc3_binary_kernel_sequence_mem_three_kernel
    {α : Type u}
    (a : ℕ → α)
    (hEven :
      ∀ n : ℕ,
        a (2 * n) = a n)
    (hOdd :
      ∀ n : ℕ,
        a (2 * n + 1) = a (3 * n + 2)) :
    ∀ e r : ℕ,
      r < 2 ^ e →
      (fun n => a (2 ^ e * n + r)) ∈ ARCKernel 3 a := by

  intro e

  induction e with

  | zero =>
      intro r hr

      have hr0 :
          r = 0 := by
        norm_num at hr
        omega

      subst r

      change
        ∃ E R : ℕ,
          R < 3 ^ E ∧
          ∀ n : ℕ,
            a (2 ^ 0 * n + 0) = a (3 ^ E * n + R)

      refine
        ⟨0, 0, ?_, ?_⟩

      · norm_num

      · intro n
        simp

  | succ e ih =>
      intro r hr

      by_cases hlow :
        r < 2 ^ e

      · /- The high binary remainder bit is 0. -/
        have hv :
            (fun n => a (2 ^ e * n + r)) ∈ ARCKernel 3 a :=
          ih r hlow

        have hclosed :
            (fun n =>
              (fun m => a (2 ^ e * m + r)) (2 * n))
              ∈ ARCKernel 3 a :=
          arc3_three_kernel_closed_even
            a
            hEven
            hOdd
            hv

        have hseq :
            (fun n => a (2 ^ (e + 1) * n + r))
              =
            (fun n =>
              (fun m => a (2 ^ e * m + r)) (2 * n)) := by

          funext n
          congr 1
          rw [pow_succ]
          ring

        rw [hseq]
        exact hclosed

      · /- The high binary remainder bit is 1. -/
        have hge :
            2 ^ e ≤ r := by
          omega

        have hr' :
            r - 2 ^ e < 2 ^ e := by
          rw [pow_succ] at hr
          omega

        have hv :
            (fun n => a (2 ^ e * n + (r - 2 ^ e)))
              ∈ ARCKernel 3 a :=
          ih (r - 2 ^ e) hr'

        have hclosed :
            (fun n =>
              (fun m =>
                a (2 ^ e * m + (r - 2 ^ e)))
                (2 * n + 1))
              ∈ ARCKernel 3 a :=
          arc3_three_kernel_closed_odd
            a
            hEven
            hOdd
            hv

        have hrSplit :
            r = 2 ^ e + (r - 2 ^ e) := by
          omega

        have hseq :
            (fun n => a (2 ^ (e + 1) * n + r))
              =
            (fun n =>
              (fun m =>
                a (2 ^ e * m + (r - 2 ^ e)))
                (2 * n + 1)) := by

          funext n
          congr 1
          calc
            2 ^ (e + 1) * n + r
                = 2 * (2 ^ e * n) + r := by
                    rw [pow_succ]
                    ring
            _ = 2 * (2 ^ e * n) + 2 ^ e + (r - 2 ^ e) := by
                    omega
            _ = 2 ^ e * (2 * n + 1) + (r - 2 ^ e) := by
                    ring

        rw [hseq]
        exact hclosed


/-!
============================================================
4. Main kernel inclusion: K₂(a) ⊆ K₃(a)
============================================================
-/

/--
The base-3 ARC kernel-transfer lemma.
-/
theorem arc3_two_kernel_subset_three_kernel
    {α : Type u}
    (a : ℕ → α)
    (hEven :
      ∀ n : ℕ,
        a (2 * n) = a n)
    (hOdd :
      ∀ n : ℕ,
        a (2 * n + 1) = a (3 * n + 2)) :
    ARCKernel 2 a ⊆ ARCKernel 3 a := by

  intro u hu

  have hu' :
      ∃ e r : ℕ,
        r < 2 ^ e ∧
        ∀ n : ℕ,
          u n = a (2 ^ e * n + r) := by
    simpa [ARCKernel] using hu

  rcases hu' with
    ⟨e, r, hr, huEq⟩

  have hcanon :
      (fun n => a (2 ^ e * n + r)) ∈ ARCKernel 3 a :=
    arc3_binary_kernel_sequence_mem_three_kernel
      a
      hEven
      hOdd
      e
      r
      hr

  have hfun :
      u = (fun n => a (2 ^ e * n + r)) := by
    funext n
    exact huEq n

  rw [hfun]
  exact hcanon


/-!
============================================================
5. Finite K₃(a) ⇒ finite K₂(a)
============================================================
-/

/--
If `a` is 3-automatic in finite-kernel form, then Collatz
invariance forces it to be 2-automatic in finite-kernel form.
-/
theorem arc3_three_kernel_finite_implies_two_kernel_finite
    {α : Type u}
    (a : ℕ → α)
    (hEven :
      ∀ n : ℕ,
        a (2 * n) = a n)
    (hOdd :
      ∀ n : ℕ,
        a (2 * n + 1) = a (3 * n + 2))
    (ha :
      (ARCKernel 3 a).Finite) :
    (ARCKernel 2 a).Finite := by

  exact
    ha.subset
      (arc3_two_kernel_subset_three_kernel
        a
        hEven
        hOdd)


/--
Same statement in the explicit finite-kernel automaticity wrapper.
-/
theorem arc3_three_automatic_kernel_implies_two_automatic_kernel
    {α : Type u}
    (a : ℕ → α)
    (hEven :
      ∀ n : ℕ,
        a (2 * n) = a n)
    (hOdd :
      ∀ n : ℕ,
        a (2 * n + 1) = a (3 * n + 2))
    (ha :
      ARCAutomaticByKernel 3 a) :
    ARCAutomaticByKernel 2 a := by

  unfold ARCAutomaticByKernel at ha ⊢

  exact
    arc3_three_kernel_finite_implies_two_kernel_finite
      a
      hEven
      hOdd
      ha


/-!
============================================================
6. Axiom audit
============================================================
-/

#print axioms arc3_three_kernel_closed_even
#print axioms arc3_three_kernel_closed_odd
#print axioms arc3_binary_kernel_sequence_mem_three_kernel
#print axioms arc3_two_kernel_subset_three_kernel
#print axioms arc3_three_kernel_finite_implies_two_kernel_finite
#print axioms arc3_three_automatic_kernel_implies_two_automatic_kernel

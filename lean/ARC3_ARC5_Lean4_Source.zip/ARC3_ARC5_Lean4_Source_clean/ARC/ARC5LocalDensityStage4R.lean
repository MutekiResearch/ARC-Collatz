import Mathlib
import ARC.ARC5LocalDensityStage4Q

set_option autoImplicit false

/-!
# ARC5 / natural-domain bridge — Stage 4R

Stage 4Q extracted finite simultaneous coalescence and finite invariant blocks
for integer-indexed colorings.

ARC5, however, is a sequence on the natural numbers.  This file builds the
clean bridge back to `ℕ`.

Main points:

* the integer shortcut map preserves nonnegativity;
* define the natural shortcut map and its iterates;
* prove that natural iterates cast exactly to the integer iterates;
* every dyadic cylinder contains a positive natural integer;
* therefore every natural coloring invariant under the shortcut map has
  arbitrarily long finite monochromatic blocks.

The later ARC5 stages will add the required base-5 alignment.
-/

/-- Natural shortcut Collatz map corresponding to `arcShortcutInt`. -/
def arcShortcutNat (n : ℕ) : ℕ :=
  if n % 2 = 0
    then n / 2
    else (3 * n + 1) / 2

/-- Iterates of the natural shortcut map. -/
def arcShortcutNatIter : ℕ → ℕ → ℕ
  | 0, n => n
  | h + 1, n =>
      arcShortcutNatIter h (arcShortcutNat n)

/--
The integer shortcut map preserves nonnegativity.
-/
lemma arcShortcutInt_nonneg
    {x : ℤ}
    (hx : 0 ≤ x) :
    0 ≤ arcShortcutInt x := by

  by_cases he : x % 2 = 0

  · have hEven :
        x = 2 * (x / 2) := by
      omega

    rw [arcShortcutInt_of_even hEven]

    exact
      Int.ediv_nonneg
        hx
        (by norm_num)

  · have hnum :
        0 ≤ 3 * x + 1 := by
      omega

    have hOdd :
        3 * x + 1 =
          2 * ((3 * x + 1) / 2) := by
      omega

    rw [arcShortcutInt_of_odd hOdd]

    exact
      Int.ediv_nonneg
        hnum
        (by norm_num)

/--
All integer shortcut iterates of a nonnegative input remain nonnegative.
-/
lemma arcShortcutIter_nonneg :
    ∀ h : ℕ,
      ∀ x : ℤ,
        0 ≤ x →
        0 ≤ arcShortcutIter h x := by

  intro h

  induction h with

  | zero =>
      intro x hx
      simpa [arcShortcutIter] using hx

  | succ h ih =>
      intro x hx

      change
        0 ≤
          arcShortcutIter
            h
            (arcShortcutInt x)

      exact
        ih
          (arcShortcutInt x)
          (arcShortcutInt_nonneg hx)

/--
Casting the natural shortcut map to `ℤ` gives exactly the integer shortcut
map on a natural input.
-/
theorem arcShortcutNat_cast
    (n : ℕ) :
    ((arcShortcutNat n : ℕ) : ℤ)
      =
    arcShortcutInt (n : ℤ) := by

  by_cases he : n % 2 = 0

  · have heZ :
        ((n : ℤ) % 2) = 0 := by
      exact_mod_cast he

    simp
      [arcShortcutNat,
       arcShortcutInt,
       he,
       heZ]

  · have heZ :
        ((n : ℤ) % 2) ≠ 0 := by
      intro hz

      have hn :
          n % 2 = 0 := by
        exact_mod_cast hz

      exact he hn

    simp
      [arcShortcutNat,
       arcShortcutInt,
       he,
       heZ]

/--
Casting every natural shortcut iterate to `ℤ` agrees with the integer
shortcut iterate.
-/
theorem arcShortcutNatIter_cast :
    ∀ h : ℕ,
      ∀ n : ℕ,
        ((arcShortcutNatIter h n : ℕ) : ℤ)
          =
        arcShortcutIter h (n : ℤ) := by

  intro h

  induction h with

  | zero =>
      intro n
      rfl

  | succ h ih =>
      intro n

      change
        ((arcShortcutNatIter
            h
            (arcShortcutNat n) : ℕ) : ℤ)
          =
        arcShortcutIter
          h
          (arcShortcutInt (n : ℤ))

      rw [ih]
      rw [arcShortcutNat_cast]

/--
Equality of integer shortcut iterates on two natural inputs implies equality
of the corresponding natural iterates.
-/
lemma arcShortcutNatIter_eq_of_int
    {h n m : ℕ}
    (heq :
      arcShortcutIter h (n : ℤ)
        =
      arcShortcutIter h (m : ℤ)) :
    arcShortcutNatIter h n
      =
    arcShortcutNatIter h m := by

  apply Int.ofNat.inj

  calc
    ((arcShortcutNatIter h n : ℕ) : ℤ)
        =
      arcShortcutIter h (n : ℤ) :=
        arcShortcutNatIter_cast h n

    _ =
      arcShortcutIter h (m : ℤ) :=
        heq

    _ =
      ((arcShortcutNatIter h m : ℕ) : ℤ) :=
        (arcShortcutNatIter_cast h m).symm

/--
One-step natural shortcut invariance propagates to all finite iterates.
-/
theorem arcNatColor_iter_invariant
    {α : Type*}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n) :
    ∀ h : ℕ,
      ∀ n : ℕ,
        a (arcShortcutNatIter h n) = a n := by

  intro h

  induction h with

  | zero =>
      intro n
      rfl

  | succ h ih =>
      intro n

      change
        a
          (arcShortcutNatIter
            h
            (arcShortcutNat n))
          =
        a n

      calc
        a
          (arcShortcutNatIter
            h
            (arcShortcutNat n))
            =
        a (arcShortcutNat n) := by
          exact ih (arcShortcutNat n)

        _ = a n := hinv n

/--
Every dyadic cylinder contains a positive natural integer.
-/
theorem arcDyadicCylinder_has_positive_nat
    (M : ℕ)
    (s : ℤ) :
    ∃ n : ℕ,
      0 < n
      ∧
      arcDyadicCylinder M s (n : ℤ) := by

  let P : ℤ := (2 : ℤ) ^ M

  have hPpos :
      0 < P := by
    dsimp [P]
    positivity

  have hP :
      1 ≤ P := by
    omega

  by_cases hs : 0 < s

  · let n : ℕ := s.natAbs

    have hcast :
        ((n : ℕ) : ℤ) = s := by
      dsimp [n]
      exact
        Int.ofNat_natAbs_of_nonneg
          (le_of_lt hs)

    have hnpos :
        0 < n := by
      dsimp [n]
      exact
        (Int.natAbs_pos).2
          (ne_of_gt hs)

    refine
      ⟨n,
       hnpos,
       ?_⟩

    rw [hcast]

    exact
      ⟨0, by ring⟩

  · have hs0 :
        s ≤ 0 := by
      omega

    let t : ℤ := -s + 1
    let x : ℤ := s + P * t

    have htpos :
        0 < t := by
      dsimp [t]
      omega

    have hxpos :
        0 < x := by
      dsimp [x]

      have hPt :
          t ≤ P * t := by
        nlinarith

      nlinarith

    let n : ℕ := x.natAbs

    have hcast :
        ((n : ℕ) : ℤ) = x := by
      dsimp [n]
      exact
        Int.ofNat_natAbs_of_nonneg
          (le_of_lt hxpos)

    have hnpos :
        0 < n := by
      dsimp [n]
      exact
        (Int.natAbs_pos).2
          (ne_of_gt hxpos)

    refine
      ⟨n,
       hnpos,
       ?_⟩

    refine
      ⟨t, ?_⟩

    rw [hcast]

/--
Natural-domain finite invariant block.

For every finite `H`, a natural coloring invariant under the shortcut map has
a positive start `n` such that

    a(n) = a(n+j)    for every 0 <= j <= H.
-/
theorem arcFiniteNaturalInvariantBlock
    {α : Type*}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (H : ℕ) :
    ∃ n : ℕ,
      0 < n
      ∧
      ∀ j : ℕ,
        j ≤ H
          →
        a n = a (n + j) := by

  rcases
    arcFiniteSimultaneousLocalDensity
      H
      0
      0 with
    ⟨M, s,
     hParent,
     hCoal⟩

  rcases
    arcDyadicCylinder_has_positive_nat
      M
      s with
    ⟨n, hnpos, hnCyl⟩

  refine
    ⟨n,
     hnpos,
     ?_⟩

  intro j hj

  by_cases hj0 : j = 0

  · subst j
    simp

  · have hjpos :
        0 < j := by
      omega

    rcases
      hCoal
        j
        hjpos
        hj with
      ⟨h, hh⟩

    have hInt :
        arcShortcutIter h (n : ℤ)
          =
        arcShortcutIter h ((n + j : ℕ) : ℤ) := by

      have h0 :=
        hh
          (n : ℤ)
          hnCyl

      simpa using h0

    have hNat :
        arcShortcutNatIter h n
          =
        arcShortcutNatIter h (n + j) :=
      arcShortcutNatIter_eq_of_int hInt

    have hnInv :
        a (arcShortcutNatIter h n)
          =
        a n :=
      arcNatColor_iter_invariant
        a
        hinv
        h
        n

    have hnjInv :
        a (arcShortcutNatIter h (n + j))
          =
        a (n + j) :=
      arcNatColor_iter_invariant
        a
        hinv
        h
        (n + j)

    calc
      a n
          =
      a (arcShortcutNatIter h n) :=
        hnInv.symm

      _ =
      a (arcShortcutNatIter h (n + j)) := by
        rw [hNat]

      _ =
      a (n + j) :=
        hnjInv

/--
The exact natural block length used later for ARC5.
-/
theorem arcFiniteNaturalInvariantBlock_pow5
    {α : Type*}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (q : ℕ) :
    ∃ n : ℕ,
      0 < n
      ∧
      ∀ j : ℕ,
        j < 5 ^ q
          →
        a n = a (n + j) := by

  rcases
    arcFiniteNaturalInvariantBlock
      a
      hinv
      (5 ^ q - 1) with
    ⟨n, hnpos, hblock⟩

  refine
    ⟨n,
     hnpos,
     ?_⟩

  intro j hj

  have hjle :
      j ≤ 5 ^ q - 1 := by
    have hpow :
        0 < 5 ^ q := by
      positivity
    omega

  exact
    hblock
      j
      hjle

#print axioms arcShortcutInt_nonneg
#print axioms arcShortcutNat_cast
#print axioms arcShortcutNatIter_cast
#print axioms arcDyadicCylinder_has_positive_nat
#print axioms arcFiniteNaturalInvariantBlock
#print axioms arcFiniteNaturalInvariantBlock_pow5

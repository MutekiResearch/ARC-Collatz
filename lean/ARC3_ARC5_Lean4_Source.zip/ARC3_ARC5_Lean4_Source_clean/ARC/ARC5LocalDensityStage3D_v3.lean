import Mathlib
import ARC.ARC5LocalDensityStage3C

set_option autoImplicit false

/-!
# ARC5 / Local-Density audit — Stage 3D

Stage 3C reduced unconditional cylinder coalescence to one remaining existence
question: does every prescribed parity word have at least one seed residue?

This file proves yes, constructively.

The false/even prefix is immediate: if `r` realizes the tail word, then `2r`
realizes `false :: w`.

For a true/odd prefix, a tail seed may first be shifted inside its already
verified dyadic cylinder.  We choose the shift so that the adjusted tail start
`z` satisfies `2z - 1` divisible by 3; then `x = (2z-1)/3` is an integer and
satisfies the genuine odd-branch equation `3x+1=2z`.

The elementary congruence used to choose the shift is encoded without modular
inverses: for every n,

    3 | ((2^n)^2 - 1).

This is enough because a power of 2 is its own inverse modulo 3 up to sign.

The final theorem removes the seed hypothesis from Stage 3C.
-/

/--
Elementary arithmetic input:
for every n, 3 divides `(2^n)^2 - 1`.
-/
lemma arcThree_dvd_two_pow_sq_sub_one
    (n : ℕ) :
    (3 : ℤ) ∣ (((2 : ℤ) ^ n) ^ 2 - 1) := by

  induction n with
  | zero =>
      norm_num

  | succ n ih =>
      rcases ih with ⟨q, hq⟩

      refine ⟨4 * q + 1, ?_⟩

      have hp :
          (2 : ℤ) ^ (n + 1)
            =
          2 * ((2 : ℤ) ^ n) := by
        rw [pow_succ]
        ring

      rw [hp]

      calc
        (2 * ((2 : ℤ) ^ n)) ^ 2 - 1
            =
        4 * ((((2 : ℤ) ^ n) ^ 2) - 1) + 3 := by
          ring
        _ = 4 * (3 * q) + 3 := by
          rw [hq]
        _ = 3 * (4 * q + 1) := by
          ring

/--
Lift a tail seed through a false/even prefix.
-/
lemma arcFalse_seed_of_tail_seed
    (w : List Bool)
    (r : ℤ)
    (hr : arcWordCongruence w r) :
    arcWordCongruence (false :: w) (2 * r) := by

  apply (arcWordCongruence_iff_dvd (false :: w) (2 * r)).mpr

  have hrDvd :
      ((2 : ℤ) ^ w.length) ∣ arcWordNumerator w r :=
    (arcWordCongruence_iff_dvd w r).mp hr

  rcases hrDvd with ⟨q, hq⟩

  refine ⟨q, ?_⟩

  have hstep :
      arcWordNumerator (false :: w) (2 * r)
        =
      2 * arcWordNumerator w r :=
    arcWordNumerator_false_step (by rfl)

  rw [hstep, hq]
  simp [pow_succ]
  ring

/--
Lift a tail seed through a true/odd prefix.

The tail seed is first shifted by a multiple of `2^L`, hence remains in the
same tail cylinder.  The particular shift makes `2z-1` divisible by 3, so a
genuine integer odd predecessor exists.
-/
lemma arcTrue_seed_of_tail_seed
    (w : List Bool)
    (r : ℤ)
    (hr : arcWordCongruence w r) :
    ∃ x : ℤ,
      arcWordCongruence (true :: w) x := by

  let A : ℤ := (2 : ℤ) ^ w.length
  let B : ℤ := (2 : ℤ) ^ (w.length + 1)
  let t : ℤ := (1 - 2 * r) * B
  let z : ℤ := r + A * t

  have hzCyl :
      arcDyadicCylinder w.length r z := by
    refine ⟨t, ?_⟩
    dsimp [z, A]

  have hzCong :
      arcWordCongruence w z :=
    arcWordCongruence_on_cylinder
      w
      r
      z
      hr
      hzCyl

  have hB :
      (3 : ℤ) ∣ B ^ 2 - 1 := by
    dsimp [B]
    exact
      arcThree_dvd_two_pow_sq_sub_one
        (w.length + 1)

  rcases hB with ⟨q, hq⟩

  have hBA :
      B = 2 * A := by
    dsimp [B, A]
    rw [pow_succ]
    ring

  have hfactor :
      2 * z - 1
        =
      -(2 * r - 1) * (B ^ 2 - 1) := by
    dsimp [z, t]
    rw [hBA]
    ring

  have hthree :
      (3 : ℤ) ∣ (2 * z - 1) := by
    refine ⟨-(2 * r - 1) * q, ?_⟩
    rw [hfactor, hq]
    ring

  rcases hthree with ⟨x, hx⟩

  have hbranch :
      3 * x + 1 = 2 * z := by
    linarith

  refine ⟨x, ?_⟩

  apply
    (arcWordCongruence_iff_dvd
      (true :: w)
      x).mpr

  have hzDvd :
      ((2 : ℤ) ^ w.length)
        ∣
      arcWordNumerator w z :=
    (arcWordCongruence_iff_dvd w z).mp hzCong

  rcases hzDvd with ⟨s, hs⟩

  refine ⟨s, ?_⟩

  have hstep :
      arcWordNumerator (true :: w) x
        =
      2 * arcWordNumerator w z :=
    arcWordNumerator_true_step hbranch

  rw [hstep, hs]
  simp [pow_succ]
  ring

/--
Every finite parity word has at least one integer seed satisfying its exact
dyadic congruence condition.
-/
theorem arcEveryWord_has_seed :
    ∀ w : List Bool,
      ∃ r : ℤ,
        arcWordCongruence w r := by

  intro w

  induction w with
  | nil =>
      refine ⟨0, ?_⟩
      apply (arcWordCongruence_iff_dvd [] 0).mpr
      simp [arcWordNumerator, arcOnes, arcIntercept]

  | cons b w ih =>
      rcases ih with ⟨r, hr⟩

      cases b with
      | false =>
          exact
            ⟨2 * r,
             arcFalse_seed_of_tail_seed
               w
               r
               hr⟩

      | true =>
          exact
            arcTrue_seed_of_tail_seed
              w
              r
              hr

/--
Unconditional universal dyadic-cylinder coalescence.

For every positive integer gap `N`, there are equal-length parity words
`u,v` with equal odd-step count and an actual seed residue `r` such that
every integer in the full dyadic cylinder `r mod 2^|u|` genuinely follows
`u`, its translate by `N` genuinely follows `v`, and the two endpoints are
equal.
-/
theorem arcUniversalDyadicCylinderCoalescence
    (N : ℕ)
    (hN : 0 < N) :
    ∃ u v : List Bool,
      ∃ r : ℤ,
        u.length = v.length ∧
        arcOnes u = arcOnes v ∧
        arcWordCongruence u r ∧
        ∀ x : ℤ,
          arcDyadicCylinder u.length r x →
          ∃ yu yv : ℤ,
            arcFollowsTo u x yu ∧
            arcFollowsTo v (x + (N : ℤ)) yv ∧
            yu = yv := by

  rcases arcUniversalCylinderCoalescence_of_seed N hN with
    ⟨u, v, hlen, hones, hmain⟩

  rcases arcEveryWord_has_seed u with
    ⟨r, hr⟩

  refine
    ⟨u, v, r,
     hlen,
     hones,
     hr,
     ?_⟩

  intro x hx

  exact hmain r hr x hx

#print axioms arcThree_dvd_two_pow_sq_sub_one
#print axioms arcEveryWord_has_seed
#print axioms arcUniversalDyadicCylinderCoalescence

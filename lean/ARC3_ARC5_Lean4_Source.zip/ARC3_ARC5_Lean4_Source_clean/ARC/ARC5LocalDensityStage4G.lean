import Mathlib
import ARC.ARC5LocalDensityStage4F_v2

set_option autoImplicit false

/-!
# ARC5 / Local-Density audit — Stage 4G

Stage 4F packaged the four genuine steering moves on paired parity words.

This file isolates the well-founded arithmetic measures behind termination.

There are two quantities:

  1. exponent imbalance
         Δ(a,b) = (a-b) + (b-a) = |a-b|;

  2. absolute offset size
         |B| = Int.natAbs B.

The steering rules have the following behavior.

* 00:
    exponents are unchanged, while a nonzero even offset B = 2 C satisfies
    |C| < |B|.

* 10, used when a < b:
    the left exponent rises by one, so Δ drops by exactly one.

* 01, used when b < a:
    the right exponent rises by one, so Δ drops by exactly one.

* 11 zero-offset kick:
    both exponents rise by one, hence Δ is unchanged; but when a != b the
    new offset is provably nonzero.

Thus the only same-Δ process is repeated halving of a nonzero even offset,
and that process strictly decreases a natural-number measure.  The next stage
will package these facts into the finite steering termination theorem.
-/

/-- Absolute difference of the two odd-step counts, written without `abs`. -/
def arcImbalance (a b : ℕ) : ℕ :=
  (a - b) + (b - a)

/-- Balanced exponents have zero imbalance. -/
lemma arcImbalance_eq_zero
    (a : ℕ) :
    arcImbalance a a = 0 := by
  simp [arcImbalance]

/-- Simultaneously increasing both exponents preserves the imbalance. -/
lemma arcImbalance_succ_succ
    (a b : ℕ) :
    arcImbalance (a + 1) (b + 1)
      =
    arcImbalance a b := by
  unfold arcImbalance
  omega

/-- A 00 move preserves exponent imbalance. -/
lemma arcImbalance_step00
    (a b : ℕ) :
    arcImbalance a b = arcImbalance a b := by
  rfl

/--
If `a < b`, a 10 move raises `a` by one and decreases the imbalance by
exactly one.
-/
lemma arcImbalance_step10_exact
    {a b : ℕ}
    (hab : a < b) :
    arcImbalance (a + 1) b + 1
      =
    arcImbalance a b := by
  unfold arcImbalance
  omega

lemma arcImbalance_step10_lt
    {a b : ℕ}
    (hab : a < b) :
    arcImbalance (a + 1) b
      <
    arcImbalance a b := by
  have h :=
    arcImbalance_step10_exact hab
  omega

/--
If `b < a`, a 01 move raises `b` by one and decreases the imbalance by
exactly one.
-/
lemma arcImbalance_step01_exact
    {a b : ℕ}
    (hba : b < a) :
    arcImbalance a (b + 1) + 1
      =
    arcImbalance a b := by
  unfold arcImbalance
  omega

lemma arcImbalance_step01_lt
    {a b : ℕ}
    (hba : b < a) :
    arcImbalance a (b + 1)
      <
    arcImbalance a b := by
  have h :=
    arcImbalance_step01_exact hba
  omega

/--
A nonzero even offset strictly shrinks in absolute value when divided by two.
This is the well-founded measure for repeated 00 moves.
-/
lemma arcEvenHalf_natAbs_lt
    {B C : ℤ}
    (hBC : B = 2 * C)
    (hB0 : B ≠ 0) :
    C.natAbs < B.natAbs := by

  have hC0 : C ≠ 0 := by
    intro h
    apply hB0
    rw [hBC, h]
    norm_num

  have hCpos :
      0 < C.natAbs :=
    (Int.natAbs_pos).2 hC0

  calc
    C.natAbs
        < 2 * C.natAbs := by
            omega
    _ = (2 * C).natAbs := by
          rw [Int.natAbs_mul]
          norm_num
    _ = B.natAbs := by
          rw [hBC]

/--
Distinct exponents give distinct powers of 3 over the integers.
-/
lemma arcThreePow_ne_of_ne
    {a b : ℕ}
    (hab : a ≠ b) :
    (3 : ℤ) ^ a ≠ (3 : ℤ) ^ b := by

  intro hpow

  have hinj :
      Function.Injective
        (fun n : ℕ => (3 : ℤ) ^ n) :=
    Int.pow_right_injective
      (by norm_num)

  exact hab (hinj hpow)

/--
The 11 zero-offset kick really creates a nonzero offset whenever the exponent
imbalance is nonzero.

This is important: the zero-offset exceptional state cannot trap steering
unless the exponents were already balanced.
-/
lemma arcZeroKick_nonzero
    {a b : ℕ}
    {D : ℤ}
    (hab : a ≠ b)
    (hD :
      2 * D
        =
      (3 : ℤ) ^ (a + 1)
        - (3 : ℤ) ^ (b + 1)) :
    D ≠ 0 := by

  intro hD0

  have hpoweq :
      (3 : ℤ) ^ (a + 1)
        =
      (3 : ℤ) ^ (b + 1) := by
    rw [hD0] at hD
    linarith

  have hsucc :
      a + 1 = b + 1 := by
    have hinj :
        Function.Injective
          (fun n : ℕ => (3 : ℤ) ^ n) :=
      Int.pow_right_injective
        (by norm_num)
    exact hinj hpoweq

  apply hab
  omega

/--
Zero imbalance is equivalent to equality of the two exponent counts.
-/
lemma arcImbalance_zero_iff
    (a b : ℕ) :
    arcImbalance a b = 0
      ↔
    a = b := by

  unfold arcImbalance
  omega

/--
At zero imbalance and zero offset, the scaled relation has already merged:
the two current orbit values are equal.
-/
theorem arcScaledRelation_coalesces_of_zero_measure
    {a b : ℕ}
    {y y' : ℤ}
    (hDelta :
      arcImbalance a b = 0)
    (hrel :
      arcScaledRelation a b 0 y y') :
    y = y' := by

  have hab : a = b :=
    (arcImbalance_zero_iff a b).mp hDelta

  subst b

  exact
    arcScaledRelation_eq_of_balanced_zero
      hrel

#print axioms arcImbalance_step10_lt
#print axioms arcImbalance_step01_lt
#print axioms arcEvenHalf_natAbs_lt
#print axioms arcThreePow_ne_of_ne
#print axioms arcZeroKick_nonzero
#print axioms arcScaledRelation_coalesces_of_zero_measure

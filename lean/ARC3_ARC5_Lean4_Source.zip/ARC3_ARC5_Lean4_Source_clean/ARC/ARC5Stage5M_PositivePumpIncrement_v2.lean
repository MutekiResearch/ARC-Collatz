import Mathlib
import ARC.ARC5Stage5L_NumericWordPumping_v2

set_option autoImplicit false

/-!
# ARC5 — Stage 5M
## Positivity of the numerical pumping increment

Stage 5L identified a pumped MSD word

    a ++ repeat(b,n) ++ c

with the arithmetic family

    ARC5PumpedFamily N0 d (length b) n,

where

    d =
      5^(length c) *
      ( value(a) * (5^(length b) - 1) + value(b) ).

For the 2-adic arithmetic of Stage 5J we must exclude the degenerate case
`d = 0`.

The correct hypothesis is that the original word is a positive canonical MSD
representation: it is nonempty and its first digit is nonzero.  Then:

* if the pumping loop starts after a nonempty prefix `a`, `value(a) > 0`;
* if the loop starts at the first digit (`a = []`), then the nonempty block
  `b` begins with the nonzero leading digit, so `value(b) > 0`.

Thus every nonempty pump block extracted from a positive canonical word has a
strictly positive numerical increment.
-/

/-!
============================================================
1. Positive canonical MSD words
============================================================
-/

/--
A positive canonical base-5 MSD word: the word has a first digit, and that
first digit is nonzero.

This intentionally excludes the canonical representation `[0]` of zero.
-/
def ARC5CanonicalPositiveMSDWord
    (L : List (Fin 5)) :
    Prop :=
  ∃ d : Fin 5,
    ∃ ds : List (Fin 5),
      L = d :: ds
        ∧
      0 < d.val

/--
A positive canonical word is nonempty.
-/
lemma arc5_canonicalPositive_ne_nil
    {L : List (Fin 5)}
    (hL :
      ARC5CanonicalPositiveMSDWord L) :
    L ≠ [] := by

  rcases hL with
    ⟨d, ds, hL, hd⟩

  rw [hL]

  simp


/-!
============================================================
2. A nonzero leading digit gives positive numerical value
============================================================
-/

/--
A base-5 MSD word beginning with a positive digit has positive numerical
value.
-/
theorem arc5_msdValue_cons_pos
    (d : Fin 5)
    (ds : List (Fin 5))
    (hd :
      0 < d.val) :
    0 < ARC5MSDValue (d :: ds) := by

  have happ :=
    arc5_msdValue_append
      [d]
      ds

  have hsingle :
      ARC5MSDValue [d] = d.val := by
    simp [ARC5MSDValue]

  have hform :
      ARC5MSDValue (d :: ds)
        =
      d.val * 5 ^ ds.length
        +
      ARC5MSDValue ds := by

    simpa [hsingle] using happ

  have hpow :
      0 < 5 ^ ds.length := by
    positivity

  have hlead :
      0 < d.val * 5 ^ ds.length :=
    Nat.mul_pos hd hpow

  rw [hform]

  omega

/--
Every positive canonical MSD word has positive numerical value.
-/
theorem arc5_msdValue_pos_of_canonicalPositive
    {L : List (Fin 5)}
    (hL :
      ARC5CanonicalPositiveMSDWord L) :
    0 < ARC5MSDValue L := by

  rcases hL with
    ⟨d, ds, rfl, hd⟩

  exact
    arc5_msdValue_cons_pos
      d
      ds
      hd


/-!
============================================================
3. The base-5 length factor of a nonempty pump block is positive
============================================================
-/

/--
For every natural `n`, `5^(n+1) - 1` is positive.
-/
lemma arc5_pow5_succ_sub_one_pos
    (n : ℕ) :
    0 < 5 ^ (n + 1) - 1 := by

  have hpow :
      0 < 5 ^ n := by
    positivity

  have hgt :
      1 < 5 ^ (n + 1) := by
    rw [pow_succ]
    nlinarith

  omega


/-!
============================================================
4. Positivity of the word-pumping increment
============================================================
-/

/--
If a positive canonical word is split as `a ++ b ++ c` with a nonempty
middle block `b`, then the numerical pumping increment from Stage 5L is
strictly positive.
-/
theorem arc5_wordPumpIncrement_pos
    (x a b c : List (Fin 5))
    (hxCanonical :
      ARC5CanonicalPositiveMSDWord x)
    (hsplit :
      x = a ++ b ++ c)
    (hbne :
      b ≠ []) :
    0 < ARC5WordPumpIncrement a b c := by

  rcases hxCanonical with
    ⟨d, ds, hxform, hdpos⟩

  cases b with

  | nil =>
      exact
        (hbne rfl).elim

  | cons e es =>

      have hbaseSub :
          0 < 5 ^ (e :: es).length - 1 := by
        change
          0 < 5 ^ (es.length + 1) - 1
        exact
          arc5_pow5_succ_sub_one_pos
            es.length

      have hcpow :
          0 < 5 ^ c.length := by
        positivity

      cases a with

      | nil =>

          have hcons :
              e :: (es ++ c)
                =
              d :: ds := by

            calc
              e :: (es ++ c)
                  =
              x := by
                simpa using hsplit.symm

              _ =
              d :: ds :=
                hxform

          have hed :
              e = d := by
            injection hcons

          have hepos :
              0 < e.val := by
            simpa [hed] using hdpos

          have hbval :
              0 < ARC5MSDValue (e :: es) :=
            arc5_msdValue_cons_pos
              e
              es
              hepos

          unfold ARC5WordPumpIncrement

          have hnil :
              ARC5MSDValue ([] : List (Fin 5)) = 0 := by
            simp [ARC5MSDValue]

          rw [hnil]

          simp only [zero_mul, zero_add]

          exact
            Nat.mul_pos
              hcpow
              hbval

      | cons f fs =>

          have hcons :
              f :: (fs ++ e :: es ++ c)
                =
              d :: ds := by

            calc
              f :: (fs ++ e :: es ++ c)
                  =
              x := by
                simpa [List.append_assoc] using hsplit.symm

              _ =
              d :: ds :=
                hxform

          have hfd :
              f = d := by
            injection hcons

          have hfpos :
              0 < f.val := by
            simpa [hfd] using hdpos

          have haval :
              0 < ARC5MSDValue (f :: fs) :=
            arc5_msdValue_cons_pos
              f
              fs
              hfpos

          have hprod :
              0 <
                ARC5MSDValue (f :: fs)
                  *
                (5 ^ (e :: es).length - 1) :=
            Nat.mul_pos
              haval
              hbaseSub

          have hinterior :
              0 <
                ARC5MSDValue (f :: fs)
                    *
                  (5 ^ (e :: es).length - 1)
                  +
                ARC5MSDValue (e :: es) := by
            omega

          unfold ARC5WordPumpIncrement

          exact
            Nat.mul_pos
              hcpow
              hinterior


/-!
============================================================
5. Stage-5M positive pumping handoff
============================================================
-/

/--
Stage-5L pumping, strengthened by positivity of the numerical increment when
the starting support word is a positive canonical base-5 representation.
-/
theorem arc5_stage5M_positive_numeric_pumping_handoff
    (M : ARCMSDDFAO 5 Bool)
    [Fintype M.State]
    (s : ℕ → Bool)
    (hM :
      ARCMSDDFAO.Generates M s)
    (x : List (Fin 5))
    (hxCanonical :
      ARC5CanonicalPositiveMSDWord x)
    (hx :
      ARC5MSDValue x
        ∈
      ARC5BoolSupport s)
    (hlen :
      Fintype.card M.State
        ≤
      x.length) :
    ∃ a b c : List (Fin 5),
      x = a ++ b ++ c
        ∧
      a.length + b.length
        ≤
      Fintype.card M.State
        ∧
      b ≠ []
        ∧
      0 < ARC5WordPumpIncrement a b c
        ∧
      (
        ∀ n : ℕ,
          ARC5PumpedFamily
              (ARC5MSDValue (a ++ c))
              (ARC5WordPumpIncrement a b c)
              b.length
              n
            ∈
          ARC5BoolSupport s
      )
        ∧
      (
        ∀ n : ℕ,
          ARC5MSDValue
              (a ++ ARC5ListRepeat b n ++ c)
            =
          ARC5PumpedFamily
              (ARC5MSDValue (a ++ c))
              (ARC5WordPumpIncrement a b c)
              b.length
              n
      ) := by

  rcases
    arc5_stage5L_numeric_pumping_handoff
      M
      s
      hM
      x
      hx
      hlen with
    ⟨a,
     b,
     c,
     hsplit,
     hshort,
     hbne,
     hpump,
     hvalue⟩

  have hinc :
      0 < ARC5WordPumpIncrement a b c :=
    arc5_wordPumpIncrement_pos
      x
      a
      b
      c
      hxCanonical
      hsplit
      hbne

  exact
    ⟨a,
     b,
     c,
     hsplit,
     hshort,
     hbne,
     hinc,
     hpump,
     hvalue⟩


/-!
============================================================
6. Axiom audit
============================================================
-/

#print axioms arc5_canonicalPositive_ne_nil
#print axioms arc5_msdValue_cons_pos
#print axioms arc5_msdValue_pos_of_canonicalPositive
#print axioms arc5_pow5_succ_sub_one_pos
#print axioms arc5_wordPumpIncrement_pos
#print axioms arc5_stage5M_positive_numeric_pumping_handoff

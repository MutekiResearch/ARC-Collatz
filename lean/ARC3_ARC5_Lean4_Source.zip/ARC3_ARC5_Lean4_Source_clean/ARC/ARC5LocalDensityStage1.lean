import Mathlib

set_option autoImplicit false

/-!
# ARC5 / Local-Density audit — Stage 1

This file isolates the purely finite parity-word construction behind the
"universal local translation" step.

No automatic-sequence hypothesis is used here.

For a binary word `w`, `arcNormShift w` is the normalized affine translation
term `C(w) / 3^(number of 1-bits)` for the shortcut Collatz affine branch word.

The main theorem proved here is:

    for every positive integer N,
    there are two binary words u,v of the same length and the same number
    of 1-bits such that

        arcNormShift u - arcNormShift v = N.

This is the finite combinatorial core that later yields a dyadic cylinder on
which x and x+N coalesce after the same number of shortcut-Collatz steps.
-/

def arcOnes : List Bool → ℕ
  | [] => 0
  | b :: w => (if b then 1 else 0) + arcOnes w

/--
Normalized translation term for a parity word.

If a word `w` has length `L`, contains `k` one-bits, and has affine form

    F_w(x) = (3^k x + C(w)) / 2^L,

then `arcNormShift w = C(w) / 3^k`.
-/
def arcNormShift : List Bool → ℚ
  | [] => 0
  | false :: w => 2 * arcNormShift w
  | true  :: w => (1 : ℚ) / 3 + ((2 : ℚ) / 3) * arcNormShift w

def arcNormDiff (u v : List Bool) : ℚ :=
  arcNormShift u - arcNormShift v

lemma arcNormDiff_false_false
    (u v : List Bool) :
    arcNormDiff (false :: u) (false :: v)
      = 2 * arcNormDiff u v := by
  simp [arcNormDiff, arcNormShift]
  ring

lemma arcNormDiff_plus
    (u v : List Bool) :
    arcNormDiff (false :: true :: u) (true :: false :: v)
      = ((4 : ℚ) * arcNormDiff u v + 1) / 3 := by
  simp [arcNormDiff, arcNormShift]
  ring

lemma arcNormDiff_minus
    (u v : List Bool) :
    arcNormDiff (true :: false :: u) (false :: true :: v)
      = ((4 : ℚ) * arcNormDiff u v - 1) / 3 := by
  simp [arcNormDiff, arcNormShift]
  ring

lemma arcBaseTranslation :
    arcNormDiff [false, false, true] [true, false, false] = 1 := by
  norm_num [arcNormDiff, arcNormShift]

lemma arcBaseLength :
    [false, false, true].length = [true, false, false].length := by
  decide

lemma arcBaseOnes :
    arcOnes [false, false, true] = arcOnes [true, false, false] := by
  norm_num [arcOnes]

/--
Universal finite translation words.

For every positive integer `N`, there are equal-length parity words with
equal odd-step count and normalized translation difference exactly `N`.
-/
theorem arcUniversalTranslationWords :
    ∀ N : ℕ,
      0 < N →
      ∃ u v : List Bool,
        u.length = v.length ∧
        arcOnes u = arcOnes v ∧
        arcNormDiff u v = (N : ℚ) := by
  intro N
  induction N using Nat.strong_induction_on with
  | h N ih =>
      intro hN

      by_cases h1 : N = 1
      · subst N
        exact
          ⟨[false, false, true],
           [true, false, false],
           arcBaseLength,
           arcBaseOnes,
           arcBaseTranslation⟩

      rcases Nat.even_or_odd' N with ⟨m, hEven | hOdd⟩

      · -- N = 2m.
        have hmpos : 0 < m := by
          omega
        have hmlt : m < N := by
          omega

        rcases ih m hmlt hmpos with
          ⟨u, v, hlen, hones, hdiff⟩

        refine
          ⟨false :: u,
           false :: v,
           ?_,
           ?_,
           ?_⟩

        · simp [hlen]
        · simp [arcOnes, hones]
        · rw [arcNormDiff_false_false, hdiff]
          have hNm : N = 2 * m := by
            omega
          rw [hNm]
          push_cast
          ring

      · -- N = 2m+1. Split m once more to obtain N = 4s+1 or 4s+3.
        rcases Nat.even_or_odd' m with ⟨s, hmEven | hmOdd⟩

        · -- N = 4s+1. Since N ≠ 1, s > 0.
          have hspos : 0 < s := by
            omega

          let M : ℕ := 3 * s + 1

          have hMpos : 0 < M := by
            dsimp [M]
            omega

          have hMlt : M < N := by
            dsimp [M]
            omega

          rcases ih M hMlt hMpos with
            ⟨u, v, hlen, hones, hdiff⟩

          refine
            ⟨true :: false :: u,
             false :: true :: v,
             ?_,
             ?_,
             ?_⟩

          · simp [hlen]
          · simp [arcOnes, hones]
          · rw [arcNormDiff_minus, hdiff]
            dsimp [M]
            have hNform : N = 4 * s + 1 := by
              omega
            rw [hNform]
            push_cast
            ring

        · -- N = 4s+3.
          let M : ℕ := 3 * s + 2

          have hMpos : 0 < M := by
            dsimp [M]
            omega

          have hMlt : M < N := by
            dsimp [M]
            omega

          rcases ih M hMlt hMpos with
            ⟨u, v, hlen, hones, hdiff⟩

          refine
            ⟨false :: true :: u,
             true :: false :: v,
             ?_,
             ?_,
             ?_⟩

          · simp [hlen]
          · simp [arcOnes, hones]
          · rw [arcNormDiff_plus, hdiff]
            dsimp [M]
            have hNform : N = 4 * s + 3 := by
              omega
            rw [hNform]
            push_cast
            ring

#print axioms arcUniversalTranslationWords

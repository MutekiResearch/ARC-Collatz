import Mathlib
import Mathlib.Computability.DFA
import ARC.ARC5Stage5J_PumpingArithmeticCore_v2
import ARC.ARCAutomaticBridge2

set_option autoImplicit false

universe u v

/-!
# ARC5 — Stage 5K
## MSD support DFA and pumping-loop bridge

Stage 5J formalized the arithmetic of a numerical family produced by pumping
a nonempty base-5 digit block.

Stage 5K connects the ARC MSD-DFAO interface to Mathlib's ordinary DFA
pumping machinery.

The steps are:

1. turn a Boolean-output `ARCMSDDFAO 5 Bool` into an ordinary DFA whose
   accepting states are exactly the states with output `true`;
2. prove that the ordinary DFA evaluates a word to exactly the same state as
   the ARC MSD-DFAO;
3. identify its accepted language with the support language of the generated
   Boolean sequence;
4. package Mathlib's finite-state loop into a convenient theorem saying that
   a sufficiently long accepted word has a nonempty middle block which can be
   repeated any number of times and remain accepted.

This stage is deliberately still word-level.  Stage 5L will convert
`a ++ b^k ++ c` into the numerical pumped family used in Stage 5J.
-/

/-!
============================================================
1. Support DFA of a Boolean MSD-DFAO
============================================================
-/

/--
Forget the output alphabet and regard output `true` as acceptance.
-/
def ARC5MSDSupportDFA
    (M : ARCMSDDFAO 5 Bool) :
    DFA (Fin 5) M.State where
  step := M.step
  start := M.start
  accept := {q | M.output q = true}

/--
The standard DFA and the ARC MSD-DFAO use exactly the same transition
recursion.
-/
theorem arc5_msdSupportDFA_evalFrom_eq
    (M : ARCMSDDFAO 5 Bool)
    (q : M.State)
    (L : List (Fin 5)) :
    (ARC5MSDSupportDFA M).evalFrom q L
      =
    ARCMSDDFAO.eval M q L := by

  induction L generalizing q with

  | nil =>
      rfl

  | cons d ds ih =>
      rw [DFA.evalFrom_cons]
      change
        (ARC5MSDSupportDFA M).evalFrom
            (M.step q d)
            ds
          =
        ARCMSDDFAO.eval
            M
            (M.step q d)
            ds
      exact ih (M.step q d)

/--
The two machines therefore agree when started from their common start state.
-/
theorem arc5_msdSupportDFA_eval_eq
    (M : ARCMSDDFAO 5 Bool)
    (L : List (Fin 5)) :
    (ARC5MSDSupportDFA M).eval L
      =
    ARCMSDDFAO.eval M M.start L := by

  unfold DFA.eval

  exact
    arc5_msdSupportDFA_evalFrom_eq
      M
      M.start
      L

/--
A word is accepted by the support DFA exactly when the original DFAO outputs
`true` on that word.
-/
theorem arc5_msdSupportDFA_accepts_iff_output_true
    (M : ARCMSDDFAO 5 Bool)
    (L : List (Fin 5)) :
    L ∈ (ARC5MSDSupportDFA M).accepts
      ↔
    M.output
        (ARCMSDDFAO.eval M M.start L)
      =
    true := by

  rw [DFA.mem_accepts]

  change
    (ARC5MSDSupportDFA M).eval L
        ∈
      {q : M.State | M.output q = true}
      ↔
    M.output
        (ARCMSDDFAO.eval M M.start L)
      =
    true

  rw [arc5_msdSupportDFA_eval_eq]

  rfl


/-!
============================================================
2. Connection with the generated Boolean sequence
============================================================
-/

/--
The natural number represented by an MSD base-5 word, using the same
convention as `ARCMSDDFAO.Generates`.
-/
def ARC5MSDValue
    (L : List (Fin 5)) :
    ℕ :=
  Nat.ofDigits
    5
    (
      L.reverse.map
        (fun d => d.val)
    )

/--
If `M` generates `s`, then the support DFA accepts exactly the words whose
represented natural number lies in the Boolean support of `s`.
-/
theorem arc5_msdSupportDFA_accepts_iff_support
    (M : ARCMSDDFAO 5 Bool)
    (s : ℕ → Bool)
    (hM :
      ARCMSDDFAO.Generates M s)
    (L : List (Fin 5)) :
    L ∈ (ARC5MSDSupportDFA M).accepts
      ↔
    ARC5MSDValue L
      ∈
    ARC5BoolSupport s := by

  rw [arc5_msdSupportDFA_accepts_iff_output_true]

  have hgen :=
    hM L

  unfold ARC5BoolSupport
  unfold ARC5MSDValue

  rw [hgen]

  rfl


/-!
============================================================
3. Explicit repetition of a word
============================================================
-/

/--
`ARC5ListRepeat b n` is the word obtained by concatenating `b` exactly `n`
times.

We use an explicit function rather than `b ^ n`, because `List` does not
carry the multiplicative `HPow` instance expected by that notation.
-/
def ARC5ListRepeat
    {β : Type u}
    (b : List β) :
    ℕ → List β
  | 0 => []
  | n + 1 => ARC5ListRepeat b n ++ b

@[simp]
lemma arc5_listRepeat_zero
    {β : Type u}
    (b : List β) :
    ARC5ListRepeat b 0 = [] := by
  rfl

@[simp]
lemma arc5_listRepeat_succ
    {β : Type u}
    (b : List β)
    (n : ℕ) :
    ARC5ListRepeat b (n + 1)
      =
    ARC5ListRepeat b n ++ b := by
  rfl


/-!
============================================================
4. Generic DFA loop pumping
============================================================
-/

/--
If a word returns a DFA state to itself, then every power of that word does
the same.
-/
theorem arc5_dfa_evalFrom_word_pow
    {β : Type u}
    {σ : Type v}
    (M : DFA β σ)
    (q : σ)
    (b : List β)
    (hloop :
      M.evalFrom q b = q) :
    ∀ n : ℕ,
      M.evalFrom q (ARC5ListRepeat b n) = q := by

  intro n

  induction n with

  | zero =>
      simp

  | succ n ih =>
      rw [arc5_listRepeat_succ]
      rw [DFA.evalFrom_of_append]
      rw [ih]
      exact hloop

/--
Convenient pumping-loop form extracted from a sufficiently long accepted
word.

Unlike the language-theoretic statement of `DFA.pumping_lemma`, this records
the actual repeated word explicitly as `ARC5ListRepeat b n`.
-/
theorem arc5_dfa_pumping_loop
    {β : Type u}
    {σ : Type v}
    (M : DFA β σ)
    [Fintype σ]
    {x : List β}
    (hx :
      x ∈ M.accepts)
    (hlen :
      Fintype.card σ ≤ x.length) :
    ∃ a b c : List β,
      x = a ++ b ++ c
        ∧
      a.length + b.length
        ≤
      Fintype.card σ
        ∧
      b ≠ []
        ∧
      ∀ n : ℕ,
        a ++ (ARC5ListRepeat b n) ++ c
          ∈
        M.accepts := by

  have hacc :
      M.eval x ∈ M.accept := by
    exact
      (DFA.mem_accepts M).1 hx

  have hsplit :
      ∃ q : σ,
        ∃ a b c : List β,
          x = a ++ b ++ c
            ∧
          a.length + b.length
            ≤
          Fintype.card σ
            ∧
          b ≠ []
            ∧
          M.evalFrom M.start a = q
            ∧
          M.evalFrom q b = q
            ∧
          M.evalFrom q c = M.eval x := by

    exact
      M.evalFrom_split
        hlen
        (by
          rfl)

  rcases hsplit with
    ⟨q,
     a,
     b,
     c,
     hsplitWord,
     hshort,
     hbne,
     ha,
     hb,
     hc⟩

  refine
    ⟨a,
     b,
     c,
     hsplitWord,
     hshort,
     hbne,
     ?_⟩

  intro n

  rw [DFA.mem_accepts]

  unfold DFA.eval

  rw [DFA.evalFrom_of_append]
  rw [DFA.evalFrom_of_append]
  rw [ha]

  have hpow :
      M.evalFrom q (ARC5ListRepeat b n) = q :=
    arc5_dfa_evalFrom_word_pow
      M
      q
      b
      hb
      n

  rw [hpow]
  rw [hc]

  exact hacc


/-!
============================================================
5. Support-language pumping for ARC MSD-DFAO
============================================================
-/

/--
A sufficiently long support word of a Boolean ARC MSD-DFAO has a nonempty
pumpable block, and every pumped word still represents an input where the
generated Boolean sequence is `true`.
-/
theorem arc5_msd_support_word_pumping
    (M : ARCMSDDFAO 5 Bool)
    [Fintype M.State]
    (s : ℕ → Bool)
    (hM :
      ARCMSDDFAO.Generates M s)
    (x : List (Fin 5))
    (hx :
      ARC5MSDValue x
        ∈
      ARC5BoolSupport s)
    (hlen :
      Fintype.card M.State
        ≤
      x.length) :
    ∃ a b c : List (Fin 5),
      x = a ++ b ++ c
        ∧
      a.length + b.length
        ≤
      Fintype.card M.State
        ∧
      b ≠ []
        ∧
      ∀ n : ℕ,
        ARC5MSDValue
            (a ++ (ARC5ListRepeat b n) ++ c)
          ∈
        ARC5BoolSupport s := by

  have hxDFA :
      x ∈ (ARC5MSDSupportDFA M).accepts := by

    exact
      (arc5_msdSupportDFA_accepts_iff_support
        M
        s
        hM
        x).2
        hx

  rcases
    arc5_dfa_pumping_loop
      (ARC5MSDSupportDFA M)
      hxDFA
      hlen with
    ⟨a,
     b,
     c,
     hsplit,
     hshort,
     hbne,
     hpump⟩

  refine
    ⟨a,
     b,
     c,
     hsplit,
     hshort,
     hbne,
     ?_⟩

  intro n

  exact
    (arc5_msdSupportDFA_accepts_iff_support
      M
      s
      hM
      (a ++ (ARC5ListRepeat b n) ++ c)).1
      (hpump n)


/-!
============================================================
6. Stage-5K handoff
============================================================
-/

/--
Stage-5K word-level handoff.

Once a Boolean sequence is presented by an MSD-DFAO, every sufficiently long
support word produces a genuine nonempty pumpable base-5 digit block whose
all repetitions remain inside the support.

Stage 5L will calculate the natural-number value of these pumped words and
identify it with the arithmetic family from Stage 5J.
-/
theorem arc5_stage5K_word_pumping_handoff
    (M : ARCMSDDFAO 5 Bool)
    [Fintype M.State]
    (s : ℕ → Bool)
    (hM :
      ARCMSDDFAO.Generates M s) :
    ∀ x : List (Fin 5),
      ARC5MSDValue x
        ∈
      ARC5BoolSupport s
        →
      Fintype.card M.State
        ≤
      x.length
        →
      ∃ a b c : List (Fin 5),
        x = a ++ b ++ c
          ∧
        a.length + b.length
          ≤
        Fintype.card M.State
          ∧
        b ≠ []
          ∧
        ∀ n : ℕ,
          ARC5MSDValue
              (a ++ (ARC5ListRepeat b n) ++ c)
            ∈
          ARC5BoolSupport s := by

  intro x hx hlen

  exact
    arc5_msd_support_word_pumping
      M
      s
      hM
      x
      hx
      hlen


/-!
============================================================
7. Axiom audit
============================================================
-/

#print axioms arc5_msdSupportDFA_evalFrom_eq
#print axioms arc5_msdSupportDFA_accepts_iff_output_true
#print axioms arc5_msdSupportDFA_accepts_iff_support
#print axioms arc5_dfa_evalFrom_word_pow
#print axioms arc5_dfa_pumping_loop
#print axioms arc5_msd_support_word_pumping
#print axioms arc5_stage5K_word_pumping_handoff

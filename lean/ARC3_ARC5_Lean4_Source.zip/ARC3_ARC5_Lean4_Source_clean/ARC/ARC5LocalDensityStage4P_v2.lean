import Mathlib
import ARC.ARC5LocalDensityStage4O_v2

set_option autoImplicit false

/-!
# ARC5 / Local-Density audit — Stage 4P

Stage 4O supplied the last exit-side infrastructure.

This file closes the finite Local-Density argument.

Starting inside an arbitrary prescribed dyadic cylinder, Stage 4O gives a
balanced prefix pair `U,V` with constant endpoint gap

    D = z' - z.

There are three cases.

* D = 0:
    the balanced prefixes already coalesce.

* D > 0:
    attach a universal coalescing suffix for the positive gap D to the left
    balanced endpoint, and the companion suffix to the right endpoint.

* D < 0:
    do the symmetric construction from the right balanced endpoint, using
    the positive gap -D.

The resulting two full words have equal length and equal odd-step count and
coalesce at one seed.  Stage 4O then upgrades seed coalescence to uniform
coalescence on the whole final dyadic subcylinder.

The final theorem is the functional synchronized Local Density statement for
the shortcut Collatz map.
-/

/-- Odd-step count is additive under word concatenation. -/
lemma arcOnes_append
    (u v : List Bool) :
    arcOnes (u ++ v)
      =
    arcOnes u + arcOnes v := by

  induction u with
  | nil =>
      simp [arcOnes]

  | cons b u ih =>
      cases b <;>
        simp [arcOnes, ih, Nat.add_assoc]

/-- Positive integer equals the cast of its natural absolute value. -/
lemma arcNatAbs_cast_of_pos
    {D : ℤ}
    (hD : 0 < D) :
    ((D.natAbs : ℕ) : ℤ) = D := by

  have hcases :
      D = ((D.natAbs : ℕ) : ℤ)
        ∨
      D = -((D.natAbs : ℕ) : ℤ) := by
    exact
      (Int.natAbs_eq_iff).mp
        (rfl : D.natAbs = D.natAbs)

  rcases hcases with hpos | hneg

  · exact hpos.symm

  · omega

/-- For a negative integer, natAbs casts to its negation. -/
lemma arcNatAbs_cast_of_neg
    {D : ℤ}
    (hD : D < 0) :
    ((D.natAbs : ℕ) : ℤ) = -D := by

  have hcases :
      D = ((D.natAbs : ℕ) : ℤ)
        ∨
      D = -((D.natAbs : ℕ) : ℤ) := by
    exact
      (Int.natAbs_eq_iff).mp
        (rfl : D.natAbs = D.natAbs)

  rcases hcases with hpos | hneg

  · omega

  · omega

/--
Relational Local Density.

For every positive gap `N` and every prescribed parent cylinder `C(r,m)`,
there are equal-length / equal-odd-count words `W,X` and a deeper seed `s`
such that

* the entire final `W`-cylinder lies inside `C(r,m)`;
* every point in that final cylinder follows `W`;
* its translate by `N` follows `X`;
* the two endpoints are equal.

This is the word/cylinder form of synchronized Local Density.
-/
theorem arcLocalDensity_relational
    (N : ℕ)
    (hN : 0 < N)
    (m : ℕ)
    (r : ℤ) :
    ∃ W X : List Bool,
      ∃ s : ℤ,
        W.length = X.length
        ∧
        arcOnes W = arcOnes X
        ∧
        (
          ∀ x : ℤ,
            arcDyadicCylinder W.length s x
              →
            arcDyadicCylinder m r x
        )
        ∧
        (
          ∀ x : ℤ,
            arcDyadicCylinder W.length s x
              →
            ∃ y y' : ℤ,
              arcFollowsTo W x y
              ∧
              arcFollowsTo X (x + (N : ℤ)) y'
              ∧
              y = y'
        ) := by

  rcases
    arcPrescribedCylinder_steer_balanced_strong
      m
      r
      (N : ℤ) with
    ⟨A, E, U, V, s, z, z',
     hUVlen,
     hUA,
     hVA,
     hUz,
     hVz,
     hrelA,
     hParent⟩

  have hUVones :
      arcOnes U = arcOnes V := by
    rw [hUA, hVA]

  let D : ℤ := z' - z

  rcases lt_trichotomy D 0 with hDneg | hDzero | hDpos

  /- ------------------------------ D < 0 ------------------------------ -/
  · let G : ℕ := D.natAbs

    have hGpos : 0 < G := by
      dsimp [G]
      exact
        (Int.natAbs_pos).2
          (by
            intro h
            subst D
            omega)

    have hGcast :
        ((G : ℕ) : ℤ) = -D := by
      dsimp [G]
      exact arcNatAbs_cast_of_neg hDneg

    rcases
      arcUniversalCylinderCoalescence_of_seed
        G
        hGpos with
      ⟨p, q,
       hpqlen,
       hpqones,
       hcoal⟩

    -- Force the first universal suffix on the RIGHT balanced prefix.
    rcases
      arcFollowsTo_force_suffix_split
        (w := V)
        (q := p)
        hVz with
      ⟨qstart, midR, forcedEnd,
       hqParent,
       hVq,
       hpMidR,
       hVfullForced,
       hRightSubset⟩

    -- Translate back to the corresponding LEFT start and recover its
    -- balanced-prefix endpoint.
    rcases
      arcBalanced_partner_from_right
        hUVlen
        hUVones
        hUz
        hVz
        hqParent
        hVq with
      ⟨t, midL,
       htEq,
       htParent,
       hUt,
       hgap⟩

    have hmid :
        midL = midR + (G : ℤ) := by
      dsimp [D] at hgap hGcast
      rw [hGcast]
      linarith

    have hpCong :
        arcWordCongruence p midR :=
      arcFollowsTo_congruence hpMidR

    have hseed :
        arcDyadicCylinder p.length midR midR := by
      exact ⟨0, by ring⟩

    rcases
      hcoal
        midR
        hpCong
        midR
        hseed with
      ⟨ep, eq,
       hpCoal,
       hqCoal,
       heq⟩

    have hqAtLeft :
        arcFollowsTo q midL eq := by
      rw [hmid]
      exact hqCoal

    have hLeftFull :
        arcFollowsTo (U ++ q) t eq :=
      arcFollowsTo_append
        hUt
        hqAtLeft

    have hRightStart :
        qstart = t + (N : ℤ) := by
      rw [htEq]
      ring

    have hRightFull0 :
        arcFollowsTo
          (V ++ p)
          qstart
          ep :=
      arcFollowsTo_append
        hVq
        hpCoal

    have hRightFull :
        arcFollowsTo
          (V ++ p)
          (t + (N : ℤ))
          ep := by
      rw [← hRightStart]
      exact hRightFull0

    have hLeftSame :
        arcFollowsTo
          (U ++ q)
          t
          ep := by
      rw [heq]
      exact hLeftFull

    have hFinalLen :
        (U ++ q).length
          =
        (V ++ p).length := by
      simp [List.length_append, hUVlen, hpqlen]

    have hFinalOnes :
        arcOnes (U ++ q)
          =
        arcOnes (V ++ p) := by
      rw [arcOnes_append, arcOnes_append]
      rw [hUVones, hpqones]

    have hUniform :=
      arcEqualSeed_uniform_coalescence
        hFinalLen
        hFinalOnes
        hLeftSame
        hRightFull

    have hExt :
        arcWordExtends U (U ++ q) := by
      exact ⟨q, rfl⟩

    have hFinalParent :
        ∀ x : ℤ,
          arcDyadicCylinder
            (U ++ q).length
            t
            x
            →
          arcDyadicCylinder m r x := by

      intro x hx

      have hxU :
          arcDyadicCylinder
            U.length
            s
            x :=
        arcDyadicCylinder_of_word_extension
          hExt
          htParent
          hx

      exact hParent x hxU

    refine
      ⟨U ++ q,
       V ++ p,
       t,
       hFinalLen,
       hFinalOnes,
       hFinalParent,
       ?_⟩

    intro x hx
    exact hUniform x hx

  /- ------------------------------ D = 0 ------------------------------ -/
  · have hzz :
        z' = z := by
      dsimp [D] at hDzero
      linarith

    have hVzSame :
        arcFollowsTo
          V
          (s + (N : ℤ))
          z := by
      rw [← hzz]
      exact hVz

    have hUniform :=
      arcEqualSeed_uniform_coalescence
        hUVlen
        hUVones
        hUz
        hVzSame

    refine
      ⟨U, V, s,
       hUVlen,
       hUVones,
       hParent,
       ?_⟩

    intro x hx
    exact hUniform x hx

  /- ------------------------------ D > 0 ------------------------------ -/
  · let G : ℕ := D.natAbs

    have hGpos : 0 < G := by
      dsimp [G]
      exact
        (Int.natAbs_pos).2
          (by
            intro h
            subst D
            omega)

    have hGcast :
        ((G : ℕ) : ℤ) = D := by
      dsimp [G]
      exact arcNatAbs_cast_of_pos hDpos

    rcases
      arcUniversalCylinderCoalescence_of_seed
        G
        hGpos with
      ⟨p, q,
       hpqlen,
       hpqones,
       hcoal⟩

    -- Force the first universal suffix on the LEFT balanced prefix.
    rcases
      arcFollowsTo_force_suffix_split
        (w := U)
        (q := p)
        hUz with
      ⟨t, midL, forcedEnd,
       htParent,
       hUt,
       hpMidL,
       hUfullForced,
       hLeftSubset⟩

    -- The right balanced endpoint at the same refined start is the left
    -- endpoint plus the same constant gap D.
    rcases
      arcBalanced_partner_on_cylinder
        hUVlen
        hUVones
        hUz
        hVz
        htParent
        hUt with
      ⟨midR,
       hVt,
       hgap⟩

    have hmid :
        midR = midL + (G : ℤ) := by
      dsimp [D] at hgap hGcast
      rw [hGcast]
      exact hgap

    have hpCong :
        arcWordCongruence p midL :=
      arcFollowsTo_congruence hpMidL

    have hseed :
        arcDyadicCylinder p.length midL midL := by
      exact ⟨0, by ring⟩

    rcases
      hcoal
        midL
        hpCong
        midL
        hseed with
      ⟨ep, eq,
       hpCoal,
       hqCoal,
       heq⟩

    have hqAtRight :
        arcFollowsTo q midR eq := by
      rw [hmid]
      exact hqCoal

    have hLeftFull :
        arcFollowsTo
          (U ++ p)
          t
          ep :=
      arcFollowsTo_append
        hUt
        hpCoal

    have hRightFull0 :
        arcFollowsTo
          (V ++ q)
          (t + (N : ℤ))
          eq :=
      arcFollowsTo_append
        hVt
        hqAtRight

    have hRightFull :
        arcFollowsTo
          (V ++ q)
          (t + (N : ℤ))
          ep := by
      rw [heq]
      exact hRightFull0

    have hFinalLen :
        (U ++ p).length
          =
        (V ++ q).length := by
      simp [List.length_append, hUVlen, hpqlen]

    have hFinalOnes :
        arcOnes (U ++ p)
          =
        arcOnes (V ++ q) := by
      rw [arcOnes_append, arcOnes_append]
      rw [hUVones, hpqones]

    have hUniform :=
      arcEqualSeed_uniform_coalescence
        hFinalLen
        hFinalOnes
        hLeftFull
        hRightFull

    have hExt :
        arcWordExtends U (U ++ p) := by
      exact ⟨p, rfl⟩

    have hFinalParent :
        ∀ x : ℤ,
          arcDyadicCylinder
            (U ++ p).length
            t
            x
            →
          arcDyadicCylinder m r x := by

      intro x hx

      have hxU :
          arcDyadicCylinder
            U.length
            s
            x :=
        arcDyadicCylinder_of_word_extension
          hExt
          htParent
          hx

      exact hParent x hxU

    refine
      ⟨U ++ p,
       V ++ q,
       t,
       hFinalLen,
       hFinalOnes,
       hFinalParent,
       ?_⟩

    intro x hx
    exact hUniform x hx

/--
Functional synchronized Local Density for the shortcut map.

For every positive integer gap `N` and every prescribed dyadic parent
cylinder `C(r,m)`, there is a deeper dyadic cylinder `C(s,h)` such that

    T^h(x) = T^h(x+N)

for every integer `x` in the deeper cylinder, and the deeper cylinder is
contained in the prescribed parent cylinder.
-/
theorem arcLocalDensity
    (N : ℕ)
    (hN : 0 < N)
    (m : ℕ)
    (r : ℤ) :
    ∃ h : ℕ,
      ∃ s : ℤ,
        (
          ∀ x : ℤ,
            arcDyadicCylinder h s x
              →
            arcDyadicCylinder m r x
        )
        ∧
        (
          ∀ x : ℤ,
            arcDyadicCylinder h s x
              →
            arcShortcutIter h x
              =
            arcShortcutIter h (x + (N : ℤ))
        ) := by

  rcases
    arcLocalDensity_relational
      N
      hN
      m
      r with
    ⟨W, X, s,
     hlen,
     hones,
     hParent,
     hCoal⟩

  refine
    ⟨W.length,
     s,
     hParent,
     ?_⟩

  intro x hx

  rcases
    hCoal x hx with
    ⟨y, y',
     hWy,
     hXy,
     hEq⟩

  have hWIter :
      arcShortcutIter W.length x = y :=
    arcFollowsTo_shortcutIter hWy

  have hXIter :
      arcShortcutIter X.length
        (x + (N : ℤ))
        =
      y' :=
    arcFollowsTo_shortcutIter hXy

  have hXIter' :
      arcShortcutIter W.length
        (x + (N : ℤ))
        =
      y' := by
    rw [hlen]
    exact hXIter

  calc
    arcShortcutIter W.length x
        = y := hWIter
    _ = y' := hEq
    _ =
      arcShortcutIter W.length
        (x + (N : ℤ)) := hXIter'.symm

#print axioms arcNatAbs_cast_of_pos
#print axioms arcNatAbs_cast_of_neg
#print axioms arcLocalDensity_relational
#print axioms arcLocalDensity

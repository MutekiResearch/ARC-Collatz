import Mathlib
import ARC.ARC5Stage5S_TopologicalPumpingClosure

set_option autoImplicit false

universe u

/-!
# ARC5 — Stage 5T
## Automaticity of the change indicator

Define the change set

    D_a = { n | a n ≠ a (n+1) }.

The Boolean characteristic sequence of this set is

    ARC5ChangeIndicator a.

The goal of Stage 5T is to prove that finite base-5 kernel of `a` implies
finite base-5 kernel of the change indicator.

The only subtlety is the carry at the end of a base-5 residue block.

For a residual input

    5^e * n + r,

the right-hand comparison point is

    5^e * n + r + 1.

If `r+1 < 5^e`, this is another ordinary kernel residual.

If `r+1 = 5^e`, the carry gives

    5^e * (n+1),

which is the one-step successor of the zero-residue kernel state.

Therefore every kernel residual of the change indicator lies in a finite
family of disagreement indicators comparing

* one ordinary kernel state, with
* either another ordinary kernel state or the successor of one.

This is enough to prove 5-automaticity of the change indicator.
-/

/-!
============================================================
1. Change set and Boolean indicator
============================================================
-/

/--
The set of adjacent changes of `a`.
-/
def ARC5ChangeSet
    {α : Type u}
    (a : ℕ → α) :
    Set ℕ :=
  {n | a n ≠ a (n + 1)}

/--
Boolean characteristic sequence of the adjacent-change set.
-/
noncomputable def ARC5ChangeIndicator
    {α : Type u}
    (a : ℕ → α) :
    ℕ → Bool :=
  ARC5DisagreeIndicator
    a
    (fun n => a (n + 1))

/--
The change indicator is true exactly on the change set.
-/
theorem arc5_changeIndicator_true_iff
    {α : Type u}
    (a : ℕ → α)
    (n : ℕ) :
    ARC5ChangeIndicator a n = true
      ↔
    n ∈ ARC5ChangeSet a := by

  unfold ARC5ChangeIndicator
  unfold ARC5ChangeSet

  exact
    arc5_disagreeIndicator_true_iff
      a
      (fun n => a (n + 1))
      n

/--
The Boolean support of the change indicator is exactly the change set.
-/
theorem arc5_boolSupport_changeIndicator
    {α : Type u}
    (a : ℕ → α) :
    ARC5BoolSupport
        (ARC5ChangeIndicator a)
      =
    ARC5ChangeSet a := by

  ext n

  change
    ARC5ChangeIndicator a n = true
      ↔
    n ∈ ARC5ChangeSet a

  exact
    arc5_changeIndicator_true_iff
      a
      n


/-!
============================================================
2. Successors of kernel states
============================================================
-/

/--
One-step successor of a sequence.
-/
def ARC5SuccState
    {α : Type u}
    (v : ℕ → α) :
    ℕ → α :=
  fun n => v (n + 1)

/--
All one-step successors of full base-5 kernel states.
-/
def ARC5SuccKernelFamily
    {α : Type u}
    (a : ℕ → α) :
    Set (ℕ → α) :=
  (ARC5SuccState '' (ARCKernel 5 a))

/--
Ordinary kernel states together with one-step successors of kernel states.
-/
def ARC5KernelOrSuccFamily
    {α : Type u}
    (a : ℕ → α) :
    Set (ℕ → α) :=
  (ARCKernel 5 a) ∪ ARC5SuccKernelFamily a

/--
If the full base-5 kernel is finite, then its successor family is finite.
-/
theorem arc5_succKernelFamily_finite
    {α : Type u}
    (a : ℕ → α)
    (hfinite :
      (ARCKernel 5 a).Finite) :
    (ARC5SuccKernelFamily a).Finite := by

  unfold ARC5SuccKernelFamily

  exact
    hfinite.image
      ARC5SuccState

/--
The union of kernel states and successor-kernel states is finite.
-/
theorem arc5_kernelOrSuccFamily_finite
    {α : Type u}
    (a : ℕ → α)
    (hfinite :
      (ARCKernel 5 a).Finite) :
    (ARC5KernelOrSuccFamily a).Finite := by

  unfold ARC5KernelOrSuccFamily

  exact
    hfinite.union
      (arc5_succKernelFamily_finite
        a
        hfinite)


/-!
============================================================
3. Finite comparison family for change residuals
============================================================
-/

/--
Finite comparison family that will contain every base-5 kernel residual of
the change indicator.
-/
def ARC5ChangeComparisonFamily
    {α : Type u}
    (a : ℕ → α) :
    Set (ℕ → Bool) :=
  Set.image2
    (fun x y : ℕ → α =>
      ARC5DisagreeIndicator x y)
    (ARCKernel 5 a)
    (ARC5KernelOrSuccFamily a)

/--
The comparison family is finite whenever the full base-5 kernel of `a` is
finite.
-/
theorem arc5_changeComparisonFamily_finite
    {α : Type u}
    (a : ℕ → α)
    (hfinite :
      (ARCKernel 5 a).Finite) :
    (ARC5ChangeComparisonFamily a).Finite := by

  unfold ARC5ChangeComparisonFamily

  exact
    Set.Finite.image2
      (fun x y : ℕ → α =>
        ARC5DisagreeIndicator x y)
      hfinite
      (arc5_kernelOrSuccFamily_finite
        a
        hfinite)


/-!
============================================================
4. Every change residual belongs to the finite family
============================================================
-/

/--
Every base-5 kernel residual of the change indicator is a disagreement
indicator between

* an ordinary kernel state, and
* either an ordinary kernel state or a successor of one.

The second case is exactly the base-5 carry case.
-/
theorem arc5_changeIndicator_kernel_subset_family
    {α : Type u}
    (a : ℕ → α) :
    ARCKernel 5
        (ARC5ChangeIndicator a)
      ⊆
    ARC5ChangeComparisonFamily a := by

  intro u hu

  change
    ∃ e r : ℕ,
      r < 5 ^ e
        ∧
      ∀ n : ℕ,
        u n =
          ARC5ChangeIndicator a
            (5 ^ e * n + r)
    at hu

  rcases hu with
    ⟨e, r, hr, huEq⟩

  let x : ℕ → α :=
    fun n =>
      a (5 ^ e * n + r)

  let y : ℕ → α :=
    fun n =>
      a (5 ^ e * n + r + 1)

  have hx :
      x ∈ ARCKernel 5 a := by

    change
      ∃ E R : ℕ,
        R < 5 ^ E
          ∧
        ∀ n : ℕ,
          x n =
            a (5 ^ E * n + R)

    refine
      ⟨e, r, hr, ?_⟩

    intro n
    rfl

  have hy :
      y ∈ ARC5KernelOrSuccFamily a := by

    unfold ARC5KernelOrSuccFamily

    by_cases hnext :
        r + 1 < 5 ^ e

    · left

      change
        ∃ E R : ℕ,
          R < 5 ^ E
            ∧
          ∀ n : ℕ,
            y n =
              a (5 ^ E * n + R)

      refine
        ⟨e, r + 1, hnext, ?_⟩

      intro n

      dsimp [y]

      congr 1

    · right

      have hedge :
          r + 1 = 5 ^ e := by

        have hpowpos :
            0 < 5 ^ e := by
          positivity

        omega

      let z : ℕ → α :=
        fun n =>
          a (5 ^ e * n)

      have hz :
          z ∈ ARCKernel 5 a := by

        change
          ∃ E R : ℕ,
            R < 5 ^ E
              ∧
            ∀ n : ℕ,
              z n =
                a (5 ^ E * n + R)

        refine
          ⟨e, 0, ?_, ?_⟩

        · positivity

        · intro n
          simp [z]

      unfold ARC5SuccKernelFamily

      refine
        ⟨z, hz, ?_⟩

      funext n

      dsimp [ARC5SuccState, y, z]

      congr 1

      calc
        5 ^ e * (n + 1)
            =
        5 ^ e * n + 5 ^ e := by
          ring

        _ =
        5 ^ e * n + (r + 1) := by
          rw [hedge]

        _ =
        5 ^ e * n + r + 1 := by
          omega

  unfold ARC5ChangeComparisonFamily

  refine
    ⟨x,
     hx,
     y,
     hy,
     ?_⟩

  funext n

  have h :=
    huEq n

  simpa
    [ARC5ChangeIndicator,
     ARC5SuccState,
     x,
     y,
     ARC5DisagreeIndicator]
    using h.symm


/-!
============================================================
5. Change indicator is 5-automatic
============================================================
-/

/--
Finite full base-5 kernel of `a` implies finite base-5 kernel of its adjacent
change indicator.
-/
theorem arc5_changeIndicator_kernel_finite
    {α : Type u}
    (a : ℕ → α)
    (hfinite :
      (ARCKernel 5 a).Finite) :
    (ARCKernel 5
      (ARC5ChangeIndicator a)).Finite := by

  exact
    (arc5_changeComparisonFamily_finite
      a
      hfinite).subset
        (arc5_changeIndicator_kernel_subset_family
          a)

/--
Automaticity wrapper for the adjacent-change indicator.
-/
theorem arc5_changeIndicator_automatic
    {α : Type u}
    (a : ℕ → α)
    (ha5 :
      ARCAutomaticByKernel 5 a) :
    ARCAutomaticByKernel
      5
      (ARC5ChangeIndicator a) := by

  unfold ARCAutomaticByKernel at ha5 ⊢

  exact
    arc5_changeIndicator_kernel_finite
      a
      ha5


/-!
============================================================
6. Once thinness is supplied, Stage 5S makes the change set finite
============================================================
-/

/--
If the adjacent-change set is dyadically nowhere thick, then under finite
base-5 kernel it is finite.

Stage 5U will discharge the thinness hypothesis using Strong Dyadic CPS.
-/
theorem arc5_changeSet_finite_of_nowhereThick
    {α : Type u}
    (a : ℕ → α)
    (ha5 :
      ARCAutomaticByKernel 5 a)
    (hthin :
      ARC5DyadicallyNowhereThick
        (ARC5ChangeSet a)) :
    (ARC5ChangeSet a).Finite := by

  have hAuto :
      ARCAutomaticByKernel
        5
        (ARC5ChangeIndicator a) :=
    arc5_changeIndicator_automatic
      a
      ha5

  have hSupportEq :
      ARC5BoolSupport
          (ARC5ChangeIndicator a)
        =
      ARC5ChangeSet a :=
    arc5_boolSupport_changeIndicator
      a

  have hThinSupport :
      ARC5DyadicallyNowhereThick
        (ARC5BoolSupport
          (ARC5ChangeIndicator a)) := by

    simpa [hSupportEq] using hthin

  have hFiniteSupport :
      (ARC5BoolSupport
        (ARC5ChangeIndicator a)).Finite :=
    arc5_stage5S_topological_pumping_principle
      (ARC5ChangeIndicator a)
      hAuto
      hThinSupport

  simpa [hSupportEq] using hFiniteSupport


/-!
============================================================
7. Stage-5T handoff
============================================================
-/

/--
Stage-5T handoff:

the adjacent-change indicator of every base-5 automatic sequence is itself
base-5 automatic, and its support is exactly the adjacent-change set.
-/
theorem arc5_stage5T_change_automaticity
    {α : Type u}
    (a : ℕ → α)
    (ha5 :
      ARCAutomaticByKernel 5 a) :
    ARCAutomaticByKernel
        5
        (ARC5ChangeIndicator a)
      ∧
    ARC5BoolSupport
        (ARC5ChangeIndicator a)
      =
    ARC5ChangeSet a := by

  constructor

  · exact
      arc5_changeIndicator_automatic
        a
        ha5

  · exact
      arc5_boolSupport_changeIndicator
        a


/-!
============================================================
8. Axiom audit
============================================================
-/

#print axioms arc5_changeIndicator_true_iff
#print axioms arc5_boolSupport_changeIndicator
#print axioms arc5_succKernelFamily_finite
#print axioms arc5_kernelOrSuccFamily_finite
#print axioms arc5_changeComparisonFamily_finite
#print axioms arc5_changeIndicator_kernel_subset_family
#print axioms arc5_changeIndicator_kernel_finite
#print axioms arc5_changeIndicator_automatic
#print axioms arc5_changeSet_finite_of_nowhereThick
#print axioms arc5_stage5T_change_automaticity

import Mathlib
import Mathlib.Data.Nat.ModEq
import ARC.ARC5Stage5P_DyadicChildFilling_v2

set_option autoImplicit false

/-!
# ARC5 — Stage 5Q
## Collision of dyadic child filling with nowhere-thin support

Stage 5P proved that a pumped family whose increment has the form

    d = 2^s * (2*v+1)

hits every canonical dyadic child of its parent cylinder

    n ≡ N0 [MOD 2^s].

Stage 5Q makes this collide directly with

    ARC5DyadicallyNowhereThick S.

There are two ingredients.

1. Child completeness:
   every point of the parent cylinder belongs to one of our canonical
   relative-depth `R` children.

2. Nowhere-thick collision:
   the empty cylinder supplied by `ARC5DyadicallyNowhereThick` contains a
   positive point.  Refine that point to a still deeper canonical child.
   Stage 5P puts a pumped support point in that child, hence also in the
   allegedly empty cylinder — contradiction.

This stage assumes that a sufficiently long canonical positive support word
has already been supplied.  The remaining later task is therefore the
"infinite support -> sufficiently long canonical support word" bridge.
-/

/-!
============================================================
1. Every parent point belongs to a canonical deeper child
============================================================
-/

/--
Every natural number in the parent cylinder

    n ≡ N0 [MOD 2^s]

belongs, at every relative depth `R`, to one of the canonical children

    N0 + 2^s * r,   r < 2^R,

modulo `2^(s+R)`.
-/
theorem arc5_parent_point_has_canonical_child
    (N0 s R n : ℕ)
    (hnParent :
      n ≡ N0 [MOD 2 ^ s]) :
    ∃ r : Fin (2 ^ R),
      n
        ≡
      ARC5DyadicChildRepresentative
          N0
          s
          R
          r
        [MOD 2 ^ (s + R)] := by

  let D : ℕ :=
    2 ^ (s + R)

  let A : ℕ :=
    n + D * N0

  have hDpos :
      0 < D := by
    simp [D]

  have hDone :
      1 ≤ D := by
    omega

  have hN0mul :
      N0 ≤ D * N0 := by

    have h :=
      Nat.mul_le_mul_right
        N0
        hDone

    simpa using h

  have hN0A :
      N0 ≤ A := by

    dsimp [A]

    omega

  have hzero :
      D * N0
        ≡
      0
        [MOD 2 ^ s] := by

    have hz :
        (2 ^ s) * ((2 ^ R) * N0) + 0
          ≡
        0
          [MOD 2 ^ s] :=
      Nat.ModEq.modulus_mul_add

    simpa [D, pow_add, Nat.mul_assoc] using hz

  have hAParent :
      A
        ≡
      N0
        [MOD 2 ^ s] := by

    have hadd :=
      hnParent.add
        hzero

    simpa [A] using hadd

  have hN0Amod :
      N0
        ≡
      A
        [MOD 2 ^ s] :=
    hAParent.symm

  rcases
    (Nat.modEq_iff_exists_eq_add hN0A).mp
      hN0Amod with
    ⟨q, hAq⟩

  let r : Fin (2 ^ R) :=
    ⟨
      q % (2 ^ R),
      Nat.mod_lt
        q
        (Nat.two_pow_pos R)
    ⟩

  refine
    ⟨r, ?_⟩

  have hq :
      q
        ≡
      q % (2 ^ R)
        [MOD 2 ^ R] :=

    (Nat.mod_modEq
      q
      (2 ^ R)).symm

  have hscaledRaw :
      (2 ^ s) * q
        ≡
      (2 ^ s) * (q % (2 ^ R))
        [MOD (2 ^ s) * (2 ^ R)] :=

    Nat.ModEq.mul_left'
      (2 ^ s)
      hq

  have hscaled :
      (2 ^ s) * q
        ≡
      (2 ^ s) * (q % (2 ^ R))
        [MOD D] := by

    simpa [D, pow_add] using hscaledRaw

  have hchildRaw :
      N0 + (2 ^ s) * q
        ≡
      N0 + (2 ^ s) * (q % (2 ^ R))
        [MOD D] :=

    Nat.ModEq.add_left
      N0
      hscaled

  have hAchild :
      A
        ≡
      ARC5DyadicChildRepresentative
          N0
          s
          R
          r
        [MOD D] := by

    rw [hAq]

    simpa
      [ARC5DyadicChildRepresentative, r]
      using hchildRaw

  have hAn :
      A
        ≡
      n
        [MOD D] := by

    have hbase :
        D * N0 + n
          ≡
        n
          [MOD D] :=
      Nat.ModEq.modulus_mul_add

    simpa [A, Nat.add_comm] using hbase

  have hnA :
      n
        ≡
      A
        [MOD D] :=
    hAn.symm

  exact
    hnA.trans
      hAchild


/-!
============================================================
2. A deeper canonical child stays inside any shallower cylinder
============================================================
-/

/--
If two points agree modulo `2^(s+M)`, then they agree modulo `2^M`.
-/
theorem arc5_deep_dyadic_congruence_descends
    (s M : ℕ)
    {a b : ℕ}
    (h :
      a ≡ b [MOD 2 ^ (s + M)]) :
    a ≡ b [MOD 2 ^ M] := by

  have hdvd :
      2 ^ M ∣ 2 ^ (s + M) := by

    refine
      ⟨2 ^ s, ?_⟩

    rw [pow_add]

    ring

  exact
    Nat.ModEq.of_dvd
      hdvd
      h


/-!
============================================================
3. Stage-5P filling contradicts nowhere-thick
============================================================
-/

/--
A pumped family contained in `S` and filling all children of its parent
cylinder is incompatible with `ARC5DyadicallyNowhereThick S`.
-/
theorem arc5_child_filling_not_nowhereThick
    (S : Set ℕ)
    (N0 d L s v : ℕ)
    (hd :
      d = 2 ^ s * (2 * v + 1))
    (hpump :
      ∀ k : ℕ,
        ARC5PumpedFamily
            N0
            d
            L
            k
          ∈
        S) :
    ¬ ARC5DyadicallyNowhereThick S := by

  intro hthin

  rcases
    hthin
      s
      N0 with
    ⟨M,
     t,
     hinside,
     hpositive,
     hempty⟩

  rcases
    hpositive with
    ⟨n,
     hnpos,
     hnt⟩

  have hnParent :
      n ≡ N0 [MOD 2 ^ s] :=
    hinside
      n
      hnt

  rcases
    arc5_parent_point_has_canonical_child
      N0
      s
      M
      n
      hnParent with
    ⟨r, hnChild⟩

  rcases
    arc5_pumpedFamily_hits_every_child_of_exact_two_factor
      N0
      d
      L
      s
      v
      M
      hd
      r with
    ⟨k, hkChild⟩

  have hPumpNDeep :
      ARC5PumpedFamily
          N0
          d
          L
          k.val
        ≡
      n
        [MOD 2 ^ (s + M)] :=

    hkChild.trans
      hnChild.symm

  have hPumpN :
      ARC5PumpedFamily
          N0
          d
          L
          k.val
        ≡
      n
        [MOD 2 ^ M] :=

    arc5_deep_dyadic_congruence_descends
      s
      M
      hPumpNDeep

  have hPumpT :
      ARC5PumpedFamily
          N0
          d
          L
          k.val
        ≡
      t
        [MOD 2 ^ M] :=

    hPumpN.trans
      hnt

  have hnotmem :
      ARC5PumpedFamily
          N0
          d
          L
          k.val
        ∉
      S :=

    hempty
      (ARC5PumpedFamily
        N0
        d
        L
        k.val)
      hPumpT

  exact
    hnotmem
      (hpump k.val)


/-!
============================================================
4. Automatic-support version from one long canonical support word
============================================================
-/

/--
A single sufficiently long canonical positive support word already contradicts
dyadic nowhere-thickness.

This theorem combines:

* Stage 5N:
  extraction of a positive pump with exact two-factorization;
* Stage 5P:
  filling of all deeper dyadic children;
* the Stage-5Q collision theorem above.

The only remaining global bridge is to obtain such a long canonical word from
an infinite automatic support.
-/
theorem arc5_long_canonical_support_word_not_nowhereThick
    (M : ARCMSDDFAO 5 Bool)
    [Fintype M.State]
    (sseq : ℕ → Bool)
    (hM :
      ARCMSDDFAO.Generates M sseq)
    (x : List (Fin 5))
    (hxCanonical :
      ARC5CanonicalPositiveMSDWord x)
    (hx :
      ARC5MSDValue x
        ∈
      ARC5BoolSupport sseq)
    (hlen :
      Fintype.card M.State
        ≤
      x.length) :
    ¬
      ARC5DyadicallyNowhereThick
        (ARC5BoolSupport sseq) := by

  rcases
    arc5_stage5N_exact_dyadic_pumping_handoff
      M
      sseq
      hM
      x
      hxCanonical
      hx
      hlen with
    ⟨a,
     b,
     c,
     s,
     v,
     hsplit,
     hshort,
     hbne,
     hblen,
     hinc,
     hfactor,
     hpump,
     hvalue,
     hdyadic⟩

  exact
    arc5_child_filling_not_nowhereThick
      (ARC5BoolSupport sseq)
      (ARC5MSDValue (a ++ c))
      (ARC5WordPumpIncrement a b c)
      b.length
      s
      v
      hfactor
      hpump


/-!
============================================================
5. Stage-5Q handoff
============================================================
-/

/--
Stage-5Q handoff:

a Boolean MSD automatic presentation together with one sufficiently long
canonical positive support word forces failure of dyadic nowhere-thickness.
-/
theorem arc5_stage5Q_long_word_collision
    (M : ARCMSDDFAO 5 Bool)
    [Fintype M.State]
    (sseq : ℕ → Bool)
    (hM :
      ARCMSDDFAO.Generates M sseq)
    (x : List (Fin 5))
    (hxCanonical :
      ARC5CanonicalPositiveMSDWord x)
    (hx :
      ARC5MSDValue x
        ∈
      ARC5BoolSupport sseq)
    (hlen :
      Fintype.card M.State
        ≤
      x.length) :
    ¬
      ARC5DyadicallyNowhereThick
        (ARC5BoolSupport sseq) := by

  exact
    arc5_long_canonical_support_word_not_nowhereThick
      M
      sseq
      hM
      x
      hxCanonical
      hx
      hlen


/-!
============================================================
6. Axiom audit
============================================================
-/

#print axioms arc5_parent_point_has_canonical_child
#print axioms arc5_deep_dyadic_congruence_descends
#print axioms arc5_child_filling_not_nowhereThick
#print axioms arc5_long_canonical_support_word_not_nowhereThick
#print axioms arc5_stage5Q_long_word_collision

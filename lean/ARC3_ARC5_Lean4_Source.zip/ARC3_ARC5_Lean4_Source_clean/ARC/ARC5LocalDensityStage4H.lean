import Mathlib
import ARC.ARC5LocalDensityStage4G

set_option autoImplicit false

/-!
# ARC5 / Local-Density audit — Stage 4H

Stage 4G established the two well-founded arithmetic measures used by
steering.  This file packages them into a complete one-step progress
classification for every *unbalanced* exponent state.

Recall the scaled relation parameters

    (a,b,B)

correspond to

    3^a y' = 3^b y + B.

When `a != b`, exactly the following steering logic is available:

1. `B = 0`:
   perform the 11 kick.  Both exponents rise together, so the imbalance is
   unchanged, but the new offset is nonzero.

2. `B != 0` and `B` even:
   perform 00.  The exponent imbalance is unchanged and `|B|` strictly
   decreases.

3. `B` odd:
   if `a < b`, perform 10;
   if `b < a`, perform 01.
   In either case the exponent imbalance strictly decreases.

This is the arithmetic control table that the finite termination proof will
iterate in the next stage.
-/

/--
00 parameter progress:
a nonzero even offset can be halved, and its absolute-value measure strictly
decreases.
-/
theorem arcParamProgress00
    {B : ℤ}
    (hEven : Even B)
    (hB0 : B ≠ 0) :
    ∃ C : ℤ,
      B = 2 * C
      ∧
      C.natAbs < B.natAbs := by

  rcases arcOffset00_exists hEven with
    ⟨C, hBC⟩

  refine ⟨C, hBC, ?_⟩

  exact
    arcEvenHalf_natAbs_lt
      hBC
      hB0

/--
10 parameter progress:
for an odd offset and `a < b`, the required integer next offset exists and
the exponent imbalance strictly decreases.
-/
theorem arcParamProgress10
    {a b : ℕ}
    {B : ℤ}
    (hOdd : Odd B)
    (hab : a < b) :
    ∃ C : ℤ,
      2 * C
        =
      3 * B - (3 : ℤ) ^ b
      ∧
      arcImbalance (a + 1) b
        <
      arcImbalance a b := by

  rcases arcOffset10_exists hOdd with
    ⟨C, hC⟩

  exact
    ⟨C,
     hC,
     arcImbalance_step10_lt hab⟩

/--
01 parameter progress:
for an odd offset and `b < a`, the required integer next offset exists and
the exponent imbalance strictly decreases.
-/
theorem arcParamProgress01
    {a b : ℕ}
    {B : ℤ}
    (hOdd : Odd B)
    (hba : b < a) :
    ∃ C : ℤ,
      2 * C
        =
      3 * B + (3 : ℤ) ^ a
      ∧
      arcImbalance a (b + 1)
        <
      arcImbalance a b := by

  rcases arcOffset01_exists hOdd with
    ⟨C, hC⟩

  exact
    ⟨C,
     hC,
     arcImbalance_step01_lt hba⟩

/--
11 zero-offset kick:
if the exponents differ, an integer offset exists after raising both
exponents by one; it is nonzero, while the imbalance is unchanged.
-/
theorem arcParamProgress11_zero
    {a b : ℕ}
    (hab : a ≠ b) :
    ∃ D : ℤ,
      2 * D
        =
      (3 : ℤ) ^ (a + 1)
        - (3 : ℤ) ^ (b + 1)
      ∧
      D ≠ 0
      ∧
      arcImbalance (a + 1) (b + 1)
        =
      arcImbalance a b := by

  rcases arcOffset11_zero_exists
      (a + 1)
      (b + 1) with
    ⟨D, hD⟩

  have hD0 : D ≠ 0 :=
    arcZeroKick_nonzero
      hab
      hD

  refine
    ⟨D,
     hD,
     hD0,
     ?_⟩

  exact
    arcImbalance_succ_succ a b

/--
A non-even integer is odd.
-/
lemma arcOdd_of_not_even
    {B : ℤ}
    (h : ¬ Even B) :
    Odd B := by

  exact
    (Int.not_even_iff_odd).mp h

/--
Complete arithmetic progress classification for every unbalanced state.

The four disjuncts correspond to:
  * zero-offset 11 kick;
  * nonzero-even 00 halving;
  * odd-offset 10 when `a < b`;
  * odd-offset 01 when `b < a`.

No Collatz conjecture or orbit-growth statement is involved: this is a finite
integer-arithmetic steering lemma.
-/
theorem arcParamProgress_classify
    {a b : ℕ}
    {B : ℤ}
    (hab : a ≠ b) :
    (
      B = 0
      ∧
      ∃ D : ℤ,
        2 * D
          =
        (3 : ℤ) ^ (a + 1)
          - (3 : ℤ) ^ (b + 1)
        ∧
        D ≠ 0
        ∧
        arcImbalance (a + 1) (b + 1)
          =
        arcImbalance a b
    )
    ∨
    (
      B ≠ 0
      ∧
      Even B
      ∧
      ∃ C : ℤ,
        B = 2 * C
        ∧
        C.natAbs < B.natAbs
    )
    ∨
    (
      Odd B
      ∧
      a < b
      ∧
      ∃ C : ℤ,
        2 * C
          =
        3 * B - (3 : ℤ) ^ b
        ∧
        arcImbalance (a + 1) b
          <
        arcImbalance a b
    )
    ∨
    (
      Odd B
      ∧
      b < a
      ∧
      ∃ C : ℤ,
        2 * C
          =
        3 * B + (3 : ℤ) ^ a
        ∧
        arcImbalance a (b + 1)
          <
        arcImbalance a b
    ) := by

  by_cases hB0 : B = 0

  · left

    refine
      ⟨hB0, ?_⟩

    exact
      arcParamProgress11_zero hab

  · by_cases hEven : Even B

    · right
      left

      refine
        ⟨hB0,
         hEven,
         ?_⟩

      exact
        arcParamProgress00
          hEven
          hB0

    · have hOdd : Odd B :=
        arcOdd_of_not_even hEven

      have horder :
          a < b ∨ b < a := by
        omega

      rcases horder with hablt | hbalt

      · right
        right
        left

        refine
          ⟨hOdd,
           hablt,
           ?_⟩

        exact
          arcParamProgress10
            hOdd
            hablt

      · right
        right
        right

        refine
          ⟨hOdd,
           hbalt,
           ?_⟩

        exact
          arcParamProgress01
            hOdd
            hbalt

#print axioms arcParamProgress00
#print axioms arcParamProgress10
#print axioms arcParamProgress01
#print axioms arcParamProgress11_zero
#print axioms arcParamProgress_classify

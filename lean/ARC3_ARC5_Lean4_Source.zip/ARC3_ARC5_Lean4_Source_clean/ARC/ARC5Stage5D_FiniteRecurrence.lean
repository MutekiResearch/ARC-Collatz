import Mathlib
import ARC.ARC5Stage5C_TransitionGraph

set_option autoImplicit false

universe u v

/-!
# ARC5 — Stage 5D
## Finite-state recurrence

Stage 5C constructed the finite base-5 kernel transition graph.

Stage 5D isolates the pure finite-state consequence:

* any infinite sequence taking values in a finite set repeats a state;
* therefore, repeatedly reading one fixed base-5 digit from any kernel state
  eventually revisits a previous kernel state;
* because the fixed-digit transition is deterministic, the state orbit is
  periodic from that point onward.

No CPS5 argument is used in this file yet.  This is the recurrence component
that will be combined with the uniform synchronization theorem later.
-/

/-!
============================================================
1. A generic finite-state pigeonhole lemma
============================================================
-/

/--
An infinite sequence taking values in a finite set must repeat a state.

The proof uses `|S| + 1` initial states and the ordinary finite pigeonhole
principle via cardinality.
-/
theorem arc_finite_set_recurrence
    {β : Type v}
    (S : Set β)
    (hS : S.Finite)
    (f : ℕ → β)
    (hf :
      ∀ n : ℕ,
        f n ∈ S) :
    ∃ i j : ℕ,
      i < j
        ∧
      f i = f j := by

  classical

  letI : Fintype S :=
    hS.fintype

  let N : ℕ :=
    Fintype.card S

  let g :
      Fin (N + 1) → S :=
    fun i =>
      ⟨f i.val,
       hf i.val⟩

  have hnotinj :
      ¬ Function.Injective g := by

    intro hinj

    have hle :
        Fintype.card (Fin (N + 1))
          ≤
        Fintype.card S :=
      Fintype.card_le_of_injective
        g
        hinj

    simpa [N] using hle

  have hpair :
      ∃ x y : Fin (N + 1),
        x ≠ y
          ∧
        g x = g y := by

    by_contra hnone

    apply hnotinj

    intro x y hxy

    by_contra hne

    exact
      hnone
        ⟨x,
         y,
         hne,
         hxy⟩

  rcases hpair with
    ⟨x, y, hxy, hg⟩

  have hfxy :
      f x.val = f y.val := by
    exact
      congrArg
        Subtype.val
        hg

  rcases lt_or_gt_of_ne hxy with
    hlt | hgt

  · exact
      ⟨x.val,
       y.val,
       hlt,
       hfxy⟩

  · exact
      ⟨y.val,
       x.val,
       hgt,
       hfxy.symm⟩


/-!
============================================================
2. Fixed-digit state orbit
============================================================
-/

/--
Repeatedly read the same base-5 digit `d`.
-/
def ARC5FixedDigitOrbit
    {α : Type u}
    (d : ℕ)
    (v : ℕ → α) :
    ℕ → (ℕ → α)
  | 0 =>
      v
  | n + 1 =>
      ARC5DigitResidual
        d
        (ARC5FixedDigitOrbit d v n)

/--
Successor equation for the fixed-digit orbit.
-/
lemma arc5_fixedDigitOrbit_succ
    {α : Type u}
    (d : ℕ)
    (v : ℕ → α)
    (n : ℕ) :
    ARC5FixedDigitOrbit d v (n + 1)
      =
    ARC5DigitResidual
      d
      (ARC5FixedDigitOrbit d v n) := by
  rfl

/--
If the starting state belongs to the full 5-kernel and `d < 5`, every state
on the fixed-digit orbit remains in the full 5-kernel.
-/
theorem arc5_fixedDigitOrbit_mem_kernel
    {α : Type u}
    (a : ℕ → α)
    {d : ℕ}
    {v : ℕ → α}
    (hd : d < 5)
    (hv :
      v ∈ ARCKernel 5 a) :
    ∀ n : ℕ,
      ARC5FixedDigitOrbit d v n
        ∈
      ARCKernel 5 a := by

  intro n

  induction n with

  | zero =>
      simpa [ARC5FixedDigitOrbit] using hv

  | succ n ih =>
      rw [arc5_fixedDigitOrbit_succ]

      exact
        arc5_digitResidual_kernel_closed
          a
          hd
          ih


/-!
============================================================
3. Recurrence in the finite 5-kernel
============================================================
-/

/--
For a finite 5-kernel, every fixed-digit orbit starting inside the kernel
revisits a previous state.
-/
theorem arc5_fixedDigitOrbit_recurrence
    {α : Type u}
    (a : ℕ → α)
    {d : ℕ}
    {v : ℕ → α}
    (hd : d < 5)
    (hv :
      v ∈ ARCKernel 5 a)
    (hfinite :
      (ARCKernel 5 a).Finite) :
    ∃ i j : ℕ,
      i < j
        ∧
      ARC5FixedDigitOrbit d v i
        =
      ARC5FixedDigitOrbit d v j := by

  exact
    arc_finite_set_recurrence
      (ARCKernel 5 a)
      hfinite
      (ARC5FixedDigitOrbit d v)
      (arc5_fixedDigitOrbit_mem_kernel
        a
        hd
        hv)


/-!
============================================================
4. Deterministic propagation of a repeated state
============================================================
-/

/--
Once two times on the same fixed-digit orbit have the same state, applying
the same digit repeatedly preserves equality forever.
-/
theorem arc5_fixedDigitOrbit_eq_propagates
    {α : Type u}
    (d : ℕ)
    (v : ℕ → α)
    {i j : ℕ}
    (hij :
      ARC5FixedDigitOrbit d v i
        =
      ARC5FixedDigitOrbit d v j) :
    ∀ t : ℕ,
      ARC5FixedDigitOrbit d v (i + t)
        =
      ARC5FixedDigitOrbit d v (j + t) := by

  intro t

  induction t with

  | zero =>
      simpa using hij

  | succ t ih =>
      rw [Nat.add_succ, Nat.add_succ]
      rw [arc5_fixedDigitOrbit_succ]
      rw [arc5_fixedDigitOrbit_succ]
      rw [ih]


/--
Finite-state recurrence can be packaged as eventual periodicity of the
fixed-digit state orbit.

There exist a preperiod index `i` and a positive period `p` such that the
kernel state at time `i+t` equals the state at time `i+p+t` for every `t`.
-/
theorem arc5_fixedDigitOrbit_eventually_periodic
    {α : Type u}
    (a : ℕ → α)
    {d : ℕ}
    {v : ℕ → α}
    (hd : d < 5)
    (hv :
      v ∈ ARCKernel 5 a)
    (hfinite :
      (ARCKernel 5 a).Finite) :
    ∃ i p : ℕ,
      0 < p
        ∧
      ∀ t : ℕ,
        ARC5FixedDigitOrbit d v (i + t)
          =
        ARC5FixedDigitOrbit d v (i + p + t) := by

  rcases
    arc5_fixedDigitOrbit_recurrence
      a
      hd
      hv
      hfinite with
    ⟨i, j, hij, hstate⟩

  let p : ℕ :=
    j - i

  have hp :
      0 < p := by
    dsimp [p]
    omega

  have hj :
      j = i + p := by
    dsimp [p]
    omega

  refine
    ⟨i,
     p,
     hp,
     ?_⟩

  intro t

  have hprop :=
    arc5_fixedDigitOrbit_eq_propagates
      d
      v
      hstate
      t

  rw [hj] at hprop

  simpa [Nat.add_assoc] using hprop


/-!
============================================================
5. Automatic-sequence specialization
============================================================
-/

/--
For every 5-automatic sequence in finite-kernel form, every fixed base-5
digit transition orbit from every kernel state is eventually periodic at
the level of kernel states.
-/
theorem arc5_stage5D_fixed_digit_state_recurrence
    {α : Type u}
    (a : ℕ → α)
    (ha5 :
      ARCAutomaticByKernel 5 a) :
    ∀ v : ℕ → α,
      v ∈ ARCKernel 5 a
        →
      ∀ d : Fin 5,
        ∃ i p : ℕ,
          0 < p
            ∧
          ∀ t : ℕ,
            ARC5FixedDigitOrbit d.val v (i + t)
              =
            ARC5FixedDigitOrbit d.val v (i + p + t) := by

  have hfinite :
      (ARCKernel 5 a).Finite := by
    simpa [ARCAutomaticByKernel] using ha5

  intro v hv d

  exact
    arc5_fixedDigitOrbit_eventually_periodic
      a
      d.isLt
      hv
      hfinite


/--
Combined Stage-5C + Stage-5D package under the ARC5 hypotheses.

We retain the uniform CPS synchronization from Stage 5B and add eventual
recurrence for every fixed digit orbit in the finite 5-kernel graph.
-/
theorem arc5_stage5D_recurrence_with_uniform_cps
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha5 :
      ARCAutomaticByKernel 5 a) :
    ARC5LevelBlockSync a
      ∧
    (
      ∀ v : ℕ → α,
        v ∈ ARCKernel 5 a
          →
        ∀ d : Fin 5,
          ∃ i p : ℕ,
            0 < p
              ∧
            ∀ t : ℕ,
              ARC5FixedDigitOrbit d.val v (i + t)
                =
              ARC5FixedDigitOrbit d.val v (i + p + t)
    ) := by

  have hC :=
    arc5_stage5C_finite_graph_with_uniform_cps
      a
      hinv
      ha5

  rcases hC with
    ⟨_hfinite,
     _hclosed,
     huniform⟩

  refine
    ⟨huniform,
     ?_⟩

  exact
    arc5_stage5D_fixed_digit_state_recurrence
      a
      ha5


/-!
============================================================
6. Axiom audit
============================================================
-/

#print axioms arc_finite_set_recurrence
#print axioms arc5_fixedDigitOrbit_mem_kernel
#print axioms arc5_fixedDigitOrbit_recurrence
#print axioms arc5_fixedDigitOrbit_eq_propagates
#print axioms arc5_fixedDigitOrbit_eventually_periodic
#print axioms arc5_stage5D_fixed_digit_state_recurrence
#print axioms arc5_stage5D_recurrence_with_uniform_cps

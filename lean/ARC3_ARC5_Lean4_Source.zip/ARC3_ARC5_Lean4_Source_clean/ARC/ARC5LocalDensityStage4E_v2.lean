import Mathlib
import ARC.ARC5LocalDensityStage4D_v2

set_option autoImplicit false

/-!
# ARC5 / Local-Density audit — Stage 4E

Stage 4D proved that, inside one realized dyadic word-cylinder, the endpoint
parity can be chosen freely by moving to one of the two child cylinders.

For Local Density we must do this simultaneously for the two translated
starts `x` and `x+N`.

The natural scaled relation for two equal-length realized words `u,v` is

    3^(ones u) * y' = 3^(ones v) * y + B.

If the common start parameter is shifted by one parent modulus `2^L * t`,
the two endpoints shift by

    y  -> y  + 3^(ones u) * t,
    y' -> y' + 3^(ones v) * t.

The scaled relation is therefore unchanged, because the extra cross-terms are
the same product `3^(ones u) * 3^(ones v) * t`.

This file proves that paired-shift invariance and then packages the two local
refinements:
  * refine the parent cylinder so that the left endpoint is even;
  * refine it so that the left endpoint is odd;
while preserving both realized parent words and the same scaled relation.
-/

/--
The scaled relation is invariant under the common endpoint shifts naturally
induced by moving the common start parameter inside an equal-depth dyadic
cylinder.
-/
lemma arcScaledRelation_common_shift
    {a b : ℕ}
    {B y y' z z' t : ℤ}
    (hrel : arcScaledRelation a b B y y')
    (hz :
      z = y + ((3 : ℤ) ^ a) * t)
    (hz' :
      z' = y' + ((3 : ℤ) ^ b) * t) :
    arcScaledRelation a b B z z' := by

  unfold arcScaledRelation at hrel ⊢
  rw [hz, hz']

  calc
    (3 : ℤ) ^ a
          * (y' + (3 : ℤ) ^ b * t)
        =
      (3 : ℤ) ^ a * y'
        + ((3 : ℤ) ^ a * (3 : ℤ) ^ b) * t := by
          ring
    _ =
      ((3 : ℤ) ^ b * y + B)
        + ((3 : ℤ) ^ a * (3 : ℤ) ^ b) * t := by
          rw [hrel]
    _ =
      (3 : ℤ) ^ b
          * (y + (3 : ℤ) ^ a * t)
        + B := by
          ring

/--
Paired shift of two equal-length realized words.

Both starts are moved by the same multiple of the common dyadic modulus.
The exact endpoint shifts are recorded, and the scaled relation is preserved.
-/
theorem arcPairedShift
    {u v : List Bool}
    {r N y y' B : ℤ}
    (hlen : u.length = v.length)
    (hu : arcFollowsTo u r y)
    (hv : arcFollowsTo v (r + N) y')
    (hrel :
      arcScaledRelation
        (arcOnes u)
        (arcOnes v)
        B
        y
        y')
    (t : ℤ) :
    ∃ z z' : ℤ,
      arcFollowsTo
        u
        (r + ((2 : ℤ) ^ u.length) * t)
        z
      ∧
      arcFollowsTo
        v
        ((r + ((2 : ℤ) ^ u.length) * t) + N)
        z'
      ∧
      z
        =
      y + ((3 : ℤ) ^ arcOnes u) * t
      ∧
      z'
        =
      y' + ((3 : ℤ) ^ arcOnes v) * t
      ∧
      arcScaledRelation
        (arcOnes u)
        (arcOnes v)
        B
        z
        z' := by

  rcases arcFollowsTo_shift_period hu t with
    ⟨z, huz, hz⟩

  rcases arcFollowsTo_shift_period hv t with
    ⟨z', hvz, hz'⟩

  have hstart :
      (r + N) + ((2 : ℤ) ^ v.length) * t
        =
      (r + ((2 : ℤ) ^ u.length) * t) + N := by
    rw [← hlen]
    ring

  rw [hstart] at hvz

  have hrel' :
      arcScaledRelation
        (arcOnes u)
        (arcOnes v)
        B
        z
        z' :=
    arcScaledRelation_common_shift
      hrel
      hz
      hz'

  exact
    ⟨z, z', huz, hvz, hz, hz', hrel'⟩

/--
Paired local refinement forcing the left endpoint to be even.

The new start stays in the original parent dyadic cylinder, both old words
remain genuinely realized, and the same scaled relation is preserved.
-/
theorem arcPairedRefine_even
    {u v : List Bool}
    {r N y y' B : ℤ}
    (hlen : u.length = v.length)
    (hu : arcFollowsTo u r y)
    (hv : arcFollowsTo v (r + N) y')
    (hrel :
      arcScaledRelation
        (arcOnes u)
        (arcOnes v)
        B
        y
        y') :
    ∃ s z z' : ℤ,
      arcDyadicCylinder u.length r s
      ∧
      arcFollowsTo u s z
      ∧
      arcFollowsTo v (s + N) z'
      ∧
      arcScaledRelation
        (arcOnes u)
        (arcOnes v)
        B
        z
        z'
      ∧
      Even z := by

  by_cases hy : Even y

  · rcases arcPairedShift hlen hu hv hrel 0 with
      ⟨z, z', huz, hvz, hz, hz', hrel'⟩

    have hzEq : z = y := by
      simpa using hz

    have hzEven : Even z := by
      rw [hzEq]
      exact hy

    refine
      ⟨r,
       z,
       z',
       ?_,
       ?_,
       ?_,
       hrel',
       hzEven⟩

    · exact ⟨0, by ring⟩
    · simpa using huz
    · simpa using hvz

  · have hyOdd : Odd y :=
      (Int.not_even_iff_odd).mp hy

    rcases arcPairedShift hlen hu hv hrel 1 with
      ⟨z, z', huz, hvz, hz, hz', hrel'⟩

    have h3Odd :
        Odd ((3 : ℤ) ^ arcOnes u) :=
      arcThreePow_odd (arcOnes u)

    rcases hyOdd with ⟨q, hq⟩
    rcases h3Odd with ⟨p, hp⟩

    have hzEven : Even z := by
      refine ⟨q + p + 1, ?_⟩
      rw [hz, hq, hp]
      ring

    refine
      ⟨r + (2 : ℤ) ^ u.length,
       z,
       z',
       ?_,
       (by simpa using huz),
       (by simpa using hvz),
       hrel',
       hzEven⟩

    exact arcShift_one_in_parent u.length r

/--
Paired local refinement forcing the left endpoint to be odd.

Again the new start stays in the original parent cylinder and the paired
scaled relation is preserved.
-/
theorem arcPairedRefine_odd
    {u v : List Bool}
    {r N y y' B : ℤ}
    (hlen : u.length = v.length)
    (hu : arcFollowsTo u r y)
    (hv : arcFollowsTo v (r + N) y')
    (hrel :
      arcScaledRelation
        (arcOnes u)
        (arcOnes v)
        B
        y
        y') :
    ∃ s z z' : ℤ,
      arcDyadicCylinder u.length r s
      ∧
      arcFollowsTo u s z
      ∧
      arcFollowsTo v (s + N) z'
      ∧
      arcScaledRelation
        (arcOnes u)
        (arcOnes v)
        B
        z
        z'
      ∧
      Odd z := by

  by_cases hy : Even y

  · rcases arcPairedShift hlen hu hv hrel 1 with
      ⟨z, z', huz, hvz, hz, hz', hrel'⟩

    have h3Odd :
        Odd ((3 : ℤ) ^ arcOnes u) :=
      arcThreePow_odd (arcOnes u)

    rcases hy with ⟨q, hq⟩
    rcases h3Odd with ⟨p, hp⟩

    have hzOdd : Odd z := by
      refine ⟨q + p, ?_⟩
      rw [hz, hq, hp]
      ring

    refine
      ⟨r + (2 : ℤ) ^ u.length,
       z,
       z',
       ?_,
       (by simpa using huz),
       (by simpa using hvz),
       hrel',
       hzOdd⟩

    exact arcShift_one_in_parent u.length r

  · have hyOdd : Odd y :=
      (Int.not_even_iff_odd).mp hy

    rcases arcPairedShift hlen hu hv hrel 0 with
      ⟨z, z', huz, hvz, hz, hz', hrel'⟩

    have hzEq : z = y := by
      simpa using hz

    have hzOdd : Odd z := by
      rw [hzEq]
      exact hyOdd

    refine
      ⟨r,
       z,
       z',
       ?_,
       ?_,
       ?_,
       hrel',
       hzOdd⟩

    · exact ⟨0, by ring⟩
    · simpa using huz
    · simpa using hvz

#print axioms arcScaledRelation_common_shift
#print axioms arcPairedShift
#print axioms arcPairedRefine_even
#print axioms arcPairedRefine_odd

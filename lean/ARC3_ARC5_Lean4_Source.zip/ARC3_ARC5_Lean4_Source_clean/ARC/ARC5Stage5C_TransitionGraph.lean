import Mathlib
import ARC.ARC5Stage5B_UniformCPS

set_option autoImplicit false

universe u

/-!
# ARC5 — Stage 5C
## The finite 5-kernel transition graph

Stage 5B proved uniform CPS synchronization on arbitrary power-of-5 blocks.
Before using finiteness, we now make the base-5 transition system explicit.

For a sequence `v : ℕ → α` and a digit `d ∈ {0,1,2,3,4}`, define

    D_d(v)(n) = v(5n + d).

If `v` is an exact depth-q residual of `a`, then `D_d(v)` is an exact
depth-(q+1) residual.  The packed residue is

    5^q d + r.

Hence the exact kernel levels form a rooted 5-ary transition graph, and the
full 5-kernel is closed under all five digit transitions.

When `a` is 5-automatic in finite-kernel form, this transition graph has only
finitely many states.  Stage 5C stops at this graph-theoretic handoff; the
later stage will use repetition / pigeonhole arguments.
-/

/-!
============================================================
1. One-digit residual operator
============================================================
-/

/--
Read one base-5 digit on a residual sequence.
-/
def ARC5DigitResidual
    {α : Type u}
    (d : ℕ)
    (v : ℕ → α) :
    ℕ → α :=
  fun n => v (5 * n + d)

/--
The packed residue created by appending the digit `d` to a depth-q residual
with residue `r`.
-/
def ARC5PackedResidue
    (q d r : ℕ) : ℕ :=
  5 ^ q * d + r

/--
For a genuine base-5 digit `d < 5` and a depth-q residue `r < 5^q`,
the packed residue lies below `5^(q+1)`.
-/
lemma arc5_packedResidue_lt
    (q d r : ℕ)
    (hd : d < 5)
    (hr : r < 5 ^ q) :
    ARC5PackedResidue q d r < 5 ^ (q + 1) := by
  unfold ARC5PackedResidue

  have hd1 :
      d + 1 ≤ 5 := by
    omega

  have hstep :
      5 ^ q * d + r
        <
      5 ^ q * (d + 1) := by
    have h :=
      Nat.add_lt_add_left
        hr
        (5 ^ q * d)
    calc
      5 ^ q * d + r
          <
      5 ^ q * d + 5 ^ q :=
        h
      _ =
      5 ^ q * (d + 1) := by
        ring

  have hmul :
      5 ^ q * (d + 1)
        ≤
      5 ^ q * 5 := by
    exact
      Nat.mul_le_mul_left
        (5 ^ q)
        hd1

  have hfinal :
      5 ^ q * d + r
        <
      5 ^ q * 5 :=
    lt_of_lt_of_le
      hstep
      hmul

  simpa [pow_succ] using hfinal

/--
Arithmetic identity behind one base-5 transition.
-/
lemma arc5_digitResidual_index
    (q d r n : ℕ) :
    5 ^ q * (5 * n + d) + r
      =
    5 ^ (q + 1) * n
      + ARC5PackedResidue q d r := by
  unfold ARC5PackedResidue
  rw [pow_succ]
  ring


/-!
============================================================
2. Exact-level transition closure
============================================================
-/

/--
A digit transition sends an exact depth-q residual to an exact depth-(q+1)
residual.
-/
theorem arc5_digitResidual_level_step
    {α : Type u}
    (a : ℕ → α)
    {q d : ℕ}
    {v : ℕ → α}
    (hd : d < 5)
    (hv :
      v ∈ ARC5LevelKernel q a) :
    ARC5DigitResidual d v
      ∈
    ARC5LevelKernel (q + 1) a := by

  change
    ∃ r : ℕ,
      r < 5 ^ q
        ∧
      ∀ n : ℕ,
        v n = a (5 ^ q * n + r)
    at hv

  rcases hv with
    ⟨r, hr, hvEq⟩

  change
    ∃ s : ℕ,
      s < 5 ^ (q + 1)
        ∧
      ∀ n : ℕ,
        ARC5DigitResidual d v n
          =
        a (5 ^ (q + 1) * n + s)

  refine
    ⟨ARC5PackedResidue q d r,
     arc5_packedResidue_lt q d r hd hr,
     ?_⟩

  intro n

  unfold ARC5DigitResidual

  calc
    v (5 * n + d)
        =
    a (5 ^ q * (5 * n + d) + r) :=
      hvEq (5 * n + d)

    _ =
    a
      (5 ^ (q + 1) * n
        + ARC5PackedResidue q d r) := by
      rw [arc5_digitResidual_index]


/--
Every state at exact depth q has five legal outgoing digit transitions, all
landing at depth q+1.
-/
theorem arc5_level_has_five_successors
    {α : Type u}
    (a : ℕ → α)
    {q : ℕ}
    {v : ℕ → α}
    (hv :
      v ∈ ARC5LevelKernel q a) :
    ∀ d : Fin 5,
      ARC5DigitResidual d.val v
        ∈
      ARC5LevelKernel (q + 1) a := by

  intro d

  exact
    arc5_digitResidual_level_step
      a
      d.isLt
      hv


/-!
============================================================
3. Full 5-kernel closure
============================================================
-/

/--
The full 5-kernel is closed under every genuine base-5 digit residual.
-/
theorem arc5_digitResidual_kernel_closed
    {α : Type u}
    (a : ℕ → α)
    {d : ℕ}
    {v : ℕ → α}
    (hd : d < 5)
    (hv :
      v ∈ ARCKernel 5 a) :
    ARC5DigitResidual d v
      ∈
    ARCKernel 5 a := by

  change
    ∃ e r : ℕ,
      r < 5 ^ e
        ∧
      ∀ n : ℕ,
        v n = a (5 ^ e * n + r)
    at hv

  rcases hv with
    ⟨e, r, hr, hvEq⟩

  change
    ∃ e' r' : ℕ,
      r' < 5 ^ e'
        ∧
      ∀ n : ℕ,
        ARC5DigitResidual d v n
          =
        a (5 ^ e' * n + r')

  refine
    ⟨e + 1,
     ARC5PackedResidue e d r,
     arc5_packedResidue_lt e d r hd hr,
     ?_⟩

  intro n

  unfold ARC5DigitResidual

  calc
    v (5 * n + d)
        =
    a (5 ^ e * (5 * n + d) + r) :=
      hvEq (5 * n + d)

    _ =
    a
      (5 ^ (e + 1) * n
        + ARC5PackedResidue e d r) := by
      rw [arc5_digitResidual_index]


/-!
============================================================
4. Transition graph
============================================================
-/

/--
One directed edge in the base-5 kernel graph:
`v -> w` if `w` is obtained by reading one digit `d < 5`.
-/
def ARC5KernelEdge
    {α : Type u}
    (v w : ℕ → α) : Prop :=
  ∃ d : ℕ,
    d < 5
      ∧
    w = ARC5DigitResidual d v

/--
Every edge out of a 5-kernel state stays inside the full 5-kernel.
-/
theorem arc5_kernelEdge_closed
    {α : Type u}
    (a : ℕ → α)
    {v w : ℕ → α}
    (hv :
      v ∈ ARCKernel 5 a)
    (hedge :
      ARC5KernelEdge v w) :
    w ∈ ARCKernel 5 a := by

  rcases hedge with
    ⟨d, hd, rfl⟩

  exact
    arc5_digitResidual_kernel_closed
      a
      hd
      hv

/--
Every exact-level edge moves from level q to level q+1.
-/
theorem arc5_kernelEdge_level_step
    {α : Type u}
    (a : ℕ → α)
    {q : ℕ}
    {v w : ℕ → α}
    (hv :
      v ∈ ARC5LevelKernel q a)
    (hedge :
      ARC5KernelEdge v w) :
    w ∈ ARC5LevelKernel (q + 1) a := by

  rcases hedge with
    ⟨d, hd, rfl⟩

  exact
    arc5_digitResidual_level_step
      a
      hd
      hv


/-!
============================================================
5. Finite graph handoff
============================================================
-/

/--
Stage-5C handoff.

For a 5-automatic sequence in finite-kernel form:

* the vertex set `ARCKernel 5 a` is finite;
* every one-digit base-5 transition from a vertex remains a vertex.

Together with Stage 5B, this gives a finite directed transition graph carrying
uniform CPS blocks.
-/
theorem arc5_stage5C_finite_transition_graph
    {α : Type u}
    (a : ℕ → α)
    (ha5 :
      ARCAutomaticByKernel 5 a) :
    (ARCKernel 5 a).Finite
      ∧
    ∀ v : ℕ → α,
      v ∈ ARCKernel 5 a
        →
      ∀ d : Fin 5,
        ARC5DigitResidual d.val v
          ∈
        ARCKernel 5 a := by

  constructor

  · simpa [ARCAutomaticByKernel] using ha5

  · intro v hv d

    exact
      arc5_digitResidual_kernel_closed
        a
        d.isLt
        hv

/--
Combined Stage-5B + Stage-5C package for the ARC5 hypotheses.

We now have simultaneously:

1. a finite full 5-kernel;
2. closure under all five digit transitions;
3. uniform CPS synchronization on arbitrary power-of-5 blocks at every exact
   kernel level.
-/
theorem arc5_stage5C_finite_graph_with_uniform_cps
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha5 :
      ARCAutomaticByKernel 5 a) :
    (ARCKernel 5 a).Finite
      ∧
    (
      ∀ v : ℕ → α,
        v ∈ ARCKernel 5 a
          →
        ∀ d : Fin 5,
          ARC5DigitResidual d.val v
            ∈
          ARCKernel 5 a
    )
      ∧
    ARC5LevelBlockSync a := by

  have hgraph :=
    arc5_stage5C_finite_transition_graph
      a
      ha5

  have hsync :=
    arc5_stage5B_finite_kernel_uniform_cps
      a
      hinv
      ha5

  rcases hgraph with
    ⟨hfinite, hclosed⟩

  rcases hsync with
    ⟨_hfinite2, huniform⟩

  exact
    ⟨hfinite,
     hclosed,
     huniform⟩


/-!
============================================================
6. Axiom audit
============================================================
-/

#print axioms arc5_packedResidue_lt
#print axioms arc5_digitResidual_index
#print axioms arc5_digitResidual_level_step
#print axioms arc5_level_has_five_successors
#print axioms arc5_digitResidual_kernel_closed
#print axioms arc5_kernelEdge_closed
#print axioms arc5_kernelEdge_level_step
#print axioms arc5_stage5C_finite_transition_graph
#print axioms arc5_stage5C_finite_graph_with_uniform_cps

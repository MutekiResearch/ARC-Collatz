import Mathlib
import ARC.ARC5LocalDensityStage4N

set_option autoImplicit false

/-!
# ARC5 / Local-Density audit — Stage 4O

Stage 4N proved arbitrary finite suffix forcing inside a word-cylinder.

This file prepares the final Local-Density exit step.  It records three facts:

1. if a word is extended, then the deeper word-cylinder really is contained
   in the old one;
2. equal-length / equal-odd-count words which meet at one seed meet
   synchronously on the whole seed cylinder;
3. at a balanced prefix, the endpoint gap is constant under every common
   refinement of the start cylinder.

Finally we strengthen Stage 4M so that its balanced state comes equipped with
an explicit proof that its *entire current word-cylinder* lies inside the
original prescribed cylinder.
-/

/--
If `U` extends `u`, a `U`-depth cylinder based at a point of the `u`-depth
parent cylinder is contained in that parent cylinder.
-/
lemma arcDyadicCylinder_of_word_extension
    {u U : List Bool}
    {r s x : ℤ}
    (hExt : arcWordExtends u U)
    (hs : arcDyadicCylinder u.length r s)
    (hx : arcDyadicCylinder U.length s x) :
    arcDyadicCylinder u.length r x := by

  rcases hExt with ⟨w, hUw⟩
  subst U

  rcases hs with ⟨a, ha⟩
  rcases hx with ⟨b, hb⟩

  refine
    ⟨a + ((2 : ℤ) ^ w.length) * b,
     ?_⟩

  rw [hb, ha]
  simp [List.length_append, pow_add]
  ring

/--
Translate a dyadic cylinder backwards by a fixed integer.
-/
lemma arcDyadicCylinder_sub
    {L : ℕ}
    {r x N : ℤ}
    (hx :
      arcDyadicCylinder L (r + N) x) :
    arcDyadicCylinder L r (x - N) := by

  rcases hx with ⟨t, ht⟩

  refine ⟨t, ?_⟩

  rw [ht]
  ring

/--
Equal-length words with equal odd-step counts which have the same endpoint at
one seed coalesce synchronously on the entire seed dyadic cylinder.
-/
theorem arcEqualSeed_uniform_coalescence
    {u v : List Bool}
    {r N e : ℤ}
    (hlen : u.length = v.length)
    (hones : arcOnes u = arcOnes v)
    (hu : arcFollowsTo u r e)
    (hv : arcFollowsTo v (r + N) e) :
    ∀ x : ℤ,
      arcDyadicCylinder u.length r x →
      ∃ yu yv : ℤ,
        arcFollowsTo u x yu
        ∧
        arcFollowsTo v (x + N) yv
        ∧
        yu = yv := by

  intro x hx

  rcases hx with ⟨t, ht⟩

  rcases
    arcFollowsTo_shift_period
      hu
      t with
    ⟨yu, huy, hyu⟩

  rcases
    arcFollowsTo_shift_period
      hv
      t with
    ⟨yv, hvy, hyv⟩

  have hstart :
      (r + N)
          + ((2 : ℤ) ^ v.length) * t
        =
      x + N := by
    rw [← hlen, ht]
    ring

  rw [hstart] at hvy

  have hEq : yu = yv := by
    rw [hyu, hyv, hones]

  exact
    ⟨yu, yv,
     (by simpa [ht] using huy),
     hvy,
     hEq⟩

/--
At a balanced prefix, the endpoint gap is constant on every common refinement
of the start cylinder.

If the old seed endpoints are `z,z'`, then after moving the common start to
`t` inside the same dyadic cylinder, the new right endpoint is always

    mid + (z' - z).
-/
theorem arcBalanced_partner_on_cylinder
    {U V : List Bool}
    {s N z z' t mid : ℤ}
    (hlen : U.length = V.length)
    (hones : arcOnes U = arcOnes V)
    (hUz : arcFollowsTo U s z)
    (hVz : arcFollowsTo V (s + N) z')
    (ht : arcDyadicCylinder U.length s t)
    (hUt : arcFollowsTo U t mid) :
    ∃ mid' : ℤ,
      arcFollowsTo V (t + N) mid'
      ∧
      mid' = mid + (z' - z) := by

  rcases ht with ⟨q, hq⟩

  rcases
    arcFollowsTo_shift_period
      hUz
      q with
    ⟨zu, hUq, hzu⟩

  have hzuMid : zu = mid :=
    arcFollowsTo_endpoint_unique
      hUq
      (by
        simpa [hq] using hUt)

  rcases
    arcFollowsTo_shift_period
      hVz
      q with
    ⟨zv, hVq, hzv⟩

  have hstart :
      (s + N)
          + ((2 : ℤ) ^ V.length) * q
        =
      t + N := by
    rw [← hlen, hq]
    ring

  rw [hstart] at hVq

  refine
    ⟨zv,
     hVq,
     ?_⟩

  rw [← hzuMid, hzu, hzv, hones]
  ring

/--
Symmetric form: if the refined *right* prefix endpoint is known, recover the
left prefix endpoint and the same constant gap.
-/
theorem arcBalanced_partner_from_right
    {U V : List Bool}
    {s N z z' q mid' : ℤ}
    (hlen : U.length = V.length)
    (hones : arcOnes U = arcOnes V)
    (hUz : arcFollowsTo U s z)
    (hVz : arcFollowsTo V (s + N) z')
    (hq :
      arcDyadicCylinder V.length (s + N) q)
    (hVq : arcFollowsTo V q mid') :
    ∃ t mid : ℤ,
      t = q - N
      ∧
      arcDyadicCylinder U.length s t
      ∧
      arcFollowsTo U t mid
      ∧
      mid' = mid + (z' - z) := by

  let t : ℤ := q - N

  have htV :
      arcDyadicCylinder
        V.length
        s
        t := by
    have hsub :
        arcDyadicCylinder
          V.length
          s
          (q - N) :=
      arcDyadicCylinder_sub
        (r := s)
        (N := N)
        hq
    simpa [t] using hsub

  have htU :
      arcDyadicCylinder
        U.length
        s
        t := by
    rw [hlen]
    exact htV

  -- Realize `U` at the translated-left start directly from the
  -- word-congruence on the parent cylinder.
  have hUcongBase :
      arcWordCongruence U s :=
    arcFollowsTo_congruence hUz

  have hUcongT :
      arcWordCongruence U t :=
    arcWordCongruence_on_cylinder
      U
      s
      t
      hUcongBase
      htU

  rcases
    arcWordCongruence_realizes
      U
      t
      hUcongT with
    ⟨mid, hUt⟩

  rcases
    arcBalanced_partner_on_cylinder
      hlen
      hones
      hUz
      hVz
      htU
      hUt with
    ⟨mid2, hVt, hgap⟩

  have hqEq :
      t + N = q := by
    dsimp [t]
    ring

  rw [hqEq] at hVt

  have hmidEq :
      mid2 = mid' :=
    arcFollowsTo_endpoint_unique
      hVt
      hVq

  refine
    ⟨t, mid,
     rfl,
     htU,
     hUt,
     ?_⟩

  rw [← hmidEq]
  exact hgap

/--
Strengthened prescribed-cylinder balanced steering.

In addition to the Stage-4M data, every point of the current `U`-depth
cylinder is explicitly certified to remain inside the originally prescribed
depth-`m` cylinder.
-/
theorem arcPrescribedCylinder_steer_balanced_strong
    (m : ℕ)
    (r N : ℤ) :
    ∃ A : ℕ,
      ∃ E : ℤ,
        ∃ U V : List Bool,
          ∃ s z z' : ℤ,
            U.length = V.length
            ∧
            arcOnes U = A
            ∧
            arcOnes V = A
            ∧
            arcFollowsTo U s z
            ∧
            arcFollowsTo V (s + N) z'
            ∧
            arcScaledRelation A A E z z'
            ∧
            ∀ x : ℤ,
              arcDyadicCylinder U.length s x
                →
              arcDyadicCylinder m r x := by

  rcases
    arcInitialPair_exists
      m
      r
      N with
    ⟨u, v, y, y', B,
     hulen, hvlen, hlen,
     huy, hvy, hrel⟩

  rcases
    arcSteer_to_balanced
      hlen
      rfl
      rfl
      huy
      hvy
      hrel with
    ⟨A, E, U, V, s, z, z',
     hUext, hVext,
     hUVlen, hUA, hVA,
     hs, hUz, hVz, hrelA⟩

  refine
    ⟨A, E, U, V, s, z, z',
     hUVlen,
     hUA,
     hVA,
     hUz,
     hVz,
     hrelA,
     ?_⟩

  intro x hx

  have hxParentU :
      arcDyadicCylinder
        u.length
        r
        x :=
    arcDyadicCylinder_of_word_extension
      hUext
      hs
      hx

  simpa [hulen] using hxParentU

#print axioms arcDyadicCylinder_of_word_extension
#print axioms arcEqualSeed_uniform_coalescence
#print axioms arcBalanced_partner_on_cylinder
#print axioms arcBalanced_partner_from_right
#print axioms arcPrescribedCylinder_steer_balanced_strong

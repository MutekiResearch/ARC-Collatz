import Mathlib
import ARC.ARC5LocalDensityStage3A_v2

set_option autoImplicit false

/-!
# ARC5 / Local-Density audit — Stage 3B

Stage 3A introduced the genuine integer branch-realization relation
`arcFollowsTo`.

This file proves the crucial sufficiency direction:

    arcWordCongruence w x
      ->
    there exists an integer y such that arcFollowsTo w x y.

Thus the Stage-2C dyadic congruence is not merely a formal condition:
it really forces the integer orbit to follow the prescribed parity word.

The proof is by induction on the word.  At each nonempty step, divisibility by
`2^(L+1)` first forces the correct parity of the current integer.  After taking
that genuine Collatz branch, the remaining divisibility condition cancels one
factor of 2 and becomes exactly the congruence condition for the tail word.
-/

/-- Rewrite the Stage-2C congruence as ordinary divisibility. -/
lemma arcWordCongruence_iff_dvd
    (w : List Bool)
    (x : ℤ) :
    arcWordCongruence w x
      ↔
    ((2 : ℤ) ^ w.length) ∣ arcWordNumerator w x := by
  unfold arcWordCongruence
  exact Int.modEq_zero_iff_dvd

/-- Raw numerator formula for a false/even prefix. -/
lemma arcWordNumerator_false_raw
    (w : List Bool)
    (x : ℤ) :
    arcWordNumerator (false :: w) x
      =
    (3 : ℤ) ^ arcOnes w * x + 2 * arcIntercept w := by
  simp [arcWordNumerator, arcOnes, arcIntercept]

/-- Raw numerator formula for a true/odd prefix. -/
lemma arcWordNumerator_true_raw
    (w : List Bool)
    (x : ℤ) :
    arcWordNumerator (true :: w) x
      =
    (3 : ℤ) ^ arcOnes w * (3 * x + 1)
      + 2 * arcIntercept w := by
  simp [arcWordNumerator, arcOnes, arcIntercept, pow_succ]
  ring

/--
If a false branch is genuine (`x = 2z`), then the prefix numerator is exactly
twice the tail numerator.
-/
lemma arcWordNumerator_false_step
    {w : List Bool}
    {x z : ℤ}
    (hx : x = 2 * z) :
    arcWordNumerator (false :: w) x
      =
    2 * arcWordNumerator w z := by
  rw [arcWordNumerator_false_raw]
  unfold arcWordNumerator
  rw [hx]
  ring

/--
If a true branch is genuine (`3x+1 = 2z`), then the prefix numerator is
exactly twice the tail numerator.
-/
lemma arcWordNumerator_true_step
    {w : List Bool}
    {x z : ℤ}
    (hx : 3 * x + 1 = 2 * z) :
    arcWordNumerator (true :: w) x
      =
    2 * arcWordNumerator w z := by
  rw [arcWordNumerator_true_raw]
  unfold arcWordNumerator
  rw [hx]
  ring

/--
The odd coefficient `3^k` is never even.
-/
lemma arcThreePow_not_even
    (k : ℕ) :
    ¬ Even ((3 : ℤ) ^ k) := by
  rw [Int.even_pow]
  norm_num

/--
A full prefix congruence forces the false/even branch parity.
-/
lemma arcFalsePrefix_forces_even
    {w : List Bool}
    {x : ℤ}
    (h :
      ((2 : ℤ) ^ (false :: w).length)
        ∣
      arcWordNumerator (false :: w) x) :
    ∃ z : ℤ, x = 2 * z := by

  have htwoPow :
      (2 : ℤ) ∣ (2 : ℤ) ^ (false :: w).length := by
    exact dvd_pow_self (2 : ℤ) (by simp)

  have htwoNum :
      (2 : ℤ) ∣ arcWordNumerator (false :: w) x :=
    htwoPow.trans h

  rcases htwoNum with ⟨q, hq⟩

  have hprod :
      (2 : ℤ) ∣ ((3 : ℤ) ^ arcOnes w * x) := by
    refine ⟨q - arcIntercept w, ?_⟩
    rw [arcWordNumerator_false_raw] at hq
    linarith

  have hEvenProd :
      Even ((3 : ℤ) ^ arcOnes w * x) := by
    exact (even_iff_two_dvd).2 hprod

  have hxEven : Even x := by
    rcases (Int.even_mul.mp hEvenProd) with h3 | hx
    · exact False.elim ((arcThreePow_not_even (arcOnes w)) h3)
    · exact hx

  exact (even_iff_exists_two_mul.mp hxEven)

/--
A full prefix congruence forces the true/odd branch equation
`3x+1 = 2z`.
-/
lemma arcTruePrefix_forces_branch
    {w : List Bool}
    {x : ℤ}
    (h :
      ((2 : ℤ) ^ (true :: w).length)
        ∣
      arcWordNumerator (true :: w) x) :
    ∃ z : ℤ, 3 * x + 1 = 2 * z := by

  have htwoPow :
      (2 : ℤ) ∣ (2 : ℤ) ^ (true :: w).length := by
    exact dvd_pow_self (2 : ℤ) (by simp)

  have htwoNum :
      (2 : ℤ) ∣ arcWordNumerator (true :: w) x :=
    htwoPow.trans h

  rcases htwoNum with ⟨q, hq⟩

  have hprod :
      (2 : ℤ) ∣
        ((3 : ℤ) ^ arcOnes w * (3 * x + 1)) := by
    refine ⟨q - arcIntercept w, ?_⟩
    rw [arcWordNumerator_true_raw] at hq
    linarith

  have hEvenProd :
      Even ((3 : ℤ) ^ arcOnes w * (3 * x + 1)) := by
    exact (even_iff_two_dvd).2 hprod

  have hInnerEven : Even (3 * x + 1) := by
    rcases (Int.even_mul.mp hEvenProd) with h3 | hinner
    · exact False.elim ((arcThreePow_not_even (arcOnes w)) h3)
    · exact hinner

  exact (even_iff_exists_two_mul.mp hInnerEven)

/--
Cancel the leading factor 2 in the prefix divisibility condition.
-/
lemma arcTail_dvd_of_step
    {w : List Bool}
    {prefixNum tailNum : ℤ}
    (hstep : prefixNum = 2 * tailNum)
    (h :
      ((2 : ℤ) ^ (w.length + 1)) ∣ prefixNum) :
    ((2 : ℤ) ^ w.length) ∣ tailNum := by

  have hscaled :
      (2 : ℤ) * ((2 : ℤ) ^ w.length)
        ∣
      (2 : ℤ) * tailNum := by
    simpa [pow_succ, mul_comm, mul_left_comm, mul_assoc, hstep] using h

  exact
    (mul_dvd_mul_iff_left
      (by norm_num : (2 : ℤ) ≠ 0)).mp hscaled

/--
Main Stage-3B theorem:
the dyadic word congruence really realizes the prescribed parity word.
-/
theorem arcWordCongruence_realizes
    (w : List Bool)
    (x : ℤ)
    (hcong : arcWordCongruence w x) :
    ∃ y : ℤ, arcFollowsTo w x y := by

  induction w generalizing x with
  | nil =>
      refine ⟨x, ?_⟩
      simp [arcFollowsTo]

  | cons b w ih =>
      have hdiv :
          ((2 : ℤ) ^ (b :: w).length)
            ∣
          arcWordNumerator (b :: w) x :=
        (arcWordCongruence_iff_dvd (b :: w) x).mp hcong

      cases b with
      | false =>
          rcases arcFalsePrefix_forces_even hdiv with ⟨z, hx⟩

          have hstep :
              arcWordNumerator (false :: w) x
                =
              2 * arcWordNumerator w z :=
            arcWordNumerator_false_step hx

          have htailDvd :
              ((2 : ℤ) ^ w.length)
                ∣
              arcWordNumerator w z := by
            apply arcTail_dvd_of_step hstep
            simpa using hdiv

          have htailCong :
              arcWordCongruence w z :=
            (arcWordCongruence_iff_dvd w z).mpr htailDvd

          rcases ih z htailCong with ⟨y, hy⟩

          exact ⟨y, ⟨z, hx, hy⟩⟩

      | true =>
          rcases arcTruePrefix_forces_branch hdiv with ⟨z, hx⟩

          have hstep :
              arcWordNumerator (true :: w) x
                =
              2 * arcWordNumerator w z :=
            arcWordNumerator_true_step hx

          have htailDvd :
              ((2 : ℤ) ^ w.length)
                ∣
              arcWordNumerator w z := by
            apply arcTail_dvd_of_step hstep
            simpa using hdiv

          have htailCong :
              arcWordCongruence w z :=
            (arcWordCongruence_iff_dvd w z).mpr htailDvd

          rcases ih z htailCong with ⟨y, hy⟩

          exact ⟨y, ⟨z, hx, hy⟩⟩

#print axioms arcFalsePrefix_forces_even
#print axioms arcTruePrefix_forces_branch
#print axioms arcWordCongruence_realizes

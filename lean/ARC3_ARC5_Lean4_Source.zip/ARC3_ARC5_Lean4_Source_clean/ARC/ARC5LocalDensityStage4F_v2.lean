import Mathlib
import ARC.ARC5LocalDensityStage4E_v2

set_option autoImplicit false

/-!
# ARC5 / Local-Density audit — Stage 4F

Stage 4E established paired local parity control while preserving the scaled
relation

    3^(ones u) * y' = 3^(ones v) * y + B.

This file turns that control into the four actual steering moves on *extended
parity words*.  Each move:
  * refines the current dyadic parent cylinder;
  * appends one genuine branch bit to each word;
  * preserves equal word length;
  * updates the scaled offset exactly as in Stage 4B.

These are the finite transition rules that the later termination proof will
iterate.
-/

/-- Appending an even/false bit does not change the odd-step count. -/
lemma arcOnes_append_false
    (w : List Bool) :
    arcOnes (w ++ [false]) = arcOnes w := by
  induction w with
  | nil =>
      simp [arcOnes]
  | cons b w ih =>
      cases b <;>
        simp [arcOnes, ih]

/-- Appending an odd/true bit increases the odd-step count by one. -/
lemma arcOnes_append_true
    (w : List Bool) :
    arcOnes (w ++ [true]) = arcOnes w + 1 := by
  induction w with
  | nil =>
      simp [arcOnes]
  | cons b w ih =>
      cases b <;>
        simp [arcOnes, ih, Nat.add_assoc, Nat.add_comm, Nat.add_left_comm]

/-- Appending one bit increases word length by one. -/
lemma arcLength_append_bit
    (w : List Bool)
    (b : Bool) :
    (w ++ [b]).length = w.length + 1 := by
  simp

/--
00 steering move.

For an even offset B we force the left endpoint even.  The parity table then
forces the right endpoint even as well.  Both words are extended by `false`,
and the new offset C satisfies B = 2 C.
-/
theorem arcSteer00_of_evenOffset
    {u v : List Bool}
    {r N y y' B : ℤ}
    (hlen : u.length = v.length)
    (hu : arcFollowsTo u r y)
    (hv : arcFollowsTo v (r + N) y')
    (hrel :
      arcScaledRelation
        (arcOnes u)
        (arcOnes v)
        B
        y
        y')
    (hB : Even B) :
    ∃ s z z' C : ℤ,
      arcDyadicCylinder u.length r s
      ∧
      (u ++ [false]).length = (v ++ [false]).length
      ∧
      arcFollowsTo (u ++ [false]) s z
      ∧
      arcFollowsTo (v ++ [false]) (s + N) z'
      ∧
      B = 2 * C
      ∧
      arcScaledRelation
        (arcOnes (u ++ [false]))
        (arcOnes (v ++ [false]))
        C
        z
        z' := by

  rcases arcPairedRefine_even hlen hu hv hrel with
    ⟨s, p, p', hs, hup, hvp, hrelp, hpEven⟩

  rcases arcScaledRelation_branches00 hrelp hB hpEven with
    ⟨⟨z, hz⟩, ⟨z', hz'⟩⟩

  rcases arcOffset00_exists hB with
    ⟨C, hC⟩

  have hstep :
      arcScaledRelation
        (arcOnes u)
        (arcOnes v)
        C
        z
        z' :=
    arcScaledRelation_step00
      hrelp
      hz
      hz'
      hC

  have hufull :
      arcFollowsTo (u ++ [false]) s z := by
    apply arcFollowsTo_append hup
    refine ⟨z, hz, ?_⟩
    simp [arcFollowsTo]

  have hvfull :
      arcFollowsTo (v ++ [false]) (s + N) z' := by
    apply arcFollowsTo_append hvp
    refine ⟨z', hz', ?_⟩
    simp [arcFollowsTo]

  refine
    ⟨s, z, z', C,
     hs,
     ?_,
     hufull,
     hvfull,
     hC,
     ?_⟩

  · simp [hlen]

  · simpa
      [arcOnes_append_false]
      using hstep

/--
01 steering move.

For an odd offset B we force the left endpoint even.  The parity table forces
the right endpoint odd.  The left word gets `false`, the right word gets
`true`, and the right exponent count rises by one.
-/
theorem arcSteer01_of_oddOffset
    {u v : List Bool}
    {r N y y' B : ℤ}
    (hlen : u.length = v.length)
    (hu : arcFollowsTo u r y)
    (hv : arcFollowsTo v (r + N) y')
    (hrel :
      arcScaledRelation
        (arcOnes u)
        (arcOnes v)
        B
        y
        y')
    (hB : Odd B) :
    ∃ s z z' C : ℤ,
      arcDyadicCylinder u.length r s
      ∧
      (u ++ [false]).length = (v ++ [true]).length
      ∧
      arcFollowsTo (u ++ [false]) s z
      ∧
      arcFollowsTo (v ++ [true]) (s + N) z'
      ∧
      2 * C = 3 * B + (3 : ℤ) ^ arcOnes u
      ∧
      arcScaledRelation
        (arcOnes (u ++ [false]))
        (arcOnes (v ++ [true]))
        C
        z
        z' := by

  rcases arcPairedRefine_even hlen hu hv hrel with
    ⟨s, p, p', hs, hup, hvp, hrelp, hpEven⟩

  rcases arcScaledRelation_branches01 hrelp hB hpEven with
    ⟨⟨z, hz⟩, ⟨z', hz'⟩⟩

  rcases arcOffset01_exists hB with
    ⟨C, hC⟩

  have hstep :
      arcScaledRelation
        (arcOnes u)
        (arcOnes v + 1)
        C
        z
        z' :=
    arcScaledRelation_step01
      hrelp
      hz
      hz'
      hC

  have hufull :
      arcFollowsTo (u ++ [false]) s z := by
    apply arcFollowsTo_append hup
    refine ⟨z, hz, ?_⟩
    simp [arcFollowsTo]

  have hvfull :
      arcFollowsTo (v ++ [true]) (s + N) z' := by
    apply arcFollowsTo_append hvp
    refine ⟨z', hz', ?_⟩
    simp [arcFollowsTo]

  refine
    ⟨s, z, z', C,
     hs,
     ?_,
     hufull,
     hvfull,
     hC,
     ?_⟩

  · simp [hlen]

  · simpa
      [arcOnes_append_false,
       arcOnes_append_true]
      using hstep

/--
10 steering move.

For an odd offset B we force the left endpoint odd.  The parity table forces
the right endpoint even.  The left exponent count rises by one.
-/
theorem arcSteer10_of_oddOffset
    {u v : List Bool}
    {r N y y' B : ℤ}
    (hlen : u.length = v.length)
    (hu : arcFollowsTo u r y)
    (hv : arcFollowsTo v (r + N) y')
    (hrel :
      arcScaledRelation
        (arcOnes u)
        (arcOnes v)
        B
        y
        y')
    (hB : Odd B) :
    ∃ s z z' C : ℤ,
      arcDyadicCylinder u.length r s
      ∧
      (u ++ [true]).length = (v ++ [false]).length
      ∧
      arcFollowsTo (u ++ [true]) s z
      ∧
      arcFollowsTo (v ++ [false]) (s + N) z'
      ∧
      2 * C = 3 * B - (3 : ℤ) ^ arcOnes v
      ∧
      arcScaledRelation
        (arcOnes (u ++ [true]))
        (arcOnes (v ++ [false]))
        C
        z
        z' := by

  rcases arcPairedRefine_odd hlen hu hv hrel with
    ⟨s, p, p', hs, hup, hvp, hrelp, hpOdd⟩

  rcases arcScaledRelation_branches10 hrelp hB hpOdd with
    ⟨⟨z, hz⟩, ⟨z', hz'⟩⟩

  rcases arcOffset10_exists hB with
    ⟨C, hC⟩

  have hstep :
      arcScaledRelation
        (arcOnes u + 1)
        (arcOnes v)
        C
        z
        z' :=
    arcScaledRelation_step10
      hrelp
      hz
      hz'
      hC

  have hufull :
      arcFollowsTo (u ++ [true]) s z := by
    apply arcFollowsTo_append hup
    refine ⟨z, hz, ?_⟩
    simp [arcFollowsTo]

  have hvfull :
      arcFollowsTo (v ++ [false]) (s + N) z' := by
    apply arcFollowsTo_append hvp
    refine ⟨z', hz', ?_⟩
    simp [arcFollowsTo]

  refine
    ⟨s, z, z', C,
     hs,
     ?_,
     hufull,
     hvfull,
     hC,
     ?_⟩

  · simp [hlen]

  · simpa
      [arcOnes_append_false,
       arcOnes_append_true]
      using hstep

/--
11 zero-offset kick.

If the offset has vanished, we can force both endpoints odd.  Both words are
extended by `true`, so both odd-step counts rise by one.  In the old exponent
normalization Stage 4B produces an offset `C` with

    2 C = 3^(ones u) - 3^(ones v).

After raising both exponents by one, the natural offset for the extended
words is `D = 3 C`.  Equivalently,

    2 D = 3^(ones u + 1) - 3^(ones v + 1).

The next stage will show that this new offset is nonzero whenever the two
odd-step counts differ.
-/
theorem arcSteer11_of_zeroOffset
    {u v : List Bool}
    {r N y y' : ℤ}
    (hlen : u.length = v.length)
    (hu : arcFollowsTo u r y)
    (hv : arcFollowsTo v (r + N) y')
    (hrel :
      arcScaledRelation
        (arcOnes u)
        (arcOnes v)
        0
        y
        y') :
    ∃ s z z' D : ℤ,
      arcDyadicCylinder u.length r s
      ∧
      (u ++ [true]).length = (v ++ [true]).length
      ∧
      arcFollowsTo (u ++ [true]) s z
      ∧
      arcFollowsTo (v ++ [true]) (s + N) z'
      ∧
      2 * D
        =
      (3 : ℤ) ^ arcOnes (u ++ [true])
        - (3 : ℤ) ^ arcOnes (v ++ [true])
      ∧
      arcScaledRelation
        (arcOnes (u ++ [true]))
        (arcOnes (v ++ [true]))
        D
        z
        z' := by

  have h0Even : Even (0 : ℤ) := by
    exact ⟨0, by norm_num⟩

  rcases arcPairedRefine_odd hlen hu hv hrel with
    ⟨s, p, p', hs, hup, hvp, hrelp, hpOdd⟩

  rcases arcScaledRelation_branches11 hrelp h0Even hpOdd with
    ⟨⟨z, hz⟩, ⟨z', hz'⟩⟩

  rcases arcOffset11_zero_exists
      (arcOnes u)
      (arcOnes v) with
    ⟨C, hC⟩

  have hstep :
      arcScaledRelation
        (arcOnes u)
        (arcOnes v)
        C
        z
        z' := by
    apply arcScaledRelation_step11 hrelp hz hz'
    simpa using hC

  have hufull :
      arcFollowsTo (u ++ [true]) s z := by
    apply arcFollowsTo_append hup
    refine ⟨z, hz, ?_⟩
    simp [arcFollowsTo]

  have hvfull :
      arcFollowsTo (v ++ [true]) (s + N) z' := by
    apply arcFollowsTo_append hvp
    refine ⟨z', hz', ?_⟩
    simp [arcFollowsTo]

  let D : ℤ := 3 * C

  refine
    ⟨s, z, z', D,
     hs,
     ?_,
     hufull,
     hvfull,
     ?_,
     ?_⟩

  · simp [hlen]

  · dsimp [D]
    rw [arcOnes_append_true, arcOnes_append_true]
    rw [pow_succ, pow_succ]
    linear_combination 3 * hC

  · dsimp [D]
    rw [arcOnes_append_true, arcOnes_append_true]
    unfold arcScaledRelation at hstep ⊢

    calc
      (3 : ℤ) ^ (arcOnes u + 1) * z'
          =
      3 * ((3 : ℤ) ^ arcOnes u * z') := by
        rw [pow_succ]
        ring
      _ =
      3 * ((3 : ℤ) ^ arcOnes v * z + C) := by
        rw [hstep]
      _ =
      (3 : ℤ) ^ (arcOnes v + 1) * z + 3 * C := by
        rw [pow_succ]
        ring

#print axioms arcSteer00_of_evenOffset
#print axioms arcSteer01_of_oddOffset
#print axioms arcSteer10_of_oddOffset
#print axioms arcSteer11_of_zeroOffset

import Mathlib
import ARC.ARC5Stage5M_PositivePumpIncrement_v2

set_option autoImplicit false

/-!
# ARC5 — Stage 5N
## Exact two-adic factorization of the positive pumping increment

Stage 5M proved that the numerical pumping increment `d` is positive for a
pump extracted from a positive canonical base-5 word.

Stage 5N performs two tasks.

1. Prove internally, by strong induction, the elementary factorization

       d > 0  ->  ∃ s v, d = 2^s * (2*v + 1).

   This avoids any dependency on a separate valuation API.

2. Feed that factorization into the Stage-5J arithmetic core.  Thus the
   automatic-support pump family obtained in Stages 5K--5M acquires an exact
   dyadic displacement law:

       N_(k + 2^t(2u+1))
         =
       N_k + 2^(s+t)(2w+1).

This is the first stage where the automaton pumping construction and the
exact 2-adic arithmetic of Stage 5J are combined in one theorem.
-/

/-!
============================================================
1. Every positive natural has an exact power-of-two factor
============================================================
-/

/--
Every positive natural number is a power of two times an odd positive number,
written in the convenient form `2^s * (2*v + 1)`.
-/
theorem arc5_exists_twoPow_mul_odd
    (d : ℕ)
    (hd :
      0 < d) :
    ∃ s v : ℕ,
      d = 2 ^ s * (2 * v + 1) := by

  revert hd

  induction d using Nat.strong_induction_on with

  | h d ih =>

      intro hd

      by_cases heven :
          d % 2 = 0

      · have htwo :
            2 ∣ d :=
          Nat.dvd_of_mod_eq_zero
            heven

        rcases htwo with
          ⟨q, hq⟩

        have hqpos :
            0 < q := by
          nlinarith

        have hqlt :
            q < d := by
          nlinarith

        rcases
          ih q hqlt hqpos with
          ⟨s, v, hsv⟩

        refine
          ⟨s + 1, v, ?_⟩

        rw [hq, hsv, pow_succ]

        ring

      · have hmodlt :
            d % 2 < 2 :=
          Nat.mod_lt
            d
            (by norm_num)

        have hmod :
            d % 2 = 1 := by
          omega

        have hdiv :=
          Nat.mod_add_div d 2

        refine
          ⟨0, d / 2, ?_⟩

        simp

        omega


/-!
============================================================
2. Exact two-factorization of the Stage-5M pump increment
============================================================
-/

/--
The positive word-pumping increment from Stage 5M has an exact power-of-two
factorization.
-/
theorem arc5_wordPumpIncrement_exact_two_factor
    (a b c : List (Fin 5))
    (hinc :
      0 < ARC5WordPumpIncrement a b c) :
    ∃ s v : ℕ,
      ARC5WordPumpIncrement a b c
        =
      2 ^ s * (2 * v + 1) := by

  exact
    arc5_exists_twoPow_mul_odd
      (ARC5WordPumpIncrement a b c)
      hinc


/-!
============================================================
3. Direct Stage-5J injection
============================================================
-/

/--
Once the word-pump increment is positive, the Stage-5J exact dyadic
displacement law applies to its entire pumped numerical family.
-/
theorem arc5_wordPumpFamily_exact_dyadic_displacement
    (a b c : List (Fin 5))
    (hinc :
      0 < ARC5WordPumpIncrement a b c) :
    ∃ s v : ℕ,
      ARC5WordPumpIncrement a b c
        =
      2 ^ s * (2 * v + 1)
        ∧
      ∀ k t u : ℕ,
        ∃ w : ℕ,
          ARC5PumpedFamily
              (ARC5MSDValue (a ++ c))
              (ARC5WordPumpIncrement a b c)
              b.length
              (k + 2 ^ t * (2 * u + 1))
            =
          ARC5PumpedFamily
              (ARC5MSDValue (a ++ c))
              (ARC5WordPumpIncrement a b c)
              b.length
              k
            +
          2 ^ (s + t) * (2 * w + 1) := by

  rcases
    arc5_wordPumpIncrement_exact_two_factor
      a
      b
      c
      hinc with
    ⟨s, v, hfactor⟩

  refine
    ⟨s, v, hfactor, ?_⟩

  intro k t u

  exact
    arc5_stage5J_pumping_arithmetic_core
      (ARC5MSDValue (a ++ c))
      (ARC5WordPumpIncrement a b c)
      b.length
      k
      s
      v
      hfactor
      t
      u


/-!
============================================================
4. Full Stage-5N automatic-support handoff
============================================================
-/

/--
Full Stage-5N handoff.

Starting from a sufficiently long positive canonical support word of a
Boolean MSD-DFAO, we obtain:

* a genuine nonempty pump block;
* a positive numerical pump increment;
* an exact factorization `d = 2^s * (2*v+1)`;
* every pumped value remains in the Boolean support;
* the word value equals the Stage-5J arithmetic family;
* every odd-times-`2^t` change in pump count produces an exact
  odd-times-`2^(s+t)` numerical displacement.
-/
theorem arc5_stage5N_exact_dyadic_pumping_handoff
    (M : ARCMSDDFAO 5 Bool)
    [Fintype M.State]
    (sseq : ℕ → Bool)
    (hM :
      ARCMSDDFAO.Generates M sseq)
    (x : List (Fin 5))
    (hxCanonical :
      ARC5CanonicalPositiveMSDWord x)
    (hx :
      ARC5MSDValue x
        ∈
      ARC5BoolSupport sseq)
    (hlen :
      Fintype.card M.State
        ≤
      x.length) :
    ∃ a b c : List (Fin 5),
    ∃ s v : ℕ,
      x = a ++ b ++ c
        ∧
      a.length + b.length
        ≤
      Fintype.card M.State
        ∧
      b ≠ []
        ∧
      0 < b.length
        ∧
      0 < ARC5WordPumpIncrement a b c
        ∧
      ARC5WordPumpIncrement a b c
        =
      2 ^ s * (2 * v + 1)
        ∧
      (
        ∀ n : ℕ,
          ARC5PumpedFamily
              (ARC5MSDValue (a ++ c))
              (ARC5WordPumpIncrement a b c)
              b.length
              n
            ∈
          ARC5BoolSupport sseq
      )
        ∧
      (
        ∀ n : ℕ,
          ARC5MSDValue
              (a ++ ARC5ListRepeat b n ++ c)
            =
          ARC5PumpedFamily
              (ARC5MSDValue (a ++ c))
              (ARC5WordPumpIncrement a b c)
              b.length
              n
      )
        ∧
      (
        ∀ k t u : ℕ,
          ∃ w : ℕ,
            ARC5PumpedFamily
                (ARC5MSDValue (a ++ c))
                (ARC5WordPumpIncrement a b c)
                b.length
                (k + 2 ^ t * (2 * u + 1))
              =
            ARC5PumpedFamily
                (ARC5MSDValue (a ++ c))
                (ARC5WordPumpIncrement a b c)
                b.length
                k
              +
            2 ^ (s + t) * (2 * w + 1)
      ) := by

  rcases
    arc5_stage5M_positive_numeric_pumping_handoff
      M
      sseq
      hM
      x
      hxCanonical
      hx
      hlen with
    ⟨a,
     b,
     c,
     hsplit,
     hshort,
     hbne,
     hinc,
     hpump,
     hvalue⟩

  have hblen :
      0 < b.length := by
    cases b with
    | nil =>
        exact (hbne rfl).elim
    | cons d ds =>
        simp

  rcases
    arc5_wordPumpFamily_exact_dyadic_displacement
      a
      b
      c
      hinc with
    ⟨s, v, hfactor, hdyadic⟩

  exact
    ⟨a,
     b,
     c,
     s,
     v,
     hsplit,
     hshort,
     hbne,
     hblen,
     hinc,
     hfactor,
     hpump,
     hvalue,
     hdyadic⟩


/-!
============================================================
5. Axiom audit
============================================================
-/

#print axioms arc5_exists_twoPow_mul_odd
#print axioms arc5_wordPumpIncrement_exact_two_factor
#print axioms arc5_wordPumpFamily_exact_dyadic_displacement
#print axioms arc5_stage5N_exact_dyadic_pumping_handoff

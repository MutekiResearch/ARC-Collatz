import Mathlib
import ARC.ARC5LocalDensityStage2B

set_option autoImplicit false

/-!
# ARC5 / Local-Density audit — Stage 2C

Stage 2B produced equal-length words `u,v`, with equal odd-step count, and

    C(u) - C(v) = 3^k N.

This file turns that identity into the exact dyadic-congruence shift needed
for the parity-cylinder step.

For a word `w`, the formal affine numerator is

    3^k x + C(w),

and the candidate residue class for realizing `w` is characterized by this
numerator being divisible by `2^L`.

The key theorem below says that the Stage-2B witness pair has exactly the
same numerator after translating the starting point by `N`. Hence the
candidate dyadic congruence for `u` at `x` is equivalent to the candidate
dyadic congruence for `v` at `x+N`.

The next stage will prove that this congruence condition is not merely formal:
it is exactly the condition that the actual shortcut-Collatz orbit follows
the prescribed parity word.
-/

/-- Integer affine numerator associated with a parity word. -/
def arcWordNumerator
    (w : List Bool)
    (x : ℤ) : ℤ :=
  (3 : ℤ) ^ arcOnes w * x + arcIntercept w

/--
Candidate dyadic cylinder condition for a parity word:
the affine numerator is divisible by `2^(word length)`.
-/
def arcWordCongruence
    (w : List Bool)
    (x : ℤ) : Prop :=
  Int.ModEq
    ((2 : ℤ) ^ w.length)
    (arcWordNumerator w x)
    0

/--
The intercept-gap identity is exactly the statement that the two affine
numerators agree after translating the input by `N`.
-/
theorem arcWordNumerator_translation
    {N : ℕ}
    {u v : List Bool}
    (hones : arcOnes u = arcOnes v)
    (hgap :
      arcIntercept u - arcIntercept v
        =
      (3 : ℤ) ^ arcOnes u * (N : ℤ))
    (x : ℤ) :
    arcWordNumerator u x
      =
    arcWordNumerator v (x + (N : ℤ)) := by

  unfold arcWordNumerator
  rw [← hones]
  linear_combination hgap

/--
Equal length plus the exact intercept gap implies exact translation of the
candidate dyadic congruence classes.
-/
theorem arcWordCongruence_translation
    {N : ℕ}
    {u v : List Bool}
    (hlen : u.length = v.length)
    (hones : arcOnes u = arcOnes v)
    (hgap :
      arcIntercept u - arcIntercept v
        =
      (3 : ℤ) ^ arcOnes u * (N : ℤ))
    (x : ℤ) :
    arcWordCongruence u x
      ↔
    arcWordCongruence v (x + (N : ℤ)) := by

  have hnum :
      arcWordNumerator u x
        =
      arcWordNumerator v (x + (N : ℤ)) :=
    arcWordNumerator_translation
      hones
      hgap
      x

  unfold arcWordCongruence

  rw [← hlen]
  rw [← hnum]

/--
Universal modular-translation witnesses.

For every positive integer `N`, there are equal-length parity words with
equal odd-step count such that their candidate dyadic congruence classes are
translated by exactly `N`.
-/
theorem arcUniversalCongruenceTranslation
    (N : ℕ)
    (hN : 0 < N) :
    ∃ u v : List Bool,
      u.length = v.length ∧
      arcOnes u = arcOnes v ∧
      (∀ x : ℤ,
        arcWordCongruence u x
          ↔
        arcWordCongruence v (x + (N : ℤ))) := by

  rcases arcUniversalInterceptGap N hN with
    ⟨u, v, hlen, hones, hgap⟩

  refine ⟨u, v, hlen, hones, ?_⟩

  intro x

  exact
    arcWordCongruence_translation
      hlen
      hones
      hgap
      x

#print axioms arcWordNumerator_translation
#print axioms arcUniversalCongruenceTranslation

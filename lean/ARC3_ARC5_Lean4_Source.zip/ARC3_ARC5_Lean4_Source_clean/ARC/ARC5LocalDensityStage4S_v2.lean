import Mathlib
import ARC.ARC5LocalDensityStage4R

set_option autoImplicit false

/-!
# ARC5 / base-5 aligned natural blocks — Stage 4S

Stage 4R proved that every natural coloring invariant under the shortcut
Collatz map contains arbitrarily long finite monochromatic blocks, in
particular blocks of length `5^q`.

For the later 5-automatic / 5-kernel argument we need a slightly more
structured form: the left endpoint should be aligned with a base-5 block
boundary.

This file proves that for every `q` there is a positive `k` such that

    a (5^q * k) = a (5^q * k + r)

for every `r < 5^q`.

The proof asks Stage 4R for a longer block of length `5^(q+1)`.  Inside any
interval of that length there is room for the next multiple of `5^q` and the
entire following block of length `5^q`.

No automatic-sequence hypothesis is used yet; Stage 4S is still a purely
Collatz-invariance consequence.
-/

/--
Base-5 aligned natural invariant block.

For every `q`, a shortcut-invariant coloring contains a complete monochromatic
block of length `5^q` whose left endpoint is a positive multiple of `5^q`.
-/
theorem arcFiniteNaturalAlignedInvariantBlock_pow5
    {α : Type*}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (q : ℕ) :
    ∃ k : ℕ,
      0 < k
      ∧
      ∀ r : ℕ,
        r < 5 ^ q
          →
        a (5 ^ q * k)
          =
        a (5 ^ q * k + r) := by

  /-
  Ask Stage 4R for a block five times longer than the final block.
  -/
  rcases
    arcFiniteNaturalInvariantBlock_pow5
      a
      hinv
      (q + 1) with
    ⟨n, _hnpos, hblock⟩

  /-
  `B` is the target base-5 block size.
  -/
  let B : ℕ := 5 ^ q

  have hBpos :
      0 < B := by
    dsimp [B]
    positivity

  /-
  The next strictly later multiple of `B` is

      m = B * (n / B + 1).

  We deliberately choose the next multiple even when `n` itself is already
  divisible by `B`; the longer `5^(q+1)` block easily has enough room.
  -/
  let k : ℕ := n / B + 1
  let m : ℕ := B * k

  have hkpos :
      0 < k := by
    dsimp [k]
    simpa [Nat.succ_eq_add_one] using
      (Nat.zero_lt_succ (n / B))

  /-
  Euclidean division of `n` by `B`.
  -/
  have hmod :
      n % B < B :=
    Nat.mod_lt n hBpos

  have hsplit :
      n % B + B * (n / B) = n :=
    Nat.mod_add_div n B

  have hmform :
      m = B * (n / B) + B := by
    dsimp [m, k]
    ring

  /-
  Hence the next aligned point lies between `n` and `n+B`.
  -/
  have hnm :
      n ≤ m := by
    omega

  have hdelta :
      m - n ≤ B := by
    omega

  /-
  The Stage-4R block has length `5^(q+1) = 5B`.
  In particular, a displacement smaller than `2B` is safely inside it.
  -/
  have hlong :
      2 * B < 5 ^ (q + 1) := by
    calc
      2 * B < 5 * B := by
        omega
      _ = 5 ^ (q + 1) := by
        dsimp [B]
        rw [pow_succ]
        ring

  refine
    ⟨k,
     hkpos,
     ?_⟩

  intro r hr

  /-
  First connect the original Stage-4R start `n` to the aligned start `m`.
  -/
  have hj0 :
      m - n < 5 ^ (q + 1) := by
    omega

  have h0raw :
      a n = a (n + (m - n)) :=
    hblock
      (m - n)
      hj0

  have hsum0 :
      n + (m - n) = m := by
    omega

  have h0 :
      a n = a m := by
    calc
      a n
          =
      a (n + (m - n)) :=
        h0raw
      _ =
      a m := by
        rw [hsum0]

  /-
  Now connect `n` to every point `m+r` in the aligned block.
  Since `m-n ≤ B` and `r < B`, the total displacement is `< 2B`,
  hence still `< 5^(q+1)`.
  -/
  have hnmr :
      n ≤ m + r := by
    omega

  have hjrSmall :
      m + r - n < 2 * B := by
    omega

  have hjr :
      m + r - n < 5 ^ (q + 1) := by
    omega

  have hrRaw :
      a n = a (n + (m + r - n)) :=
    hblock
      (m + r - n)
      hjr

  have hsumr :
      n + (m + r - n) = m + r := by
    omega

  have hrFromN :
      a n = a (m + r) := by
    calc
      a n
          =
      a (n + (m + r - n)) :=
        hrRaw
      _ =
      a (m + r) := by
        rw [hsumr]

  have hfinal :
      a m = a (m + r) := by
    calc
      a m = a n := h0.symm
      _ = a (m + r) := hrFromN

  simpa [m, B] using hfinal


/--
Equivalent packaging: there is a positive aligned starting index `N` which is
explicitly a multiple of `5^q`, and the whole following `5^q`-block is
monochromatic.
-/
theorem arcFiniteNaturalAlignedStart_pow5
    {α : Type*}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (q : ℕ) :
    ∃ N : ℕ,
      0 < N
      ∧
      (∃ k : ℕ, N = 5 ^ q * k)
      ∧
      ∀ r : ℕ,
        r < 5 ^ q
          →
        a N = a (N + r) := by

  rcases
    arcFiniteNaturalAlignedInvariantBlock_pow5
      a
      hinv
      q with
    ⟨k, hkpos, hblock⟩

  let N : ℕ := 5 ^ q * k

  have hNpos :
      0 < N := by
    dsimp [N]
    positivity

  refine
    ⟨N,
     hNpos,
     ?_,
     ?_⟩

  · exact
      ⟨k, rfl⟩

  · intro r hr
    simpa [N] using hblock r hr


#print axioms arcFiniteNaturalAlignedInvariantBlock_pow5
#print axioms arcFiniteNaturalAlignedStart_pow5

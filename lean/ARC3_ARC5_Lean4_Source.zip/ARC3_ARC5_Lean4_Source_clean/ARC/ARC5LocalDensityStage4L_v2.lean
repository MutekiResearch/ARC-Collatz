import Mathlib
import ARC.ARC5LocalDensityStage4K_v2

set_option autoImplicit false

/-!
# ARC5 / Local-Density audit — Stage 4L

Stage 4J proved that the abstract parameter steering relation reaches equal
exponents.  Stage 4K matched each abstract constructor with one genuine
parity-word / dyadic-cylinder steering move.

This file lifts an *entire finite `arcParamReach` path*.

Starting from two equal-length realized words `u,v` with

    3^a * y' = 3^b * y + B,

every abstract path

    (a,b,B)  ->*  (A,D,E)

is realized by longer parity words `U,V`, a refinement of the original
dyadic cylinder, and genuine endpoints `z,z'` satisfying

    3^A * z' = 3^D * z + E.

As a corollary, Stage 4J's arithmetic termination theorem lifts to a genuine
finite cylinder steering theorem reaching equal odd-step counts.
-/

/-- `U` extends `u` by a finite suffix. -/
def arcWordExtends
    (u U : List Bool) : Prop :=
  ∃ w : List Bool, U = u ++ w

lemma arcWordExtends_refl
    (u : List Bool) :
    arcWordExtends u u := by
  refine ⟨[], ?_⟩
  simp

/--
If `U` extends `u ++ w`, then `U` also extends `u`.
-/
lemma arcWordExtends_of_append
    {u w U : List Bool}
    (h : arcWordExtends (u ++ w) U) :
    arcWordExtends u U := by

  rcases h with ⟨t, ht⟩

  refine ⟨w ++ t, ?_⟩

  rw [ht]
  simp [List.append_assoc]

/--
Lift a complete abstract parameter path to genuine word/cylinder steering.
-/
theorem arcParamReach_realize
    {a b A D : ℕ}
    {B E : ℤ}
    (hreach :
      arcParamReach a b B A D E) :
    ∀ {u v : List Bool}
      {r N y y' : ℤ},
      u.length = v.length →
      arcOnes u = a →
      arcOnes v = b →
      arcFollowsTo u r y →
      arcFollowsTo v (r + N) y' →
      arcScaledRelation a b B y y' →
      ∃ U V : List Bool,
        ∃ s z z' : ℤ,
          arcWordExtends u U
          ∧
          arcWordExtends v V
          ∧
          U.length = V.length
          ∧
          arcOnes U = A
          ∧
          arcOnes V = D
          ∧
          arcDyadicCylinder u.length r s
          ∧
          arcFollowsTo U s z
          ∧
          arcFollowsTo V (s + N) z'
          ∧
          arcScaledRelation A D E z z' := by

  induction hreach with

  | refl a b B =>

      intro u v r N y y'
        hlen ha hb hu hv hrel

      refine
        ⟨u, v, r, y, y',
         arcWordExtends_refl u,
         arcWordExtends_refl v,
         hlen,
         ha,
         hb,
         ?_,
         hu,
         hv,
         hrel⟩

      exact ⟨0, by ring⟩

  | @step00 a b A D B C E hBC hrest ih =>

      intro u v r N y y'
        hlen ha hb hu hv hrel

      rcases
        arcSteer00_exact
          hlen
          ha
          hb
          hu
          hv
          hrel
          hBC with
        ⟨s, p, p',
         hs, hlen1, hu1, hv1, hrel1⟩

      have ha1 :
          arcOnes (u ++ [false]) = a := by
        simpa [arcOnes_append_false] using ha

      have hb1 :
          arcOnes (v ++ [false]) = b := by
        simpa [arcOnes_append_false] using hb

      rcases
        ih
          hlen1
          ha1
          hb1
          hu1
          hv1
          hrel1 with
        ⟨U, V, t, z, z',
         hUext1, hVext1,
         hUVlen, hUA, hVD,
         htChild,
         hUz, hVz, hrelFinal⟩

      have htParent :
          arcDyadicCylinder u.length r t :=
        arcChildCylinder_subset_parent
          hs
          htChild

      refine
        ⟨U, V, t, z, z',
         ?_,
         ?_,
         hUVlen,
         hUA,
         hVD,
         htParent,
         hUz,
         hVz,
         hrelFinal⟩

      · exact
          arcWordExtends_of_append
            (u := u)
            (w := [false])
            hUext1

      · exact
          arcWordExtends_of_append
            (u := v)
            (w := [false])
            hVext1

  | @step01 a b A D B C E hC hrest ih =>

      intro u v r N y y'
        hlen ha hb hu hv hrel

      rcases
        arcSteer01_exact
          hlen
          ha
          hb
          hu
          hv
          hrel
          hC with
        ⟨s, p, p',
         hs, hlen1, hu1, hv1, hrel1⟩

      have ha1 :
          arcOnes (u ++ [false]) = a := by
        simpa [arcOnes_append_false] using ha

      have hb1 :
          arcOnes (v ++ [true]) = b + 1 := by
        rw [arcOnes_append_true, hb]

      rcases
        ih
          hlen1
          ha1
          hb1
          hu1
          hv1
          hrel1 with
        ⟨U, V, t, z, z',
         hUext1, hVext1,
         hUVlen, hUA, hVD,
         htChild,
         hUz, hVz, hrelFinal⟩

      have htParent :
          arcDyadicCylinder u.length r t :=
        arcChildCylinder_subset_parent
          hs
          htChild

      refine
        ⟨U, V, t, z, z',
         ?_,
         ?_,
         hUVlen,
         hUA,
         hVD,
         htParent,
         hUz,
         hVz,
         hrelFinal⟩

      · exact
          arcWordExtends_of_append
            (u := u)
            (w := [false])
            hUext1

      · exact
          arcWordExtends_of_append
            (u := v)
            (w := [true])
            hVext1

  | @step10 a b A D B C E hC hrest ih =>

      intro u v r N y y'
        hlen ha hb hu hv hrel

      rcases
        arcSteer10_exact
          hlen
          ha
          hb
          hu
          hv
          hrel
          hC with
        ⟨s, p, p',
         hs, hlen1, hu1, hv1, hrel1⟩

      have ha1 :
          arcOnes (u ++ [true]) = a + 1 := by
        rw [arcOnes_append_true, ha]

      have hb1 :
          arcOnes (v ++ [false]) = b := by
        simpa [arcOnes_append_false] using hb

      rcases
        ih
          hlen1
          ha1
          hb1
          hu1
          hv1
          hrel1 with
        ⟨U, V, t, z, z',
         hUext1, hVext1,
         hUVlen, hUA, hVD,
         htChild,
         hUz, hVz, hrelFinal⟩

      have htParent :
          arcDyadicCylinder u.length r t :=
        arcChildCylinder_subset_parent
          hs
          htChild

      refine
        ⟨U, V, t, z, z',
         ?_,
         ?_,
         hUVlen,
         hUA,
         hVD,
         htParent,
         hUz,
         hVz,
         hrelFinal⟩

      · exact
          arcWordExtends_of_append
            (u := u)
            (w := [true])
            hUext1

      · exact
          arcWordExtends_of_append
            (u := v)
            (w := [false])
            hVext1

  | @step11zero a b A D E C hC hrest ih =>

      intro u v r N y y'
        hlen ha hb hu hv hrel

      rcases
        arcSteer11_exact
          hlen
          ha
          hb
          hu
          hv
          hrel
          hC with
        ⟨s, p, p',
         hs, hlen1, hu1, hv1, hrel1⟩

      have ha1 :
          arcOnes (u ++ [true]) = a + 1 := by
        rw [arcOnes_append_true, ha]

      have hb1 :
          arcOnes (v ++ [true]) = b + 1 := by
        rw [arcOnes_append_true, hb]

      rcases
        ih
          hlen1
          ha1
          hb1
          hu1
          hv1
          hrel1 with
        ⟨U, V, t, z, z',
         hUext1, hVext1,
         hUVlen, hUA, hVD,
         htChild,
         hUz, hVz, hrelFinal⟩

      have htParent :
          arcDyadicCylinder u.length r t :=
        arcChildCylinder_subset_parent
          hs
          htChild

      refine
        ⟨U, V, t, z, z',
         ?_,
         ?_,
         hUVlen,
         hUA,
         hVD,
         htParent,
         hUz,
         hVz,
         hrelFinal⟩

      · exact
          arcWordExtends_of_append
            (u := u)
            (w := [true])
            hUext1

      · exact
          arcWordExtends_of_append
            (u := v)
            (w := [true])
            hVext1

/--
Genuine steering to equal odd-step counts.

This is the cylinder/word lift of `arcParamReach_balanced`.
-/
theorem arcSteer_to_balanced
    {a b : ℕ}
    {u v : List Bool}
    {r N y y' B : ℤ}
    (hlen : u.length = v.length)
    (ha : arcOnes u = a)
    (hb : arcOnes v = b)
    (hu : arcFollowsTo u r y)
    (hv : arcFollowsTo v (r + N) y')
    (hrel :
      arcScaledRelation a b B y y') :
    ∃ A : ℕ,
      ∃ E : ℤ,
        ∃ U V : List Bool,
          ∃ s z z' : ℤ,
            arcWordExtends u U
            ∧
            arcWordExtends v V
            ∧
            U.length = V.length
            ∧
            arcOnes U = A
            ∧
            arcOnes V = A
            ∧
            arcDyadicCylinder u.length r s
            ∧
            arcFollowsTo U s z
            ∧
            arcFollowsTo V (s + N) z'
            ∧
            arcScaledRelation A A E z z' := by

  rcases
    arcParamReach_balanced
      a
      b
      B with
    ⟨A, E, hreach⟩

  rcases
    arcParamReach_realize
      hreach
      hlen
      ha
      hb
      hu
      hv
      hrel with
    ⟨U, V, s, z, z',
     hUext, hVext,
     hUVlen, hUA, hVA,
     hs, hUz, hVz, hrelA⟩

  exact
    ⟨A, E, U, V, s, z, z',
     hUext, hVext,
     hUVlen, hUA, hVA,
     hs, hUz, hVz, hrelA⟩

#print axioms arcWordExtends_of_append
#print axioms arcParamReach_realize
#print axioms arcSteer_to_balanced

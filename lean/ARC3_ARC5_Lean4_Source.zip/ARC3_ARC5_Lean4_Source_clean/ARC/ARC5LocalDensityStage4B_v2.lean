import Mathlib
import ARC.ARC5LocalDensityStage4A

set_option autoImplicit false

/-!
# ARC5 / Local-Density audit — Stage 4B

Stage 4A gave an exact equivalence between dyadic word-congruence and genuine
parity-word realization.

We now begin the steering proof itself.

For two current orbit values `y` and `y'`, the convenient denominator-free
state is

    3^a * y' = 3^b * y + B.

The exponent imbalance `b-a` is the integer analogue of the rational
coefficient exponent `d` in

    y' = 3^d y + beta.

This file verifies the four exact one-step transition identities.  They are
the algebraic engine for the later steering argument.

Branch equations:
  0-branch at y  : y = 2 z
  1-branch at y  : 3 y + 1 = 2 z

and similarly for y'.
-/

/-- Denominator-free steering relation. -/
def arcScaledRelation
    (a b : ℕ)
    (B y y' : ℤ) : Prop :=
  (3 : ℤ) ^ a * y'
    =
  (3 : ℤ) ^ b * y + B

/--
The trivial initial scaled relation between two integers.
-/
lemma arcScaledRelation_initial
    (y y' : ℤ) :
    arcScaledRelation 0 0 (y' - y) y y' := by
  simp [arcScaledRelation]

/--
00 transition: both current values take the even branch.

If `B = 2 C`, then the new offset is `C` and the exponents are unchanged.
-/
lemma arcScaledRelation_step00
    {a b : ℕ}
    {B C y y' z z' : ℤ}
    (hrel : arcScaledRelation a b B y y')
    (hy : y = 2 * z)
    (hy' : y' = 2 * z')
    (hB : B = 2 * C) :
    arcScaledRelation a b C z z' := by

  unfold arcScaledRelation at hrel ⊢

  have h2 :
      2 * ((3 : ℤ) ^ a * z')
        =
      2 * ((3 : ℤ) ^ b * z + C) := by
    calc
      2 * ((3 : ℤ) ^ a * z')
          = (3 : ℤ) ^ a * y' := by
              rw [hy']
              ring
      _ = (3 : ℤ) ^ b * y + B := hrel
      _ = 2 * ((3 : ℤ) ^ b * z + C) := by
              rw [hy, hB]
              ring

  apply mul_left_cancel₀ (show (2 : ℤ) ≠ 0 by norm_num)
  exact h2

/--
01 transition: y takes the even branch and y' takes the odd branch.

The exponent `b` rises by one.  The new offset `C` is characterized by

    2 C = 3 B + 3^a.
-/
lemma arcScaledRelation_step01
    {a b : ℕ}
    {B C y y' z z' : ℤ}
    (hrel : arcScaledRelation a b B y y')
    (hy : y = 2 * z)
    (hy' : 3 * y' + 1 = 2 * z')
    (hC : 2 * C = 3 * B + (3 : ℤ) ^ a) :
    arcScaledRelation a (b + 1) C z z' := by

  unfold arcScaledRelation at hrel ⊢

  have h2 :
      2 * ((3 : ℤ) ^ a * z')
        =
      2 * ((3 : ℤ) ^ (b + 1) * z + C) := by
    calc
      2 * ((3 : ℤ) ^ a * z')
          = (3 : ℤ) ^ a * (3 * y' + 1) := by
              rw [hy']
              ring
      _ = 3 * ((3 : ℤ) ^ a * y') + (3 : ℤ) ^ a := by
              ring
      _ = 3 * ((3 : ℤ) ^ b * y + B) + (3 : ℤ) ^ a := by
              rw [hrel]
      _ = 3 * ((3 : ℤ) ^ b * (2 * z) + B) + (3 : ℤ) ^ a := by
              rw [hy]
      _ = 2 * ((3 : ℤ) ^ (b + 1) * z) + (3 * B + (3 : ℤ) ^ a) := by
              rw [pow_succ]
              ring
      _ = 2 * ((3 : ℤ) ^ (b + 1) * z) + 2 * C := by
              rw [hC]
      _ = 2 * ((3 : ℤ) ^ (b + 1) * z + C) := by
              ring

  apply mul_left_cancel₀ (show (2 : ℤ) ≠ 0 by norm_num)
  exact h2

/--
10 transition: y takes the odd branch and y' takes the even branch.

The exponent `a` rises by one.  The new offset `C` is characterized by

    2 C = 3 B - 3^b.
-/
lemma arcScaledRelation_step10
    {a b : ℕ}
    {B C y y' z z' : ℤ}
    (hrel : arcScaledRelation a b B y y')
    (hy : 3 * y + 1 = 2 * z)
    (hy' : y' = 2 * z')
    (hC : 2 * C = 3 * B - (3 : ℤ) ^ b) :
    arcScaledRelation (a + 1) b C z z' := by

  unfold arcScaledRelation at hrel ⊢

  have h2 :
      2 * ((3 : ℤ) ^ (a + 1) * z')
        =
      2 * ((3 : ℤ) ^ b * z + C) := by
    calc
      2 * ((3 : ℤ) ^ (a + 1) * z')
          = 3 * ((3 : ℤ) ^ a * y') := by
              rw [pow_succ, hy']
              ring
      _ = 3 * ((3 : ℤ) ^ b * y + B) := by
              rw [hrel]
      _ = (3 : ℤ) ^ b * (3 * y) + 3 * B := by
              ring
      _ = (3 : ℤ) ^ b * (2 * z - 1) + 3 * B := by
              rw [show 3 * y = 2 * z - 1 by linarith [hy]]
      _ = 2 * ((3 : ℤ) ^ b * z) + (3 * B - (3 : ℤ) ^ b) := by
              ring
      _ = 2 * ((3 : ℤ) ^ b * z) + 2 * C := by
              rw [hC]
      _ = 2 * ((3 : ℤ) ^ b * z + C) := by
              ring

  apply mul_left_cancel₀ (show (2 : ℤ) ≠ 0 by norm_num)
  exact h2

/--
11 transition: both current values take the odd branch.

The exponents are unchanged.  The new offset `C` is characterized by

    2 C = 3 B + 3^a - 3^b.
-/
lemma arcScaledRelation_step11
    {a b : ℕ}
    {B C y y' z z' : ℤ}
    (hrel : arcScaledRelation a b B y y')
    (hy : 3 * y + 1 = 2 * z)
    (hy' : 3 * y' + 1 = 2 * z')
    (hC :
      2 * C
        =
      3 * B + (3 : ℤ) ^ a - (3 : ℤ) ^ b) :
    arcScaledRelation a b C z z' := by

  unfold arcScaledRelation at hrel ⊢

  have h2 :
      2 * ((3 : ℤ) ^ a * z')
        =
      2 * ((3 : ℤ) ^ b * z + C) := by
    calc
      2 * ((3 : ℤ) ^ a * z')
          = (3 : ℤ) ^ a * (3 * y' + 1) := by
              rw [hy']
              ring
      _ = 3 * ((3 : ℤ) ^ a * y') + (3 : ℤ) ^ a := by
              ring
      _ = 3 * ((3 : ℤ) ^ b * y + B) + (3 : ℤ) ^ a := by
              rw [hrel]
      _ = (3 : ℤ) ^ b * (3 * y) + 3 * B + (3 : ℤ) ^ a := by
              ring
      _ = (3 : ℤ) ^ b * (2 * z - 1) + 3 * B + (3 : ℤ) ^ a := by
              rw [show 3 * y = 2 * z - 1 by linarith [hy]]
      _ = 2 * ((3 : ℤ) ^ b * z)
            + (3 * B + (3 : ℤ) ^ a - (3 : ℤ) ^ b) := by
              ring
      _ = 2 * ((3 : ℤ) ^ b * z) + 2 * C := by
              rw [hC]
      _ = 2 * ((3 : ℤ) ^ b * z + C) := by
              ring

  apply mul_left_cancel₀ (show (2 : ℤ) ≠ 0 by norm_num)
  exact h2

/--
When the two exponents have been synchronized and the offset is zero,
the current orbit values are equal.
-/
lemma arcScaledRelation_eq_of_balanced_zero
    {a : ℕ}
    {y y' : ℤ}
    (hrel : arcScaledRelation a a 0 y y') :
    y = y' := by

  unfold arcScaledRelation at hrel

  have hpow :
      (3 : ℤ) ^ a ≠ 0 := by
    exact pow_ne_zero _ (by norm_num)

  apply mul_left_cancel₀ hpow

  simpa using hrel.symm

#print axioms arcScaledRelation_step00
#print axioms arcScaledRelation_step01
#print axioms arcScaledRelation_step10
#print axioms arcScaledRelation_step11
#print axioms arcScaledRelation_eq_of_balanced_zero

import Mathlib
import ARC.ARC5Stage5I_FiniteDisagreementHandoff

set_option autoImplicit false

/-!
# ARC5 — Stage 5J
## Arithmetic core for odd-base topological pumping

Stage 5I isolated the missing principle

    5-automatic + dyadically nowhere thick  ==>  finite support.

The automata-theoretic side of that principle will come from a pumping
argument.  If an accepted base-5 word contains a pumpable nonempty block of
length `L`, the corresponding accepted integers lie in a family whose
successive structure is governed by the geometric sum

    1 + c + ... + c^(k-1),   c = 5^L.

The purpose of Stage 5J is to formalize the arithmetic fact behind the
2-adic part of this argument:

* `c = 5^L` is `1 mod 4`;
* if `h = 2^t * odd`, then
      1 + c + ... + c^(h-1)
  is also exactly `2^t * odd`;
* therefore the pumped family has exact dyadic displacement controlled by
  the 2-adic order of the pumping-count difference.

No automaton pumping theorem is assumed here.
-/

/-!
============================================================
1. Finite geometric sums
============================================================
-/

/--
`ARC5GeomSum c n = 1 + c + ... + c^(n-1)`.
-/
def ARC5GeomSum (c : ℕ) : ℕ → ℕ
  | 0 => 0
  | n + 1 => ARC5GeomSum c n + c ^ n

@[simp]
lemma arc5_geomSum_zero
    (c : ℕ) :
    ARC5GeomSum c 0 = 0 := by
  rfl

@[simp]
lemma arc5_geomSum_succ
    (c n : ℕ) :
    ARC5GeomSum c (n + 1)
      =
    ARC5GeomSum c n + c ^ n := by
  rfl

/--
Additive splitting of a geometric sum.
-/
theorem arc5_geomSum_add
    (c m n : ℕ) :
    ARC5GeomSum c (m + n)
      =
    ARC5GeomSum c m
      + c ^ m * ARC5GeomSum c n := by

  induction n with
  | zero =>
      simp
  | succ n ih =>
      rw [Nat.add_succ]
      rw [arc5_geomSum_succ]
      rw [ih]
      rw [arc5_geomSum_succ]
      rw [pow_add]
      ring

/--
Block decomposition of a geometric sum.
-/
theorem arc5_geomSum_mul
    (c m n : ℕ) :
    ARC5GeomSum c (m * n)
      =
    ARC5GeomSum c m
      * ARC5GeomSum (c ^ m) n := by

  induction n with
  | zero =>
      simp
  | succ n ih =>
      rw [Nat.mul_succ]
      rw [arc5_geomSum_add]
      rw [ih]
      rw [arc5_geomSum_succ]
      rw [pow_mul]
      ring


/-!
============================================================
2. Odd powers
============================================================
-/

/--
A power of a number congruent to `1 mod 2` is again `1 mod 2`.
-/
lemma arc5_pow_two_add_one
    (a n : ℕ) :
    ∃ b : ℕ,
      (2 * a + 1) ^ n = 2 * b + 1 := by

  induction n with
  | zero =>
      exact ⟨0, by simp⟩
  | succ n ih =>
      rcases ih with ⟨b, hb⟩
      refine
        ⟨2 * a * b + a + b, ?_⟩
      rw [pow_succ, hb]
      ring

/--
A power of a number congruent to `1 mod 4` is again `1 mod 4`.
-/
lemma arc5_pow_four_add_one
    (a n : ℕ) :
    ∃ b : ℕ,
      (4 * a + 1) ^ n = 4 * b + 1 := by

  induction n with
  | zero =>
      exact ⟨0, by simp⟩
  | succ n ih =>
      rcases ih with ⟨b, hb⟩
      refine
        ⟨4 * a * b + a + b, ?_⟩
      rw [pow_succ, hb]
      ring

/--
Every power `5^L` is congruent to `1 mod 4`.
-/
lemma arc5_pow5_four_add_one
    (L : ℕ) :
    ∃ a : ℕ,
      5 ^ L = 4 * a + 1 := by

  simpa using
    (arc5_pow_four_add_one 1 L)


/-!
============================================================
3. Parity of odd-base geometric sums
============================================================
-/

/--
For an odd base `2a+1`, the geometric sum differs from its length by an even
number.
-/
lemma arc5_geomSum_two_add_one
    (a n : ℕ) :
    ∃ b : ℕ,
      ARC5GeomSum (2 * a + 1) n
        =
      2 * b + n := by

  induction n with
  | zero =>
      exact ⟨0, by simp⟩
  | succ n ih =>
      rcases ih with ⟨b, hb⟩
      rcases
        arc5_pow_two_add_one a n with
        ⟨p, hp⟩

      refine
        ⟨b + p, ?_⟩

      rw [arc5_geomSum_succ, hb, hp]
      ring

/--
An odd number of terms in an odd-base geometric sum gives an odd result.
-/
lemma arc5_geomSum_odd_length
    (a u : ℕ) :
    ∃ b : ℕ,
      ARC5GeomSum
          (2 * a + 1)
          (2 * u + 1)
        =
      2 * b + 1 := by

  rcases
    arc5_geomSum_two_add_one
      a
      (2 * u + 1) with
    ⟨b, hb⟩

  refine
    ⟨b + u, ?_⟩

  rw [hb]
  ring


/-!
============================================================
4. Exact powers of two in geometric sums for c = 1 mod 4
============================================================
-/

/--
For `c = 4a+1`, the geometric sum of length `2^t` has exactly the factor
`2^t`: its remaining factor is odd.
-/
theorem arc5_geomSum_pow_two_exact
    (a t : ℕ) :
    ∃ u : ℕ,
      ARC5GeomSum
          (4 * a + 1)
          (2 ^ t)
        =
      2 ^ t * (2 * u + 1) := by

  induction t with
  | zero =>
      exact
        ⟨0, by simp [ARC5GeomSum]⟩

  | succ t ih =>
      rcases ih with
        ⟨u, hu⟩

      rcases
        arc5_pow_four_add_one
          a
          (2 ^ t) with
        ⟨b, hb⟩

      have htwo :
          ARC5GeomSum
              ((4 * a + 1) ^ (2 ^ t))
              2
            =
          2 * (2 * b + 1) := by

        simp [ARC5GeomSum, hb]
        ring

      refine
        ⟨2 * u * b + u + b, ?_⟩

      calc
        ARC5GeomSum
            (4 * a + 1)
            (2 ^ (t + 1))
            =
        ARC5GeomSum
            (4 * a + 1)
            (2 ^ t * 2) := by
              rw [pow_succ]
        _ =
        ARC5GeomSum
            (4 * a + 1)
            (2 ^ t)
          *
        ARC5GeomSum
            ((4 * a + 1) ^ (2 ^ t))
            2 := by
              rw [arc5_geomSum_mul]
        _ =
        (2 ^ t * (2 * u + 1))
          * (2 * (2 * b + 1)) := by
              rw [hu, htwo]
        _ =
        2 ^ (t + 1)
          *
        (2 * (2 * u * b + u + b) + 1) := by
              rw [pow_succ]
              ring

/--
General exact 2-power statement.

If the length is `2^t * odd`, then the geometric sum for a base congruent to
`1 mod 4` is also `2^t * odd`.
-/
theorem arc5_geomSum_exact_two_factor
    (a t u : ℕ) :
    ∃ w : ℕ,
      ARC5GeomSum
          (4 * a + 1)
          (2 ^ t * (2 * u + 1))
        =
      2 ^ t * (2 * w + 1) := by

  rcases
    arc5_geomSum_pow_two_exact
      a
      t with
    ⟨x, hx⟩

  rcases
    arc5_pow_four_add_one
      a
      (2 ^ t) with
    ⟨b, hb⟩

  have hbaseOdd :
      (4 * a + 1) ^ (2 ^ t)
        =
      2 * (2 * b) + 1 := by
    rw [hb]
    ring

  rcases
    arc5_geomSum_odd_length
      (2 * b)
      u with
    ⟨y, hy⟩

  have hy' :
      ARC5GeomSum
          ((4 * a + 1) ^ (2 ^ t))
          (2 * u + 1)
        =
      2 * y + 1 := by

    rw [hbaseOdd]
    exact hy

  refine
    ⟨2 * x * y + x + y, ?_⟩

  calc
    ARC5GeomSum
        (4 * a + 1)
        (2 ^ t * (2 * u + 1))
        =
    ARC5GeomSum
        (4 * a + 1)
        (2 ^ t)
      *
    ARC5GeomSum
        ((4 * a + 1) ^ (2 ^ t))
        (2 * u + 1) := by
          rw [arc5_geomSum_mul]
    _ =
    (2 ^ t * (2 * x + 1))
      * (2 * y + 1) := by
          rw [hx, hy']
    _ =
    2 ^ t
      *
    (2 * (2 * x * y + x + y) + 1) := by
          ring


/-!
============================================================
5. Pumped numerical families
============================================================
-/

/--
Arithmetic model of one pumped base-5 family.

`N0` is the first value, `d` is the first increment, and `L` is the length
of the pumped block.
-/
def ARC5PumpedFamily
    (N0 d L k : ℕ) : ℕ :=
  N0
    + d * ARC5GeomSum (5 ^ L) k

/--
One pumping step adds `d * (5^L)^k`.
-/
lemma arc5_pumpedFamily_succ
    (N0 d L k : ℕ) :
    ARC5PumpedFamily
        N0 d L (k + 1)
      =
    ARC5PumpedFamily
        N0 d L k
      + d * (5 ^ L) ^ k := by

  unfold ARC5PumpedFamily
  rw [arc5_geomSum_succ]
  ring

/--
Difference formula across `h` pumping steps.
-/
theorem arc5_pumpedFamily_add
    (N0 d L k h : ℕ) :
    ARC5PumpedFamily
        N0 d L (k + h)
      =
    ARC5PumpedFamily
        N0 d L k
      +
    d * (5 ^ L) ^ k
      * ARC5GeomSum (5 ^ L) h := by

  unfold ARC5PumpedFamily
  rw [arc5_geomSum_add]
  ring


/-!
============================================================
6. Exact dyadic displacement in a pumped family
============================================================
-/

/--
If the initial increment `d` has exact factor `2^s` and the pumping-count
difference has exact factor `2^t`, then the numerical displacement has exact
factor `2^(s+t)`.
-/
theorem arc5_pumpedFamily_exact_two_factor
    (N0 d L k s v t u : ℕ)
    (hd :
      d =
        2 ^ s * (2 * v + 1)) :
    ∃ w : ℕ,
      ARC5PumpedFamily
          N0 d L
          (k + 2 ^ t * (2 * u + 1))
        =
      ARC5PumpedFamily
          N0 d L k
        +
      2 ^ (s + t) * (2 * w + 1) := by

  rcases
    arc5_pow5_four_add_one L with
    ⟨a, ha⟩

  rcases
    arc5_geomSum_exact_two_factor
      a
      t
      u with
    ⟨g, hg⟩

  have hg5 :
      ARC5GeomSum
          (5 ^ L)
          (2 ^ t * (2 * u + 1))
        =
      2 ^ t * (2 * g + 1) := by

    rw [ha]
    exact hg

  rcases
    arc5_pow_two_add_one
      (2 * a)
      k with
    ⟨p, hp⟩

  have hp5 :
      (5 ^ L) ^ k
        =
      2 * p + 1 := by

    rw [ha]
    have hbase :
        4 * a + 1
          =
        2 * (2 * a) + 1 := by
      ring
    rw [hbase]
    exact hp

  let z : ℕ :=
    2 * v * p + v + p

  have hz :
      (2 * v + 1) * (2 * p + 1)
        =
      2 * z + 1 := by
    dsimp [z]
    ring

  let w : ℕ :=
    2 * z * g + z + g

  have hw :
      (2 * z + 1) * (2 * g + 1)
        =
      2 * w + 1 := by
    dsimp [w]
    ring

  refine
    ⟨w, ?_⟩

  calc
    ARC5PumpedFamily
        N0 d L
        (k + 2 ^ t * (2 * u + 1))
        =
    ARC5PumpedFamily
        N0 d L k
      +
    d * (5 ^ L) ^ k
      *
    ARC5GeomSum
        (5 ^ L)
        (2 ^ t * (2 * u + 1)) := by
          rw [arc5_pumpedFamily_add]
    _ =
    ARC5PumpedFamily
        N0 d L k
      +
    (2 ^ s * (2 * v + 1))
      * (2 * p + 1)
      * (2 ^ t * (2 * g + 1)) := by
          rw [hd, hp5, hg5]
    _ =
    ARC5PumpedFamily
        N0 d L k
      +
    2 ^ (s + t)
      * (2 * w + 1) := by
          rw [pow_add]
          calc
            ARC5PumpedFamily N0 d L k
                + 2 ^ s * (2 * v + 1) * (2 * p + 1)
                    * (2 ^ t * (2 * g + 1))
                =
            ARC5PumpedFamily N0 d L k
                + (2 ^ s * 2 ^ t)
                    * (((2 * v + 1) * (2 * p + 1))
                        * (2 * g + 1)) := by
                          ring
            _ =
            ARC5PumpedFamily N0 d L k
                + (2 ^ s * 2 ^ t)
                    * ((2 * z + 1) * (2 * g + 1)) := by
                          rw [hz]
            _ =
            ARC5PumpedFamily N0 d L k
                + (2 ^ s * 2 ^ t)
                    * (2 * w + 1) := by
                          rw [hw]


/-!
============================================================
7. Stage-5J handoff
============================================================
-/

/--
Arithmetic core needed by the topological pumping argument.

For every nonzero-style exact two-factor decomposition of the first
increment, pumping-count differences with prescribed exact 2-order produce
numerical displacements with the correspondingly shifted exact 2-order.
-/
theorem arc5_stage5J_pumping_arithmetic_core
    (N0 d L k s v : ℕ)
    (hd :
      d =
        2 ^ s * (2 * v + 1)) :
    ∀ t u : ℕ,
      ∃ w : ℕ,
        ARC5PumpedFamily
            N0 d L
            (k + 2 ^ t * (2 * u + 1))
          =
        ARC5PumpedFamily
            N0 d L k
          +
        2 ^ (s + t) * (2 * w + 1) := by

  intro t u

  exact
    arc5_pumpedFamily_exact_two_factor
      N0
      d
      L
      k
      s
      v
      t
      u
      hd


/-!
============================================================
8. Axiom audit
============================================================
-/

#print axioms arc5_geomSum_add
#print axioms arc5_geomSum_mul
#print axioms arc5_pow5_four_add_one
#print axioms arc5_geomSum_pow_two_exact
#print axioms arc5_geomSum_exact_two_factor
#print axioms arc5_pumpedFamily_add
#print axioms arc5_pumpedFamily_exact_two_factor
#print axioms arc5_stage5J_pumping_arithmetic_core

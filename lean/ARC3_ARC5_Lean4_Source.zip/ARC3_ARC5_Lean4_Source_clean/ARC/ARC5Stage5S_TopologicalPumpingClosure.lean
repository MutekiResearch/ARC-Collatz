import Mathlib
import ARC.ARCAutomaticBridge2
import ARC.ARC5Stage5I_FiniteDisagreementHandoff
import ARC.ARC5Stage5R_InfiniteSupportLongWord_v3

set_option autoImplicit false

universe u

/-!
# ARC5 — Stage 5S
## Topological pumping closure and unconditional finite disagreement

Stage 5I introduced the standalone proposition

    ARC5OddBaseTopologicalPumpingPrinciple

as an explicit hypothesis.  Stages 5J--5R then proved its mathematical
content at the finite MSD-DFAO level.

Stage 5S closes the remaining interface gap:

    finite base-5 kernel
        -> MSD automatic
        -> finite MSD-DFAO presentation
        -> Stage 5R
        -> finite support.

Consequently the Stage-5I pumping hypothesis is discharged, and all
same-level disagreement sets are finite under the original ARC5 hypotheses
alone.

No new Collatz dynamics are introduced here.  This is an integration stage.
-/

/-!
============================================================
1. Kernel automaticity -> finite support under nowhere-thickness
============================================================
-/

/--
Kernel-level form of the Stage-5R topological pumping theorem.

A Boolean sequence with finite base-5 kernel cannot have an infinite
dyadically nowhere-thick support.
-/
theorem arc5_kernelAutomatic_nowhereThick_support_finite
    (sseq : ℕ → Bool)
    (hAuto :
      ARCAutomaticByKernel 5 sseq)
    (hthin :
      ARC5DyadicallyNowhereThick
        (ARC5BoolSupport sseq)) :
    (ARC5BoolSupport sseq).Finite := by

  have hKernel :
      (ARCKernel 5 sseq).Finite := by
    simpa [ARCAutomaticByKernel] using hAuto

  have hMSD :
      ARCMSDAutomatic 5 sseq :=
    arc_finite_kernel_implies_msd_automatic
      5
      sseq
      hKernel

  rcases hMSD with
    ⟨M, hM⟩

  letI : Finite M.State :=
    M.stateFinite

  letI : Fintype M.State :=
    Fintype.ofFinite M.State

  exact
    arc5_stage5R_msd_topological_pumping
      M
      sseq
      hM
      hthin


/-!
============================================================
2. Discharge the Stage-5I pumping hypothesis
============================================================
-/

/--
The standalone topological pumping principle introduced in Stage 5I is now a
theorem.
-/
theorem arc5_stage5S_topological_pumping_principle :
    ARC5OddBaseTopologicalPumpingPrinciple := by

  intro sseq hAuto hthin

  exact
    arc5_kernelAutomatic_nowhereThick_support_finite
      sseq
      hAuto
      hthin


/-!
============================================================
3. Same-level disagreement is unconditionally finite
============================================================
-/

/--
Under shortcut invariance and finite base-5 kernel, every disagreement set
between two states from the same exact base-5 level is finite.

The explicit Stage-5I pumping hypothesis has disappeared.
-/
theorem arc5_level_disagreement_finite_unconditional
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha5 :
      ARCAutomaticByKernel 5 a)
    (q : ℕ)
    {v w : ℕ → α}
    (hv :
      v ∈ ARC5LevelKernel q a)
    (hw :
      w ∈ ARC5LevelKernel q a) :
    (ARC5Disagree v w).Finite := by

  exact
    arc5_level_disagreement_finite
      arc5_stage5S_topological_pumping_principle
      a
      hinv
      ha5
      q
      hv
      hw


/--
Uniform exact-level form: every pair of states at every exact base-5 level
has finite disagreement.
-/
theorem arc5_stage5S_all_level_disagreements_finite
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha5 :
      ARCAutomaticByKernel 5 a) :
    ∀ q : ℕ,
      ∀ v w : ℕ → α,
        v ∈ ARC5LevelKernel q a
          →
        w ∈ ARC5LevelKernel q a
          →
        (ARC5Disagree v w).Finite := by

  exact
    arc5_stage5I_all_level_disagreements_finite
      arc5_stage5S_topological_pumping_principle
      a
      hinv
      ha5


/-!
============================================================
4. Exact finite obstruction, now unconditional
============================================================
-/

/--
Distinct same-level states can differ only on a nonempty finite set.

This is the correct endpoint: exact equality is deliberately not claimed,
because a finite boundary defect (notably at input `0`) is compatible with
the ARC target.
-/
theorem arc5_stage5S_exact_finite_obstruction
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha5 :
      ARCAutomaticByKernel 5 a)
    (q : ℕ)
    {v w : ℕ → α}
    (hv :
      v ∈ ARC5LevelKernel q a)
    (hw :
      w ∈ ARC5LevelKernel q a) :
    v = w
      ∨
    (
      (ARC5Disagree v w).Nonempty
        ∧
      (ARC5Disagree v w).Finite
    ) := by

  exact
    arc5_stage5I_exact_finite_obstruction
      arc5_stage5S_topological_pumping_principle
      a
      hinv
      ha5
      q
      hv
      hw


/-!
============================================================
5. Stage-5S unconditional handoff
============================================================
-/

/--
Stage-5S handoff.

The original ARC5 hypotheses now imply, without any additional pumping
axiom:

* the full base-5 kernel is finite;
* every same-level pair has finite disagreement.
-/
theorem arc5_stage5S_finite_disagreement_handoff
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha5 :
      ARCAutomaticByKernel 5 a) :
    (ARCKernel 5 a).Finite
      ∧
    (
      ∀ q : ℕ,
        ∀ v w : ℕ → α,
          v ∈ ARC5LevelKernel q a
            →
          w ∈ ARC5LevelKernel q a
            →
          (ARC5Disagree v w).Finite
    ) := by

  exact
    arc5_stage5I_finite_disagreement_handoff
      arc5_stage5S_topological_pumping_principle
      a
      hinv
      ha5


/-!
============================================================
6. Axiom audit
============================================================
-/

#print axioms arc5_kernelAutomatic_nowhereThick_support_finite
#print axioms arc5_stage5S_topological_pumping_principle
#print axioms arc5_level_disagreement_finite_unconditional
#print axioms arc5_stage5S_all_level_disagreements_finite
#print axioms arc5_stage5S_exact_finite_obstruction
#print axioms arc5_stage5S_finite_disagreement_handoff

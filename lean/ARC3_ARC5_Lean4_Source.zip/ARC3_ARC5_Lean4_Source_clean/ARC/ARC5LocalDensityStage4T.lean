import Mathlib
import ARC.ARC5LocalDensityStage4S_v2
import ARC.ARCAutomaticBridge2

set_option autoImplicit false

universe u

/-!
# ARC5 / Local-Density audit — Stage 4T
## Final Stage-4 interface with the 5-kernel

Stage 4S produced base-5 aligned monochromatic blocks:

    for every q,
    there is k > 0 such that
    a(5^q k) = a(5^q k + r)   for every r < 5^q.

This file packages that statement in the language of the exact depth-q
5-kernel family.

For fixed q, define the depth-q family

    u_r(n) = a(5^q n + r),     0 <= r < 5^q.

Stage 4S implies that all these depth-q residual sequences have one common
positive input k at which they take the same value.

If the full 5-kernel is finite (equivalently, in the finite-kernel
automaticity interface used elsewhere in ARC), then these exact-level
residuals are simultaneously

  * members of the finite 5-kernel, and
  * synchronized at one common positive argument.

This is the final output of the Local-Density Stage-4 chain.

Important scope note:
this theorem is the rigorous finite-state interface supplied by Local Density.
It does NOT by itself assert ultimate periodicity of the odd-indexed
subsequence.  That remaining implication is the separate ARC5 Bridge Problem.
-/

/-!
============================================================
1. Exact depth-q 5-kernel family
============================================================
-/

/--
The exact depth-`q` base-5 residual family of `a`.

An element has the form

    n ↦ a (5^q * n + r)

with `r < 5^q`.
-/
def ARC5LevelKernel
    {α : Type u}
    (q : ℕ)
    (a : ℕ → α) :
    Set (ℕ → α) :=
  {v |
    ∃ r : ℕ,
      r < 5 ^ q ∧
      ∀ n : ℕ,
        v n = a (5 ^ q * n + r)}

/--
Every exact depth-`q` base-5 residual is, of course, a member of the full
5-kernel.
-/
theorem arc5_levelKernel_subset_kernel
    {α : Type u}
    (a : ℕ → α)
    (q : ℕ) :
    ARC5LevelKernel q a ⊆ ARCKernel 5 a := by
  intro v hv

  change
    ∃ r : ℕ,
      r < 5 ^ q ∧
      ∀ n : ℕ,
        v n = a (5 ^ q * n + r)
    at hv

  rcases hv with
    ⟨r, hr, hvEq⟩

  change
    ∃ e r : ℕ,
      r < 5 ^ e ∧
      ∀ n : ℕ,
        v n = a (5 ^ e * n + r)

  exact
    ⟨q, r, hr, hvEq⟩


/-!
============================================================
2. Stage-4S synchronization, rewritten at kernel level
============================================================
-/

/--
Canonical residue form of the Stage-4S conclusion:

at every base-5 depth `q`, all residues `r,s < 5^q` agree at one common
positive quotient input `k`.
-/
theorem arc5_all_depth_residues_agree_at_positive_input
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (q : ℕ) :
    ∃ k : ℕ,
      0 < k
      ∧
      ∀ r s : ℕ,
        r < 5 ^ q
          →
        s < 5 ^ q
          →
        a (5 ^ q * k + r)
          =
        a (5 ^ q * k + s) := by

  rcases
    arcFiniteNaturalAlignedInvariantBlock_pow5
      a
      hinv
      q with
    ⟨k, hkpos, hblock⟩

  refine
    ⟨k,
     hkpos,
     ?_⟩

  intro r s hr hs

  calc
    a (5 ^ q * k + r)
        =
    a (5 ^ q * k) :=
      (hblock r hr).symm

    _ =
    a (5 ^ q * k + s) :=
      hblock s hs


/--
Kernel-family form of the same result.

For every depth `q`, all exact depth-`q` 5-kernel residual sequences take one
common value at one common positive input `k`.
-/
theorem arc5_levelKernel_common_output_at_positive_input
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (q : ℕ) :
    ∃ k : ℕ,
      0 < k
      ∧
      ∃ c : α,
        ∀ v : ℕ → α,
          v ∈ ARC5LevelKernel q a
            →
          v k = c := by

  rcases
    arcFiniteNaturalAlignedInvariantBlock_pow5
      a
      hinv
      q with
    ⟨k, hkpos, hblock⟩

  refine
    ⟨k,
     hkpos,
     a (5 ^ q * k),
     ?_⟩

  intro v hv

  change
    ∃ r : ℕ,
      r < 5 ^ q ∧
      ∀ n : ℕ,
        v n = a (5 ^ q * n + r)
    at hv

  rcases hv with
    ⟨r, hr, hvEq⟩

  calc
    v k
        =
    a (5 ^ q * k + r) :=
      hvEq k

    _ =
    a (5 ^ q * k) :=
      (hblock r hr).symm


/-!
============================================================
3. Final Stage-4 finite-kernel interface
============================================================
-/

/--
Final theorem of the Stage-4 Local-Density chain.

Assume `a` is 5-automatic in the finite-kernel formulation used by the ARC
development, and invariant under the natural shortcut Collatz map.

Then:

1. the full 5-kernel is finite;
2. at every exact base-5 depth `q`, there is a common positive input `k`
   and a common value `c`;
3. every depth-`q` residual belongs to the full finite 5-kernel and takes
   the value `c` at that same input `k`.

This is the precise handoff from Local Density to the remaining ARC5
finite-state Bridge Problem.
-/
theorem arc5_stage4_final_finite_kernel_interface
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha5 :
      ARCAutomaticByKernel 5 a) :
    (ARCKernel 5 a).Finite
      ∧
    ∀ q : ℕ,
      ∃ k : ℕ,
        0 < k
        ∧
        ∃ c : α,
          ∀ v : ℕ → α,
            v ∈ ARC5LevelKernel q a
              →
            (
              v ∈ ARCKernel 5 a
                ∧
              v k = c
            ) := by

  constructor

  · simpa [ARCAutomaticByKernel] using ha5

  · intro q

    rcases
      arc5_levelKernel_common_output_at_positive_input
        a
        hinv
        q with
      ⟨k, hkpos, c, hcommon⟩

    refine
      ⟨k,
       hkpos,
       c,
       ?_⟩

    intro v hv

    constructor

    · exact
        arc5_levelKernel_subset_kernel
          a
          q
          hv

    · exact
        hcommon
          v
          hv


/-!
============================================================
4. Axiom audit
============================================================
-/

#print axioms arc5_levelKernel_subset_kernel
#print axioms arc5_all_depth_residues_agree_at_positive_input
#print axioms arc5_levelKernel_common_output_at_positive_input
#print axioms arc5_stage4_final_finite_kernel_interface

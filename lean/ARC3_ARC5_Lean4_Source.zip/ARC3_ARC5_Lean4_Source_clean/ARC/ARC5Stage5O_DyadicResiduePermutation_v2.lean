import Mathlib
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Fintype.Card
import ARC.ARC5Stage5N_ExactDyadicPumpHandoff_v2

set_option autoImplicit false

/-!
# ARC5 — Stage 5O
## Dyadic residue permutation core

Stage 5N connected automaton pumping to the exact displacement law

    N_(k + 2^t(2u+1))
      =
    N_k + 2^(s+t)(2w+1).

Stage 5O isolates the normalized odd-increment case.  For

    P(k) = ARC5PumpedFamily 0 (2v+1) L k,

we prove that for every depth `M`, the map

    k ↦ P(k) mod 2^M

is a permutation of the `2^M` residue classes when `0 ≤ k < 2^M`.

This is the finite residue form of the 2-adic isometry behind the pumping
argument.  Stage 5P will lift this normalized permutation back through the
factor `2^s` and the offset `N0`.
-/

/-!
============================================================
1. Normalized residue map
============================================================
-/

/--
The odd-increment pumped family, reduced modulo `2^M`, on the complete index
window `0 ≤ k < 2^M`.
-/
def ARC5OddPumpResidueMap
    (v L M : ℕ) :
    Fin (2 ^ M) → Fin (2 ^ M) :=
  fun k =>
    ⟨
      ARC5PumpedFamily
          0
          (2 * v + 1)
          L
          k.val
        %
      (2 ^ M),
      Nat.mod_lt
        _
        (Nat.two_pow_pos M)
    ⟩


/-!
============================================================
2. Exact separation of two distinct indices
============================================================
-/

/--
If `i < j < 2^M`, their odd-increment pumped values are not congruent modulo
`2^M`.

The proof factors the positive index difference as

    j-i = 2^t(2u+1),

uses Stage 5J to obtain an exact value difference

    P(j)-P(i) = 2^t(2w+1),

and observes that `t < M`; hence `2^M` cannot divide that difference.
-/
theorem arc5_oddPumpResidues_ne_of_lt
    (v L M : ℕ)
    {i j : Fin (2 ^ M)}
    (hij :
      i.val < j.val) :
    ARC5OddPumpResidueMap v L M i
      ≠
    ARC5OddPumpResidueMap v L M j := by

  have hdiffPos :
      0 < j.val - i.val := by
    omega

  rcases
    arc5_exists_twoPow_mul_odd
      (j.val - i.val)
      hdiffPos with
    ⟨t, u, hdiffFactor⟩

  have hj :
      j.val
        =
      i.val + 2 ^ t * (2 * u + 1) := by

    have hbase :
        j.val = i.val + (j.val - i.val) := by
      omega

    rw [hdiffFactor] at hbase

    exact hbase

  have hdiffLt :
      j.val - i.val < 2 ^ M := by
    omega

  have hoddPos :
      0 < 2 * u + 1 := by
    omega

  have htwoLe :
      2 ^ t ≤ j.val - i.val := by

    rw [hdiffFactor]

    calc
      2 ^ t
          =
      2 ^ t * 1 := by
        simp

      _ ≤
      2 ^ t * (2 * u + 1) := by
        exact
          Nat.mul_le_mul_left
            (2 ^ t)
            (by omega)

  have htwoLt :
      2 ^ t < 2 ^ M := by
    omega

  have htM :
      t < M := by
    exact
      (Nat.pow_lt_pow_iff_right
        (by norm_num : 1 < (2 : ℕ))).mp
        htwoLt

  have hfactorOdd :
      (2 * v + 1)
        =
      2 ^ 0 * (2 * v + 1) := by
    simp

  rcases
    arc5_stage5J_pumping_arithmetic_core
      0
      (2 * v + 1)
      L
      i.val
      0
      v
      hfactorOdd
      t
      u with
    ⟨w, hdisp⟩

  have hdisp' :
      ARC5PumpedFamily
          0
          (2 * v + 1)
          L
          j.val
        =
      ARC5PumpedFamily
          0
          (2 * v + 1)
          L
          i.val
        +
      2 ^ t * (2 * w + 1) := by

    simpa [hj] using hdisp

  intro hEq

  have hrem :
      ARC5PumpedFamily
          0
          (2 * v + 1)
          L
          i.val
        %
      (2 ^ M)
        =
      ARC5PumpedFamily
          0
          (2 * v + 1)
          L
          j.val
        %
      (2 ^ M) := by

    have hval :=
      congrArg Fin.val hEq

    simpa [ARC5OddPumpResidueMap] using hval

  have hmod :
      ARC5PumpedFamily
          0
          (2 * v + 1)
          L
          i.val
        ≡
      ARC5PumpedFamily
          0
          (2 * v + 1)
          L
          j.val
        [MOD 2 ^ M] := by

    exact hrem

  have hdvd :
      2 ^ M
        ∣
      2 ^ t * (2 * w + 1) := by

    have hdvdRaw :=
      hmod.dvd'

    rw [hdisp'] at hdvdRaw

    simpa using hdvdRaw

  have htLe :
      t ≤ M := by
    omega

  have hMsplit :
      M = t + (M - t) := by
    omega

  have hdvdFactored :
      2 ^ t * 2 ^ (M - t)
        ∣
      2 ^ t * (2 * w + 1) := by

    rw [hMsplit] at hdvd

    simpa [pow_add] using hdvd

  have htailDvd :
      2 ^ (M - t)
        ∣
      2 * w + 1 := by

    exact
      Nat.dvd_of_mul_dvd_mul_left
        (Nat.two_pow_pos t)
        hdvdFactored

  have htailPos :
      0 < M - t := by
    omega

  have honeLe :
      1 ≤ M - t := by
    omega

  have htwoDvdTailPow :
      2 ∣ 2 ^ (M - t) := by

    have hpowDvd :
        2 ^ 1 ∣ 2 ^ (M - t) :=
      Nat.pow_dvd_pow
        2
        honeLe

    simpa using hpowDvd

  have htwoDvdOdd :
      2 ∣ 2 * w + 1 :=
    Nat.dvd_trans
      htwoDvdTailPow
      htailDvd

  exact
    (Nat.not_two_dvd_bit1 w)
      htwoDvdOdd


/-!
============================================================
3. Injectivity on the complete dyadic index window
============================================================
-/

/--
The normalized residue map is injective.
-/
theorem arc5_oddPumpResidueMap_injective
    (v L M : ℕ) :
    Function.Injective
      (ARC5OddPumpResidueMap v L M) := by

  intro i j hijMap

  apply Fin.ext

  by_contra hne

  rcases
    lt_or_gt_of_ne hne with
    hij | hji

  · exact
      (arc5_oddPumpResidues_ne_of_lt
        v
        L
        M
        hij)
        hijMap

  · exact
      (arc5_oddPumpResidues_ne_of_lt
        v
        L
        M
        hji)
        hijMap.symm


/-!
============================================================
4. Surjectivity / permutation
============================================================
-/

/--
Because the domain and codomain are the same finite type, injectivity implies
surjectivity.
-/
theorem arc5_oddPumpResidueMap_surjective
    (v L M : ℕ) :
    Function.Surjective
      (ARC5OddPumpResidueMap v L M) := by

  have hinj :
      Function.Injective
        (ARC5OddPumpResidueMap v L M) :=
    arc5_oddPumpResidueMap_injective
      v
      L
      M

  have hbij :
      Function.Bijective
        (ARC5OddPumpResidueMap v L M) :=
    Function.Injective.bijective_of_finite
      hinj

  exact hbij.2

/--
Every residue `r < 2^M` is hit by a unique-window pumping index
`k < 2^M`.
-/
theorem arc5_oddPumpResidueMap_hits_every_residue
    (v L M : ℕ)
    (r : Fin (2 ^ M)) :
    ∃ k : Fin (2 ^ M),
      ARC5PumpedFamily
          0
          (2 * v + 1)
          L
          k.val
        %
      (2 ^ M)
        =
      r.val := by

  rcases
    arc5_oddPumpResidueMap_surjective
      v
      L
      M
      r with
    ⟨k, hk⟩

  refine
    ⟨k, ?_⟩

  have hval :=
    congrArg Fin.val hk

  simpa [ARC5OddPumpResidueMap] using hval


/-!
============================================================
5. Stage-5O handoff
============================================================
-/

/--
Stage-5O dyadic permutation core:

for every `M`, the first `2^M` values of an odd-increment Stage-5J pumped
family hit all residues modulo `2^M` exactly once.
-/
theorem arc5_stage5O_dyadic_residue_permutation
    (v L M : ℕ) :
    Function.Bijective
      (ARC5OddPumpResidueMap v L M) := by

  constructor

  · exact
      arc5_oddPumpResidueMap_injective
        v
        L
        M

  · exact
      arc5_oddPumpResidueMap_surjective
        v
        L
        M


/-!
============================================================
6. Axiom audit
============================================================
-/

#print axioms arc5_oddPumpResidues_ne_of_lt
#print axioms arc5_oddPumpResidueMap_injective
#print axioms arc5_oddPumpResidueMap_surjective
#print axioms arc5_oddPumpResidueMap_hits_every_residue
#print axioms arc5_stage5O_dyadic_residue_permutation

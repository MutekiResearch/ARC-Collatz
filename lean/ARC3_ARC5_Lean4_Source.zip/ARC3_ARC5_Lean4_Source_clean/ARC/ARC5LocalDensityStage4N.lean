import Mathlib
import ARC.ARC5LocalDensityStage4M

set_option autoImplicit false

/-!
# ARC5 / Local-Density audit — Stage 4N

Stage 4M reached a balanced state inside an arbitrarily prescribed parent
dyadic cylinder.

The remaining "exit bridge" must attach a finite coalescing suffix to one of
the balanced endpoints.  Before doing that, this file proves the general
suffix-forcing infrastructure:

* any prescribed finite parity suffix can be forced by refining inside the
  current word-cylinder;
* the final refined cylinder is contained in the original parent cylinder;
* a realization of an appended word can be split at the prefix/suffix
  boundary.

These are purely finite parity-cylinder facts.  The next stage will combine
them with the Universal Dyadic Cylinder Coalescence theorem.
-/

/--
A dyadic cylinder translates with its base point.
-/
lemma arcDyadicCylinder_add
    {L : ℕ}
    {r x N : ℤ}
    (hx : arcDyadicCylinder L r x) :
    arcDyadicCylinder L (r + N) (x + N) := by

  rcases hx with ⟨t, ht⟩

  refine ⟨t, ?_⟩

  rw [ht]
  ring

/--
Split a genuine realization of an appended word at the append boundary.
-/
theorem arcFollowsTo_split_append
    {u v : List Bool}
    {x z : ℤ}
    (h : arcFollowsTo (u ++ v) x z) :
    ∃ y : ℤ,
      arcFollowsTo u x y
      ∧
      arcFollowsTo v y z := by

  induction u generalizing x z with

  | nil =>
      have hv :
          arcFollowsTo v x z := by
        simpa using h

      refine ⟨x, ?_, hv⟩

      simp [arcFollowsTo]

  | cons b u ih =>

      cases b with

      | false =>
          rcases h with
            ⟨q, hxq, htail⟩

          rcases ih htail with
            ⟨y, huy, hv⟩

          refine
            ⟨y, ?_, hv⟩

          exact
            ⟨q, hxq, huy⟩

      | true =>
          rcases h with
            ⟨q, hxq, htail⟩

          rcases ih htail with
            ⟨y, huy, hv⟩

          refine
            ⟨y, ?_, hv⟩

          exact
            ⟨q, hxq, huy⟩

/--
Force an arbitrary finite suffix inside a realized word-cylinder.

If `r` satisfies the congruence for `w`, then there is a refined base `s`
inside the cylinder of `r` such that `w ++ q` is admissible at `s`.

Moreover, the entire final cylinder for `w ++ q` is contained in the original
parent cylinder for `w`.
-/
theorem arcWordCongruence_force_suffix :
    ∀ q : List Bool,
      ∀ w : List Bool,
        ∀ r : ℤ,
          arcWordCongruence w r →
          ∃ s : ℤ,
            arcDyadicCylinder w.length r s
            ∧
            arcWordCongruence (w ++ q) s
            ∧
            ∀ x : ℤ,
              arcDyadicCylinder (w ++ q).length s x
                →
              arcDyadicCylinder w.length r x := by

  intro q

  induction q with

  | nil =>
      intro w r hr

      refine
        ⟨r,
         ?_,
         ?_,
         ?_⟩

      · exact ⟨0, by ring⟩

      · simpa using hr

      · intro x hx
        simpa using hx

  | cons b q ih =>
      intro w r hr

      cases b with

      | false =>
          rcases
            arcWordCongruence_refine_false
              w
              r
              hr with
            ⟨s, hsParent, hsCong, hsSubset⟩

          rcases
            ih
              (w ++ [false])
              s
              hsCong with
            ⟨t, htParent, htCong, htSubset⟩

          have htOriginal :
              arcDyadicCylinder w.length r t :=
            hsSubset t htParent

          refine
            ⟨t,
             htOriginal,
             ?_,
             ?_⟩

          · simpa [List.append_assoc] using htCong

          · intro x hx

            have hx' :
                arcDyadicCylinder
                  ((w ++ [false]) ++ q).length
                  t
                  x := by
              simpa [List.append_assoc] using hx

            exact
              hsSubset
                x
                (htSubset x hx')

      | true =>
          rcases
            arcWordCongruence_refine_true
              w
              r
              hr with
            ⟨s, hsParent, hsCong, hsSubset⟩

          rcases
            ih
              (w ++ [true])
              s
              hsCong with
            ⟨t, htParent, htCong, htSubset⟩

          have htOriginal :
              arcDyadicCylinder w.length r t :=
            hsSubset t htParent

          refine
            ⟨t,
             htOriginal,
             ?_,
             ?_⟩

          · simpa [List.append_assoc] using htCong

          · intro x hx

            have hx' :
                arcDyadicCylinder
                  ((w ++ [true]) ++ q).length
                  t
                  x := by
              simpa [List.append_assoc] using hx

            exact
              hsSubset
                x
                (htSubset x hx')

/--
Realization form of arbitrary suffix forcing.
-/
theorem arcFollowsTo_force_suffix
    {w q : List Bool}
    {r y : ℤ}
    (h : arcFollowsTo w r y) :
    ∃ s z : ℤ,
      arcDyadicCylinder w.length r s
      ∧
      arcFollowsTo (w ++ q) s z
      ∧
      ∀ x : ℤ,
        arcDyadicCylinder (w ++ q).length s x
          →
        arcDyadicCylinder w.length r x := by

  have hr :
      arcWordCongruence w r :=
    arcFollowsTo_congruence h

  rcases
    arcWordCongruence_force_suffix
      q
      w
      r
      hr with
    ⟨s, hsParent, hsCong, hsSubset⟩

  rcases
    arcWordCongruence_realizes
      (w ++ q)
      s
      hsCong with
    ⟨z, hsz⟩

  exact
    ⟨s, z,
     hsParent,
     hsz,
     hsSubset⟩

/--
After forcing a suffix, expose the intermediate endpoint at the old prefix.
-/
theorem arcFollowsTo_force_suffix_split
    {w q : List Bool}
    {r y : ℤ}
    (h : arcFollowsTo w r y) :
    ∃ s mid z : ℤ,
      arcDyadicCylinder w.length r s
      ∧
      arcFollowsTo w s mid
      ∧
      arcFollowsTo q mid z
      ∧
      arcFollowsTo (w ++ q) s z
      ∧
      ∀ x : ℤ,
        arcDyadicCylinder (w ++ q).length s x
          →
        arcDyadicCylinder w.length r x := by

  rcases
    arcFollowsTo_force_suffix
      (q := q)
      h with
    ⟨s, z, hsParent, hfull, hsSubset⟩

  rcases
    arcFollowsTo_split_append
      hfull with
    ⟨mid, hprefix, hsuffix⟩

  exact
    ⟨s, mid, z,
     hsParent,
     hprefix,
     hsuffix,
     hfull,
     hsSubset⟩

#print axioms arcDyadicCylinder_add
#print axioms arcFollowsTo_split_append
#print axioms arcWordCongruence_force_suffix
#print axioms arcFollowsTo_force_suffix
#print axioms arcFollowsTo_force_suffix_split

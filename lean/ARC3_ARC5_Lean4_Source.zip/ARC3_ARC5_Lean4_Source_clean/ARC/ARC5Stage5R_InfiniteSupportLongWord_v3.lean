import Mathlib
import Mathlib.Order.Interval.Finset.Basic
import ARC.ARC5Stage5Q_NowhereThickCollision

set_option autoImplicit false

/-!
# ARC5 — Stage 5R
## Infinite support produces a long canonical base-5 support word

Stage 5Q reduced the topological pumping argument to one remaining bridge:

    infinite Boolean support
      ->
    existence of a sufficiently long canonical positive base-5 support word.

Stage 5R proves that bridge.

For a positive natural number `n`, we construct its canonical MSD base-5 word
by:

1. taking `Nat.digits 5 n` (little-endian);
2. reversing it;
3. coercing each digit to `Fin 5`.

We prove that:

* its `ARC5MSDValue` is exactly `n`;
* it is canonical positive whenever `n > 0`;
* its length is the usual base-5 digit length;
* numbers `n >= 5^Q` yield words of length at least `Q`.

Hence an infinite support, being unbounded in `ℕ`, contains a number whose
canonical base-5 word is as long as required.

Combining this with Stage 5Q gives the MSD-DFAO form of the desired
topological pumping theorem:

    finite-state MSD presentation
      +
    dyadically nowhere-thick support
      ->
    finite support.
-/

/-!
============================================================
1. Canonical base-5 word attached to a natural number
============================================================
-/

/--
A total coercion of a natural number to a base-5 digit.

For genuine base-5 digits the `% 5` is later proved to be inert.
-/
def ARC5FinDigit (d : ℕ) : Fin 5 :=
  ⟨
    d % 5,
    Nat.mod_lt d (by norm_num)
  ⟩

/--
Canonical MSD base-5 word of `n`.

`Nat.digits` is little-endian, hence the reversal.
-/
def ARC5CanonicalWordOfNat
    (n : ℕ) :
    List (Fin 5) :=
  (Nat.digits 5 n).reverse.map ARC5FinDigit


/-!
============================================================
2. The word decodes back to the original natural number
============================================================
-/

/--
On genuine base-5 digits, `ARC5FinDigit` preserves the digit value.
-/
theorem arc5_finDigit_val_of_lt
    {d : ℕ}
    (hd :
      d < 5) :
    (ARC5FinDigit d).val = d := by

  simp
    [ARC5FinDigit,
     Nat.mod_eq_of_lt hd]

/--
The digit-value list underlying `ARC5CanonicalWordOfNat n` is exactly
`Nat.digits 5 n`.
-/
theorem arc5_canonicalWordOfNat_digit_values
    (n : ℕ) :
    (
      (ARC5CanonicalWordOfNat n).reverse.map
        (fun d : Fin 5 => d.val)
    )
      =
    Nat.digits 5 n := by

  unfold ARC5CanonicalWordOfNat

  simp only
    [List.map_reverse,
     List.reverse_reverse,
     List.map_map]

  calc
    List.map
        ((fun d : Fin 5 => d.val) ∘ ARC5FinDigit)
        (Nat.digits 5 n)
      =
    List.map
        (fun d : ℕ => d)
        (Nat.digits 5 n) := by

      apply
        List.map_congr_left

      intro d hd

      simpa only [Function.comp_apply] using
        arc5_finDigit_val_of_lt
          (
            Nat.digits_lt_base
              (by norm_num : 1 < (5 : ℕ))
              hd
          )

    _ =
    Nat.digits 5 n := by
      simp

/--
The canonical MSD word decodes to exactly `n`.
-/
theorem arc5_canonicalWordOfNat_value
    (n : ℕ) :
    ARC5MSDValue
        (ARC5CanonicalWordOfNat n)
      =
    n := by

  unfold ARC5MSDValue

  rw
    [arc5_canonicalWordOfNat_digit_values]

  exact
    Nat.ofDigits_digits
      5
      n


/-!
============================================================
3. Positivity / canonical leading digit
============================================================
-/

/--
For positive `n`, the canonical MSD word has a nonzero leading digit.
-/
theorem arc5_canonicalWordOfNat_positive
    {n : ℕ}
    (hn :
      0 < n) :
    ARC5CanonicalPositiveMSDWord
      (ARC5CanonicalWordOfNat n) := by

  have hn0 :
      n ≠ 0 := by
    omega

  have hdigitsNe :
      Nat.digits 5 n ≠ [] :=
    (
      Nat.digits_ne_nil_iff_ne_zero
    ).2
      hn0

  have hrevNe :
      (Nat.digits 5 n).reverse ≠ [] := by
    simpa using hdigitsNe

  cases hrev :
      (Nat.digits 5 n).reverse with

  | nil =>

      exact
        (hrevNe hrev).elim

  | cons d ds =>

      refine
        ⟨ARC5FinDigit d,
         ds.map ARC5FinDigit,
         ?_,
         ?_⟩

      · unfold ARC5CanonicalWordOfNat

        rw [hrev]

        rfl

      · have hdLast :
            d
              =
            (Nat.digits 5 n).getLast
              hdigitsNe := by

          have hhead :=
            List.head_reverse
              hrevNe

          simpa [hrev] using hhead

        have hlastNe :
            (Nat.digits 5 n).getLast
                hdigitsNe
              ≠
            0 :=
          Nat.getLast_digit_ne_zero
            5
            hn0

        have hdNe :
            d ≠ 0 := by

          intro hd0

          apply hlastNe

          rw [← hdLast, hd0]

        have hdMem :
            d
              ∈
            Nat.digits 5 n := by

          rw [hdLast]

          exact
            List.getLast_mem
              hdigitsNe

        have hdLt :
            d < 5 :=
          Nat.digits_lt_base
            (by norm_num : 1 < (5 : ℕ))
            hdMem

        change
          0 < d % 5

        rw
          [Nat.mod_eq_of_lt hdLt]

        omega


/-!
============================================================
4. Length control
============================================================
-/

/--
The MSD word has exactly the ordinary base-5 digit length.
-/
theorem arc5_canonicalWordOfNat_length
    (n : ℕ) :
    (ARC5CanonicalWordOfNat n).length
      =
    (Nat.digits 5 n).length := by

  simp
    [ARC5CanonicalWordOfNat]

/--
If `5^Q ≤ n`, then the canonical word of `n` has length at least `Q`.
-/
theorem arc5_canonicalWordOfNat_length_ge
    (Q n : ℕ)
    (hn :
      5 ^ Q ≤ n) :
    Q
      ≤
    (ARC5CanonicalWordOfNat n).length := by

  have hlen :
      Q
        <
      (Nat.digits 5 n).length :=

    (
      Nat.lt_digits_length_iff
        (b := 5)
        (k := Q)
        (by norm_num : 1 < (5 : ℕ))
        n
    ).2
      hn

  rw
    [arc5_canonicalWordOfNat_length]

  omega


/-!
============================================================
5. Infinite support gives an arbitrarily long canonical support word
============================================================
-/

/--
An infinite Boolean support contains a canonical positive support word of
arbitrarily prescribed minimum length.
-/
theorem arc5_infinite_support_has_long_canonical_word
    (sseq : ℕ → Bool)
    (Q : ℕ)
    (hinf :
      (ARC5BoolSupport sseq).Infinite) :
    ∃ x : List (Fin 5),
      ARC5CanonicalPositiveMSDWord x
        ∧
      ARC5MSDValue x
        ∈
      ARC5BoolSupport sseq
        ∧
      Q ≤ x.length := by

  rcases
    hinf.exists_gt
      (5 ^ Q) with
    ⟨n,
     hnSupport,
     hnLarge⟩

  have hnPowPos :
      0 < 5 ^ Q :=
    pow_pos
      (by norm_num : 0 < (5 : ℕ))
      Q

  have hnPos :
      0 < n := by
    omega

  have hnPow :
      5 ^ Q ≤ n := by
    omega

  refine
    ⟨ARC5CanonicalWordOfNat n,
     arc5_canonicalWordOfNat_positive hnPos,
     ?_,
     arc5_canonicalWordOfNat_length_ge
       Q
       n
       hnPow⟩

  simpa
    [arc5_canonicalWordOfNat_value]
    using hnSupport


/-!
============================================================
6. Infinite MSD-automatic support cannot be dyadically nowhere thick
============================================================
-/

/--
If an MSD-DFAO presentation has infinite support, then its support is not
dyadically nowhere thick.
-/
theorem arc5_infinite_msd_support_not_nowhereThick
    (M : ARCMSDDFAO 5 Bool)
    [Fintype M.State]
    (sseq : ℕ → Bool)
    (hM :
      ARCMSDDFAO.Generates M sseq)
    (hinf :
      (ARC5BoolSupport sseq).Infinite) :
    ¬
      ARC5DyadicallyNowhereThick
        (ARC5BoolSupport sseq) := by

  rcases
    arc5_infinite_support_has_long_canonical_word
      sseq
      (Fintype.card M.State)
      hinf with
    ⟨x,
     hxCanonical,
     hxSupport,
     hxLength⟩

  exact
    arc5_stage5Q_long_word_collision
      M
      sseq
      hM
      x
      hxCanonical
      hxSupport
      hxLength


/-!
============================================================
7. MSD-DFAO topological pumping theorem
============================================================
-/

/--
MSD-DFAO form of the odd-base topological pumping theorem:

a Boolean sequence generated by a finite base-5 MSD automaton whose support is
dyadically nowhere thick has finite support.
-/
theorem arc5_msd_nowhereThick_support_finite
    (M : ARCMSDDFAO 5 Bool)
    [Fintype M.State]
    (sseq : ℕ → Bool)
    (hM :
      ARCMSDDFAO.Generates M sseq)
    (hthin :
      ARC5DyadicallyNowhereThick
        (ARC5BoolSupport sseq)) :
    (ARC5BoolSupport sseq).Finite := by

  by_contra hfinite

  have hinf :
      (ARC5BoolSupport sseq).Infinite :=
    (Set.not_finite).mp
      hfinite

  have hnotThin :
      ¬
      ARC5DyadicallyNowhereThick
        (ARC5BoolSupport sseq) :=

    arc5_infinite_msd_support_not_nowhereThick
      M
      sseq
      hM
      hinf

  exact
    hnotThin
      hthin


/-!
============================================================
8. Stage-5R handoff
============================================================
-/

/--
Stage-5R final handoff.

This closes the topological pumping argument at the explicit MSD-DFAO level.
The remaining integration step is only to feed an `ARCAutomaticByKernel 5`
hypothesis through the already established finite-kernel -> MSD-automatic
bridge.
-/
theorem arc5_stage5R_msd_topological_pumping
    (M : ARCMSDDFAO 5 Bool)
    [Fintype M.State]
    (sseq : ℕ → Bool)
    (hM :
      ARCMSDDFAO.Generates M sseq)
    (hthin :
      ARC5DyadicallyNowhereThick
        (ARC5BoolSupport sseq)) :
    (ARC5BoolSupport sseq).Finite := by

  exact
    arc5_msd_nowhereThick_support_finite
      M
      sseq
      hM
      hthin


/-!
============================================================
9. Axiom audit
============================================================
-/

#print axioms arc5_finDigit_val_of_lt
#print axioms arc5_canonicalWordOfNat_digit_values
#print axioms arc5_canonicalWordOfNat_value
#print axioms arc5_canonicalWordOfNat_positive
#print axioms arc5_canonicalWordOfNat_length
#print axioms arc5_canonicalWordOfNat_length_ge
#print axioms arc5_infinite_support_has_long_canonical_word
#print axioms arc5_infinite_msd_support_not_nowhereThick
#print axioms arc5_msd_nowhereThick_support_finite
#print axioms arc5_stage5R_msd_topological_pumping

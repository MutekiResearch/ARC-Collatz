import Mathlib
import ARC.ARC3Main
import ARC.ARCAutomaticBridge5

set_option autoImplicit false

universe u

/-!
# ARC₃ adversarial-audit closure file

This file closes two interface gaps found during hostile review:

1. It proves the manuscript's *direct* intermediate statement that
   a 3-automatic Collatz-invariant sequence `a` is ultimately periodic
   (conditional on the explicit Cobham principle), rather than only
   reaching the final theorem by reusing the already-verified ARC₂ theorem.

2. It states ARC₃ using the canonical MSD automaticity conventions already
   formalized in AutomaticBridge4/5, including the common convention that
   zero is represented by the one-digit word `[0]`.
-/

/--
Direct manuscript-form Corollary 3.3 for ARC₃:
finite 3-kernel + Collatz invariance forces finite 2-kernel, hence `a` is
both 2- and 3-automatic; Cobham then makes `a` ultimately periodic.
-/
theorem arc3_direct_ultimately_periodic_of_cobham
    {α : Type u}
    [Finite α]
    (hCobham : ARCCobhamPrinciple.{u})
    (a : ℕ → α)
    (hEven : ∀ n : ℕ, a (2 * n) = a n)
    (hOdd : ∀ n : ℕ, a (2 * n + 1) = a (3 * n + 2))
    (ha3 : ARCAutomaticByKernel 3 a) :
    ARCUltimatelyPeriodic a := by

  have ha2 : ARCAutomaticByKernel 2 a :=
    arc3_three_automatic_kernel_implies_two_automatic_kernel
      a hEven hOdd ha3

  have hAuto2 : ARCMSDAutomatic 2 a := by
    exact arc_finite_kernel_implies_msd_automatic 2 a ha2

  have hAuto3 : ARCMSDAutomatic 3 a := by
    exact arc_finite_kernel_implies_msd_automatic 3 a ha3

  unfold ARCCobhamPrinciple at hCobham

  exact
    hCobham
      (β := α)
      (k := 2)
      (l := 3)
      (by norm_num)
      (by norm_num)
      arc_two_three_multiplicatively_independent
      a
      hAuto2
      hAuto3

/--
ARC₃ with the canonical MSD convention used in AutomaticBridge4
(zero represented by the empty word in that interface).
-/
theorem arc3_main_standard_msd_form_of_cobham
    {α : Type u}
    [Finite α]
    (hCobham : ARCCobhamPrinciple.{u})
    (a : ℕ → α)
    (hEven : ∀ n : ℕ, a (2 * n) = a n)
    (hOdd : ∀ n : ℕ, a (2 * n + 1) = a (3 * n + 2))
    (ha3 : ARCStandardMSDAutomatic 3 a) :
    ∃ c : α, ∀ N : ℕ, 1 ≤ N → a N = c := by

  have hAll : ARCMSDAutomatic 3 a :=
    arc_standard_msd_automatic_implies_msd_automatic a ha3

  exact
    arc3_main_msd_form_of_cobham
      hCobham a hEven hOdd hAll

/--
ARC₃ with the usual canonical convention that zero is represented by `[0]`.
This is the interface that most closely matches the manuscript wording.
-/
theorem arc3_main_zero_digit_standard_msd_form_of_cobham
    {α : Type u}
    [Finite α]
    (hCobham : ARCCobhamPrinciple.{u})
    (a : ℕ → α)
    (hEven : ∀ n : ℕ, a (2 * n) = a n)
    (hOdd : ∀ n : ℕ, a (2 * n + 1) = a (3 * n + 2))
    (ha3 : ARCStandardMSDZeroDigitAutomatic 3 a) :
    ∃ c : α, ∀ N : ℕ, 1 ≤ N → a N = c := by

  have hAll : ARCMSDAutomatic 3 a :=
    arc_zero_digit_standard_implies_msd_automatic a ha3

  exact
    arc3_main_msd_form_of_cobham
      hCobham a hEven hOdd hAll

#print axioms arc3_direct_ultimately_periodic_of_cobham
#print axioms arc3_main_standard_msd_form_of_cobham
#print axioms arc3_main_zero_digit_standard_msd_form_of_cobham

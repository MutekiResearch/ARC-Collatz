import Mathlib
import ARC.ARC5Stage5D_FiniteRecurrence

set_option autoImplicit false

universe u

theorem arc5_natColor_iter_invariant
    {α : Type u}
    (a : ℕ → α)
    (hinv : ∀ n : ℕ, a (arcShortcutNat n) = a n) :
    ∀ h n : ℕ, a (arcShortcutNatIter h n) = a n := by
  intro h n
  exact arcNatColor_iter_invariant a hinv h n

theorem arc5_naturalInvariantBlock_in_dyadicCylinder
    {α : Type u}
    (a : ℕ → α)
    (hinv : ∀ n : ℕ, a (arcShortcutNat n) = a n)
    (H m : ℕ)
    (r : ℤ) :
    ∃ M : ℕ,
      ∃ s : ℤ,
        (∀ x : ℤ,
          arcDyadicCylinder M s x →
          arcDyadicCylinder m r x)
        ∧
        (∃ n : ℕ,
          0 < n ∧
          arcDyadicCylinder M s (n : ℤ))
        ∧
        (∀ n : ℕ,
          arcDyadicCylinder M s (n : ℤ) →
          ∀ j : ℕ,
            j ≤ H →
            a n = a (n + j)) := by

  rcases
    arcFiniteSimultaneousLocalDensity H m r with
    ⟨M, s, hParent, hCoal⟩

  rcases
    arcDyadicCylinder_has_positive_nat M s with
    ⟨n0, hn0pos, hn0Cyl⟩

  refine ⟨M, s, hParent, ⟨n0, hn0pos, hn0Cyl⟩, ?_⟩

  intro n hnCyl j hj

  by_cases hj0 : j = 0
  · subst j
    simp

  · have hjpos : 0 < j := by
      omega

    rcases hCoal j hjpos hj with ⟨h, hh⟩

    have hInt :
        arcShortcutIter h (n : ℤ) =
        arcShortcutIter h ((n + j : ℕ) : ℤ) := by
      have h0 := hh (n : ℤ) hnCyl
      simpa using h0

    have hNat :
        arcShortcutNatIter h n =
        arcShortcutNatIter h (n + j) :=
      arcShortcutNatIter_eq_of_int hInt

    have hnInv :
        a (arcShortcutNatIter h n) = a n :=
      arc5_natColor_iter_invariant a hinv h n

    have hnjInv :
        a (arcShortcutNatIter h (n + j)) = a (n + j) :=
      arc5_natColor_iter_invariant a hinv h (n + j)

    calc
      a n = a (arcShortcutNatIter h n) := hnInv.symm
      _ = a (arcShortcutNatIter h (n + j)) := by rw [hNat]
      _ = a (n + j) := hnjInv

def ARC5StrongDyadicCPS
    {α : Type u}
    (a : ℕ → α) : Prop :=
  ∀ q m : ℕ,
    ∀ r : ℤ,
      ∃ M : ℕ,
        ∃ s : ℤ,
          (∀ x : ℤ,
            arcDyadicCylinder M s x →
            arcDyadicCylinder m r x)
          ∧
          (∃ n : ℕ,
            0 < n ∧
            arcDyadicCylinder M s (n : ℤ))
          ∧
          (∀ n : ℕ,
            arcDyadicCylinder M s (n : ℤ) →
            ∀ j : ℕ,
              j < 5 ^ q →
              a n = a (n + j))

theorem arc5_strongDyadicCPS_of_shortcut_invariant
    {α : Type u}
    (a : ℕ → α)
    (hinv : ∀ n : ℕ, a (arcShortcutNat n) = a n) :
    ARC5StrongDyadicCPS a := by

  intro q m r

  rcases
    arc5_naturalInvariantBlock_in_dyadicCylinder
      a hinv (5 ^ q - 1) m r with
    ⟨M, s, hParent, hPos, hBlock⟩

  refine ⟨M, s, hParent, hPos, ?_⟩

  intro n hnCyl j hj

  have hjle : j ≤ 5 ^ q - 1 := by
    have hpow : 0 < 5 ^ q := by positivity
    omega

  exact hBlock n hnCyl j hjle

theorem arc5_strongDyadicCPS_has_positive_block
    {α : Type u}
    (a : ℕ → α)
    (hstrong : ARC5StrongDyadicCPS a)
    (q : ℕ) :
    ∃ n : ℕ,
      0 < n ∧
      ∀ j : ℕ,
        j < 5 ^ q →
        a n = a (n + j) := by

  rcases hstrong q 0 0 with
    ⟨M, s, _hParent, hPos, hBlock⟩

  rcases hPos with ⟨n, hnpos, hnCyl⟩

  exact ⟨n, hnpos, fun j hj => hBlock n hnCyl j hj⟩

theorem arc5_stage5E_strongDyadicCPS_with_recurrence
    {α : Type u}
    (a : ℕ → α)
    (hinv : ∀ n : ℕ, a (arcShortcutNat n) = a n)
    (ha5 : ARCAutomaticByKernel 5 a) :
    ARC5StrongDyadicCPS a
      ∧
    (∀ v : ℕ → α,
      v ∈ ARCKernel 5 a →
      ∀ d : Fin 5,
        ∃ i p : ℕ,
          0 < p ∧
          ∀ t : ℕ,
            ARC5FixedDigitOrbit d.val v (i + t) =
            ARC5FixedDigitOrbit d.val v (i + p + t)) := by

  constructor
  · exact arc5_strongDyadicCPS_of_shortcut_invariant a hinv
  · exact arc5_stage5D_fixed_digit_state_recurrence a ha5

#print axioms arc5_natColor_iter_invariant
#print axioms arc5_naturalInvariantBlock_in_dyadicCylinder
#print axioms arc5_strongDyadicCPS_of_shortcut_invariant
#print axioms arc5_strongDyadicCPS_has_positive_block
#print axioms arc5_stage5E_strongDyadicCPS_with_recurrence

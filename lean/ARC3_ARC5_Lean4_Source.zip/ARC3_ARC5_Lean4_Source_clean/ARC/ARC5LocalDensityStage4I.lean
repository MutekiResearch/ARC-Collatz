import Mathlib
import ARC.ARC5LocalDensityStage4H

set_option autoImplicit false

/-!
# ARC5 / Local-Density audit — Stage 4I

Stage 4H classified every unbalanced arithmetic steering state.  Before the
outer termination induction, we isolate one finite subroutine:

    every nonzero offset B can be reduced, by finitely many 00 moves,
    to an odd offset.

The proof is strong induction on `Int.natAbs B`.  Whenever B is even and
nonzero, Stage 4G/4H supplies B = 2 C with

    natAbs C < natAbs B.

Thus repeated 00 moves cannot continue forever.

This file also introduces a small arithmetic reachability relation.  Later
stages will use the same relation to concatenate 00-normalization, one 01/10
imbalance-reducing move, and the occasional 11 zero-offset kick.
-/

/--
Finite reachability under the four arithmetic steering moves.

The constructors are oriented "first move, then the rest", which makes
well-founded recursive proofs convenient.
-/
inductive arcParamReach :
    ℕ → ℕ → ℤ →
    ℕ → ℕ → ℤ →
    Prop

  | refl
      (a b : ℕ)
      (B : ℤ) :
      arcParamReach a b B a b B

  | step00
      {a b A D : ℕ}
      {B C E : ℤ}
      (hBC : B = 2 * C)
      (hrest :
        arcParamReach a b C A D E) :
      arcParamReach a b B A D E

  | step01
      {a b A D : ℕ}
      {B C E : ℤ}
      (hC :
        2 * C
          =
        3 * B + (3 : ℤ) ^ a)
      (hrest :
        arcParamReach a (b + 1) C A D E) :
      arcParamReach a b B A D E

  | step10
      {a b A D : ℕ}
      {B C E : ℤ}
      (hC :
        2 * C
          =
        3 * B - (3 : ℤ) ^ b)
      (hrest :
        arcParamReach (a + 1) b C A D E) :
      arcParamReach a b B A D E

  | step11zero
      {a b A D : ℕ}
      {E : ℤ}
      (C : ℤ)
      (hC :
        2 * C
          =
        (3 : ℤ) ^ (a + 1)
          - (3 : ℤ) ^ (b + 1))
      (hrest :
        arcParamReach (a + 1) (b + 1) C A D E) :
      arcParamReach a b 0 A D E

/--
A single 00 move is reachable.
-/
lemma arcParamReach_one00
    {a b : ℕ}
    {B C : ℤ}
    (hBC : B = 2 * C) :
    arcParamReach a b B a b C := by

  exact
    arcParamReach.step00
      hBC
      (arcParamReach.refl a b C)

/--
Strong-induction helper:
a nonzero integer offset of absolute size exactly `n` reaches an odd offset
using only 00 moves.
-/
theorem arcNormalizeOffset_nonzero_aux :
    ∀ n : ℕ,
      ∀ B : ℤ,
        B.natAbs = n →
        B ≠ 0 →
        ∀ a b : ℕ,
          ∃ C : ℤ,
            Odd C
            ∧
            arcParamReach a b B a b C := by

  intro n

  induction n using Nat.strong_induction_on with
  | h n ih =>

      intro B hAbs hB0 a b

      by_cases hEven : Even B

      · rcases
          arcParamProgress00
            hEven
            hB0 with
          ⟨C, hBC, hlt⟩

        have hC0 : C ≠ 0 := by
          intro hC
          apply hB0
          rw [hBC, hC]
          norm_num

        have hltN :
            C.natAbs < n := by
          simpa [hAbs] using hlt

        rcases
          ih
            C.natAbs
            hltN
            C
            rfl
            hC0
            a
            b with
          ⟨D, hDodd, hreach⟩

        refine
          ⟨D,
           hDodd,
           ?_⟩

        exact
          arcParamReach.step00
            hBC
            hreach

      · have hOdd : Odd B :=
          arcOdd_of_not_even hEven

        exact
          ⟨B,
           hOdd,
           arcParamReach.refl a b B⟩

/--
Every nonzero offset reaches an odd offset after finitely many 00 moves.
The exponent pair is unchanged throughout.
-/
theorem arcNormalizeOffset_nonzero
    (a b : ℕ)
    (B : ℤ)
    (hB0 : B ≠ 0) :
    ∃ C : ℤ,
      Odd C
      ∧
      arcParamReach a b B a b C := by

  exact
    arcNormalizeOffset_nonzero_aux
      B.natAbs
      B
      rfl
      hB0
      a
      b

/--
The normalization theorem preserves exponent imbalance because it preserves
the exponent pair itself.
-/
theorem arcNormalizeOffset_preserves_imbalance
    {a b : ℕ}
    {B C : ℤ}
    (_h :
      arcParamReach a b B a b C) :
    arcImbalance a b = arcImbalance a b := by

  rfl

#print axioms arcParamReach_one00
#print axioms arcNormalizeOffset_nonzero_aux
#print axioms arcNormalizeOffset_nonzero

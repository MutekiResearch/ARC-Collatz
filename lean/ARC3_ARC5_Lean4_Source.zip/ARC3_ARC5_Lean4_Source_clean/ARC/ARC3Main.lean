import Mathlib
import ARC.ARC3KernelTransfer
import ARC.ARCAutomaticBridge3

set_option autoImplicit false

universe u

/-!
# ARC₃ — main theorem bridge

This file connects the new base-3 kernel-transfer lemma to the
already verified base-2 ARC theorem.

The mathematical chain is:

    3-automatic (finite 3-kernel)
        ↓  ARC₃ kernel transfer
    2-automatic (finite 2-kernel)
        ↓  verified ARC₂ theorem, conditional on Cobham
    constant on positive integers.

Thus the genuinely new Lean obligation for ARC₃ is the transfer
K₂(a) ⊆ K₃(a), proved in `ARC3KernelTransfer.lean`.
-/


/-!
============================================================
1. Kernel-form ARC₃ theorem
============================================================
-/

/--
ARC₃ in finite-kernel form, conditional on the same explicit
Cobham principle used by the ARC₂ development.
-/
theorem arc3_main_kernel_form_of_cobham
    {α : Type u}
    [Finite α]
    (hCobham : ARCCobhamPrinciple.{u})
    (a : ℕ → α)
    (hEven :
      ∀ n : ℕ,
        a (2 * n) = a n)
    (hOdd :
      ∀ n : ℕ,
        a (2 * n + 1) =
          a (3 * n + 2))
    (ha3 :
      ARCAutomaticByKernel 3 a) :
    ∃ c : α,
      ∀ N : ℕ,
        1 ≤ N →
        a N = c := by

  have ha2 :
      ARCAutomaticByKernel 2 a :=
    arc3_three_automatic_kernel_implies_two_automatic_kernel
      a
      hEven
      hOdd
      ha3

  exact
    arc_main_kernel_form_of_cobham
      hCobham
      a
      hEven
      hOdd
      ha2


/-!
============================================================
2. Explicit MSD-automatic entrance
============================================================
-/

/--
ARC₃ with the automaticity hypothesis stated using the explicit
MSD-reading DFAO notion from the ARC automaticity bridge.
-/
theorem arc3_main_msd_form_of_cobham
    {α : Type u}
    [Finite α]
    (hCobham : ARCCobhamPrinciple.{u})
    (a : ℕ → α)
    (hEven :
      ∀ n : ℕ,
        a (2 * n) = a n)
    (hOdd :
      ∀ n : ℕ,
        a (2 * n + 1) =
          a (3 * n + 2))
    (ha3 :
      ARCMSDAutomatic 3 a) :
    ∃ c : α,
      ∀ N : ℕ,
        1 ≤ N →
        a N = c := by

  have hKernel3 :
      ARCAutomaticByKernel 3 a :=
    arc_msd_automatic_implies_finite_kernel
      (k := 3)
      (by norm_num)
      a
      ha3

  exact
    arc3_main_kernel_form_of_cobham
      hCobham
      a
      hEven
      hOdd
      hKernel3


/-!
============================================================
3. Axiom audit
============================================================
-/

#print axioms arc3_main_kernel_form_of_cobham
#print axioms arc3_main_msd_form_of_cobham

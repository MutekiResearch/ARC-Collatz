import Mathlib
import ARC.ARC5LocalDensityStage2C

set_option autoImplicit false

/-!
# ARC5 / Local-Density audit — Stage 3A

This file introduces a branch-by-branch integer realization relation.

`arcFollowsTo w x y` means that starting from the integer `x`, one may follow
exactly the branch word `w` and end at `y`, with every intermediate state
remaining integral.  The branch equations are written without integer
division:

* `false` (even branch): `x = 2 z`;
* `true`  (odd branch): `3 x + 1 = 2 z`.

Thus the relation encodes the genuine parity admissibility of the shortcut
Collatz branches.

The main theorem proves that every such genuine branch realization agrees
with the rational affine map `arcAffine` formalized in Stage 2A.

Stage 3B will prove the difficult converse/cylinder statement: each prescribed
word is realized by one complete residue class modulo `2^(word length)`, and
the translated Stage-2C witness words are realized simultaneously.
-/

/--
`arcFollowsTo w x y` means that the integer start `x` follows the exact
branch word `w` and reaches the integer endpoint `y`.
-/
def arcFollowsTo : List Bool → ℤ → ℤ → Prop
  | [], x, y =>
      y = x
  | false :: w, x, y =>
      ∃ z : ℤ,
        x = 2 * z ∧
        arcFollowsTo w z y
  | true :: w, x, y =>
      ∃ z : ℤ,
        3 * x + 1 = 2 * z ∧
        arcFollowsTo w z y

/--
A realized false branch starts from an even integer.
-/
lemma arcFollowsTo_false_even
    {w : List Bool}
    {x y : ℤ}
    (h : arcFollowsTo (false :: w) x y) :
    ∃ z : ℤ, x = 2 * z := by
  rcases h with ⟨z, hx, _⟩
  exact ⟨z, hx⟩

/--
A realized true branch starts from an odd integer, expressed as `x = 2q+1`.
-/
lemma arcFollowsTo_true_odd
    {w : List Bool}
    {x y : ℤ}
    (h : arcFollowsTo (true :: w) x y) :
    ∃ q : ℤ, x = 2 * q + 1 := by

  rcases h with ⟨z, hz, _⟩

  have hdiv : 2 ∣ x - 1 := by
    use (z - x - 1)
    linarith

  rcases hdiv with ⟨q, hq⟩
  refine ⟨q, ?_⟩
  linarith

/--
A genuine integer branch realization has exactly the value predicted by the
rational affine branch map.
-/
theorem arcFollowsTo_affine
    {w : List Bool}
    {x y : ℤ}
    (h : arcFollowsTo w x y) :
    arcAffine w (x : ℚ) = (y : ℚ) := by

  induction w generalizing x y with
  | nil =>
      simp [arcFollowsTo] at h
      subst y
      simp [arcAffine]

  | cons b w ih =>
      cases b with
      | false =>
          rcases h with ⟨z, hx, hz⟩

          have hxcast : (x : ℚ) = 2 * (z : ℚ) := by
            exact_mod_cast hx

          have hxq : (x : ℚ) / 2 = (z : ℚ) := by
            linarith

          simp only [arcAffine]
          rw [hxq]

          exact ih hz

      | true =>
          rcases h with ⟨z, hx, hz⟩

          have hxq :
              ((3 : ℚ) * (x : ℚ) + 1) / 2
                =
              (z : ℚ) := by
            have hx' :
                (3 : ℚ) * (x : ℚ) + 1
                  =
                2 * (z : ℚ) := by
              exact_mod_cast hx
            linarith

          simp only [arcAffine]
          rw [hxq]

          exact ih hz

/--
If the Stage-2 affine witness words are genuinely realized from `x` and
`x+N`, then their integer endpoints are equal.
-/
theorem arcRealizedCoalescence_of_affine
    {N : ℕ}
    {u v : List Bool}
    {x yu yv : ℤ}
    (hcoal :
      ∀ q : ℚ,
        arcAffine u q =
        arcAffine v (q + N))
    (hu : arcFollowsTo u x yu)
    (hv : arcFollowsTo v (x + (N : ℤ)) yv) :
    yu = yv := by

  have huq :
      arcAffine u (x : ℚ) = (yu : ℚ) :=
    arcFollowsTo_affine hu

  have hvq :
      arcAffine v ((x + (N : ℤ) : ℤ) : ℚ) = (yv : ℚ) :=
    arcFollowsTo_affine hv

  have hshift :
      (((x + (N : ℤ) : ℤ) : ℚ))
        =
      (x : ℚ) + (N : ℚ) := by
    norm_num

  have hmain := hcoal (x : ℚ)

  rw [hshift] at hvq

  have hyq : (yu : ℚ) = (yv : ℚ) := by
    calc
      (yu : ℚ) = arcAffine u (x : ℚ) := huq.symm
      _ = arcAffine v ((x : ℚ) + (N : ℚ)) := hmain
      _ = (yv : ℚ) := hvq

  exact_mod_cast hyq

/--
Universal word witnesses already obtained in Stage 2A have the following
semantic consequence: whenever their prescribed branch words are both
realized from starts differing by `N`, the endpoints coincide.
-/
theorem arcUniversalRealizedCoalescence
    (N : ℕ)
    (hN : 0 < N) :
    ∃ u v : List Bool,
      u.length = v.length ∧
      arcOnes u = arcOnes v ∧
      ∀ x yu yv : ℤ,
        arcFollowsTo u x yu →
        arcFollowsTo v (x + (N : ℤ)) yv →
        yu = yv := by

  rcases arcUniversalAffineCoalescence N hN with
    ⟨u, v, hlen, hones, hcoal⟩

  refine ⟨u, v, hlen, hones, ?_⟩

  intro x yu yv hu hv

  exact
    arcRealizedCoalescence_of_affine
      hcoal
      hu
      hv

#print axioms arcFollowsTo_affine
#print axioms arcUniversalRealizedCoalescence

import Mathlib
import ARC.ARC5LocalDensityStage4P_v2

set_option autoImplicit false

/-!
# ARC5 / Local-Density audit — Stage 4Q

Stage 4P proved synchronized Local Density inside every prescribed dyadic
cylinder.

This file extracts the finite simultaneous consequence needed later for ARC5.

By nesting Local Density for the shifts

    1, 2, ..., H,

we obtain one final dyadic subcylinder on which every one of those shifts
coalesces (possibly at a different finite time).

For any coloring invariant under the shortcut Collatz map, synchronized
coalescence forces equality of colors.  Hence the final cylinder is
monochromatic across every finite interval of shifts `0,...,H`.

This is the finite CPS-style consequence.  It is base-independent; the later
ARC5 stage will specialize to `H = 5^q - 1` and then use the 5-automatic
automaton structure.
-/

/--
Finite simultaneous Local Density.

For every finite shift bound `H` and every prescribed parent cylinder, there
is one child cylinder contained in the parent such that every positive shift
`j <= H` synchronously coalesces on the whole child cylinder.

The coalescence time may depend on `j`.
-/
theorem arcFiniteSimultaneousLocalDensity :
    ∀ H m : ℕ,
      ∀ r : ℤ,
        ∃ M : ℕ,
          ∃ s : ℤ,
            (
              ∀ x : ℤ,
                arcDyadicCylinder M s x
                  →
                arcDyadicCylinder m r x
            )
            ∧
            (
              ∀ j : ℕ,
                0 < j
                  →
                j ≤ H
                  →
                ∃ h : ℕ,
                  ∀ x : ℤ,
                    arcDyadicCylinder M s x
                      →
                    arcShortcutIter h x
                      =
                    arcShortcutIter h
                      (x + (j : ℤ))
            ) := by

  intro H

  induction H with

  | zero =>
      intro m r

      refine
        ⟨m, r,
         ?_,
         ?_⟩

      · intro x hx
        exact hx

      · intro j hj hle
        omega

  | succ H ih =>
      intro m r

      rcases ih m r with
        ⟨M, s,
         hParent,
         hOld⟩

      rcases
        arcLocalDensity
          (H + 1)
          (by omega)
          M
          s with
        ⟨L, t,
         hSub,
         hNew⟩

      refine
        ⟨L, t,
         ?_,
         ?_⟩

      · intro x hx

        exact
          hParent
            x
            (hSub x hx)

      · intro j hj hle

        by_cases hjTop :
            j = H + 1

        · subst j

          exact
            ⟨L,
             hNew⟩

        · have hjOld :
              j ≤ H := by
            omega

          rcases
            hOld
              j
              hj
              hjOld with
            ⟨h, hh⟩

          refine
            ⟨h,
             ?_⟩

          intro x hx

          exact
            hh
              x
              (hSub x hx)

/--
One-step shortcut invariance propagates to every finite iterate.
-/
theorem arcColor_iter_invariant
    {α : Type*}
    (c : ℤ → α)
    (hinv :
      ∀ x : ℤ,
        c (arcShortcutInt x) = c x) :
    ∀ h : ℕ,
      ∀ x : ℤ,
        c (arcShortcutIter h x) = c x := by

  intro h

  induction h with

  | zero =>
      intro x
      rfl

  | succ h ih =>
      intro x

      calc
        c (arcShortcutIter (h + 1) x)
            =
        c
          (arcShortcutIter
            h
            (arcShortcutInt x)) := by
              rfl

        _ =
        c (arcShortcutInt x) := by
          exact ih (arcShortcutInt x)

        _ =
        c x := hinv x

/--
Finite monochromatic-cylinder consequence for an invariant coloring.

Inside every prescribed parent cylinder and for every finite `H`, there is a
child cylinder such that, for every point `x` in that child cylinder,

    c(x) = c(x+j)    for all 0 <= j <= H.
-/
theorem arcFiniteInvariantBlock
    {α : Type*}
    (c : ℤ → α)
    (hinv :
      ∀ x : ℤ,
        c (arcShortcutInt x) = c x)
    (H m : ℕ)
    (r : ℤ) :
    ∃ M : ℕ,
      ∃ s : ℤ,
        (
          ∀ x : ℤ,
            arcDyadicCylinder M s x
              →
            arcDyadicCylinder m r x
        )
        ∧
        (
          ∀ x : ℤ,
            arcDyadicCylinder M s x
              →
            ∀ j : ℕ,
              j ≤ H
                →
              c x
                =
              c (x + (j : ℤ))
        ) := by

  rcases
    arcFiniteSimultaneousLocalDensity
      H
      m
      r with
    ⟨M, s,
     hParent,
     hCoal⟩

  refine
    ⟨M, s,
     hParent,
     ?_⟩

  intro x hx j hj

  by_cases hj0 : j = 0

  · subst j
    simp

  · have hjpos :
        0 < j := by
      omega

    rcases
      hCoal
        j
        hjpos
        hj with
      ⟨h, hh⟩

    have hEq :
        arcShortcutIter h x
          =
        arcShortcutIter h
          (x + (j : ℤ)) :=
      hh x hx

    have hxInv :
        c (arcShortcutIter h x)
          =
        c x :=
      arcColor_iter_invariant
        c
        hinv
        h
        x

    have hxjInv :
        c
          (arcShortcutIter h
            (x + (j : ℤ)))
          =
        c (x + (j : ℤ)) :=
      arcColor_iter_invariant
        c
        hinv
        h
        (x + (j : ℤ))

    calc
      c x
          =
      c (arcShortcutIter h x) :=
        hxInv.symm

      _ =
      c
        (arcShortcutIter h
          (x + (j : ℤ))) := by
            exact congrArg c hEq

      _ =
      c (x + (j : ℤ)) :=
        hxjInv

/--
The exact finite block length later used by ARC5.

For every `q`, an invariant coloring has a dyadic subcylinder on which every
interval of `5^q` consecutive shifts is monochromatic.
-/
theorem arcFiniteInvariantBlock_pow5
    {α : Type*}
    (c : ℤ → α)
    (hinv :
      ∀ x : ℤ,
        c (arcShortcutInt x) = c x)
    (q m : ℕ)
    (r : ℤ) :
    ∃ M : ℕ,
      ∃ s : ℤ,
        (
          ∀ x : ℤ,
            arcDyadicCylinder M s x
              →
            arcDyadicCylinder m r x
        )
        ∧
        (
          ∀ x : ℤ,
            arcDyadicCylinder M s x
              →
            ∀ j : ℕ,
              j < 5 ^ q
                →
              c x
                =
              c (x + (j : ℤ))
        ) := by

  rcases
    arcFiniteInvariantBlock
      c
      hinv
      (5 ^ q - 1)
      m
      r with
    ⟨M, s,
     hParent,
     hBlock⟩

  refine
    ⟨M, s,
     hParent,
     ?_⟩

  intro x hx j hj

  have hjle :
      j ≤ 5 ^ q - 1 := by
    have hpow :
        0 < 5 ^ q := by
      positivity
    omega

  exact
    hBlock
      x
      hx
      j
      hjle

#print axioms arcFiniteSimultaneousLocalDensity
#print axioms arcColor_iter_invariant
#print axioms arcFiniteInvariantBlock
#print axioms arcFiniteInvariantBlock_pow5

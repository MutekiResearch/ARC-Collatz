import Mathlib
import ARC.ARC5Stage5V_EventualConstancy

set_option autoImplicit false

universe u

/-!
# ARC5 — Stage 5W
## From eventual constancy to constancy on all positive integers

Stage 5V proved that an ARC5 sequence is eventually constant.

The shortcut invariance has an elementary but decisive consequence:

    shortcut(2n) = n,

hence

    a(2n) = a(n).

Repeating this gives

    a(2^k n) = a(n).

For every positive `n`, choose `k` large enough that `2^k n` lies in the
eventually constant tail.  We use the simple universal choice `k = N`,
together with the elementary inequality

    N ≤ 2^N

and `1 ≤ n`.

Therefore every positive input has the same value.  Input `0` is deliberately
left free; this is necessary because the example

    a(0) ≠ a(n) for n>0

can still be shortcut-invariant and 5-automatic.
-/

/-!
============================================================
1. The shortcut of an even double
============================================================
-/

/--
The natural shortcut map sends `2*n` back to `n`.
-/
theorem arc5_shortcut_double
    (n : ℕ) :
    arcShortcutNat (2 * n) = n := by

  simp
    [arcShortcutNat]

/--
Shortcut invariance therefore gives invariance under doubling.
-/
theorem arc5_double_invariance
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (n : ℕ) :
    a (2 * n) = a n := by

  have h :=
    hinv (2 * n)

  have h' :
      a n = a (2 * n) := by
    simpa
      [arc5_shortcut_double]
      using h

  exact
    h'.symm


/-!
============================================================
2. Iterated doubling
============================================================
-/

/--
Repeated doubling does not change the color.
-/
theorem arc5_pow_two_mul_invariance
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n) :
    ∀ k n : ℕ,
      a (2 ^ k * n) = a n := by

  intro k

  induction k with

  | zero =>

      intro n
      simp

  | succ k ih =>

      intro n

      calc
        a (2 ^ (k + 1) * n)
            =
        a (2 * (2 ^ k * n)) := by
          congr 1
          rw [pow_succ]
          ring

        _ =
        a (2 ^ k * n) :=
          arc5_double_invariance
            a
            hinv
            (2 ^ k * n)

        _ =
        a n :=
          ih n


/-!
============================================================
3. Elementary growth bound
============================================================
-/

/--
For every natural `N`, `N ≤ 2^N`.
-/
theorem arc5_nat_le_two_pow
    (N : ℕ) :
    N ≤ 2 ^ N := by

  induction N with

  | zero =>
      simp

  | succ N ih =>

      have hpowne :
          2 ^ N ≠ 0 := by
        exact
          pow_ne_zero
            N
            (by norm_num : (2 : ℕ) ≠ 0)

      have hone :
          1 ≤ 2 ^ N := by
        exact
          Nat.one_le_iff_ne_zero.mpr
            hpowne

      calc
        N + 1
            ≤
        2 ^ N + 1 :=
          Nat.add_le_add_right
            ih
            1

        _ ≤
        2 ^ N + 2 ^ N :=
          Nat.add_le_add_left
            hone
            (2 ^ N)

        _ =
        2 ^ (N + 1) := by
          rw [pow_succ]
          ring


/--
A positive `n` multiplied by `2^N` lies beyond `N`.
-/
theorem arc5_threshold_reached_by_doubling
    (N n : ℕ)
    (hn :
      0 < n) :
    N ≤ 2 ^ N * n := by

  have hpow :
      N ≤ 2 ^ N :=
    arc5_nat_le_two_pow
      N

  have hn1 :
      1 ≤ n := by
    omega

  have hmul :
      2 ^ N
        ≤
      2 ^ N * n := by

    simpa using
      Nat.mul_le_mul_left
        (2 ^ N)
        hn1

  exact
    le_trans
      hpow
      hmul


/-!
============================================================
4. Eventual constancy propagates to every positive input
============================================================
-/

/--
Shortcut invariance propagates an eventually constant tail backwards to all
positive integers.
-/
theorem arc5_positive_constant_of_eventual
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (N : ℕ)
    (c : α)
    (htail :
      ∀ n : ℕ,
        N ≤ n →
        a n = c) :
    ∀ n : ℕ,
      0 < n →
      a n = c := by

  intro n hn

  let x : ℕ :=
    2 ^ N * n

  have hxLarge :
      N ≤ x := by

    dsimp [x]

    exact
      arc5_threshold_reached_by_doubling
        N
        n
        hn

  have hxColor :
      a x = a n := by

    dsimp [x]

    exact
      arc5_pow_two_mul_invariance
        a
        hinv
        N
        n

  calc
    a n
        =
    a x :=
      hxColor.symm

    _ =
    c :=
      htail
        x
        hxLarge


/-!
============================================================
5. Final ARC5 positive-domain theorem
============================================================
-/

/--
Final positive-domain ARC5 theorem.

A base-5 finite-kernel sequence invariant under the natural shortcut Collatz
map is constant on all positive natural numbers.
-/
theorem arc5_positive_constant
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha5 :
      ARCAutomaticByKernel 5 a) :
    ∃ c : α,
      ∀ n : ℕ,
        0 < n →
        a n = c := by

  rcases
    arc5_stage5V_eventual_constancy
      a
      hinv
      ha5 with
    ⟨N,
     c,
     htail⟩

  exact
    ⟨c,
     arc5_positive_constant_of_eventual
       a
       hinv
       N
       c
       htail⟩


/--
Equivalent pairwise form: all positive inputs have the same value.
-/
theorem arc5_positive_pairwise_equal
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha5 :
      ARCAutomaticByKernel 5 a) :
    ∀ m n : ℕ,
      0 < m →
      0 < n →
      a m = a n := by

  rcases
    arc5_positive_constant
      a
      hinv
      ha5 with
    ⟨c, hc⟩

  intro m n hm hn

  calc
    a m
        =
    c :=
      hc m hm

    _ =
    a n :=
      (hc n hn).symm


/-!
============================================================
6. Stage-5W final handoff
============================================================
-/

/--
Stage-5W final handoff.

This is the target positive-domain rigidity statement for ARC5:
under base-5 finite-kernel automaticity and shortcut invariance, the sequence
has exactly one value on `ℕ_{>0}`.  No claim is made about `a 0`.
-/
theorem arc5_stage5W_positive_rigidity
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha5 :
      ARCAutomaticByKernel 5 a) :
    ∃ c : α,
      ∀ n : ℕ,
        0 < n →
        a n = c := by

  exact
    arc5_positive_constant
      a
      hinv
      ha5


/-!
============================================================
7. Axiom audit
============================================================
-/

#print axioms arc5_shortcut_double
#print axioms arc5_double_invariance
#print axioms arc5_pow_two_mul_invariance
#print axioms arc5_nat_le_two_pow
#print axioms arc5_threshold_reached_by_doubling
#print axioms arc5_positive_constant_of_eventual
#print axioms arc5_positive_constant
#print axioms arc5_positive_pairwise_equal
#print axioms arc5_stage5W_positive_rigidity

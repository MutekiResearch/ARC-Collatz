import Mathlib
import ARC.ARC5LocalDensityStage4L_v2

set_option autoImplicit false

/-!
# ARC5 / Local-Density audit — Stage 4M

Stage 4L lifted the complete finite parameter-steering path to genuine parity
words and dyadic-cylinder refinements.

To apply that theorem inside an *arbitrarily prescribed* dyadic cylinder
`C(r,m)`, we still need an initial pair of length-`m` parity words for the two
starts

    r        and        r + N.

This file supplies exactly that initialization.

No Collatz conjecture is used: every integer has a genuine next even/odd
branch, so by finite induction every integer has a realized parity word of any
prescribed finite length.

We then initialize the scaled relation with the tautological offset

    B = 3^(ones u) * y' - 3^(ones v) * y

and invoke Stage 4L.  The result is a genuine balanced steering state whose
new base point still lies inside the originally prescribed cylinder.
-/

/--
Every integer has a genuine realized parity word of every prescribed finite
length.
-/
theorem arcRealizedWord_exists :
    ∀ m : ℕ,
      ∀ x : ℤ,
        ∃ w : List Bool,
          ∃ y : ℤ,
            w.length = m
            ∧
            arcFollowsTo w x y := by

  intro m

  induction m with
  | zero =>
      intro x

      refine
        ⟨[], x, ?_, ?_⟩

      · simp

      · simp [arcFollowsTo]

  | succ m ih =>
      intro x

      by_cases hx : Even x

      · rcases arcEven_branch_exists hx with
          ⟨z, hxz⟩

        rcases ih z with
          ⟨w, y, hwlen, hwy⟩

        refine
          ⟨false :: w, y, ?_, ?_⟩

        · simp [hwlen]

        · exact
            ⟨z, hxz, hwy⟩

      · have hxOdd : Odd x :=
          (Int.not_even_iff_odd).mp hx

        rcases arcOdd_branch_exists hxOdd with
          ⟨z, hxz⟩

        rcases ih z with
          ⟨w, y, hwlen, hwy⟩

        refine
          ⟨true :: w, y, ?_, ?_⟩

        · simp [hwlen]

        · exact
            ⟨z, hxz, hwy⟩

/--
For two arbitrary starts separated by an integer gap `N`, and any prescribed
finite depth `m`, there are equal-length genuine parity words of length `m`
and a tautological scaled relation between their endpoints.
-/
theorem arcInitialPair_exists
    (m : ℕ)
    (r N : ℤ) :
    ∃ u v : List Bool,
      ∃ y y' B : ℤ,
        u.length = m
        ∧
        v.length = m
        ∧
        u.length = v.length
        ∧
        arcFollowsTo u r y
        ∧
        arcFollowsTo v (r + N) y'
        ∧
        arcScaledRelation
          (arcOnes u)
          (arcOnes v)
          B
          y
          y' := by

  rcases arcRealizedWord_exists m r with
    ⟨u, y, hulen, huy⟩

  rcases arcRealizedWord_exists m (r + N) with
    ⟨v, y', hvlen, hvy⟩

  let B : ℤ :=
    (3 : ℤ) ^ arcOnes u * y'
      -
    (3 : ℤ) ^ arcOnes v * y

  have hlen :
      u.length = v.length := by
    rw [hulen, hvlen]

  have hrel :
      arcScaledRelation
        (arcOnes u)
        (arcOnes v)
        B
        y
        y' := by

    dsimp [B]
    unfold arcScaledRelation
    ring

  exact
    ⟨u, v, y, y', B,
     hulen,
     hvlen,
     hlen,
     huy,
     hvy,
     hrel⟩

/--
Balanced steering inside an arbitrary prescribed dyadic cylinder.

Given any depth `m`, residue representative `r`, and integer gap `N`, we can
start with the first `m` genuine parity branches of `r` and `r+N`, then carry
out the finite steering procedure from Stage 4L.

The resulting base point `s` remains in the original cylinder `C(r,m)`.
-/
theorem arcPrescribedCylinder_steer_balanced
    (m : ℕ)
    (r N : ℤ) :
    ∃ A : ℕ,
      ∃ E : ℤ,
        ∃ U V : List Bool,
          ∃ s z z' : ℤ,
            U.length = V.length
            ∧
            arcOnes U = A
            ∧
            arcOnes V = A
            ∧
            arcDyadicCylinder m r s
            ∧
            arcFollowsTo U s z
            ∧
            arcFollowsTo V (s + N) z'
            ∧
            arcScaledRelation A A E z z' := by

  rcases arcInitialPair_exists m r N with
    ⟨u, v, y, y', B,
     hulen, hvlen, hlen,
     huy, hvy, hrel⟩

  rcases
    arcSteer_to_balanced
      hlen
      rfl
      rfl
      huy
      hvy
      hrel with
    ⟨A, E, U, V, s, z, z',
     hUext, hVext,
     hUVlen, hUA, hVA,
     hs, hUz, hVz, hrelA⟩

  have hsParent :
      arcDyadicCylinder m r s := by
    rw [← hulen]
    exact hs

  exact
    ⟨A, E, U, V, s, z, z',
     hUVlen,
     hUA,
     hVA,
     hsParent,
     hUz,
     hVz,
     hrelA⟩

/--
At the balanced steering state, the offset is exactly a power of 3 times the
ordinary integer endpoint difference.
-/
lemma arcBalancedRelation_offset
    {A : ℕ}
    {E z z' : ℤ}
    (hrel :
      arcScaledRelation A A E z z') :
    E
      =
    (3 : ℤ) ^ A * (z' - z) := by

  unfold arcScaledRelation at hrel

  have hE :
      E
        =
      (3 : ℤ) ^ A * z'
        - (3 : ℤ) ^ A * z := by
    linarith

  calc
    E
        =
      (3 : ℤ) ^ A * z'
        - (3 : ℤ) ^ A * z := hE
    _ =
      (3 : ℤ) ^ A * (z' - z) := by
        ring

#print axioms arcRealizedWord_exists
#print axioms arcInitialPair_exists
#print axioms arcPrescribedCylinder_steer_balanced
#print axioms arcBalancedRelation_offset

import Mathlib
import ARC.ARC5LocalDensityStage4B_v2

set_option autoImplicit false

/-!
# ARC5 / Local-Density audit — Stage 4C

Stage 4B proved the four algebraic transition identities for the denominator-
free steering relation

    3^a y' = 3^b y + B.

This file proves the parity-control table behind steering.

Because every power of 3 is odd, reducing the scaled relation modulo 2 gives

    parity(y') = parity(y + B).

Equivalently,

    Even y' ↔ (Even y ↔ Even B).

Hence:
  * B even  + y even -> y' even   (00);
  * B even  + y odd  -> y' odd    (11);
  * B odd   + y even -> y' odd    (01);
  * B odd   + y odd  -> y' even   (10).

We also prove that the offset-update numerators required by Stage 4B are
automatically even in the appropriate cases, so the next integer offset C
really exists.
-/

/-- Every power of 3 is odd. -/
lemma arcThreePow_odd
    (k : ℕ) :
    Odd ((3 : ℤ) ^ k) := by
  exact
    (Int.not_even_iff_odd).mp
      (arcThreePow_not_even k)

/--
Parity form of the scaled steering relation.

Since the coefficients `3^a` and `3^b` are odd, they do not change parity.
-/
theorem arcScaledRelation_even_iff
    {a b : ℕ}
    {B y y' : ℤ}
    (hrel : arcScaledRelation a b B y y') :
    Even y' ↔ (Even y ↔ Even B) := by

  have hleft :
      Even ((3 : ℤ) ^ a * y')
        ↔
      Even y' := by
    rw [Int.even_mul]
    simp [arcThreePow_not_even a]

  have hright :
      Even ((3 : ℤ) ^ b * y + B)
        ↔
      (Even y ↔ Even B) := by
    rw [Int.even_add, Int.even_mul]
    simp [arcThreePow_not_even b]

  unfold arcScaledRelation at hrel

  calc
    Even y'
        ↔ Even ((3 : ℤ) ^ a * y') := hleft.symm
    _ ↔ Even ((3 : ℤ) ^ b * y + B) := by
          rw [hrel]
    _ ↔ (Even y ↔ Even B) := hright

/-- Even state gives a genuine shortcut even-branch witness. -/
lemma arcEven_branch_exists
    {y : ℤ}
    (hy : Even y) :
    ∃ z : ℤ, y = 2 * z := by
  exact even_iff_exists_two_mul.mp hy

/-- Odd state gives a genuine shortcut odd-branch witness. -/
lemma arcOdd_branch_exists
    {y : ℤ}
    (hy : Odd y) :
    ∃ z : ℤ, 3 * y + 1 = 2 * z := by

  rcases hy with ⟨q, hq⟩

  refine ⟨3 * q + 2, ?_⟩
  rw [hq]
  ring

/-- `B` even and `y` even force the 00 branch pair. -/
theorem arcScaledRelation_branches00
    {a b : ℕ}
    {B y y' : ℤ}
    (hrel : arcScaledRelation a b B y y')
    (hB : Even B)
    (hy : Even y) :
    (∃ z : ℤ, y = 2 * z) ∧
    (∃ z' : ℤ, y' = 2 * z') := by

  have hpar :=
    arcScaledRelation_even_iff hrel

  have hy' : Even y' := by
    apply hpar.mpr
    constructor
    · intro _
      exact hB
    · intro _
      exact hy

  exact
    ⟨arcEven_branch_exists hy,
     arcEven_branch_exists hy'⟩

/-- `B` even and `y` odd force the 11 branch pair. -/
theorem arcScaledRelation_branches11
    {a b : ℕ}
    {B y y' : ℤ}
    (hrel : arcScaledRelation a b B y y')
    (hB : Even B)
    (hy : Odd y) :
    (∃ z : ℤ, 3 * y + 1 = 2 * z) ∧
    (∃ z' : ℤ, 3 * y' + 1 = 2 * z') := by

  have hpar :=
    arcScaledRelation_even_iff hrel

  have hyNotEven : ¬ Even y :=
    (Int.not_even_iff_odd).mpr hy

  have hy'NotEven : ¬ Even y' := by
    intro hy'Even
    have hh : Even y ↔ Even B :=
      hpar.mp hy'Even
    exact hyNotEven (hh.mpr hB)

  have hy'Odd : Odd y' :=
    (Int.not_even_iff_odd).mp hy'NotEven

  exact
    ⟨arcOdd_branch_exists hy,
     arcOdd_branch_exists hy'Odd⟩

/-- `B` odd and `y` even force the 01 branch pair. -/
theorem arcScaledRelation_branches01
    {a b : ℕ}
    {B y y' : ℤ}
    (hrel : arcScaledRelation a b B y y')
    (hB : Odd B)
    (hy : Even y) :
    (∃ z : ℤ, y = 2 * z) ∧
    (∃ z' : ℤ, 3 * y' + 1 = 2 * z') := by

  have hpar :=
    arcScaledRelation_even_iff hrel

  have hBNotEven : ¬ Even B :=
    (Int.not_even_iff_odd).mpr hB

  have hy'NotEven : ¬ Even y' := by
    intro hy'Even
    have hh : Even y ↔ Even B :=
      hpar.mp hy'Even
    exact hBNotEven (hh.mp hy)

  have hy'Odd : Odd y' :=
    (Int.not_even_iff_odd).mp hy'NotEven

  exact
    ⟨arcEven_branch_exists hy,
     arcOdd_branch_exists hy'Odd⟩

/-- `B` odd and `y` odd force the 10 branch pair. -/
theorem arcScaledRelation_branches10
    {a b : ℕ}
    {B y y' : ℤ}
    (hrel : arcScaledRelation a b B y y')
    (hB : Odd B)
    (hy : Odd y) :
    (∃ z : ℤ, 3 * y + 1 = 2 * z) ∧
    (∃ z' : ℤ, y' = 2 * z') := by

  have hpar :=
    arcScaledRelation_even_iff hrel

  have hyNotEven : ¬ Even y :=
    (Int.not_even_iff_odd).mpr hy

  have hBNotEven : ¬ Even B :=
    (Int.not_even_iff_odd).mpr hB

  have hy'Even : Even y' := by
    apply hpar.mpr
    constructor
    · intro hyEven
      exact False.elim (hyNotEven hyEven)
    · intro hBEven
      exact False.elim (hBNotEven hBEven)

  exact
    ⟨arcOdd_branch_exists hy,
     arcEven_branch_exists hy'Even⟩

/-- If `B` is even, the 00 update offset `C = B/2` exists as an integer. -/
lemma arcOffset00_exists
    {B : ℤ}
    (hB : Even B) :
    ∃ C : ℤ, B = 2 * C := by
  exact even_iff_exists_two_mul.mp hB

/--
If `B` is odd, the 01 update numerator `3B + 3^a` is even.
-/
lemma arcOffset01_exists
    {a : ℕ}
    {B : ℤ}
    (hB : Odd B) :
    ∃ C : ℤ,
      2 * C = 3 * B + (3 : ℤ) ^ a := by

  rcases hB with ⟨q, hq⟩
  rcases arcThreePow_odd a with ⟨r, hr⟩

  refine ⟨3 * q + r + 2, ?_⟩
  rw [hq, hr]
  ring

/--
If `B` is odd, the 10 update numerator `3B - 3^b` is even.
-/
lemma arcOffset10_exists
    {b : ℕ}
    {B : ℤ}
    (hB : Odd B) :
    ∃ C : ℤ,
      2 * C = 3 * B - (3 : ℤ) ^ b := by

  rcases hB with ⟨q, hq⟩
  rcases arcThreePow_odd b with ⟨r, hr⟩

  refine ⟨3 * q - r + 1, ?_⟩
  rw [hq, hr]
  ring

/--
For a zero offset, the 11 update numerator `3^a - 3^b` is even.
This is the "kick" used when the exponent imbalance is nonzero but the offset
has temporarily vanished.
-/
lemma arcOffset11_zero_exists
    (a b : ℕ) :
    ∃ C : ℤ,
      2 * C
        =
      (3 : ℤ) ^ a - (3 : ℤ) ^ b := by

  rcases arcThreePow_odd a with ⟨q, hq⟩
  rcases arcThreePow_odd b with ⟨r, hr⟩

  refine ⟨q - r, ?_⟩
  rw [hq, hr]
  ring

#print axioms arcScaledRelation_even_iff
#print axioms arcScaledRelation_branches00
#print axioms arcScaledRelation_branches11
#print axioms arcScaledRelation_branches01
#print axioms arcScaledRelation_branches10
#print axioms arcOffset01_exists
#print axioms arcOffset10_exists
#print axioms arcOffset11_zero_exists

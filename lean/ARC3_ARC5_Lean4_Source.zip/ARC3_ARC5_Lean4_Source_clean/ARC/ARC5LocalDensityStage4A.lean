import Mathlib
import ARC.ARC5LocalDensityStage3E_v2

set_option autoImplicit false

/-!
# ARC5 / Local-Density audit — Stage 4A

Stage 3B proved

    arcWordCongruence w x -> ∃ y, arcFollowsTo w x y.

For steering inside an arbitrary dyadic cylinder we also want the converse,
so that the modular condition and the genuine parity-word realization are
known to be exactly equivalent.

This file proves:

1. every genuine branch-word realization satisfies the Stage-2C congruence;
2. the endpoint of a fixed realized word is unique;
3. therefore `arcWordCongruence w x` is exactly the condition that `x`
   genuinely follows the word `w`.

This gives a clean, exact parity-cylinder interface for the later steering
argument.
-/

/--
Every genuine branch-word realization satisfies its exact dyadic congruence.
-/
theorem arcFollowsTo_congruence
    {w : List Bool}
    {x y : ℤ}
    (h : arcFollowsTo w x y) :
    arcWordCongruence w x := by

  induction w generalizing x y with
  | nil =>
      apply (arcWordCongruence_iff_dvd [] x).mpr
      simp [arcWordNumerator, arcOnes, arcIntercept]

  | cons b w ih =>
      cases b with
      | false =>
          rcases h with ⟨z, hx, hz⟩

          have htail :
              arcWordCongruence w z :=
            ih hz

          have htailDvd :
              ((2 : ℤ) ^ w.length)
                ∣
              arcWordNumerator w z :=
            (arcWordCongruence_iff_dvd w z).mp htail

          rcases htailDvd with ⟨q, hq⟩

          apply
            (arcWordCongruence_iff_dvd
              (false :: w)
              x).mpr

          refine ⟨q, ?_⟩

          have hstep :
              arcWordNumerator (false :: w) x
                =
              2 * arcWordNumerator w z :=
            arcWordNumerator_false_step hx

          rw [hstep, hq]
          simp [pow_succ]
          ring

      | true =>
          rcases h with ⟨z, hx, hz⟩

          have htail :
              arcWordCongruence w z :=
            ih hz

          have htailDvd :
              ((2 : ℤ) ^ w.length)
                ∣
              arcWordNumerator w z :=
            (arcWordCongruence_iff_dvd w z).mp htail

          rcases htailDvd with ⟨q, hq⟩

          apply
            (arcWordCongruence_iff_dvd
              (true :: w)
              x).mpr

          refine ⟨q, ?_⟩

          have hstep :
              arcWordNumerator (true :: w) x
                =
              2 * arcWordNumerator w z :=
            arcWordNumerator_true_step hx

          rw [hstep, hq]
          simp [pow_succ]
          ring

/--
For a fixed start and a fixed parity word, the integer endpoint is unique.
-/
theorem arcFollowsTo_endpoint_unique
    {w : List Bool}
    {x y₁ y₂ : ℤ}
    (h₁ : arcFollowsTo w x y₁)
    (h₂ : arcFollowsTo w x y₂) :
    y₁ = y₂ := by

  have ha₁ :
      arcAffine w (x : ℚ) = (y₁ : ℚ) :=
    arcFollowsTo_affine h₁

  have ha₂ :
      arcAffine w (x : ℚ) = (y₂ : ℚ) :=
    arcFollowsTo_affine h₂

  have hy :
      (y₁ : ℚ) = (y₂ : ℚ) := by
    calc
      (y₁ : ℚ)
          = arcAffine w (x : ℚ) := ha₁.symm
      _ = (y₂ : ℚ) := ha₂

  exact_mod_cast hy

/--
Exact parity-cylinder characterization.

The Stage-2C modular condition is equivalent to genuine realization of the
whole prescribed parity word.
-/
theorem arcWordCongruence_iff_realizes
    (w : List Bool)
    (x : ℤ) :
    arcWordCongruence w x
      ↔
    ∃ y : ℤ, arcFollowsTo w x y := by

  constructor
  · intro h
    exact arcWordCongruence_realizes w x h

  · rintro ⟨y, h⟩
    exact arcFollowsTo_congruence h

/--
Existence and uniqueness of the endpoint on an admissible parity word.
-/
theorem arcWordCongruence_existsUnique_endpoint
    (w : List Bool)
    (x : ℤ)
    (h : arcWordCongruence w x) :
    ∃! y : ℤ, arcFollowsTo w x y := by

  rcases arcWordCongruence_realizes w x h with
    ⟨y, hy⟩

  refine ⟨y, hy, ?_⟩

  intro z hz

  exact arcFollowsTo_endpoint_unique hz hy

#print axioms arcFollowsTo_congruence
#print axioms arcFollowsTo_endpoint_unique
#print axioms arcWordCongruence_iff_realizes
#print axioms arcWordCongruence_existsUnique_endpoint

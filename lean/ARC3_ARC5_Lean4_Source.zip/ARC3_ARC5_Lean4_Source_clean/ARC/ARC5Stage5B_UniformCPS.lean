import Mathlib
import ARC.ARC5Stage5A_CPS5

set_option autoImplicit false

universe u

def ARC5LevelBlockSync
    {α : Type u}
    (a : ℕ → α) : Prop :=
  ∀ q p : ℕ,
    ∃ k : ℕ,
      0 < k ∧
      ∃ c : α,
        ∀ v : ℕ → α,
          v ∈ ARC5LevelKernel q a →
          ∀ s : ℕ,
            s < 5 ^ p →
            v (5 ^ p * k + s) = c

lemma arc5_pack_residue_lt
    (q p r s : ℕ)
    (hr : r < 5 ^ q)
    (hs : s < 5 ^ p) :
    5 ^ q * s + r < 5 ^ (q + p) := by
  have hs1 : s + 1 ≤ 5 ^ p := by omega
  have hstep :
      5 ^ q * s + r < 5 ^ q * (s + 1) := by
    have h := Nat.add_lt_add_left hr (5 ^ q * s)
    calc
      5 ^ q * s + r < 5 ^ q * s + 5 ^ q := h
      _ = 5 ^ q * (s + 1) := by ring
  have hmul :
      5 ^ q * (s + 1) ≤ 5 ^ q * 5 ^ p := by
    exact Nat.mul_le_mul_left (5 ^ q) hs1
  have hfinal :
      5 ^ q * s + r < 5 ^ q * 5 ^ p :=
    lt_of_lt_of_le hstep hmul
  simpa [pow_add] using hfinal

lemma arc5_pack_index
    (q p k r s : ℕ) :
    5 ^ q * (5 ^ p * k + s) + r
      =
    5 ^ (q + p) * k + (5 ^ q * s + r) := by
  rw [pow_add]
  ring

theorem arc5_cps_uniform_residue_blocks
    {α : Type u}
    (a : ℕ → α)
    (hcps : ARC5CPS a)
    (q p : ℕ) :
    ∃ k : ℕ,
      0 < k ∧
      ∃ c : α,
        ∀ r s : ℕ,
          r < 5 ^ q →
          s < 5 ^ p →
          a (5 ^ q * (5 ^ p * k + s) + r) = c := by
  have hblock : ARC5CPSBlock a :=
    arc5_block_of_cps a hcps
  rcases hblock (q + p) with ⟨k, hkpos, hbig⟩
  refine ⟨k, hkpos, a (5 ^ (q + p) * k), ?_⟩
  intro r s hr hs
  have hpacked :
      5 ^ q * s + r < 5 ^ (q + p) :=
    arc5_pack_residue_lt q p r s hr hs
  have hmono :
      a (5 ^ (q + p) * k + (5 ^ q * s + r))
        =
      a (5 ^ (q + p) * k) :=
    hbig (5 ^ q * s + r) hpacked
  calc
    a (5 ^ q * (5 ^ p * k + s) + r)
        =
    a (5 ^ (q + p) * k + (5 ^ q * s + r)) := by
      rw [arc5_pack_index]
    _ = a (5 ^ (q + p) * k) := hmono

theorem arc5_cps_uniform_levelKernel_blocks
    {α : Type u}
    (a : ℕ → α)
    (hcps : ARC5CPS a) :
    ARC5LevelBlockSync a := by
  intro q p
  rcases
    arc5_cps_uniform_residue_blocks a hcps q p with
    ⟨k, hkpos, c, hsync⟩
  refine ⟨k, hkpos, c, ?_⟩
  intro v hv s hs
  change
    ∃ r : ℕ,
      r < 5 ^ q ∧
      ∀ n : ℕ,
        v n = a (5 ^ q * n + r)
    at hv
  rcases hv with ⟨r, hr, hvEq⟩
  calc
    v (5 ^ p * k + s)
        =
    a (5 ^ q * (5 ^ p * k + s) + r) :=
      hvEq (5 ^ p * k + s)
    _ = c := hsync r s hr hs

theorem arc5_cps_levelKernel_pairwise_common_block
    {α : Type u}
    (a : ℕ → α)
    (hcps : ARC5CPS a)
    (q p : ℕ) :
    ∃ k : ℕ,
      0 < k ∧
      ∀ v w : ℕ → α,
        v ∈ ARC5LevelKernel q a →
        w ∈ ARC5LevelKernel q a →
        ∀ s : ℕ,
          s < 5 ^ p →
          v (5 ^ p * k + s) =
          w (5 ^ p * k + s) := by
  have hsync := arc5_cps_uniform_levelKernel_blocks a hcps
  rcases hsync q p with ⟨k, hkpos, c, hcommon⟩
  refine ⟨k, hkpos, ?_⟩
  intro v w hv hw s hs
  calc
    v (5 ^ p * k + s) = c := hcommon v hv s hs
    _ = w (5 ^ p * k + s) := (hcommon w hw s hs).symm

theorem arc5_stage5B_finite_kernel_uniform_cps
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha5 :
      ARCAutomaticByKernel 5 a) :
    (ARCKernel 5 a).Finite ∧ ARC5LevelBlockSync a := by
  have h5A :=
    arc5_stage5A_finite_kernel_and_cps5 a hinv ha5
  rcases h5A with ⟨hfinite, hcps⟩
  exact
    ⟨hfinite,
     arc5_cps_uniform_levelKernel_blocks a hcps⟩

#print axioms arc5_pack_residue_lt
#print axioms arc5_pack_index
#print axioms arc5_cps_uniform_residue_blocks
#print axioms arc5_cps_uniform_levelKernel_blocks
#print axioms arc5_cps_levelKernel_pairwise_common_block
#print axioms arc5_stage5B_finite_kernel_uniform_cps

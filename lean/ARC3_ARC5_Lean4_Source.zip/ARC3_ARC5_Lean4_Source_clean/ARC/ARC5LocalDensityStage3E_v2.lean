import Mathlib
import ARC.ARC5LocalDensityStage3D_v3

set_option autoImplicit false

/-!
# ARC5 / Local-Density audit — Stage 3E

Stage 3D proved genuine branch-by-branch synchronous coalescence on a full
dyadic cylinder.  The theorem was still phrased with the relational predicate
`arcFollowsTo`.

This file packages the genuine shortcut Collatz step as a deterministic
integer-valued function and proves that every `arcFollowsTo` realization is
exactly an iterate of that function.

The final theorem therefore has the familiar functional form:

    for every N > 0,
    there exist L and a dyadic cylinder C(r,L)
    such that for every x in C(r,L),

        T^L(x) = T^L(x+N).

This is the functional "Universal Dyadic Cylinder Coalescence" theorem that
will be used as the local merge primitive in the later Local-Density proof.
-/

/--
Deterministic shortcut-Collatz map on integers.

We decide the branch by the ordinary parity test `x % 2 = 0`.
Because the numerator of the odd branch is even whenever `x` is odd, both
divisions are exact on the corresponding genuine branch.
-/
def arcShortcutInt (x : ℤ) : ℤ :=
  if x % 2 = 0 then
    x / 2
  else
    (3 * x + 1) / 2

/-- On a genuine even branch, `arcShortcutInt x = z`. -/
lemma arcShortcutInt_of_even
    {x z : ℤ}
    (hx : x = 2 * z) :
    arcShortcutInt x = z := by

  subst x
  simp [arcShortcutInt]

/--
A genuine odd-branch equation forces the starting integer to be odd.
-/
lemma arcOddBranch_mod_two_ne_zero
    {x z : ℤ}
    (hx : 3 * x + 1 = 2 * z) :
    x % 2 ≠ 0 := by
  omega

/-- On a genuine odd branch, `arcShortcutInt x = z`. -/
lemma arcShortcutInt_of_odd
    {x z : ℤ}
    (hx : 3 * x + 1 = 2 * z) :
    arcShortcutInt x = z := by

  have hodd :
      x % 2 ≠ 0 :=
    arcOddBranch_mod_two_ne_zero hx

  unfold arcShortcutInt
  rw [if_neg hodd]
  rw [hx]
  simp

/-- Iteration of the deterministic shortcut map. -/
def arcShortcutIter : ℕ → ℤ → ℤ
  | 0, x => x
  | n + 1, x => arcShortcutIter n (arcShortcutInt x)

/--
Every genuine branch-word realization is exactly the corresponding iterate of
the deterministic shortcut map.
-/
theorem arcFollowsTo_shortcutIter
    {w : List Bool}
    {x y : ℤ}
    (h : arcFollowsTo w x y) :
    arcShortcutIter w.length x = y := by

  induction w generalizing x y with
  | nil =>
      have hyx : y = x := by
        simpa [arcFollowsTo] using h
      simpa [arcShortcutIter] using hyx.symm

  | cons b w ih =>
      cases b with
      | false =>
          rcases h with ⟨z, hx, hz⟩

          change
            arcShortcutIter w.length (arcShortcutInt x) = y

          rw [arcShortcutInt_of_even hx]

          exact ih hz

      | true =>
          rcases h with ⟨z, hx, hz⟩

          change
            arcShortcutIter w.length (arcShortcutInt x) = y

          rw [arcShortcutInt_of_odd hx]

          exact ih hz

/--
Functional Universal Dyadic Cylinder Coalescence.

For every positive gap `N`, there are a time `L` and a dyadic residue class
such that every integer `x` in that class satisfies

    arcShortcutIter L x = arcShortcutIter L (x+N).
-/
theorem arcUniversalShortcutDyadicCoalescence
    (N : ℕ)
    (hN : 0 < N) :
    ∃ L : ℕ,
      ∃ r : ℤ,
        ∀ x : ℤ,
          arcDyadicCylinder L r x →
          arcShortcutIter L x
            =
          arcShortcutIter L (x + (N : ℤ)) := by

  rcases arcUniversalDyadicCylinderCoalescence N hN with
    ⟨u, v, r, hlen, hones, hr, hmain⟩

  refine ⟨u.length, r, ?_⟩

  intro x hx

  rcases hmain x hx with
    ⟨yu, yv, hu, hv, hEq⟩

  have huIter :
      arcShortcutIter u.length x = yu :=
    arcFollowsTo_shortcutIter hu

  have hvIter :
      arcShortcutIter v.length (x + (N : ℤ)) = yv :=
    arcFollowsTo_shortcutIter hv

  have hvIter' :
      arcShortcutIter u.length (x + (N : ℤ)) = yv := by
    rw [hlen]
    exact hvIter

  calc
    arcShortcutIter u.length x
        = yu := huIter
    _ = yv := hEq
    _ = arcShortcutIter u.length (x + (N : ℤ)) := hvIter'.symm

#print axioms arcShortcutInt_of_even
#print axioms arcShortcutInt_of_odd
#print axioms arcFollowsTo_shortcutIter
#print axioms arcUniversalShortcutDyadicCoalescence

import Mathlib
import ARC.ARC5LocalDensityStage2A

set_option autoImplicit false

/-!
# ARC5 / Local-Density audit — Stage 2B

Stage 2A proved an identity of affine branch maps. This file replaces the
normalized rational shift by the classical integer intercept `C(w)`:

    F_w(x) = (3^k x + C(w)) / 2^L.

The main theorem extracts from the Stage-1/2A witnesses the exact integer
identity

    C(u) - C(v) = 3^k N.

That is the congruence datum needed for the next step, where the two words
are realized simultaneously on an actual dyadic residue class.
-/

/-- Integer intercept in the affine formula of a parity word. -/
def arcIntercept : List Bool → ℤ
  | [] => 0
  | false :: w => 2 * arcIntercept w
  | true  :: w => (3 : ℤ) ^ arcOnes w + 2 * arcIntercept w

/-- Integer-intercept closed form for a parity word. -/
theorem arcAffine_closedForm_int
    (w : List Bool)
    (x : ℚ) :
    arcAffine w x
      =
    (((3 : ℚ) ^ arcOnes w) * x + (arcIntercept w : ℚ))
      /
    ((2 : ℚ) ^ w.length) := by
  induction w generalizing x with
  | nil =>
      simp [arcAffine, arcOnes, arcIntercept]
  | cons b w ih =>
      cases b <;>
        simp [arcAffine, arcOnes, arcIntercept, ih, pow_succ] <;>
        ring

/--
For equal-length words with equal odd-step count, affine coalescence under
translation by `N` forces the exact integer intercept gap
`C(u)-C(v)=3^k N`.
-/
theorem arcIntercept_gap_of_affine_coalescence
    {N : ℕ}
    {u v : List Bool}
    (hlen : u.length = v.length)
    (hones : arcOnes u = arcOnes v)
    (hcoal :
      ∀ x : ℚ,
        arcAffine u x =
        arcAffine v (x + N)) :
    arcIntercept u - arcIntercept v
      =
    (3 : ℤ) ^ arcOnes u * (N : ℤ) := by

  have h0 := hcoal 0

  rw [arcAffine_closedForm_int, arcAffine_closedForm_int] at h0
  rw [hones, hlen] at h0
  norm_num at h0

  have hden :
      ((2 : ℚ) ^ v.length) ≠ 0 := by
    positivity

  have hnum :
      (arcIntercept u : ℚ)
        =
      ((3 : ℚ) ^ arcOnes v) * (N : ℚ)
        + (arcIntercept v : ℚ) := by
    apply (div_left_inj' hden).mp
    simpa using h0

  have hnum' :
      (arcIntercept u : ℚ) - (arcIntercept v : ℚ)
        =
      ((3 : ℚ) ^ arcOnes u) * (N : ℚ) := by
    rw [hones]
    linarith

  exact_mod_cast hnum'

/--
Universal integer intercept witnesses.

For every positive integer `N`, there are two equal-length parity words with
the same odd-step count and exact intercept gap `3^k N`.
-/
theorem arcUniversalInterceptGap
    (N : ℕ)
    (hN : 0 < N) :
    ∃ u v : List Bool,
      u.length = v.length ∧
      arcOnes u = arcOnes v ∧
      arcIntercept u - arcIntercept v
        =
      (3 : ℤ) ^ arcOnes u * (N : ℤ) := by

  rcases arcUniversalAffineCoalescence N hN with
    ⟨u, v, hlen, hones, hcoal⟩

  refine ⟨u, v, hlen, hones, ?_⟩

  exact
    arcIntercept_gap_of_affine_coalescence
      hlen
      hones
      hcoal

#print axioms arcAffine_closedForm_int
#print axioms arcUniversalInterceptGap

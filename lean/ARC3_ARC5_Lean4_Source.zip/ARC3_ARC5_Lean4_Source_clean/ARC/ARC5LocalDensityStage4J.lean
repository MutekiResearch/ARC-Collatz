import Mathlib
import ARC.ARC5LocalDensityStage4I

set_option autoImplicit false

/-!
# ARC5 / Local-Density audit — Stage 4J

Stage 4I proved that every nonzero offset can be normalized, by finitely many
00 moves, to an odd offset.  We now perform the outer well-founded induction
on the exponent imbalance

    Δ(a,b) = |a-b|.

The steering scheme is:

* if a = b, stop;
* if a != b and B != 0:
    normalize B to an odd offset by finitely many 00 moves,
    then use 10 or 01 according to the order of a and b;
    this strictly decreases Δ;
* if a != b and B = 0:
    use one 11 kick to create a nonzero offset without changing Δ,
    normalize that offset to odd,
    then use 10 or 01;
    this strictly decreases Δ.

Hence every arithmetic steering state reaches, after finitely many moves, a
state with equal exponents.

This is still the parameter-level termination theorem.  The next stage will
lift the finite `arcParamReach` path to the genuine paired parity-word/cylinder
steering moves from Stage 4F.
-/

/-- Finite steering reachability is transitive. -/
theorem arcParamReach_trans
    {a b A D P Q : ℕ}
    {B E F : ℤ}
    (h₁ : arcParamReach a b B A D E)
    (h₂ : arcParamReach A D E P Q F) :
    arcParamReach a b B P Q F := by

  induction h₁ with
  | refl =>
      exact h₂

  | step00 hBC hrest ih =>
      exact
        arcParamReach.step00
          hBC
          (ih h₂)

  | step01 hC hrest ih =>
      exact
        arcParamReach.step01
          hC
          (ih h₂)

  | step10 hC hrest ih =>
      exact
        arcParamReach.step10
          hC
          (ih h₂)

  | step11zero C hC hrest ih =>
      exact
        arcParamReach.step11zero
          C
          hC
          (ih h₂)

/--
Strong-induction helper:
every parameter state of exact imbalance `n` reaches a balanced exponent pair.
-/
theorem arcParamReach_balanced_aux :
    ∀ n : ℕ,
      ∀ a b : ℕ,
        ∀ B : ℤ,
          arcImbalance a b = n →
          ∃ A : ℕ,
            ∃ E : ℤ,
              arcParamReach a b B A A E := by

  intro n

  induction n using Nat.strong_induction_on with
  | h n ih =>

      intro a b B hDelta

      by_cases hab : a = b

      · subst b

        exact
          ⟨a,
           B,
           arcParamReach.refl a a B⟩

      · have horder :
            a < b ∨ b < a := by
          omega

        by_cases hB0 : B = 0

        · subst B

          rcases
            arcParamProgress11_zero
              hab with
            ⟨D, hD, hD0, hDelta11⟩

          rcases
            arcNormalizeOffset_nonzero
              (a + 1)
              (b + 1)
              D
              hD0 with
            ⟨C, hCodd, hNorm⟩

          rcases horder with hablt | hbalt

          · have hablt' :
                a + 1 < b + 1 := by
              omega

            rcases
              arcParamProgress10
                hCodd
                hablt' with
              ⟨F, hF, hDec⟩

            have hSmall :
                arcImbalance (a + 2) (b + 1) < n := by
              rw [hDelta11] at hDec
              simpa [hDelta] using hDec

            rcases
              ih
                (arcImbalance (a + 2) (b + 1))
                hSmall
                (a + 2)
                (b + 1)
                F
                rfl with
              ⟨A, E, hTail⟩

            have hAfterNorm :
                arcParamReach
                  (a + 1)
                  (b + 1)
                  C
                  A
                  A
                  E :=
              arcParamReach.step10
                hF
                hTail

            have hFromKick :
                arcParamReach
                  (a + 1)
                  (b + 1)
                  D
                  A
                  A
                  E :=
              arcParamReach_trans
                hNorm
                hAfterNorm

            exact
              ⟨A,
               E,
               arcParamReach.step11zero
                 D
                 hD
                 hFromKick⟩

          · have hbalt' :
                b + 1 < a + 1 := by
              omega

            rcases
              arcParamProgress01
                hCodd
                hbalt' with
              ⟨F, hF, hDec⟩

            have hSmall :
                arcImbalance (a + 1) (b + 2) < n := by
              rw [hDelta11] at hDec
              simpa [hDelta] using hDec

            rcases
              ih
                (arcImbalance (a + 1) (b + 2))
                hSmall
                (a + 1)
                (b + 2)
                F
                rfl with
              ⟨A, E, hTail⟩

            have hAfterNorm :
                arcParamReach
                  (a + 1)
                  (b + 1)
                  C
                  A
                  A
                  E :=
              arcParamReach.step01
                hF
                hTail

            have hFromKick :
                arcParamReach
                  (a + 1)
                  (b + 1)
                  D
                  A
                  A
                  E :=
              arcParamReach_trans
                hNorm
                hAfterNorm

            exact
              ⟨A,
               E,
               arcParamReach.step11zero
                 D
                 hD
                 hFromKick⟩

        · rcases
            arcNormalizeOffset_nonzero
              a
              b
              B
              hB0 with
            ⟨C, hCodd, hNorm⟩

          rcases horder with hablt | hbalt

          · rcases
              arcParamProgress10
                hCodd
                hablt with
              ⟨F, hF, hDec⟩

            have hSmall :
                arcImbalance (a + 1) b < n := by
              simpa [hDelta] using hDec

            rcases
              ih
                (arcImbalance (a + 1) b)
                hSmall
                (a + 1)
                b
                F
                rfl with
              ⟨A, E, hTail⟩

            have hAfterNorm :
                arcParamReach
                  a
                  b
                  C
                  A
                  A
                  E :=
              arcParamReach.step10
                hF
                hTail

            exact
              ⟨A,
               E,
               arcParamReach_trans
                 hNorm
                 hAfterNorm⟩

          · rcases
              arcParamProgress01
                hCodd
                hbalt with
              ⟨F, hF, hDec⟩

            have hSmall :
                arcImbalance a (b + 1) < n := by
              simpa [hDelta] using hDec

            rcases
              ih
                (arcImbalance a (b + 1))
                hSmall
                a
                (b + 1)
                F
                rfl with
              ⟨A, E, hTail⟩

            have hAfterNorm :
                arcParamReach
                  a
                  b
                  C
                  A
                  A
                  E :=
              arcParamReach.step01
                hF
                hTail

            exact
              ⟨A,
               E,
               arcParamReach_trans
                 hNorm
                 hAfterNorm⟩

/--
Arithmetic steering termination:
every parameter state reaches a state with equal exponents.
-/
theorem arcParamReach_balanced
    (a b : ℕ)
    (B : ℤ) :
    ∃ A : ℕ,
      ∃ E : ℤ,
        arcParamReach a b B A A E := by

  exact
    arcParamReach_balanced_aux
      (arcImbalance a b)
      a
      b
      B
      rfl

#print axioms arcParamReach_trans
#print axioms arcParamReach_balanced_aux
#print axioms arcParamReach_balanced

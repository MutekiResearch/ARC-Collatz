import Mathlib
import ARC.ARC5Stage5W_PositiveRigidity_v2

set_option autoImplicit false

universe u

/-!
# ARC5Final

Final entry point for the ARC5 formalization.

This file deliberately contains only the public-facing final statements.
All technical lemmas and intermediate stages remain in their audited source
files and are imported transitively through

    ARC5Stage5W_PositiveRigidity_v2

The final theorem says:

If a sequence `a : ℕ → α`

1. is invariant under the shortcut Collatz map, and
2. has finite base-5 kernel,

then `a` is constant on all positive natural numbers.

No assertion is made about `a 0`.  This exclusion is necessary: the value at
zero may differ from the common value on positive integers while preserving
both shortcut invariance and base-5 automaticity.
-/

/-!
============================================================
1. Final ARC5 theorem
============================================================
-/

/--
Final ARC5 rigidity theorem.

A base-5 finite-kernel sequence invariant under the shortcut Collatz map is
constant on `ℕ_{>0}`.
-/
theorem arc5_final
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha5 :
      ARCAutomaticByKernel 5 a) :
    ∃ c : α,
      ∀ n : ℕ,
        0 < n →
        a n = c := by

  exact
    arc5_stage5W_positive_rigidity
      a
      hinv
      ha5


/-!
============================================================
2. Equivalent pairwise form
============================================================
-/

/--
Equivalent form of `arc5_final`:
all positive inputs receive the same value.
-/
theorem arc5_final_pairwise
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha5 :
      ARCAutomaticByKernel 5 a) :
    ∀ m n : ℕ,
      0 < m →
      0 < n →
      a m = a n := by

  exact
    arc5_positive_pairwise_equal
      a
      hinv
      ha5


/-!
============================================================
3. Axiom audit
============================================================
-/

#print axioms arc5_final
#print axioms arc5_final_pairwise

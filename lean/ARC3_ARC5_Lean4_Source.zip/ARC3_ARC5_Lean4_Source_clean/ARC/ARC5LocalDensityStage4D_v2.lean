import Mathlib
import ARC.ARC5LocalDensityStage4C

set_option autoImplicit false

/-!
# ARC5 / Local-Density audit — Stage 4D

Stage 4C proved the parity-control table for the scaled steering relation.

The remaining conceptual ingredient before proving termination is "local
control": while staying inside an already fixed dyadic parity cylinder, we
must be able to choose the parity of the *next* orbit value.

This file proves exactly that.

The key observation is classical and very simple:

If a word `w` has length `L` and contains `k` odd steps, then shifting the
starting value by `2^L * t` preserves the whole word `w`, and shifts the
endpoint by `3^k * t`.

Since `3^k` is odd, the two child residue classes
  r mod 2^(L+1)
and
  r + 2^L mod 2^(L+1)
have opposite endpoint parity after following `w`.

Therefore either desired next branch (0 or 1) can be forced by passing to one
of the two dyadic child cylinders.
-/

/--
Composition of genuine parity-word realizations.
-/
theorem arcFollowsTo_append
    {u v : List Bool}
    {x y z : ℤ}
    (hu : arcFollowsTo u x y)
    (hv : arcFollowsTo v y z) :
    arcFollowsTo (u ++ v) x z := by

  induction u generalizing x y with
  | nil =>
      have hyx : y = x := by
        simpa [arcFollowsTo] using hu
      subst y
      simpa using hv

  | cons b u ih =>
      cases b with
      | false =>
          rcases hu with ⟨q, hx, htail⟩
          change
            ∃ q' : ℤ,
              x = 2 * q' ∧
              arcFollowsTo (u ++ v) q' z
          refine ⟨q, hx, ?_⟩
          exact ih htail hv

      | true =>
          rcases hu with ⟨q, hx, htail⟩
          change
            ∃ q' : ℤ,
              3 * x + 1 = 2 * q' ∧
              arcFollowsTo (u ++ v) q' z
          refine ⟨q, hx, ?_⟩
          exact ih htail hv

/--
Shift lemma for a realized parity word.

If `x` follows `w` to `y`, then for every integer `t`,
`x + 2^L t` follows the same word to `y + 3^k t`.
-/
theorem arcFollowsTo_shift_period
    {w : List Bool}
    {x y : ℤ}
    (h : arcFollowsTo w x y)
    (t : ℤ) :
    ∃ y' : ℤ,
      arcFollowsTo
        w
        (x + ((2 : ℤ) ^ w.length) * t)
        y'
      ∧
      y'
        =
      y + ((3 : ℤ) ^ arcOnes w) * t := by

  induction w generalizing x y t with
  | nil =>
      have hyx : y = x := by
        simpa [arcFollowsTo] using h

      refine
        ⟨x + t, ?_, ?_⟩

      · simp [arcFollowsTo]

      · rw [hyx]
        simp [arcOnes]

  | cons b w ih =>
      cases b with
      | false =>
          rcases h with ⟨q, hx, htail⟩

          rcases ih htail t with
            ⟨y', hy', hshift⟩

          refine ⟨y', ?_, ?_⟩

          · change
              ∃ q' : ℤ,
                x
                    + ((2 : ℤ) ^ (false :: w).length) * t
                  =
                2 * q'
                ∧
                arcFollowsTo w q' y'

            refine
              ⟨q + ((2 : ℤ) ^ w.length) * t,
               ?_,
               hy'⟩

            rw [hx]
            simp [pow_succ]
            ring

          · simpa [arcOnes] using hshift

      | true =>
          rcases h with ⟨q, hx, htail⟩

          rcases ih htail (3 * t) with
            ⟨y', hy', hshift⟩

          refine ⟨y', ?_, ?_⟩

          · change
              ∃ q' : ℤ,
                3
                    * (x
                        + ((2 : ℤ) ^ (true :: w).length) * t)
                    + 1
                  =
                2 * q'
                ∧
                arcFollowsTo w q' y'

            refine
              ⟨q
                  + ((2 : ℤ) ^ w.length) * (3 * t),
               ?_,
               hy'⟩

            calc
              3
                    * (x
                        + ((2 : ℤ) ^ (true :: w).length) * t)
                    + 1
                  =
              (3 * x + 1)
                + 3 * (((2 : ℤ) ^ (true :: w).length) * t) := by
                  ring
              _ =
              2 * q
                + 3 * (((2 : ℤ) ^ (true :: w).length) * t) := by
                  rw [hx]
              _ =
              2
                * (q
                    + ((2 : ℤ) ^ w.length) * (3 * t)) := by
                  simp [pow_succ]
                  ring

          ·
            simpa
              [arcOnes,
               Nat.add_comm,
               pow_succ,
               mul_assoc,
               mul_left_comm,
               mul_comm]
              using hshift

/--
The shifted start `r + 2^L` lies in the same parent cylinder modulo `2^L`.
-/
lemma arcShift_one_in_parent
    (L : ℕ)
    (r : ℤ) :
    arcDyadicCylinder
      L
      r
      (r + (2 : ℤ) ^ L) := by

  refine ⟨1, ?_⟩
  ring

/--
If an endpoint is odd, shifting the start by one full parent modulus makes
the new endpoint even.
-/
lemma arcEndpoint_shift_to_even
    {w : List Bool}
    {r y : ℤ}
    (h : arcFollowsTo w r y)
    (hy : Odd y) :
    ∃ s z : ℤ,
      arcDyadicCylinder w.length r s
      ∧
      arcFollowsTo w s z
      ∧
      Even z := by

  rcases arcFollowsTo_shift_period h 1 with
    ⟨z, hz, hshift⟩

  have h3odd :
      Odd ((3 : ℤ) ^ arcOnes w) :=
    arcThreePow_odd (arcOnes w)

  rcases hy with ⟨q, hq⟩
  rcases h3odd with ⟨p, hp⟩

  have hzEven : Even z := by
    refine ⟨q + p + 1, ?_⟩
    rw [hshift, hq, hp]
    ring

  refine
    ⟨r + (2 : ℤ) ^ w.length,
     z,
     arcShift_one_in_parent w.length r,
     ?_,
     hzEven⟩

  simpa using hz

/--
If an endpoint is even, shifting the start by one full parent modulus makes
the new endpoint odd.
-/
lemma arcEndpoint_shift_to_odd
    {w : List Bool}
    {r y : ℤ}
    (h : arcFollowsTo w r y)
    (hy : Even y) :
    ∃ s z : ℤ,
      arcDyadicCylinder w.length r s
      ∧
      arcFollowsTo w s z
      ∧
      Odd z := by

  rcases arcFollowsTo_shift_period h 1 with
    ⟨z, hz, hshift⟩

  have h3odd :
      Odd ((3 : ℤ) ^ arcOnes w) :=
    arcThreePow_odd (arcOnes w)

  rcases hy with ⟨q, hq⟩
  rcases h3odd with ⟨p, hp⟩

  have hzOdd : Odd z := by
    refine ⟨q + p, ?_⟩
    rw [hshift, hq, hp]
    ring

  refine
    ⟨r + (2 : ℤ) ^ w.length,
     z,
     arcShift_one_in_parent w.length r,
     ?_,
     hzOdd⟩

  simpa using hz

/--
Inside any realized parent word-cylinder, there is a point in the same parent
cylinder whose endpoint after `w` is even.
-/
theorem arcEndpoint_refine_even
    {w : List Bool}
    {r y : ℤ}
    (h : arcFollowsTo w r y) :
    ∃ s z : ℤ,
      arcDyadicCylinder w.length r s
      ∧
      arcFollowsTo w s z
      ∧
      Even z := by

  by_cases hy : Even y

  · refine ⟨r, y, ?_, h, hy⟩
    exact ⟨0, by ring⟩

  · have hyOdd : Odd y :=
      (Int.not_even_iff_odd).mp hy

    exact arcEndpoint_shift_to_even h hyOdd

/--
Inside any realized parent word-cylinder, there is a point in the same parent
cylinder whose endpoint after `w` is odd.
-/
theorem arcEndpoint_refine_odd
    {w : List Bool}
    {r y : ℤ}
    (h : arcFollowsTo w r y) :
    ∃ s z : ℤ,
      arcDyadicCylinder w.length r s
      ∧
      arcFollowsTo w s z
      ∧
      Odd z := by

  by_cases hy : Even y

  · exact arcEndpoint_shift_to_odd h hy

  · have hyOdd : Odd y :=
      (Int.not_even_iff_odd).mp hy

    refine ⟨r, y, ?_, h, hyOdd⟩
    exact ⟨0, by ring⟩

/--
A child cylinder of depth `L+1`, based at a point already in a parent
cylinder of depth `L`, is contained in that parent cylinder.
-/
lemma arcChildCylinder_subset_parent
    {w : List Bool}
    {b : Bool}
    {r s x : ℤ}
    (hs :
      arcDyadicCylinder w.length r s)
    (hx :
      arcDyadicCylinder (w ++ [b]).length s x) :
    arcDyadicCylinder w.length r x := by

  rcases hs with ⟨u, hu⟩
  rcases hx with ⟨v, hv⟩

  refine ⟨u + 2 * v, ?_⟩

  rw [hv, hu]
  simp [pow_succ]
  ring

/--
Force the next branch to be the even/0 branch by refining to one dyadic child
cylinder.
-/
theorem arcWordCongruence_refine_false
    (w : List Bool)
    (r : ℤ)
    (hr : arcWordCongruence w r) :
    ∃ s : ℤ,
      arcDyadicCylinder w.length r s
      ∧
      arcWordCongruence (w ++ [false]) s
      ∧
      ∀ x : ℤ,
        arcDyadicCylinder (w ++ [false]).length s x
          →
        arcDyadicCylinder w.length r x := by

  rcases arcWordCongruence_realizes w r hr with
    ⟨y, hy⟩

  rcases arcEndpoint_refine_even hy with
    ⟨s, z, hsParent, hsz, hzEven⟩

  rcases arcEven_branch_exists hzEven with
    ⟨q, hzq⟩

  have hbit :
      arcFollowsTo [false] z q := by
    refine ⟨q, hzq, ?_⟩
    simp [arcFollowsTo]

  have hfull :
      arcFollowsTo (w ++ [false]) s q :=
    arcFollowsTo_append hsz hbit

  refine
    ⟨s,
     hsParent,
     arcFollowsTo_congruence hfull,
     ?_⟩

  intro x hx
  exact
    arcChildCylinder_subset_parent
      hsParent
      hx

/--
Force the next branch to be the odd/1 branch by refining to one dyadic child
cylinder.
-/
theorem arcWordCongruence_refine_true
    (w : List Bool)
    (r : ℤ)
    (hr : arcWordCongruence w r) :
    ∃ s : ℤ,
      arcDyadicCylinder w.length r s
      ∧
      arcWordCongruence (w ++ [true]) s
      ∧
      ∀ x : ℤ,
        arcDyadicCylinder (w ++ [true]).length s x
          →
        arcDyadicCylinder w.length r x := by

  rcases arcWordCongruence_realizes w r hr with
    ⟨y, hy⟩

  rcases arcEndpoint_refine_odd hy with
    ⟨s, z, hsParent, hsz, hzOdd⟩

  rcases arcOdd_branch_exists hzOdd with
    ⟨q, hzq⟩

  have hbit :
      arcFollowsTo [true] z q := by
    refine ⟨q, hzq, ?_⟩
    simp [arcFollowsTo]

  have hfull :
      arcFollowsTo (w ++ [true]) s q :=
    arcFollowsTo_append hsz hbit

  refine
    ⟨s,
     hsParent,
     arcFollowsTo_congruence hfull,
     ?_⟩

  intro x hx
  exact
    arcChildCylinder_subset_parent
      hsParent
      hx

#print axioms arcFollowsTo_append
#print axioms arcFollowsTo_shift_period
#print axioms arcEndpoint_refine_even
#print axioms arcEndpoint_refine_odd
#print axioms arcChildCylinder_subset_parent
#print axioms arcWordCongruence_refine_false
#print axioms arcWordCongruence_refine_true

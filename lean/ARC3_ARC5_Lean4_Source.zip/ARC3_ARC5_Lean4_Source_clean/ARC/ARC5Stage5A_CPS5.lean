import Mathlib
import ARC.ARC5LocalDensityStage4T

set_option autoImplicit false

universe u

/-!
# ARC5 — Stage 5A
## CPS5: formal statement and handoff from Local Density

Stage 4 ended with a precise finite-kernel interface. We now give the
synchronization phenomenon its own name: `CPS5`.

Two equivalent formulations are used:

* aligned block form;
* exact-level 5-kernel common-output form.

Stage 5A proves the equivalence, derives CPS5 from shortcut-Collatz invariance,
and packages the finite-kernel + CPS5 handoff for the next stage.
-/

/--
Aligned block formulation of CPS5.
-/
def ARC5CPSBlock
    {α : Type u}
    (a : ℕ → α) : Prop :=
  ∀ q : ℕ,
    ∃ k : ℕ,
      0 < k
        ∧
      ∀ r : ℕ,
        r < 5 ^ q
          →
        a (5 ^ q * k + r)
          =
        a (5 ^ q * k)

/--
Exact-level 5-kernel formulation of CPS5.
-/
def ARC5CPS
    {α : Type u}
    (a : ℕ → α) : Prop :=
  ∀ q : ℕ,
    ∃ k : ℕ,
      0 < k
        ∧
      ∃ c : α,
        ∀ v : ℕ → α,
          v ∈ ARC5LevelKernel q a
            →
          v k = c

/--
Aligned block form implies kernel common-output form.
-/
theorem arc5_cps_of_block
    {α : Type u}
    (a : ℕ → α)
    (hblock : ARC5CPSBlock a) :
    ARC5CPS a := by
  intro q
  rcases hblock q with ⟨k, hkpos, hq⟩
  refine ⟨k, hkpos, a (5 ^ q * k), ?_⟩
  intro v hv
  change
    ∃ r : ℕ,
      r < 5 ^ q
        ∧
      ∀ n : ℕ,
        v n = a (5 ^ q * n + r)
    at hv
  rcases hv with ⟨r, hr, hvEq⟩
  calc
    v k = a (5 ^ q * k + r) := hvEq k
    _ = a (5 ^ q * k) := hq r hr

/--
Kernel common-output form implies aligned block form.
-/
theorem arc5_block_of_cps
    {α : Type u}
    (a : ℕ → α)
    (hcps : ARC5CPS a) :
    ARC5CPSBlock a := by
  intro q
  rcases hcps q with ⟨k, hkpos, c, hcommon⟩
  refine ⟨k, hkpos, ?_⟩
  intro r hr

  let v0 : ℕ → α := fun n => a (5 ^ q * n)
  let vr : ℕ → α := fun n => a (5 ^ q * n + r)

  have hv0 :
      v0 ∈ ARC5LevelKernel q a := by
    change
      ∃ s : ℕ,
        s < 5 ^ q
          ∧
        ∀ n : ℕ,
          v0 n = a (5 ^ q * n + s)
    refine ⟨0, ?_, ?_⟩
    · positivity
    · intro n
      simp [v0]

  have hvr :
      vr ∈ ARC5LevelKernel q a := by
    change
      ∃ s : ℕ,
        s < 5 ^ q
          ∧
        ∀ n : ℕ,
          vr n = a (5 ^ q * n + s)
    refine ⟨r, hr, ?_⟩
    intro n
    rfl

  have h0 : v0 k = c := hcommon v0 hv0
  have hr' : vr k = c := hcommon vr hvr

  calc
    a (5 ^ q * k + r) = vr k := by rfl
    _ = c := hr'
    _ = v0 k := h0.symm
    _ = a (5 ^ q * k) := by rfl

/--
The block and kernel formulations of CPS5 are equivalent.
-/
theorem arc5_cps_block_iff_kernel
    {α : Type u}
    (a : ℕ → α) :
    ARC5CPSBlock a ↔ ARC5CPS a := by
  constructor
  · exact arc5_cps_of_block a
  · exact arc5_block_of_cps a

/--
Shortcut-Collatz invariance implies the aligned-block form of CPS5.
-/
theorem arc5_cpsBlock_of_shortcut_invariant
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n) :
    ARC5CPSBlock a := by
  intro q
  rcases
    arcFiniteNaturalAlignedInvariantBlock_pow5
      a
      hinv
      q with
    ⟨k, hkpos, hblock⟩
  refine ⟨k, hkpos, ?_⟩
  intro r hr
  exact (hblock r hr).symm

/--
Shortcut-Collatz invariance implies CPS5.
-/
theorem arc5_cps_of_shortcut_invariant
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n) :
    ARC5CPS a := by
  exact
    arc5_cps_of_block
      a
      (arc5_cpsBlock_of_shortcut_invariant a hinv)

/--
Stage-5A handoff:
finite 5-kernel together with CPS5.
-/
theorem arc5_stage5A_finite_kernel_and_cps5
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha5 :
      ARCAutomaticByKernel 5 a) :
    (ARCKernel 5 a).Finite
      ∧
    ARC5CPS a := by
  constructor
  · simpa [ARCAutomaticByKernel] using ha5
  · exact
      arc5_cps_of_shortcut_invariant
        a
        hinv

#print axioms arc5_cps_of_block
#print axioms arc5_block_of_cps
#print axioms arc5_cps_block_iff_kernel
#print axioms arc5_cpsBlock_of_shortcut_invariant
#print axioms arc5_cps_of_shortcut_invariant
#print axioms arc5_stage5A_finite_kernel_and_cps5

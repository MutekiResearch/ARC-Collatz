import Mathlib
import ARC.ARC5Stage5T_ChangeAutomaticity_v2

set_option autoImplicit false

universe u

/-!
# ARC5 — Stage 5U
## Strong Dyadic CPS makes the change set nowhere thick

Recall

    ARC5ChangeSet a = { n | a n ≠ a (n+1) }.

Stage 5T proved that its Boolean characteristic sequence is base-5 automatic.
Stage 5U supplies the missing topological input.

Strong Dyadic CPS says that inside every prescribed dyadic parent cylinder
there is a child cylinder on which, for `q = 1`,

    a n = a (n+j)    for every j < 5.

In particular, taking `j = 1` gives

    a n = a (n+1)

at every natural input in that child.  Hence that child is completely
disjoint from the change set.

The integer-cylinder output of Strong Dyadic CPS is converted to the natural
`Nat.ModEq` form used by `ARC5DyadicallyNowhereThick` via the already proved
Stage-5F preimage lemma with exponent `q = 0`.

Combining this with Stage 5T and the Stage-5S topological pumping theorem
shows that the change set is finite.
-/

/-!
============================================================
1. Strong Dyadic CPS => change set nowhere thick
============================================================
-/

/--
Strong Dyadic CPS forces the adjacent-change set to be dyadically nowhere
thick.
-/
theorem arc5_changeSet_nowhereThick_of_strongCPS
    {α : Type u}
    (a : ℕ → α)
    (hstrong :
      ARC5StrongDyadicCPS a) :
    ARC5DyadicallyNowhereThick
      (ARC5ChangeSet a) := by

  intro m r

  rcases
    hstrong
      1
      m
      (r : ℤ) with
    ⟨M,
     s,
     hParent,
     _hPositive,
     hBlock⟩

  rcases
    arc5_pow5_preimage_dyadicCylinder
      0
      M
      s with
    ⟨t,
     hPreimage⟩

  refine
    ⟨M,
     t,
     ?_,
     ?_,
     ?_⟩

  /- The natural child residue lies inside the prescribed natural parent. -/
  · intro n hn

    have hChild :
        arcDyadicCylinder
          M
          s
          (n : ℤ) := by

      have h :=
        hPreimage
          n
          hn

      simpa using h

    have hParentCyl :
        arcDyadicCylinder
          m
          (r : ℤ)
          (n : ℤ) :=
      hParent
        (n : ℤ)
        hChild

    have hIntModeq :
        (n : ℤ)
          ≡
        (r : ℤ)
          [ZMOD ((2 : ℤ) ^ m)] :=
      (arc5_dyadicCylinder_iff_modEq
        m
        (r : ℤ)
        (n : ℤ)).1
        hParentCyl

    apply
      Nat.ModEq.of_natCast
        (M := ℤ)

    simpa
      [AddCommGroup.modEq_iff_intModEq,
       Nat.cast_pow]
      using hIntModeq

  /- Every natural residue class modulo `2^M` contains a positive natural. -/
  · refine
      ⟨t + 2 ^ M,
       ?_,
       ?_⟩

    · positivity

    · exact
        Nat.add_modEq_right

  /- The whole child cylinder is free of adjacent changes. -/
  · intro n hn

    have hChild :
        arcDyadicCylinder
          M
          s
          (n : ℤ) := by

      have h :=
        hPreimage
          n
          hn

      simpa using h

    have hEq :
        a n = a (n + 1) := by

      have h :=
        hBlock
          n
          hChild
          1
          (by norm_num)

      simpa using h

    change
      ¬ (a n ≠ a (n + 1))

    exact
      fun hne =>
        hne hEq


/-!
============================================================
2. Shortcut invariance => change set nowhere thick
============================================================
-/

/--
The original shortcut-invariance hypothesis already supplies Strong Dyadic
CPS, hence makes the change set nowhere thick.
-/
theorem arc5_changeSet_nowhereThick
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n) :
    ARC5DyadicallyNowhereThick
      (ARC5ChangeSet a) := by

  exact
    arc5_changeSet_nowhereThick_of_strongCPS
      a
      (arc5_strongDyadicCPS_of_shortcut_invariant
        a
        hinv)


/-!
============================================================
3. The change set is finite
============================================================
-/

/--
Under the original ARC5 hypotheses, the adjacent-change set is finite.
-/
theorem arc5_changeSet_finite
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha5 :
      ARCAutomaticByKernel 5 a) :
    (ARC5ChangeSet a).Finite := by

  exact
    arc5_changeSet_finite_of_nowhereThick
      a
      ha5
      (arc5_changeSet_nowhereThick
        a
        hinv)


/-!
============================================================
4. Stage-5U handoff
============================================================
-/

/--
Stage-5U handoff.

Under the original ARC5 assumptions we now know simultaneously that

1. the adjacent-change indicator is base-5 automatic;
2. the adjacent-change set is dyadically nowhere thick;
3. the adjacent-change set is finite.

The next stage can convert finiteness of the change set into eventual
constancy of `a`.
-/
theorem arc5_stage5U_change_set_finite_handoff
    {α : Type u}
    (a : ℕ → α)
    (hinv :
      ∀ n : ℕ,
        a (arcShortcutNat n) = a n)
    (ha5 :
      ARCAutomaticByKernel 5 a) :
    ARCAutomaticByKernel
        5
        (ARC5ChangeIndicator a)
      ∧
    ARC5DyadicallyNowhereThick
        (ARC5ChangeSet a)
      ∧
    (ARC5ChangeSet a).Finite := by

  constructor

  · exact
      arc5_changeIndicator_automatic
        a
        ha5

  constructor

  · exact
      arc5_changeSet_nowhereThick
        a
        hinv

  · exact
      arc5_changeSet_finite
        a
        hinv
        ha5


/-!
============================================================
5. Axiom audit
============================================================
-/

#print axioms arc5_changeSet_nowhereThick_of_strongCPS
#print axioms arc5_changeSet_nowhereThick
#print axioms arc5_changeSet_finite
#print axioms arc5_stage5U_change_set_finite_handoff

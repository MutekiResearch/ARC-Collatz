import Mathlib
import ARC.ARC5LocalDensityStage1

set_option autoImplicit false

/-!
# ARC5 / Local-Density audit — Stage 2A

Stage 1 produced, for every positive integer `N`, two equal-length parity words
`u,v` with the same number of odd steps and normalized translation difference
exactly `N`.

This file verifies the affine meaning of that combinatorial statement.

For a parity word `w`, `arcAffine w x` means: apply the shortcut-Collatz branch
maps indicated by the bits of `w`, but over `ℚ` and without yet imposing parity
admissibility.

The main theorem says that the Stage-1 witness words satisfy

    arcAffine u x = arcAffine v (x + N)

for every rational `x`.

The remaining later stage is the genuinely arithmetic/admissibility bridge:
show that an appropriate dyadic residue class realizes the two prescribed
parity words simultaneously.
-/

/--
Affine branch composition attached to a parity word, in time order.

`false` is the even branch `x ↦ x/2`.
`true`  is the odd  branch `x ↦ (3x+1)/2`.
-/
def arcAffine : List Bool → ℚ → ℚ
  | [], x => x
  | false :: w, x => arcAffine w (x / 2)
  | true  :: w, x => arcAffine w ((3 * x + 1) / 2)

/--
Closed form for the affine map of a parity word:

    F_w(x) = 3^k (x + R(w)) / 2^L,

where `k = arcOnes w`, `L = w.length`, and
`R(w) = arcNormShift w`.
-/
theorem arcAffine_closedForm
    (w : List Bool)
    (x : ℚ) :
    arcAffine w x
      =
    ((3 : ℚ) ^ arcOnes w * (x + arcNormShift w))
      /
    ((2 : ℚ) ^ w.length) := by
  induction w generalizing x with
  | nil =>
      simp [arcAffine, arcOnes, arcNormShift]

  | cons b w ih =>
      cases b <;>
        simp [arcAffine, arcOnes, arcNormShift, ih, pow_succ] <;>
        ring

/--
Equal length + equal odd-step count + normalized shift difference `N`
implies exact affine coalescence after those branch words.
-/
theorem arcAffine_coalescence_of_wordData
    {N : ℕ}
    {u v : List Bool}
    (hlen : u.length = v.length)
    (hones : arcOnes u = arcOnes v)
    (hdiff : arcNormDiff u v = (N : ℚ))
    (x : ℚ) :
    arcAffine u x = arcAffine v (x + N) := by

  rw [arcAffine_closedForm, arcAffine_closedForm]
  rw [hones, hlen]

  have hshift :
      arcNormShift u
        =
      (N : ℚ) + arcNormShift v := by
    unfold arcNormDiff at hdiff
    linarith

  rw [hshift]
  ring

/--
Universal affine coalescence.

For every positive integer translation `N`, Stage 1 supplies equal-length
parity words with equal odd-step count whose affine branch maps satisfy

    F_u(x) = F_v(x+N)

identically in `x`.
-/
theorem arcUniversalAffineCoalescence
    (N : ℕ)
    (hN : 0 < N) :
    ∃ u v : List Bool,
      u.length = v.length ∧
      arcOnes u = arcOnes v ∧
      (∀ x : ℚ,
        arcAffine u x =
        arcAffine v (x + N)) := by

  rcases arcUniversalTranslationWords N hN with
    ⟨u, v, hlen, hones, hdiff⟩

  refine ⟨u, v, hlen, hones, ?_⟩

  intro x

  exact
    arcAffine_coalescence_of_wordData
      hlen
      hones
      hdiff
      x

#print axioms arcAffine_closedForm
#print axioms arcUniversalAffineCoalescence

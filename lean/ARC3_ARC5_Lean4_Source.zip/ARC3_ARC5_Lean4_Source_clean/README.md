# ARC3 + ARC5 Lean 4 source release

This package contains the Lean 4 source dependency closure used by the ARC3 and ARC5 public entry points.

## Public entry points

- `ARC/ARC3Consequences.lean`
- `ARC/ARC5Final.lean`

## Environment

- Lean toolchain: `leanprover/lean4:v4.34.0-rc2`
- mathlib revision: `v4.34.0-rc2`

The exact dependency lockfile is included as `lake-manifest.json`.

## Verification commands

From the project root:

```powershell
lake env lean ARC/ARC3Consequences.lean
lake env lean ARC/ARC5Final.lean
```

## Release audit notes

Before packaging, the source tree was statically checked for the tokens `sorry`, `admit`, `sorryAx`, top-level `axiom`, `opaque`, and `unsafe` outside comments. No such declarations/tokens were found in this release set.

ARC3 uses an explicit `ARCCobhamPrinciple` hypothesis in its theorem chain; Cobham's theorem is not reproved in the project.

The ARC5 final dependency closure contains no reference to `ARCCobhamPrinciple` or Cobham. The ARC5 route is therefore separate from the explicit Cobham assumption used by ARC3.

Historical intermediate versions that are not imported by either final entry point are intentionally omitted from this clean release package.

## Important limitation

This static packaging audit does not replace re-running Lean. The authoritative release check is to run the two verification commands above in the stated toolchain and confirm that they complete successfully.
